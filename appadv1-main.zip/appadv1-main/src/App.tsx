/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import StudyPlan from './components/StudyPlan';
import Phase1 from './components/Phase1';
import Phase2 from './components/Phase2';
import QuestionsBank from './components/QuestionsBank';
import SimulatedExams from './components/SimulatedExams';
import SmartRevision from './components/SmartRevision';
import LawPieces from './components/LawPieces';
import StudyMaterials from './components/StudyMaterials';
import OABCalendar from './components/OABCalendar';
import Performance from './components/Performance';
import Support from './components/Support';
import Onboarding from './components/Onboarding';
import Monetization from './components/Monetization';
import OABArchitecture from './components/OABArchitecture';
import OABIdentityAndCommunication from './components/OABIdentityAndCommunication';
import OABGrowthAndComercial from './components/OABGrowthAndComercial';
import OABRoadmapOfExecution from './components/OABRoadmapOfExecution';
import OABMasterDocumentation from './components/OABMasterDocumentation';
import StudySession from './components/StudySession';

import {
  StudentProgress,
  WeeklyTask,
  OABCalendarEvent,
  SimulatedResult
} from './types';

import {
  INITIAL_PROGRESS,
  WEEKLY_TASKS_TEMPLATE,
  DISCIPLINES,
  JURIDICAL_PIECES,
  QUESTIONS_BANK,
  FLASHCARDS,
  CALENDAR_EVENTS,
  SUPPORT_FAQS
} from './data/mockData';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('inicio');
  const [currentStudyTaskId, setCurrentStudyTaskId] = useState<string | null>(() => {
    return localStorage.getItem('oab3f_current_study_task_id') || null;
  });

  useEffect(() => {
    if (currentStudyTaskId) {
      localStorage.setItem('oab3f_current_study_task_id', currentStudyTaskId);
    } else {
      localStorage.removeItem('oab3f_current_study_task_id');
    }
  }, [currentStudyTaskId]);

  const [onboardingCompleted, setOnboardingCompleted] = useState<boolean>(() => {
    return localStorage.getItem('oab3f_onboarding_completed') === 'true';
  });
  const [userPlan, setUserPlan] = useState<string>(() => {
    return localStorage.getItem('oab3f_user_plan') || 'gratuito';
  });

  const handleUpdatePlan = (newPlan: string) => {
    setUserPlan(newPlan);
    localStorage.setItem('oab3f_user_plan', newPlan);
  };

  // Load from local storage or default to initial templates
  const [progress, setProgress] = useState<StudentProgress>(() => {
    const saved = localStorage.getItem('oab3f_progress');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error loading progress", e);
      }
    }
    return INITIAL_PROGRESS;
  });

  const [weeklyTasks, setWeeklyTasks] = useState<WeeklyTask[]>(() => {
    const saved = localStorage.getItem('oab3f_tasks');
    let loadedTasks: any[] = [];
    if (saved) {
      try {
        loadedTasks = JSON.parse(saved);
      } catch (e) {
        console.error("Error loading tasks", e);
        loadedTasks = WEEKLY_TASKS_TEMPLATE;
      }
    } else {
      loadedTasks = WEEKLY_TASKS_TEMPLATE;
    }

    // Sanitize loaded tasks to match corrected schema (Ajustes 1, 2, 3)
    return loadedTasks.map((t: any) => {
      const status = t.status || (t.completed ? 'completed' : 'pending');
      const estimatedMinutes = t.estimatedMinutes !== undefined ? t.estimatedMinutes : (t.durationMinutes || 60);
      return {
        ...t,
        status,
        estimatedMinutes,
        durationMinutes: estimatedMinutes // legacy safety
      };
    });
  });

  const [calendarEvents, setCalendarEvents] = useState<OABCalendarEvent[]>(() => {
    const saved = localStorage.getItem('oab3f_calendar');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error loading calendar", e);
      }
    }
    return CALENDAR_EVENTS;
  });

  // Sync state with LocalStorage
  useEffect(() => {
    localStorage.setItem('oab3f_progress', JSON.stringify(progress));
  }, [progress]);

  useEffect(() => {
    localStorage.setItem('oab3f_tasks', JSON.stringify(weeklyTasks));
  }, [weeklyTasks]);

  useEffect(() => {
    localStorage.setItem('oab3f_calendar', JSON.stringify(calendarEvents));
  }, [calendarEvents]);

  // Handler functions
  const handleToggleTask = (taskId: string) => {
    setWeeklyTasks(prev => prev.map(task => {
      if (task.id === taskId) {
        const isCompleted = task.status === 'completed';
        const nextStatus = isCompleted ? 'pending' : 'completed';
        const nextCompleted = nextStatus === 'completed';
        // Sync progress completedTaskIds
        setProgress(p => {
          const completedTaskIds = nextCompleted
            ? [...p.completedTaskIds, taskId]
            : p.completedTaskIds.filter(id => id !== taskId);
          return { ...p, completedTaskIds };
        });
        return { 
          ...task, 
          status: nextStatus,
          completedAt: nextCompleted ? new Date().toISOString() : undefined
        };
      }
      return task;
    }));
  };

  const handleUpdateTaskStatus = (taskId: string, newStatus: 'pending' | 'in_progress' | 'completed') => {
    setWeeklyTasks(prev => prev.map(task => {
      if (task.id === taskId) {
        const wasCompleted = task.status === 'completed';
        const isCompleted = newStatus === 'completed';
        if (wasCompleted !== isCompleted) {
          setProgress(p => {
            const completedTaskIds = isCompleted
              ? [...p.completedTaskIds, taskId]
              : p.completedTaskIds.filter(id => id !== taskId);
            return { ...p, completedTaskIds };
          });
        }
        return {
          ...task,
          status: newStatus,
          completedAt: isCompleted ? new Date().toISOString() : undefined,
          startedAt: newStatus === 'in_progress' && !task.startedAt ? new Date().toISOString() : task.startedAt
        };
      }
      return task;
    }));
  };

  const handleStartStudyTask = (taskId: string) => {
    setCurrentStudyTaskId(taskId);
    setActiveTab('sessao-estudo');
  };

  const handleAddTask = (taskData: Omit<WeeklyTask, 'id' | 'status'>) => {
    const est = taskData.estimatedMinutes !== undefined ? taskData.estimatedMinutes : (taskData.durationMinutes || 60);
    const newTask: WeeklyTask = {
      ...taskData,
      id: "task-" + Date.now(),
      status: 'pending',
      estimatedMinutes: est,
      durationMinutes: est
    } as WeeklyTask;
    setWeeklyTasks(prev => [newTask, ...prev]);
  };

  const handleDeleteTask = (taskId: string) => {
    setWeeklyTasks(prev => prev.filter(t => t.id !== taskId));
    setProgress(p => ({
      ...p,
      completedTaskIds: p.completedTaskIds.filter(id => id !== taskId)
    }));
  };

  const handleUpdateHoursGoal = (hours: number) => {
    setProgress(prev => ({ ...prev, studyHoursGoal: hours }));
  };

  const handleAddStudyHours = (hours: number) => {
    setProgress(prev => ({
      ...prev,
      weeklyStudyHours: parseFloat((prev.weeklyStudyHours + hours).toFixed(1))
    }));
  };

  const handleToggleLecture = (lectureId: string) => {
    setProgress(prev => {
      const isCompleted = prev.completedLectures.includes(lectureId);
      const completedLectures = isCompleted
        ? prev.completedLectures.filter(id => id !== lectureId)
        : [...prev.completedLectures, lectureId];
      return { ...prev, completedLectures };
    });
  };

  const handleTogglePDF = (pdfId: string) => {
    setProgress(prev => {
      const isCompleted = prev.completedPDFs.includes(pdfId);
      const completedPDFs = isCompleted
        ? prev.completedPDFs.filter(id => id !== pdfId)
        : [...prev.completedPDFs, pdfId];
      return { ...prev, completedPDFs };
    });
  };

  const handleSelectArea = (area: string) => {
    setProgress(prev => ({ ...prev, selectedSecondPhaseArea: area }));
  };

  const handleSavePieceNote = (pieceId: string, note: string) => {
    setProgress(prev => ({
      ...prev,
      notes: { ...prev.notes, [pieceId]: note }
    }));
  };

  const handleAddSimulatedResult = (result: SimulatedResult) => {
    setProgress(prev => ({
      ...prev,
      simulatedExamsHistory: [result, ...prev.simulatedExamsHistory]
    }));
  };

  const handleAnswerQuestion = (qId: string, optionIdx: number, isCorrect: boolean) => {
    setProgress(prev => {
      const existing = prev.answeredQuestions[qId];
      const attemptsCount = (existing?.attemptsCount || 0) + 1;
      const correctCount = (existing?.correctCount || 0) + (isCorrect ? 1 : 0);
      const incorrectCount = (existing?.incorrectCount || 0) + (isCorrect ? 0 : 1);
      
      const newAttempt = {
        selectedOption: optionIdx,
        isCorrect,
        timestamp: new Date().toISOString()
      };
      
      const history = existing?.history ? [...existing.history, newAttempt] : [newAttempt];

      return {
        ...prev,
        answeredQuestions: {
          ...prev.answeredQuestions,
          [qId]: {
            ...newAttempt,
            attemptsCount,
            correctCount,
            incorrectCount,
            history
          }
        }
      };
    });
  };

  const handleToggleFavoriteQuestion = (qId: string) => {
    setProgress(prev => {
      const isFav = prev.favoriteQuestions.includes(qId);
      const favoriteQuestions = isFav
        ? prev.favoriteQuestions.filter(id => id !== qId)
        : [...prev.favoriteQuestions, qId];
      return { ...prev, favoriteQuestions };
    });
  };

  const handleToggleFavoritePiece = (pieceId: string) => {
    setProgress(prev => {
      const isFav = prev.favoritePieces.includes(pieceId);
      const favoritePieces = isFav
        ? prev.favoritePieces.filter(id => id !== pieceId)
        : [...prev.favoritePieces, pieceId];
      return { ...prev, favoritePieces };
    });
  };

  const handleUpdateFlashcardBox = (cardId: string, increment: number) => {
    setProgress(prev => {
      const currentBox = prev.flashcardBoxes[cardId] || 1;
      let nextBox = currentBox + increment;
      if (nextBox < 1) nextBox = 1;
      if (nextBox > 5) nextBox = 5;

      const flashcardBoxes = { ...prev.flashcardBoxes, [cardId]: nextBox };
      
      // If card reached box 5, flag it as fully known/completed
      let completedFlashcards = prev.completedFlashcards;
      if (nextBox === 5 && !completedFlashcards.includes(cardId)) {
        completedFlashcards = [...completedFlashcards, cardId];
      } else if (nextBox < 5 && completedFlashcards.includes(cardId)) {
        completedFlashcards = completedFlashcards.filter(id => id !== cardId);
      }

      return { ...prev, flashcardBoxes, completedFlashcards };
    });
  };

  const handleAddEvent = (newEvent: OABCalendarEvent) => {
    setCalendarEvents(prev => [...prev, newEvent]);
  };

  const handleDeleteEvent = (eventId: string) => {
    setCalendarEvents(prev => prev.filter(ev => ev.id !== eventId));
  };

  const handleSaveActivity = (tab: string, title: string, sectionId?: string, itemId?: string) => {
    setProgress(prev => ({
      ...prev,
      lastSavedActivity: {
        tab,
        title,
        sectionId,
        itemId,
        timestamp: new Date().toISOString()
      }
    }));
  };

  // Handles quick nav requests from components
  const handleNavigateToTab = (tabId: string, sectionId?: string, itemId?: string) => {
    // Standardize internal mapping from Sidebar labels
    let mappedTab = tabId;
    if (tabId === '1ª Fase') mappedTab = 'fase1';
    if (tabId === '2ª Fase') mappedTab = 'fase2';
    if (tabId === 'Meu Plano') mappedTab = 'plano';
    if (tabId === 'Questões') mappedTab = 'questoes';
    if (tabId === 'Simulados') mappedTab = 'simulados';
    if (tabId === 'Revisão') mappedTab = 'revisao';
    if (tabId === 'Calendário OAB') mappedTab = 'calendario';

    setActiveTab(mappedTab);
    
    if (sectionId || itemId) {
      // Stores activity context so respective mount can focus
      handleSaveActivity(mappedTab, `Navegou para seção`, sectionId, itemId);
    }
  };

  const handleOnboardingComplete = (data: any) => {
    localStorage.setItem('oab3f_onboarding_completed', 'true');
    localStorage.setItem('oab3f_student_name', data.studentName);
    localStorage.setItem('oab3f_onboarding_fase', data.selectedFase);
    localStorage.setItem('oab3f_onboarding_situacao', data.situacaoAtual);
    localStorage.setItem('oab3f_onboarding_horas', data.horasPorDia);
    localStorage.setItem('oab3f_onboarding_dias', JSON.stringify(data.diasEstudo));
    localStorage.setItem('oab3f_onboarding_turno', data.estudoTurno);
    localStorage.setItem('oab3f_onboarding_blocos', data.estudoBloco);
    localStorage.setItem('oab3f_onboarding_area2a', data.areaSegundaFase);
    localStorage.setItem('oab3f_onboarding_proximidade', data.proximidadeProva);
    localStorage.setItem('oab3f_onboarding_meta', data.metaPrincipal);
    localStorage.setItem('oab3f_onboarding_dificuldades', JSON.stringify(data.disciplinasDificuldade));
    localStorage.setItem('oab3f_onboarding_errar', data.errarFoco);
    localStorage.setItem('oab3f_onboarding_constancia', data.constanciaDificuldade ? 'true' : 'false');
    localStorage.setItem('oab3f_onboarding_notifs', JSON.stringify(data.notificacoesConfig));
    localStorage.setItem('oab3f_onboarding_notif_intensa', data.notificacaoIntensidade);
    localStorage.setItem('oab3f_onboarding_notif_horario', data.notificacaoHorario);
    localStorage.setItem('oab3f_onboarding_perfil', data.perfilCalculado);

    setProgress(prev => {
      const nextProgress = { ...prev };
      nextProgress.selectedSecondPhaseArea = data.areaSegundaFase;
      
      if (data.horasPorDia === 'ate_1h') {
        nextProgress.studyHoursGoal = 5;
        nextProgress.weeklyStudyHours = 1.5;
      } else if (data.horasPorDia === '1h_2h') {
        nextProgress.studyHoursGoal = 10;
        nextProgress.weeklyStudyHours = 4.0;
      } else if (data.horasPorDia === '2h_4h') {
        nextProgress.studyHoursGoal = 20;
        nextProgress.weeklyStudyHours = 12.0;
      } else {
        nextProgress.studyHoursGoal = 35;
        nextProgress.weeklyStudyHours = 22.0;
      }
      return nextProgress;
    });

    setWeeklyTasks(prev => {
      const customTasks: WeeklyTask[] = [];
      
      if (data.selectedFase === '2a_fase' || data.situacaoAtual === 'foco_2a_fase') {
        customTasks.push(
          {
            id: "task-ob-1",
            title: `Redação de Peça Prática (${data.areaSegundaFase})`,
            day: "Sábado",
            discipline: data.areaSegundaFase,
            description: "Peça prática profissional de rascunho completo.",
            priority: 'Alta',
            durationMinutes: 180,
            estimatedMinutes: 180,
            status: 'pending'
          },
          {
            id: "task-ob-2",
            title: "Resolução de 4 Questões Discursivas da OAB",
            day: "Quarta",
            discipline: data.areaSegundaFase,
            description: "Treino de fundamentação jurídica e súmulas.",
            priority: 'Média',
            durationMinutes: 90,
            estimatedMinutes: 90,
            status: 'pending'
          },
          {
            id: "task-ob-3",
            title: "Mapeamento de Súmulas e Artigos Principais no Vade Mecum",
            day: "Segunda",
            discipline: data.areaSegundaFase,
            description: "Marcação autorizada de legislação básica.",
            priority: 'Alta',
            durationMinutes: 60,
            estimatedMinutes: 60,
            status: 'pending'
          },
          {
            id: "task-ob-4",
            title: "Leitura de Modelos Estruturados de Peças",
            day: "Sexta",
            discipline: data.areaSegundaFase,
            description: "Memorizar estruturas de teses preliminares e pedidos.",
            priority: 'Alta',
            durationMinutes: 45,
            estimatedMinutes: 45,
            status: 'pending'
          }
        );
      } else {
        customTasks.push(
          {
            id: "task-ob-1",
            title: "Estudo de Ética Profissional - Estatuto da OAB",
            day: "Segunda",
            discipline: "Ética Profissional",
            description: "Estudo do Estatuto e Regulamento Geral.",
            priority: 'Alta',
            durationMinutes: 60,
            estimatedMinutes: 60,
            status: 'pending'
          },
          {
            id: "task-ob-2",
            title: "Simulado Rápido de 20 Questões no Banco",
            day: "Quarta",
            discipline: "Direito Constitucional",
            description: "Revisão prática por questões comentadas.",
            priority: 'Média',
            durationMinutes: 45,
            estimatedMinutes: 45,
            status: 'pending'
          },
          {
            id: "task-ob-3",
            title: "Revisão Sistemática das disciplinas com Dificuldade",
            day: "Sexta",
            discipline: data.disciplinasDificuldade[0] || "Direito Civil",
            description: `Superar dificuldades em ${data.disciplinasDificuldade.join(', ') || "Direito Civil"}`,
            priority: 'Alta',
            durationMinutes: 40,
            estimatedMinutes: 40,
            status: 'pending'
          }
        );

        if (data.diasEstudo.includes('Sábado') || data.diasEstudo.includes('Domingo')) {
          customTasks.push({
            id: "task-ob-4",
            title: "Simulado Geral OAB de 80 Questões",
            day: data.diasEstudo.includes('Sábado') ? "Sábado" : "Domingo",
            discipline: "Geral",
            description: "Simulado completo cronometrado para treinar resistência física.",
            priority: 'Alta',
            durationMinutes: 300,
            estimatedMinutes: 300,
            status: 'pending'
          });
        }
      }
      return customTasks;
    });

    setOnboardingCompleted(true);
    setActiveTab('inicio');
  };

  const handleOnboardingSkip = () => {
    localStorage.setItem('oab3f_onboarding_completed', 'true');
    setOnboardingCompleted(true);
    setActiveTab('inicio');
  };

  // Dynamic Content Router
  const renderContent = () => {
    switch (activeTab) {
      case 'sessao-estudo': {
        const selectedTask = weeklyTasks.find(t => t.id === currentStudyTaskId);
        if (!selectedTask) {
          return (
            <div className="p-8 text-center text-slate-500 bg-white border border-[#E5E1D8] rounded-xl space-y-3">
              <p className="text-sm">Nenhuma tarefa selecionada ou ativa para estudo no momento.</p>
              <button
                onClick={() => setActiveTab('plano')}
                className="px-4 py-2 bg-oab-primary text-white text-xs uppercase font-bold rounded-lg"
              >
                Ir para o Cronograma
              </button>
            </div>
          );
        }
        return (
          <StudySession
            task={selectedTask}
            onBack={() => {
              setActiveTab('plano');
            }}
            onUpdateTasks={setWeeklyTasks}
            onUpdateTaskStatus={handleUpdateTaskStatus}
            onAddStudyHours={handleAddStudyHours}
          />
        );
      }
      case 'inicio':
        return (
          <Dashboard
            progress={progress}
            weeklyTasks={weeklyTasks}
            disciplines={DISCIPLINES}
            onToggleTask={handleToggleTask}
            onUpdateTaskStatus={handleUpdateTaskStatus}
            onAddStudyHours={handleAddStudyHours}
            onNavigateToTab={handleNavigateToTab}
            userPlan={userPlan}
            onStartStudyTask={handleStartStudyTask}
          />
        );
      case 'plano':
        return (
          <StudyPlan
            weeklyTasks={weeklyTasks}
            studyHoursGoal={progress.studyHoursGoal}
            weeklyStudyHours={progress.weeklyStudyHours}
            onToggleTask={handleToggleTask}
            onUpdateTaskStatus={handleUpdateTaskStatus}
            onAddTask={handleAddTask}
            onUpdateHoursGoal={handleUpdateHoursGoal}
            onDeleteTask={handleDeleteTask}
            progress={progress}
            onNavigateToTab={setActiveTab}
            onAddStudyHours={handleAddStudyHours}
            onSelectArea={handleSelectArea}
            setProgress={setProgress}
            onUpdateTasks={setWeeklyTasks}
            onStartStudyTask={handleStartStudyTask}
          />
        );
      case 'fase1':
        return (
          <Phase1
            disciplines={DISCIPLINES}
            progress={progress}
            onToggleLecture={handleToggleLecture}
            onTogglePDF={handleTogglePDF}
            onSaveActivity={handleSaveActivity}
          />
        );
      case 'fase2':
        return (
          <Phase2
            progress={progress}
            pieces={JURIDICAL_PIECES}
            onSelectArea={handleSelectArea}
            onSavePieceNote={handleSavePieceNote}
            onAddSimulatedResult={handleAddSimulatedResult}
            onSaveActivity={handleSaveActivity}
            userPlan={userPlan}
            onNavigateToTab={setActiveTab}
          />
        );
      case 'questoes':
        return (
          <QuestionsBank
            questions={QUESTIONS_BANK}
            progress={progress}
            onAnswerQuestion={handleAnswerQuestion}
            onToggleFavoriteQuestion={handleToggleFavoriteQuestion}
            onSaveActivity={handleSaveActivity}
            userPlan={userPlan}
            onNavigateToTab={setActiveTab}
          />
        );
      case 'simulados':
        return (
          <SimulatedExams
            questions={QUESTIONS_BANK}
            progress={progress}
            onAddSimulatedResult={handleAddSimulatedResult}
            onSaveActivity={handleSaveActivity}
          />
        );
      case 'revisao':
        return (
          <SmartRevision
            flashcards={FLASHCARDS}
            questions={QUESTIONS_BANK}
            progress={progress}
            onUpdateFlashcardBox={handleUpdateFlashcardBox}
            onSavePieceNote={handleSavePieceNote}
            onSaveActivity={handleSaveActivity}
          />
        );
      case 'pecas':
        return (
          <LawPieces
            pieces={JURIDICAL_PIECES}
            progress={progress}
            onToggleFavoritePiece={handleToggleFavoritePiece}
            onSaveActivity={handleSaveActivity}
          />
        );
      case 'materiais':
        return (
          <StudyMaterials
            disciplines={DISCIPLINES}
            onSaveActivity={handleSaveActivity}
            progress={progress}
            setProgress={setProgress}
          />
        );
      case 'calendario':
        return (
          <OABCalendar
            events={calendarEvents}
            onAddEvent={handleAddEvent}
            onDeleteEvent={handleDeleteEvent}
            weeklyTasks={weeklyTasks}
            onToggleTask={handleToggleTask}
            onAddTask={handleAddTask}
            onDeleteTask={handleDeleteTask}
            progress={progress}
            setProgress={setProgress}
            onNavigateToTab={setActiveTab}
            weeklyStudyHours={progress.weeklyStudyHours}
            studyHoursGoal={progress.studyHoursGoal}
            onAddStudyHours={handleAddStudyHours}
            onUpdateTasks={setWeeklyTasks}
            onStartStudyTask={handleStartStudyTask}
          />
        );
      case 'desempenho':
        return (
          <Performance
            progress={progress}
            disciplines={DISCIPLINES}
          />
        );
      case 'suporte':
        return (
          <Support
            faqs={SUPPORT_FAQS}
            userPlan={userPlan}
            onNavigateToTab={setActiveTab}
            progress={progress}
            setProgress={setProgress}
          />
        );
      case 'monetizacao':
        return (
          <Monetization
            currentPlan={userPlan}
            onUpdatePlan={handleUpdatePlan}
            onNavigateToTab={setActiveTab}
          />
        );
      case 'identidade':
        return (
          <OABIdentityAndCommunication />
        );
      case 'growth':
        return (
          <OABGrowthAndComercial />
        );
      case 'arquitetura':
        return (
          <OABArchitecture />
        );
      case 'roadmap':
        return (
          <OABRoadmapOfExecution />
        );
      case 'documentacao':
        return (
          <OABMasterDocumentation />
        );
      default:
        return (
          <div className="p-8 text-center text-slate-500">
            Página em desenvolvimento.
          </div>
        );
    }
  };

  if (!onboardingCompleted) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 sm:p-6 lg:p-12 font-sans animate-fade-in" id="onboarding-flow-container">
        <div className="max-w-5xl w-full">
          <Onboarding 
            onComplete={handleOnboardingComplete}
            onSkip={handleOnboardingSkip}
            currentName={progress.selectedSecondPhaseArea ? "Lucas Santos" : ""}
            currentSecondPhaseArea={progress.selectedSecondPhaseArea}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-slate-50 font-sans" id="app-root-layout">
      {/* Sidebar Panel Left */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        streakDays={4} // Streak can be pre-fixed for academic gamification!
      />

      {/* Main Content Pane Right */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full overflow-x-hidden">
        {renderContent()}
      </main>
    </div>
  );
}
