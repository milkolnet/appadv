/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  TrendingUp, 
  MessageSquare, 
  Mail, 
  Clock, 
  Plus, 
  Send, 
  Check, 
  User, 
  Settings, 
  HelpCircle, 
  Bell, 
  ShieldAlert,
  BarChart2
} from 'lucide-react';
import { ForumQuestion, SupportTicket, Announcement } from './CommunityData';
import { SupportFAQ } from '../types';

interface CommunityAdminProps {
  questions: ForumQuestion[];
  setQuestions: React.Dispatch<React.SetStateAction<ForumQuestion[]>>;
  tickets: SupportTicket[];
  setTickets: React.Dispatch<React.SetStateAction<SupportTicket[]>>;
  faqs: SupportFAQ[];
  setFaqs: React.Dispatch<React.SetStateAction<SupportFAQ[]>>;
  announcements: Announcement[];
  setAnnouncements: React.Dispatch<React.SetStateAction<Announcement[]>>;
}

export default function CommunityAdmin({
  questions,
  setQuestions,
  tickets,
  setTickets,
  faqs,
  setFaqs,
  announcements,
  setAnnouncements
}: CommunityAdminProps) {
  const [activeAdminSubTab, setActiveAdminSubTab] = useState<'metrics' | 'questions' | 'tickets' | 'actions'>('metrics');

  // Answer state for admin responding to forum questions
  const [forumReplyId, setForumReplyId] = useState<string | null>(null);
  const [forumReplyText, setForumReplyText] = useState('');

  // Reply state for admin responding to support tickets
  const [ticketReplyId, setTicketReplyId] = useState<string | null>(null);
  const [ticketReplyText, setTicketReplyText] = useState('');
  const [ticketStatusUpdate, setTicketStatusUpdate] = useState<'respondido' | 'resolvido' | 'em_analise'>('respondido');

  // Form to add FAQ
  const [faqQuestion, setFaqQuestion] = useState('');
  const [faqAnswer, setFaqAnswer] = useState('');
  const [faqCategory, setFaqCategory] = useState('Uso do App');
  const [faqSuccess, setFaqSuccess] = useState(false);

  // Form to add Announcement
  const [annTitle, setAnnTitle] = useState('');
  const [annText, setAnnText] = useState('');
  const [annCategory, setAnnCategory] = useState<'Geral' | 'Eventos' | 'Materiais' | 'Mentoria'>('Geral');
  const [annUrgent, setAnnUrgent] = useState(false);
  const [annSuccess, setAnnSuccess] = useState(false);

  // Calculate quick metrics
  const totalQuestionsCount = questions.length;
  const pendingQuestionsCount = questions.filter(q => q.status === 'aberta').length;
  const activeTicketsCount = tickets.filter(t => t.status !== 'resolvido' && t.status !== 'encerrado').length;
  const resolvedTicketsCount = tickets.filter(t => t.status === 'resolvido' || t.status === 'encerrado').length;

  const handleAdminForumReply = (qId: string) => {
    if (!forumReplyText.trim()) return;

    setQuestions(prev => prev.map(q => {
      if (q.id === qId) {
        return {
          ...q,
          status: 'respondida',
          answers: [
            ...q.answers,
            {
              id: `fa-prof-${Date.now()}`,
              author: 'Prof. Lucas (Equipe OAB 3F)',
              role: 'professor',
              text: forumReplyText,
              timestamp: new Date().toLocaleString('pt-BR', { hour12: false }).slice(0, 16),
              likes: 0
            }
          ]
        };
      }
      return q;
    }));

    setForumReplyText('');
    setForumReplyId(null);
  };

  const handleAdminTicketReply = (tId: string) => {
    if (!ticketReplyText.trim()) return;

    setTickets(prev => prev.map(t => {
      if (t.id === tId) {
        return {
          ...t,
          status: ticketStatusUpdate,
          replies: [
            ...t.replies,
            {
              author: 'Suporte Pedagógico OAB 3F',
              role: 'suporte',
              text: ticketReplyText,
              timestamp: new Date().toLocaleString('pt-BR', { hour12: false }).slice(0, 16)
            }
          ]
        };
      }
      return t;
    }));

    setTicketReplyText('');
    setTicketReplyId(null);
  };

  const handleAddFaq = (e: React.FormEvent) => {
    e.preventDefault();
    if (!faqQuestion.trim() || !faqAnswer.trim()) return;

    const newFaq: SupportFAQ = {
      id: `faq-${Date.now()}`,
      question: faqQuestion,
      answer: faqAnswer,
      category: faqCategory
    };

    setFaqs(prev => [...prev, newFaq]);
    setFaqQuestion('');
    setFaqAnswer('');
    setFaqSuccess(true);
    setTimeout(() => setFaqSuccess(false), 3000);
  };

  const handleAddAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle.trim() || !annText.trim()) return;

    const newAnn: Announcement = {
      id: `ann-${Date.now()}`,
      title: annTitle,
      text: annText,
      category: annCategory,
      timestamp: new Date().toLocaleDateString('pt-BR'),
      isUrgent: annUrgent,
      isRead: false
    };

    setAnnouncements(prev => [newAnn, ...prev]);
    setAnnTitle('');
    setAnnText('');
    setAnnUrgent(false);
    setAnnSuccess(true);
    setTimeout(() => setAnnSuccess(false), 3000);
  };

  const handleModerateQuestion = (id: string) => {
    // Soft moderation: delete/remove a question from community board
    if (window.confirm('Deseja realmente moderar e ocultar esta pergunta devido à violação de diretrizes?')) {
      setQuestions(prev => prev.filter(q => q.id !== id));
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="community-admin-workspace">
      
      {/* Admin Title bar */}
      <div className="bg-slate-900 text-white rounded-xl p-5 border border-slate-850 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-sm font-black tracking-widest text-[#D4AF37] uppercase font-mono">
            🛡 PAINEL DE CONTROLE PEDAGÓGICO
          </h2>
          <p className="text-[10.5px] text-slate-300 font-medium">
            Gerencie o ecossistema de relacionamento, atenda alunos, modere comentários e acompanhe métricas de engajamento em tempo real.
          </p>
        </div>

        {/* Sub tabs inside Admin */}
        <div className="flex bg-slate-800 p-1 rounded-lg border border-slate-700 w-full md:w-auto">
          <button 
            onClick={() => setActiveAdminSubTab('metrics')}
            className={`text-[10.5px] font-bold px-3 py-1.5 rounded-md flex-1 md:flex-initial cursor-pointer ${
              activeAdminSubTab === 'metrics' ? 'bg-[#D4AF37] text-slate-900' : 'text-slate-300 hover:text-white'
            }`}
          >
            Métricas
          </button>
          <button 
            onClick={() => setActiveAdminSubTab('questions')}
            className={`text-[10.5px] font-bold px-3 py-1.5 rounded-md flex-1 md:flex-initial cursor-pointer ${
              activeAdminSubTab === 'questions' ? 'bg-[#D4AF37] text-slate-900' : 'text-slate-300 hover:text-white'
            }`}
          >
            Dúvidas ({pendingQuestionsCount})
          </button>
          <button 
            onClick={() => setActiveAdminSubTab('tickets')}
            className={`text-[10.5px] font-bold px-3 py-1.5 rounded-md flex-1 md:flex-initial cursor-pointer ${
              activeAdminSubTab === 'tickets' ? 'bg-[#D4AF37] text-slate-900' : 'text-slate-300 hover:text-white'
            }`}
          >
            Tickets ({activeTicketsCount})
          </button>
          <button 
            onClick={() => setActiveAdminSubTab('actions')}
            className={`text-[10.5px] font-bold px-3 py-1.5 rounded-md flex-1 md:flex-initial cursor-pointer ${
              activeAdminSubTab === 'actions' ? 'bg-[#D4AF37] text-slate-900' : 'text-slate-300 hover:text-white'
            }`}
          >
            Postar
          </button>
        </div>
      </div>

      {/* ADMIN SUB-VIEW: METRICS */}
      {activeAdminSubTab === 'metrics' && (
        <div className="space-y-6 animate-fade-in">
          {/* Stat Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-xs">
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Tickets Ativos</span>
                <span className="text-2xl font-black text-rose-600 block font-mono">{activeTicketsCount}</span>
                <span className="text-[9.5px] text-slate-400 block">Aguardando atendimento</span>
              </div>
              <div className="h-10 w-10 bg-rose-50 rounded-lg flex items-center justify-center text-rose-500">
                <Mail className="h-5 w-5" />
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-xs">
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Tempo de Resposta</span>
                <span className="text-2xl font-black text-slate-800 block font-mono">8.4 min</span>
                <span className="text-[9.5px] text-emerald-500 block font-semibold">⚡ Metas atingidas</span>
              </div>
              <div className="h-10 w-10 bg-amber-50 rounded-lg flex items-center justify-center text-[#D4AF37]">
                <Clock className="h-5 w-5" />
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-xs">
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Dúvidas Resolvidas</span>
                <span className="text-2xl font-black text-slate-800 block font-mono">
                  {questions.filter(q => q.status === 'resolvida').length}/{totalQuestionsCount}
                </span>
                <span className="text-[9.5px] text-slate-400 block">Taxa de sucesso acadêmico</span>
              </div>
              <div className="h-10 w-10 bg-emerald-50 rounded-lg flex items-center justify-center text-emerald-500">
                <MessageSquare className="h-5 w-5" />
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-xs">
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Engajamento</span>
                <span className="text-2xl font-black text-slate-800 block font-mono">94.2%</span>
                <span className="text-[9.5px] text-emerald-500 block font-semibold">↑ 2.4% esta semana</span>
              </div>
              <div className="h-10 w-10 bg-[#D4AF37]/10 rounded-lg flex items-center justify-center text-[#D4AF37]">
                <TrendingUp className="h-5 w-5" />
              </div>
            </div>
          </div>

          {/* Graphical pure tailwind representation of categories */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <h3 className="text-xs font-black uppercase text-slate-500 tracking-wider flex items-center gap-1.5 pb-3 border-b border-slate-100">
              <BarChart2 className="h-4.5 w-4.5" /> Distribuição de Chamados por Categoria
            </h3>

            <div className="space-y-4 pt-2">
              <div className="space-y-1 text-xs">
                <div className="flex justify-between font-bold text-slate-700">
                  <span>Dúvida sobre o Aplicativo</span>
                  <span>45%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-slate-900 rounded-full" style={{ width: '45%' }} />
                </div>
              </div>

              <div className="space-y-1 text-xs">
                <div className="flex justify-between font-bold text-slate-700">
                  <span>Dúvidas Teóricas (Direito Penal/Civil)</span>
                  <span>30%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500 rounded-full" style={{ width: '30%' }} />
                </div>
              </div>

              <div className="space-y-1 text-xs">
                <div className="flex justify-between font-bold text-slate-700">
                  <span>Problemas Técnicos e Login</span>
                  <span>15%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-rose-500 rounded-full" style={{ width: '15%' }} />
                </div>
              </div>

              <div className="space-y-1 text-xs">
                <div className="flex justify-between font-bold text-slate-700">
                  <span>Financeiro e Cobrança</span>
                  <span>10%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: '10%' }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ADMIN SUB-VIEW: RESPOND TO FORUM QUESTIONS */}
      {activeAdminSubTab === 'questions' && (
        <div className="space-y-4">
          <h3 className="text-xs font-black uppercase text-slate-500 tracking-wider">Responder Dúvidas dos Alunos</h3>
          
          {questions.length === 0 ? (
            <div className="bg-white border p-6 text-center text-xs text-slate-400 rounded-xl">
              Nenhuma dúvida para moderar ou responder.
            </div>
          ) : (
            <div className="space-y-3">
              {questions.map(q => (
                <div key={q.id} className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
                  <div className="flex justify-between items-start gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                        <span className="font-bold text-slate-700">{q.author}</span>
                        <span>•</span>
                        <span className="bg-slate-100 px-1.5 py-0.5 rounded font-mono font-bold text-slate-600">{q.discipline}</span>
                      </div>
                      <h4 className="font-serif font-bold text-sm text-slate-900">{q.title}</h4>
                      <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-150 leading-relaxed font-medium">
                        {q.text}
                      </p>
                    </div>

                    <div className="flex gap-1.5 shrink-0">
                      <button 
                        onClick={() => handleModerateQuestion(q.id)}
                        className="bg-rose-50 hover:bg-rose-100 text-rose-600 p-2 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                        title="Moderar pergunta"
                      >
                        <ShieldAlert className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {q.answers.length > 0 && (
                    <div className="space-y-2 pt-2 border-t border-slate-100">
                      <span className="text-[10px] font-bold text-slate-400 block uppercase">Respostas existentes:</span>
                      {q.answers.map(ans => (
                        <div key={ans.id} className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs flex justify-between">
                          <div>
                            <span className="font-bold text-slate-700 block">{ans.author}</span>
                            <span className="text-slate-600">{ans.text}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono shrink-0">{ans.timestamp}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {forumReplyId === q.id ? (
                    <div className="bg-amber-500/5 p-4 rounded-xl border border-amber-500/25 space-y-3 animate-fade-in">
                      <label className="block text-xs font-bold text-amber-900">Resposta oficial do Professor/Tutor</label>
                      <textarea
                        placeholder="Forneça a fundamentação jurídica baseada nos artigos legais e responda ao questionamento de forma didática..."
                        value={forumReplyText}
                        onChange={(e) => setForumReplyText(e.target.value)}
                        className="w-full text-xs bg-white border border-slate-250 rounded-lg p-2.5 h-24 focus:outline-none"
                        required
                      />
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={() => setForumReplyId(null)}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold px-3 py-1.5 rounded-lg cursor-pointer"
                        >
                          Cancelar
                        </button>
                        <button 
                          onClick={() => handleAdminForumReply(q.id)}
                          className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <Send className="h-3.5 w-3.5" /> Publicar Resposta Oficial
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button 
                      onClick={() => setForumReplyId(q.id)}
                      className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2 px-4 rounded-lg flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="h-4 w-4" /> Responder como Equipe OAB 3F
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ADMIN SUB-VIEW: ATENDER SUPORTE TICKETS */}
      {activeAdminSubTab === 'tickets' && (
        <div className="space-y-4">
          <h3 className="text-xs font-black uppercase text-slate-500 tracking-wider">Responder Chamados de Atendimento</h3>

          {tickets.length === 0 ? (
            <div className="bg-white border p-6 text-center text-xs text-slate-400 rounded-xl">
              Nenhum ticket aberto ou em análise.
            </div>
          ) : (
            <div className="space-y-3">
              {tickets.map(t => (
                <div key={t.id} className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                    <div className="space-y-0.5">
                      <span className="font-mono text-xs font-bold text-slate-900">{t.protocol}</span>
                      <span className="text-[10px] text-slate-400 block font-medium">{t.category}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`text-[9.5px] uppercase font-bold px-2 py-0.5 rounded ${
                        t.urgency === 'Urgente' ? 'bg-red-50 text-red-600' :
                        t.urgency === 'Alta' ? 'bg-amber-50 text-amber-600' :
                        'bg-slate-100 text-slate-500'
                      }`}>
                        {t.urgency}
                      </span>
                      <span className={`text-[9.5px] uppercase font-bold px-2 py-0.5 rounded ${
                        t.status === 'resolvido' || t.status === 'encerrado' ? 'bg-emerald-50 text-emerald-700' :
                        t.status === 'respondido' ? 'bg-blue-50 text-blue-700' :
                        'bg-rose-50 text-rose-700 animate-pulse'
                      }`}>
                        {t.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Histórico de Diálogos:</span>
                    {t.replies.map((rep, rIdx) => (
                      <div key={rIdx} className="bg-slate-50 p-3 rounded-lg border border-slate-150 text-xs font-medium space-y-0.5 text-slate-600">
                        <div className="flex justify-between font-bold text-slate-800 text-[10.5px]">
                          <span>{rep.author}</span>
                          <span className="font-mono text-slate-400">{rep.timestamp}</span>
                        </div>
                        <p>{rep.text}</p>
                      </div>
                    ))}
                  </div>

                  {ticketReplyId === t.id ? (
                    <div className="bg-slate-100 p-4 rounded-xl space-y-3 border border-slate-250 animate-fade-in">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">Alterar Status para:</label>
                          <select
                            value={ticketStatusUpdate}
                            onChange={(e: any) => setTicketStatusUpdate(e.target.value)}
                            className="text-xs border border-slate-200 bg-white p-2 rounded-lg focus:outline-none w-full"
                          >
                            <option value="respondido">Respondido / Aguardando</option>
                            <option value="resolvido">Resolvido e Finalizado</option>
                            <option value="em_analise">Em Análise / Investigando</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Escreva a Resposta do Suporte:</label>
                        <textarea
                          placeholder="Olá! Verifiquei seu acesso e já providenciei a liberação..."
                          value={ticketReplyText}
                          onChange={(e) => setTicketReplyText(e.target.value)}
                          className="w-full text-xs bg-white border border-slate-200 rounded-lg p-2.5 h-24 focus:outline-none"
                          required
                        />
                      </div>

                      <div className="flex justify-end gap-2 pt-1">
                        <button 
                          onClick={() => setTicketReplyId(null)}
                          className="bg-slate-200 hover:bg-slate-300 text-slate-600 text-xs font-bold px-3 py-1.5 rounded-lg cursor-pointer"
                        >
                          Cancelar
                        </button>
                        <button 
                          onClick={() => handleAdminTicketReply(t.id)}
                          className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <Send className="h-3.5 w-3.5" /> Enviar Resposta Pedagógica
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button 
                      onClick={() => {
                        setTicketReplyId(t.id);
                        setTicketStatusUpdate(t.status === 'aberto' ? 'respondido' : t.status as any);
                      }}
                      className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2 px-4 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <Plus className="h-4 w-4" /> Escrever Resposta de Suporte
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ADMIN SUB-VIEW: PUBLISH FAQ & ANNOUNCEMENTS */}
      {activeAdminSubTab === 'actions' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Form to publish FAQs */}
          <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-xs space-y-4">
            <h3 className="text-xs font-black uppercase text-slate-500 tracking-wider flex items-center gap-1 pb-2 border-b border-slate-100">
              <HelpCircle className="h-4.5 w-4.5" /> Publicar Novo Artigo FAQ
            </h3>

            {faqSuccess ? (
              <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-center font-bold text-xs">
                ✔ Artigo publicado com sucesso na Base de Conhecimento!
              </div>
            ) : (
              <form onSubmit={handleAddFaq} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Categoria do Artigo</label>
                  <select
                    value={faqCategory}
                    onChange={(e) => setFaqCategory(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
                  >
                    <option value="Uso do App">Uso do Aplicativo</option>
                    <option value="Sobre o Exame">Exame OAB</option>
                    <option value="Repescagem">Repescagem</option>
                    <option value="Conteúdo">Conteúdo Acadêmico</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Título / Pergunta do FAQ</label>
                  <input
                    type="text"
                    placeholder="Ex: Como é feita a repescagem da OAB?"
                    value={faqQuestion}
                    onChange={(e) => setFaqQuestion(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-slate-400"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Fundamentação / Resposta do Artigo</label>
                  <textarea
                    placeholder="Escreva a resposta completa e detalhada para ajudar o aluno..."
                    value={faqAnswer}
                    onChange={(e) => setFaqAnswer(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg p-2.5 h-24 focus:outline-none focus:ring-1 focus:ring-slate-400"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2.5 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Plus className="h-4 w-4" /> Publicar Artigo FAQ
                </button>
              </form>
            )}
          </div>

          {/* Form to publish Announcements */}
          <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-xs space-y-4">
            <h3 className="text-xs font-black uppercase text-slate-500 tracking-wider flex items-center gap-1 pb-2 border-b border-slate-100">
              <Bell className="h-4.5 w-4.5" /> Publicar Novo Comunicado / Aviso
            </h3>

            {annSuccess ? (
              <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-center font-bold text-xs">
                ✔ Comunicado publicado com sucesso no mural de avisos!
              </div>
            ) : (
              <form onSubmit={handleAddAnnouncement} className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Categoria</label>
                    <select
                      value={annCategory}
                      onChange={(e: any) => setAnnCategory(e.target.value)}
                      className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
                    >
                      <option value="Geral">Geral</option>
                      <option value="Eventos">Eventos / Aulões</option>
                      <option value="Materiais">Materiais de Estudo</option>
                      <option value="Mentoria">Avisos de Mentoria</option>
                    </select>
                  </div>

                  <div className="flex items-center pt-5">
                    <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700">
                      <input
                        type="checkbox"
                        checked={annUrgent}
                        onChange={(e) => setAnnUrgent(e.target.checked)}
                        className="h-4 w-4 text-slate-900 focus:ring-slate-400 border-slate-300 rounded"
                      />
                      <span>Aviso Urgente (Destaque Vermelho)</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Título do Comunicado</label>
                  <input
                    type="text"
                    placeholder="Ex: 🔥 Simulado de 1ª Fase XL liberado!"
                    value={annTitle}
                    onChange={(e) => setAnnTitle(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-slate-400"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Mensagem Curta para os Alunos</label>
                  <textarea
                    placeholder="Olá alunos! Já está liberado em sua aba o simulado completo para treinar..."
                    value={annText}
                    onChange={(e) => setAnnText(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg p-2.5 h-24 focus:outline-none"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2.5 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Plus className="h-4 w-4" /> Publicar Comunicado
                </button>
              </form>
            )}
          </div>

        </div>
      )}

    </div>
  );
}
