/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Play,
  Clock,
  Calendar,
  CheckCircle,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  FileText,
  Flame,
  Plus,
  Compass,
  Award,
  BookOpen,
  Bell,
  Zap,
  Target,
  Sparkles,
  HelpCircle,
  BookOpenCheck,
  User,
  Activity,
  Check,
  ChevronRight,
  RotateCcw,
  SlidersHorizontal,
  Hourglass,
  Info
} from 'lucide-react';
import { StudentProgress, WeeklyTask, Discipline } from '../types';
import { QUESTIONS_BANK } from '../data/mockData';

interface DashboardProps {
  progress: StudentProgress;
  weeklyTasks: WeeklyTask[];
  disciplines: Discipline[];
  onToggleTask: (taskId: string) => void;
  onUpdateTaskStatus: (taskId: string, newStatus: 'pending' | 'in_progress' | 'completed') => void;
  onAddStudyHours: (hours: number) => void;
  onNavigateToTab: (tabId: string, sectionId?: string, itemId?: string) => void;
  userPlan?: string;
  onStartStudyTask?: (taskId: string) => void;
}

export default function Dashboard({
  progress,
  weeklyTasks,
  disciplines,
  onToggleTask,
  onUpdateTaskStatus,
  onAddStudyHours,
  onNavigateToTab,
  userPlan = 'gratuito',
  onStartStudyTask
}: DashboardProps) {
  
  // ----------------- ONBOARDING INTEGRATION -----------------
  const onboardingCompleted = localStorage.getItem('oab3f_onboarding_completed') === 'true';
  const obPerfil = localStorage.getItem('oab3f_onboarding_perfil') || 'Iniciante da 1ª fase';
  const obFase = localStorage.getItem('oab3f_onboarding_fase') || '1a_fase';
  const obArea2a = localStorage.getItem('oab3f_onboarding_area2a') || 'Direito Penal';
  const obHoras = localStorage.getItem('oab3f_onboarding_horas') || '2h_4h';
  
  const obDiasStr = localStorage.getItem('oab3f_onboarding_dias');
  let obDias: string[] = [];
  try {
    obDias = obDiasStr ? JSON.parse(obDiasStr) : ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta'];
  } catch (e) {
    obDias = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta'];
  }
  
  const obMeta = localStorage.getItem('oab3f_onboarding_meta') || 'organizar_rotina';
  
  const obDificuldadesStr = localStorage.getItem('oab3f_onboarding_dificuldades');
  let obDificuldades: string[] = [];
  try {
    obDificuldades = obDificuldadesStr ? JSON.parse(obDificuldadesStr) : ['Direito Civil', 'Processo Penal'];
  } catch (e) {
    obDificuldades = ['Direito Civil', 'Processo Penal'];
  }
  
  const obErrar = localStorage.getItem('oab3f_onboarding_errar') || 'teoria';
  const obConstancia = localStorage.getItem('oab3f_onboarding_constancia') === 'true';
  
  const obNotifsStr = localStorage.getItem('oab3f_onboarding_notifs');
  let obNotifs: string[] = [];
  try {
    obNotifs = obNotifsStr ? JSON.parse(obNotifsStr) : ['diario', 'revisao', 'meta'];
  } catch (e) {
    obNotifs = ['diario', 'revisao', 'meta'];
  }
  
  const obIntensidade = localStorage.getItem('oab3f_onboarding_notif_intensa') || 'moderada';
  const obHorario = localStorage.getItem('oab3f_onboarding_notif_horario') || '20:00';
  const obBlocos = localStorage.getItem('oab3f_onboarding_blocos') || 'curtos';
  const obTurno = localStorage.getItem('oab3f_onboarding_turno') || 'noite';

  const readableFase = obFase === '1a_fase' ? '1ª Fase (Objetiva)' : obFase === '2a_fase' ? '2ª Fase (Prática)' : obFase === 'completo' ? '1ª e 2ª Fase' : 'Geral';
  
  const hoursGoalMap: Record<string, string> = {
    ate_1h: 'Até 1 hora/dia',
    '1h_2h': '1 a 2 horas/dia',
    '2h_4h': '2 a 4 horas/dia',
    mais_4h: 'Mais de 4 horas/dia'
  };
  
  const handleResetOnboarding = () => {
    if (confirm("Deseja refazer o diagnóstico OAB e onboarding inicial? Seu progresso de horas e simulados será mantido, mas seu cronograma diário será recalculado.")) {
      localStorage.removeItem('oab3f_onboarding_completed');
      window.location.reload();
    }
  };

  // ----------------- NAME PERSISTENCE -----------------
  const [studentName, setStudentName] = useState(() => {
    const saved = localStorage.getItem('oab3f_student_name');
    return saved || 'Lucas Santos';
  });
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(studentName);

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (nameInput.trim()) {
      setStudentName(nameInput.trim());
      localStorage.setItem('oab3f_student_name', nameInput.trim());
      setIsEditingName(false);
    }
  };

  // ----------------- TARGET EXAM SELECTOR & COUNTDOWN -----------------
  const [selectedExam, setSelectedExam] = useState<'XL' | 'XLI' | 'Custom'>('XL');
  const [customExamDate, setCustomExamDate] = useState('2026-11-29'); // fallback
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, mins: 0 });

  useEffect(() => {
    // Get target date based on selected exam
    let targetStr = '2026-09-13T08:00:00'; // XL Exame (Approx Sept 2026)
    if (selectedExam === 'XLI') {
      targetStr = '2026-11-29T08:00:00'; // XLI Exame (Approx Nov/Dec 2026)
    } else if (selectedExam === 'Custom') {
      targetStr = `${customExamDate}T08:00:00`;
    }

    const updateCountdown = () => {
      const targetDate = new Date(targetStr);
      const now = new Date();
      const diff = targetDate.getTime() - now.getTime();
      
      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, mins: 0 });
        return;
      }
      
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const mins = Math.floor((diff / (1000 * 60)) % 60);
      
      setTimeLeft({ days, hours, mins });
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 10000); // update every 10s is sufficient
    return () => clearInterval(interval);
  }, [selectedExam, customExamDate]);

  // ----------------- TASK STATUS CONTROLLER (3 STATES) -----------------
  // Directly derive task statuses from parent task status property (Ajuste 1, 3)
  const getTaskStatus = (task: WeeklyTask): 'pendente' | 'em_andamento' | 'concluida' => {
    if (task.status === 'completed') return 'concluida';
    if (task.status === 'in_progress') return 'em_andamento';
    return 'pendente';
  };

  const handleUpdateTaskStatus = (taskId: string, newStatus: 'pendente' | 'em_andamento' | 'concluida') => {
    const mapped: 'pending' | 'in_progress' | 'completed' = 
      newStatus === 'concluida' ? 'completed' : newStatus === 'em_andamento' ? 'in_progress' : 'pending';
    onUpdateTaskStatus(taskId, mapped);
  };

  // ----------------- CALENDAR DAYS & TABS -----------------
  const weekdaysInPortuguese = [
    'Domingo',
    'Segunda-feira',
    'Terça-feira',
    'Quarta-feira',
    'Quinta-feira',
    'Sexta-feira',
    'Sábado'
  ];
  const currentWeekdayIndex = new Date().getDay();
  const currentWeekdayName = weekdaysInPortuguese[currentWeekdayIndex];

  const [selectedDay, setSelectedDay] = useState<string>(() => {
    return currentWeekdayName;
  });

  const filteredTasksForSelectedDay = weeklyTasks.filter(task => 
    task.day.toLowerCase().includes(selectedDay.split('-')[0].toLowerCase())
  );

  // Stats calculation
  const totalTasksForSelectedDay = filteredTasksForSelectedDay.length;
  const completedTasksForSelectedDay = filteredTasksForSelectedDay.filter(t => t.status === 'completed').length;
  const inProgressTasksForSelectedDay = filteredTasksForSelectedDay.filter(t => t.status === 'in_progress').length;
  const estimatedTimeForSelectedDay = filteredTasksForSelectedDay.reduce((sum, t) => sum + (t.estimatedMinutes !== undefined ? t.estimatedMinutes : t.durationMinutes), 0);

  // ----------------- QUICK STUDY LOGGER -----------------
  const [customHours, setCustomHours] = useState('');
  const [showLogSuccess, setShowLogSuccess] = useState(false);

  const handleQuickAdd = (amount: number) => {
    onAddStudyHours(amount);
    triggerLogSuccess();
  };

  const handleCustomAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(customHours);
    if (!isNaN(val) && val > 0) {
      onAddStudyHours(val);
      setCustomHours('');
      triggerLogSuccess();
    }
  };

  const triggerLogSuccess = () => {
    setShowLogSuccess(true);
    setTimeout(() => setShowLogSuccess(false), 3000);
  };

  // ----------------- STATS CALCULATIONS -----------------
  const totalTasks = weeklyTasks.length;
  const completedTasksCount = weeklyTasks.filter(t => t.status === 'completed').length;
  const taskProgressPct = totalTasks > 0 ? Math.round((completedTasksCount / totalTasks) * 100) : 0;

  const answeredList = Object.values(progress.answeredQuestions);
  const totalQuestionsAnswered = answeredList.length;
  const correctAnswersCount = answeredList.filter(a => a.isCorrect).length;
  const overallQuizSuccessRate = totalQuestionsAnswered > 0 
    ? Math.round((correctAnswersCount / totalQuestionsAnswered) * 100) 
    : 72; 

  // Dynamic Best vs Worst subject calculation based on real answers
  const disciplinePerformanceMap = React.useMemo(() => {
    const map: { [discipline: string]: { total: number; correct: number } } = {};
    Object.entries(progress.answeredQuestions).forEach(([qId, ans]) => {
      const q = QUESTIONS_BANK.find(item => item.id === qId);
      if (q) {
        if (!map[q.discipline]) {
          map[q.discipline] = { total: 0, correct: 0 };
        }
        map[q.discipline].total += 1;
        if (ans.isCorrect) {
          map[q.discipline].correct += 1;
        }
      }
    });

    return Object.entries(map).map(([discipline, stats]) => {
      const rate = Math.round((stats.correct / stats.total) * 100);
      return { discipline, rate, ...stats };
    });
  }, [progress.answeredQuestions]);

  const bestSubject = React.useMemo(() => {
    if (disciplinePerformanceMap.length === 0) {
      return { discipline: 'Ética Profissional', rate: 85, total: 0 };
    }
    return [...disciplinePerformanceMap].sort((a, b) => b.rate - a.rate || b.total - a.total)[0];
  }, [disciplinePerformanceMap]);

  const worstSubject = React.useMemo(() => {
    if (disciplinePerformanceMap.length === 0) {
      return { discipline: 'Processo Penal', rate: 48, total: 0 };
    }
    return [...disciplinePerformanceMap].sort((a, b) => a.rate - b.rate || a.total - b.total)[0];
  }, [disciplinePerformanceMap]); 

  const completedLecturesCount = progress.completedLectures?.length || 4;
  const completedPDFsCount = progress.completedPDFs?.length || 2;

  // ----------------- VISUAL SPARKLINE HISTORY DATA -----------------
  // Pre-loaded realistic curve + user's live history data
  const baseSimData = [
    { label: 'Diag.', percentage: 52 },
    { label: 'Sim 1', percentage: 58 },
    { label: 'Sim 2', percentage: 63 },
    { label: 'Sim 3', percentage: 69 },
    { label: 'Sim 4', percentage: 74 }
  ];

  const simulatedHistory = progress.simulatedExamsHistory && progress.simulatedExamsHistory.length > 0
    ? progress.simulatedExamsHistory.map((s, idx) => ({ label: `Sim ${idx + 1}`, percentage: s.percentage }))
    : baseSimData;

  const totalSimulatedDone = progress.simulatedExamsHistory?.length || simulatedHistory.length;
  const averageSimulatedScore = Math.round(simulatedHistory.reduce((sum, sim) => sum + sim.percentage, 0) / simulatedHistory.length);

  // ----------------- NOTIFICATIONS / BULLETIN BOARD -----------------
  const alerts = [
    {
      id: 'alert-1',
      tag: 'EDITAL',
      title: 'Inscrições do XL Exame de Ordem Unificado',
      desc: 'O edital oficial foi divulgado. Certifique-se de preencher os pré-requisitos e efetuar o pagamento da taxa de inscrição dentro do prazo estabelecido pela FGV.',
      date: 'Lembrete Prioritário',
      type: 'critical'
    },
    {
      id: 'alert-2',
      tag: 'SIMULADO',
      title: 'Simulado Geral de Diagnóstico Nacional',
      desc: 'Liberado neste sábado a partir das 08h00. O caderno de provas segue fielmente o perfil recente da FGV, com 80 questões comentadas item por item.',
      date: 'Este Sábado',
      type: 'info'
    },
    {
      id: 'alert-3',
      tag: 'CÓDIGO CIVIL',
      title: 'Revisão Sistemática de Direito das Coisas',
      desc: 'Incluímos novos resumos esquematizados e videoaulas atualizadas cobrindo as recentes decisões do STJ sobre usucapião extrajudicial.',
      date: 'Novo Conteúdo',
      type: 'success'
    }
  ];

  // ----------------- ACTIVE ACTIVITY SUGGESTION FALLBACK -----------------
  const resumeActivity = progress.lastSavedActivity || {
    tab: '1ª Fase',
    sectionId: 'disc-etica',
    itemId: 'video-etica-1',
    title: 'Ética Profissional - Estatuto da OAB, Art. 1º ao 5º',
    timestamp: new Date().toISOString()
  };

  const recommendedTask = weeklyTasks.find(t => t.status !== 'completed') || weeklyTasks[0];
  const currentProfile = obPerfil;

  return (
    <div className="space-y-8 pb-16 animate-fade-in" id="dashboard-container">
      
      {/* ----------------- BLOCO 1 — CABEÇALHO DE BOAS-VINDAS (Visual Premium) ----------------- */}
      <div className="bg-white border border-[#E5E1D8] shadow-sm relative overflow-hidden p-6 sm:p-8" id="welcome-header">
        {/* Subtle decorative gold brand line */}
        <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-[#D4AF37] via-[#0F172A] to-[#D4AF37]"></div>
        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-[#D4AF37]/5 to-transparent pointer-events-none"></div>
        
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 relative z-10">
          
          <div className="space-y-3 flex-1">
            <div className="flex items-center space-x-2">
              <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37] bg-[#FAF9F6] border border-[#E5E1D8] px-2.5 py-1">
                Painel de Acompanhamento Estratégico
              </span>
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" title="Sessão de estudos ativa"></span>
            </div>

            <div className="flex items-center space-x-4 flex-wrap">
              {/* Elegant Initials Avatar */}
              <div className="h-14 w-14 rounded-full bg-[#0F172A] border-2 border-[#D4AF37] flex items-center justify-center text-[#D4AF37] font-serif italic text-xl shadow-inner shrink-0">
                {studentName ? studentName.charAt(0).toUpperCase() : 'A'}
              </div>

              <div>
                {isEditingName ? (
                  <form onSubmit={handleSaveName} className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      className="border border-[#E5E1D8] px-3 py-1 text-2xl font-serif italic text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50 bg-[#FAF9F6] max-w-xs rounded"
                      autoFocus
                    />
                    <button type="submit" className="bg-[#0F172A] text-[#D4AF37] text-xs px-3 py-2 font-bold uppercase tracking-wider hover:bg-slate-800 transition-colors">
                      Confirmar
                    </button>
                    <button type="button" onClick={() => setIsEditingName(false)} className="text-xs text-slate-400 hover:text-slate-600 font-medium">
                      Cancelar
                    </button>
                  </form>
                ) : (
                  <div className="flex items-center space-x-2 group">
                    <h2 className="text-3xl sm:text-4xl font-serif text-[#0F172A] tracking-tight leading-none">
                      Olá, <span className="italic font-normal">{studentName}</span>.
                    </h2>
                    <button 
                      onClick={() => { setNameInput(studentName); setIsEditingName(true); }}
                      className="text-[11px] font-mono font-bold text-[#D4AF37] hover:text-[#0F172A] transition-colors bg-[#FAF9F6] px-2 py-0.5 border border-[#E5E1D8] rounded mt-1"
                      title="Alterar seu nome"
                    >
                      EDITAR NOME
                    </button>
                  </div>
                )}
                <p className="text-xs text-slate-400 font-mono mt-1">Matrícula ativa • Exame de Ordem Unificado</p>
              </div>
            </div>

            {/* Premium editorial quote styling */}
            <div className="pt-2 border-t border-[#F1F1ED] max-w-3xl">
              <p className="text-sm font-serif italic text-slate-600 leading-relaxed">
                &ldquo;Aprovado não é aquele que sabe tudo, mas sim aquele que domina a constância, foca nas próprias falhas e mantém o ritmo correto nos dias cinzentos.&rdquo;
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 xl:shrink-0 items-stretch">
            
            {/* Interactive countdown card */}
            <div className="bg-[#FAF9F6] border border-[#E5E1D8] p-5 text-center min-w-[200px] flex flex-col justify-between relative group hover:border-[#D4AF37] transition-all">
              <div className="flex items-center justify-between border-b border-[#E5E1D8] pb-2 mb-2">
                <span className="text-[10px] uppercase tracking-widest font-extrabold text-slate-500">Contagem de Foco</span>
                <select 
                  value={selectedExam} 
                  onChange={(e) => setSelectedExam(e.target.value as any)}
                  className="text-[10px] font-mono font-bold bg-white border border-[#E5E1D8] text-[#0F172A] py-0.5 px-1.5 focus:outline-none cursor-pointer"
                >
                  <option value="XL">Exame XL</option>
                  <option value="XLI">Exame XLI</option>
                  <option value="Custom">Data Custom</option>
                </select>
              </div>

              <div className="my-auto py-1">
                <div className="flex items-baseline justify-center space-x-1.5">
                  <span className="text-4xl font-serif font-extrabold text-[#0F172A] tracking-tight">{timeLeft.days}</span>
                  <span className="text-xs font-serif italic text-slate-500">dias</span>
                </div>
                <div className="text-[9px] font-mono text-slate-400 mt-1 uppercase tracking-wider">
                  {timeLeft.hours}h {timeLeft.mins}m restantes
                </div>
              </div>

              <div className="mt-2 pt-2 border-t border-[#E5E1D8]/60 text-[9px] text-slate-400 font-mono">
                {selectedExam === 'XL' && 'Prova prevista: 13/09/2026'}
                {selectedExam === 'XLI' && 'Prova prevista: 29/11/2026'}
                {selectedExam === 'Custom' && (
                  <input 
                    type="date" 
                    value={customExamDate} 
                    onChange={(e) => setCustomExamDate(e.target.value)}
                    className="border border-[#E5E1D8] text-[9px] text-slate-600 bg-white px-1 max-w-[110px] focus:outline-none"
                  />
                )}
              </div>
            </div>

            {/* "Continuar de onde parei" main action button */}
            <div className="bg-[#0F172A] text-white p-5 min-w-[220px] max-w-sm flex flex-col justify-between border border-[#0F172A] hover:shadow-md transition-shadow">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] uppercase tracking-wider text-[#D4AF37] font-bold">
                    REFORÇO E CONTINUIDADE
                  </span>
                  <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-ping"></span>
                </div>
                <p className="text-xs font-serif font-bold text-slate-100 mt-1 line-clamp-2" title={resumeActivity.title}>
                  {resumeActivity.title}
                </p>
                <div className="flex items-center space-x-1.5 text-[10px] text-slate-400 font-mono mt-1">
                  <span>Mapeado em:</span>
                  <span className="bg-slate-800 text-slate-200 px-1 rounded">{resumeActivity.tab}</span>
                </div>
              </div>

              <button
                onClick={() => onNavigateToTab(
                  resumeActivity.tab === '1ª Fase' ? 'fase1' : 
                  resumeActivity.tab === '2ª Fase' ? 'fase2' : 'inicio',
                  resumeActivity.sectionId,
                  resumeActivity.itemId
                )}
                className="mt-4 w-full bg-[#D4AF37] hover:bg-amber-500 text-[#0F172A] text-xs font-bold uppercase tracking-wider py-2 px-3 transition-colors flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                <span>Continuar Estudos</span>
              </button>
            </div>

          </div>
        </div>
      </div>

      {/* MONETIZAÇÃO CTA - UPGRADE PROMOTIONAL BANNER (Módulo 6 & 16) */}
      {userPlan === 'gratuito' && (
        <div className="bg-gradient-to-r from-[#0F172A] to-slate-900 border-2 border-[#D4AF37] rounded-xl p-6 text-white relative overflow-hidden shadow-lg flex flex-col lg:flex-row lg:items-center justify-between gap-6 animate-fade-in" id="dashboard-premium-promo">
          <div className="absolute top-0 right-0 w-64 h-64 bg-radial-gradient from-[#D4AF37]/15 via-transparent to-transparent pointer-events-none" />
          <div className="space-y-2 relative z-10">
            <span className="bg-[#D4AF37] text-slate-900 text-[9px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full font-mono">
              ⚡ OFERTA DE RETA FINAL OAB XL
            </span>
            <h3 className="font-serif font-bold text-xl text-[#D4AF37]">
              Sua aprovação OAB de 1ª e 2ª Fase com Plano de Estudo Inteligente
            </h3>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Você está na versão de testes **Gratuita**. Ative o plano de acesso completo hoje com **25% de desconto** usando o cupom <span className="font-mono text-[#D4AF37] font-bold">APROVADO25</span> e destrave questões ilimitadas, simulados de 5 horas, trilhas e correções personalizadas.
            </p>
          </div>
          <button
            onClick={() => onNavigateToTab('monetizacao')}
            className="bg-[#D4AF37] hover:bg-amber-500 text-slate-900 font-bold px-6 py-3 rounded-lg text-xs tracking-wider uppercase transition-all shadow-md cursor-pointer shrink-0 z-10"
          >
            Garantir Desconto de 25%
          </button>
        </div>
      )}

      {/* ----------------- SEÇÃO INTEGRADA DE ONBOARDING INTELIGENTE E PERFIL DO ALUNO (Etapa 12) ----------------- */}
      {onboardingCompleted && (
        <div className="bg-[#0F172A] text-white border-2 border-[#D4AF37]/35 relative overflow-hidden p-6 shadow-md rounded-xl animate-fade-in space-y-6" id="post-onboarding-banner">
          <div className="absolute top-0 right-0 w-32 h-32 bg-radial-gradient from-[#D4AF37]/20 via-transparent to-transparent pointer-events-none" />
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-black tracking-widest text-[#D4AF37] flex items-center gap-1.5 font-mono">
                <Sparkles className="h-4 w-4 animate-pulse text-[#D4AF37]" /> TRILHA DIRETA DE APROVAÇÃO OAB 3F
              </span>
              <h3 className="text-xl sm:text-2xl font-serif font-extrabold tracking-tight">
                Seu Painel de Estudos está <span className="italic font-normal text-[#D4AF37]">Personalizado</span>!
              </h3>
              <p className="text-xs text-slate-400">
                Olá, <strong>{studentName}</strong>! Nosso diagnóstico estratégico mapeou seu perfil como <strong className="text-white bg-slate-800 px-2 py-0.5 rounded border border-slate-700">{obPerfil}</strong>.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={handleResetOnboarding}
                className="bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 hover:text-white px-3 py-1.5 text-xs font-bold rounded flex items-center gap-1 cursor-pointer transition-all uppercase tracking-wider"
              >
                <RotateCcw className="h-3.5 w-3.5" /> Refazer Diagnóstico
              </button>

              <button
                onClick={() => onNavigateToTab(obFase === '2a_fase' ? 'fase2' : 'fase1')}
                className="bg-[#D4AF37] hover:bg-amber-500 text-slate-900 px-4 py-1.5 text-xs font-black rounded flex items-center gap-1 cursor-pointer transition-all uppercase tracking-wider"
              >
                <span>Começar Agora</span> <ArrowRight className="h-4 w-4 stroke-[3]" />
              </button>
            </div>
          </div>

          {/* Core dynamic recommendations based on onboarding choices */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
            
            {/* 1. Week focus */}
            <div className="p-4 bg-slate-950/50 rounded-lg border border-slate-800 flex flex-col justify-between">
              <div>
                <span className="text-[9px] uppercase font-mono font-bold text-[#D4AF37]">Foco da Semana</span>
                <span className="block text-sm font-extrabold text-white mt-1">{readableFase}</span>
                <p className="text-[11px] text-slate-400 leading-relaxed mt-2">
                  Seu cronograma foi dimensionado para atingir a meta semanal de <strong className="text-[#D4AF37]">{progress.studyHoursGoal} horas</strong>, estudando nos dias: <span className="text-slate-200 font-semibold">{obDias.join(', ')}</span>.
                </p>
              </div>
              <div className="text-[10px] text-slate-400 font-mono border-t border-slate-800/60 pt-2 mt-3">
                Meta Diária: {obHoras === 'ate_1h' ? 'Até 1h/dia' : obHoras === '1h_2h' ? '1 a 2h/dia' : obHoras === '2h_4h' ? '2 a 4h/dia' : 'Mais de 4h/dia'}
              </div>
            </div>

            {/* 2. First recommended task */}
            <div className="p-4 bg-slate-950/50 rounded-lg border border-slate-800 flex flex-col justify-between">
              <div>
                <span className="text-[9px] uppercase font-mono font-bold text-emerald-400">Primeira Tarefa Recomendada</span>
                {recommendedTask ? (
                  <>
                    <span className="block text-sm font-extrabold text-white mt-1 line-clamp-1" title={recommendedTask.title}>
                      {recommendedTask.title}
                    </span>
                    <p className="text-[11px] text-slate-400 leading-relaxed mt-2">
                      Fidelize seu planejamento inicial executando esta meta agendada para <strong>{recommendedTask.day}</strong>. Carga estimada de {recommendedTask.estimatedMinutes !== undefined ? recommendedTask.estimatedMinutes : recommendedTask.durationMinutes} minutos.
                    </p>
                  </>
                ) : (
                  <>
                    <span className="block text-sm font-extrabold text-white mt-1">Todas as metas concluídas!</span>
                    <p className="text-[11px] text-slate-400 leading-relaxed mt-2">
                      Parabéns! Você concluiu seu cronograma recomendado para este período de estudos.
                    </p>
                  </>
                )}
              </div>
              <div className="border-t border-slate-800/60 pt-2 mt-3 flex items-center justify-between">
                {recommendedTask && onStartStudyTask ? (
                  <button
                    onClick={() => onStartStudyTask(recommendedTask.id)}
                    className="text-[10.5px] text-emerald-400 font-black hover:underline cursor-pointer uppercase flex items-center gap-1 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded transition-all hover:bg-emerald-500/20"
                  >
                    Estudar Agora ⚡
                  </button>
                ) : (
                  <button
                    onClick={() => onNavigateToTab('plano')}
                    className="text-[10px] text-emerald-400 font-bold hover:underline cursor-pointer uppercase flex items-center gap-1"
                  >
                    Ir para Meu Plano de Estudos <ChevronRight className="h-3 w-3" />
                  </button>
                )}
              </div>
            </div>

            {/* 3. Materials Recommendation */}
            <div className="p-4 bg-slate-950/50 rounded-lg border border-slate-800 flex flex-col justify-between">
              <div>
                <span className="text-[9px] uppercase font-mono font-bold text-amber-400">Recomendação de Apoio</span>
                {obDificuldades.length > 0 ? (
                  <>
                    <span className="block text-sm font-extrabold text-white mt-1">Mitigar: {obDificuldades[0]}</span>
                    <p className="text-[11px] text-slate-400 leading-relaxed mt-2">
                      Como você declarou maior dificuldade em <strong>{obDificuldades.join(', ')}</strong>, sugerimos consultar os resumos práticos e checklists na biblioteca.
                    </p>
                  </>
                ) : (
                  <>
                    <span className="block text-sm font-extrabold text-white mt-1">Revisão Geral e Resumos</span>
                    <p className="text-[11px] text-slate-400 leading-relaxed mt-2">
                      Aproveite nossa coletânea inteligente para solidificar temas de alta recorrência doutrinária.
                    </p>
                  </>
                )}
              </div>
              <div className="border-t border-slate-800/60 pt-2 mt-3">
                <button
                  onClick={() => onNavigateToTab('materiais')}
                  className="text-[10px] text-amber-400 font-bold hover:underline cursor-pointer uppercase flex items-center gap-1"
                >
                  Abrir Biblioteca de Materiais <ChevronRight className="h-3 w-3" />
                </button>
              </div>
            </div>

          </div>

          {/* COLLAPSIBLE COMPLETE PROFILE CARD (Requisitos de Perfil do Aluno) */}
          <details className="group border-t border-slate-800/80 pt-4" id="onboarding-profile-details">
            <summary className="text-xs font-black text-[#D4AF37] hover:text-white cursor-pointer list-none flex items-center justify-between uppercase tracking-wider font-mono select-none">
              <span className="flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4" /> Visualizar Ficha Cadastral e Diagnóstico de Perfil
              </span>
              <span className="text-[10px] text-slate-400 group-open:rotate-180 transition-transform font-bold">
                ▲ CLIQUE PARA DETALHES
              </span>
            </summary>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 pt-4 text-xs animate-fade-in">
              <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
                <span className="block text-[9px] uppercase font-mono text-slate-400">1. Aluno &amp; Cadastro</span>
                <span className="block font-bold text-white mt-0.5">{studentName}</span>
                <span className="text-[10px] text-slate-500 font-mono mt-1 block">Perfil: {obPerfil}</span>
              </div>

              <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
                <span className="block text-[9px] uppercase font-mono text-slate-400">2. Fase OAB Definida</span>
                <span className="block font-bold text-white mt-0.5">{readableFase}</span>
                {obFase !== '1a_fase' && (
                  <span className="text-[10px] text-oab-accent font-mono mt-1 block">Área 2ª Fase: {obArea2a}</span>
                )}
              </div>

              <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
                <span className="block text-[9px] uppercase font-mono text-slate-400">3. Ritmo de estudos</span>
                <span className="block font-bold text-white mt-0.5">{hoursGoalMap[obHoras] || obHoras}</span>
                <span className="text-[10px] text-slate-500 font-mono mt-1 block">Blocos: {obBlocos === 'curtos' ? 'Pomodoro 25min' : 'Imersão 1h+'} • Turno: {obTurno === 'manha' ? 'Manhã' : obTurno === 'tarde' ? 'Tarde' : obTurno === 'noite' ? 'Noite' : 'Variado'}</span>
              </div>

              <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
                <span className="block text-[9px] uppercase font-mono text-slate-400">4. Dificuldades Declaradas</span>
                <span className="block font-bold text-amber-400 mt-0.5 line-clamp-1">{obDificuldades.join(', ') || 'Nenhuma'}</span>
                <span className="text-[10px] text-slate-500 font-mono mt-1 block">Foco de erro: {obErrar === 'teoria' ? 'Teoria/Falta Base' : obErrar === 'interpretacao' ? 'Interpretação de Enunciado' : 'Fundamentos/Prática'}</span>
              </div>

              <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
                <span className="block text-[9px] uppercase font-mono text-slate-400">5. Alertas &amp; Notificações</span>
                <span className="block font-bold text-white mt-0.5">{obNotifs.length} alertas cadastrados</span>
                <span className="text-[10px] text-slate-500 font-mono mt-1 block">Intensidade: {obIntensidade} • Horário: {obHorario}</span>
              </div>

              <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
                <span className="block text-[9px] uppercase font-mono text-slate-400">6. Histórico de Onboarding</span>
                <span className="block font-bold text-emerald-400 mt-0.5">Diagnóstico Ativo</span>
                <span className="text-[10px] text-slate-500 font-mono mt-1 block">Status: Sincronizado com LocalStorage</span>
              </div>
            </div>
          </details>

        </div>
      )}

      {/* ----------------- SEÇÃO PRINCIPAL (Grid Layout bento) ----------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* COLUNA ESQUERDA (8 colunas no desktop) - Cronograma, Desempenho, Radar */}
        <div className="lg:col-span-8 space-y-8">
          
          {/* ----------------- BLOCO 2 — CRONOGRAMA DO DIA (Foco, Interatividade) ----------------- */}
          <div className="bg-white border border-[#E5E1D8] p-6 shadow-sm" id="section-daily-schedule">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#E5E1D8] pb-4 mb-5">
              <div>
                <h3 className="text-xl font-serif font-bold text-[#0F172A] flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-[#D4AF37]" />
                  Cronograma Diário do Aluno
                </h3>
                <p className="text-xs text-slate-500">Mapeamento dinâmico de leitura doutrinária, videoaulas e metas de hoje</p>
              </div>
              <div className="flex flex-col items-end shrink-0 mt-2 sm:mt-0">
                <span className="text-[10px] uppercase font-mono font-bold text-slate-500 bg-[#F1F1ED] px-2.5 py-1 rounded">
                  Hoje: <span className="text-[#0F172A] font-bold">{currentWeekdayName}</span>
                </span>
                <span className="text-[10px] text-slate-400 mt-1 font-mono">
                  {completedTasksForSelectedDay} de {totalTasksForSelectedDay} concluídas • {estimatedTimeForSelectedDay} min est.
                </span>
              </div>
            </div>

            {/* Dia selector Tab Row - Horizontal Scroll with gold accents */}
            <div className="flex overflow-x-auto pb-2 mb-5 gap-2 scrollbar-thin">
              {['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'].map((day) => {
                const isToday = currentWeekdayName.startsWith(day);
                const fullName = day === 'Sábado' || day === 'Domingo' ? day : `${day}-feira`;
                const isSelected = selectedDay === fullName;
                const dayTasks = weeklyTasks.filter(t => t.day === fullName);
                const dayTasksCount = dayTasks.length;
                const dayCompletedCount = dayTasks.filter(t => t.status === 'completed').length;

                return (
                  <button
                    key={day}
                    onClick={() => setSelectedDay(fullName)}
                    className={`
                      px-3.5 py-2 text-xs font-bold transition-all shrink-0 border uppercase tracking-wider flex flex-col items-center min-w-[85px] cursor-pointer rounded
                      ${isSelected
                        ? 'bg-[#0F172A] text-white border-[#0F172A] shadow-sm'
                        : 'bg-[#FAF9F6] text-slate-600 border-[#E5E1D8] hover:bg-[#F1F1ED]'
                      }
                    `}
                  >
                    <span className="flex items-center gap-1">
                      {day}
                      {isToday && (
                        <span className="h-1.5 w-1.5 rounded-full bg-[#D4AF37]" title="Hoje"></span>
                      )}
                    </span>
                    <span className={`text-[9px] mt-1 font-mono font-semibold ${isSelected ? 'text-[#D4AF37]' : 'text-slate-400'}`}>
                      {dayCompletedCount}/{dayTasksCount} {dayTasksCount === 1 ? 'meta' : 'metas'}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* List of Tasks for selected Day with 3-state controllers */}
            {filteredTasksForSelectedDay.length === 0 ? (
              <div className="text-center py-12 bg-[#FAF9F6] border border-dashed border-[#E5E1D8] p-6 rounded">
                <BookOpen className="h-10 w-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-serif italic text-slate-500">Nenhuma meta programada para este dia.</p>
                <button
                  onClick={() => onNavigateToTab('plano')}
                  className="mt-4 bg-[#0F172A] text-[#D4AF37] text-xs font-bold uppercase tracking-wider py-2 px-4 hover:bg-slate-800 rounded transition-colors"
                >
                  Configurar Meu Plano de Estudo
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredTasksForSelectedDay.map((task) => {
                  const currentStatus = getTaskStatus(task);
                  
                  return (
                    <div
                      key={task.id}
                      className={`
                        p-4 border transition-all flex flex-col md:flex-row md:items-start justify-between gap-4 rounded
                        ${currentStatus === 'concluida'
                          ? 'bg-slate-50/60 border-[#E5E1D8] opacity-75'
                          : currentStatus === 'em_andamento'
                          ? 'bg-white border-dashed border-[#D4AF37] shadow-sm ring-1 ring-[#D4AF37]/10'
                          : 'bg-white border-[#E5E1D8] hover:border-slate-400 shadow-sm'
                        }
                      `}
                    >
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        {/* Checkbox button toggles directly to Concluída or back to Pendente */}
                        <button
                          onClick={() => handleUpdateTaskStatus(
                            task.id, 
                            currentStatus === 'concluida' ? 'pendente' : 'concluida'
                          )}
                          className={`
                            mt-0.5 h-5 w-5 flex items-center justify-center border transition-all cursor-pointer rounded shrink-0
                            ${currentStatus === 'concluida'
                              ? 'bg-[#0F172A] border-[#0F172A] text-[#D4AF37]'
                              : 'border-slate-300 hover:border-[#D4AF37] bg-white'
                            }
                          `}
                          title={currentStatus === 'concluida' ? "Marcar como Pendente" : "Marcar como Concluída"}
                        >
                          {currentStatus === 'concluida' && (
                            <Check className="h-3.5 w-3.5 text-[#D4AF37]" />
                          )}
                        </button>

                        <div className="space-y-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[10px] font-extrabold text-[#D4AF37] uppercase tracking-wider">
                              {task.discipline}
                            </span>
                            
                            <span className="text-[9px] text-slate-400 font-mono flex items-center bg-[#FAF9F6] border border-[#E5E1D8] px-1.5 py-0.5 rounded">
                              <Clock className="h-2.5 w-2.5 mr-1 text-slate-400" />
                              {task.estimatedMinutes !== undefined ? task.estimatedMinutes : task.durationMinutes} min
                            </span>

                            <span className={`
                              text-[8px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wide
                              ${task.priority === 'Alta' 
                                ? 'bg-red-50 text-red-700 border border-red-100' 
                                : task.priority === 'Média'
                                ? 'bg-amber-50 text-amber-700 border border-amber-100'
                                : 'bg-blue-50 text-blue-700 border border-blue-100'
                              }
                            `}>
                              Prioridade {task.priority}
                            </span>
                          </div>

                          <h4 className={`text-base font-bold text-[#0F172A] ${currentStatus === 'concluida' ? 'line-through text-slate-400 font-normal' : ''}`}>
                            {task.title}
                          </h4>
                          <p className={`text-xs text-slate-600 leading-relaxed ${currentStatus === 'concluida' ? 'text-slate-400' : ''}`}>
                            {task.description}
                          </p>

                          {/* Action button to trigger active study session */}
                          {onStartStudyTask && (
                            <button
                              onClick={() => onStartStudyTask(task.id)}
                              className="mt-2 text-[10.5px] font-black uppercase tracking-wider text-[#0F172A] hover:text-[#D4AF37] flex items-center gap-1 cursor-pointer hover:underline transition-all"
                            >
                              <span>
                                {currentStatus === 'concluida' 
                                  ? 'Visualizar Notas / Resumo 🔍' 
                                  : currentStatus === 'em_andamento' 
                                  ? 'Retomar Sessão de Estudo ⚡' 
                                  : 'Iniciar Sessão de Estudo ⚡'}
                              </span>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Explicit Interactive 3-State Picker Button Segment */}
                      <div className="flex md:flex-col items-end justify-between md:justify-start gap-2 pt-2 md:pt-0 border-t md:border-t-0 border-[#F1F1ED] shrink-0">
                        <span className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block">Estado da Meta:</span>
                        
                        <div className="inline-flex bg-[#FAF9F6] border border-[#E5E1D8] p-0.5 rounded text-[10px] font-bold">
                          {(['pendente', 'em_andamento', 'concluida'] as const).map((status) => {
                            const isCurrent = currentStatus === status;
                            return (
                              <button
                                key={status}
                                onClick={() => handleUpdateTaskStatus(task.id, status)}
                                className={`
                                  px-2.5 py-1 uppercase tracking-wider font-bold transition-all text-[9px] cursor-pointer rounded-sm
                                  ${isCurrent
                                    ? status === 'concluida'
                                      ? 'bg-[#0F172A] text-[#D4AF37]'
                                      : status === 'em_andamento'
                                      ? 'bg-amber-100 text-amber-800'
                                      : 'bg-slate-200 text-slate-700'
                                    : 'text-slate-400 hover:text-slate-600'
                                  }
                                `}
                              >
                                {status === 'pendente' && 'Pendente'}
                                {status === 'em_andamento' && 'Estudando'}
                                {status === 'concluida' && 'OK'}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}
            
            <div className="mt-5 pt-4 border-t border-[#E5E1D8] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-xs">
              <span className="text-slate-500 font-medium italic">
                Nota: Suas alterações de conclusão sincronizam em tempo real com seu Cronograma e Progresso Geral.
              </span>
              <button
                onClick={() => onNavigateToTab('plano')}
                className="text-xs font-bold text-[#0F172A] hover:text-[#D4AF37] transition-colors flex items-center gap-1 uppercase tracking-wider"
              >
                <span>Ir para Cronograma Completo</span>
                <ArrowRight className="h-3 w-3" />
              </button>
            </div>
          </div>

          {/* ----------------- BLOCO 6 — DESEMPENHO GERAL (Premium com Sparkline) ----------------- */}
          <div className="bg-white border border-[#E5E1D8] p-6 shadow-sm" id="section-overall-performance">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#E5E1D8] pb-4 mb-5">
              <div>
                <h3 className="text-xl font-serif font-bold text-[#0F172A] flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-[#D4AF37]" />
                  Desempenho Geral do Aluno
                </h3>
                <p className="text-xs text-slate-500">Indicadores consolidados extraídos do banco de questões e testes simulados</p>
              </div>
              <span className="text-[10px] font-bold text-[#D4AF37] bg-[#0F172A] px-2.5 py-1 uppercase tracking-widest mt-2 sm:mt-0 self-start">
                DADOS DE PROVA ATIVOS
              </span>
            </div>

            {/* Bento statistics grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-[#FAF9F6] border border-[#E5E1D8] p-4 text-center rounded relative group hover:border-[#D4AF37] transition-all">
                <span className="block text-3xl font-serif font-bold text-[#0F172A]">{overallQuizSuccessRate}%</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold block mt-1.5">Acerto em Questões</span>
                <div className="text-[9px] text-emerald-700 font-bold bg-emerald-50 px-1 py-0.5 rounded inline-block mt-1">Margem de Aprov.</div>
              </div>
              
              <div className="bg-[#FAF9F6] border border-[#E5E1D8] p-4 text-center rounded relative group hover:border-[#D4AF37] transition-all">
                <span className="block text-3xl font-serif font-bold text-[#0F172A]">{totalQuestionsAnswered}</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold block mt-1.5">Questões Respondidas</span>
                <div className="text-[9px] text-slate-400 font-mono inline-block mt-1">Banco de Dados Geral</div>
              </div>
              
              <div className="bg-[#FAF9F6] border border-[#E5E1D8] p-4 text-center rounded relative group hover:border-[#D4AF37] transition-all">
                <span className="block text-3xl font-serif font-bold text-[#0F172A]">{totalSimulatedDone}</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold block mt-1.5">Simulados Feitos</span>
                <div className="text-[9px] text-purple-700 font-bold bg-purple-50 px-1 py-0.5 rounded inline-block mt-1">Simulações Reais</div>
              </div>

              <div className="bg-[#FAF9F6] border border-[#E5E1D8] p-4 text-center rounded relative group hover:border-[#D4AF37] transition-all">
                <span className="block text-3xl font-serif font-bold text-[#0F172A]">{averageSimulatedScore}%</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold block mt-1.5">Média nos Simulados</span>
                <div className="text-[9px] text-amber-700 font-bold bg-amber-50 px-1 py-0.5 rounded inline-block mt-1">Meta: &gt; 60%</div>
              </div>
            </div>

            {/* Custom SVG Sparkline Trend Graph */}
            <div className="bg-[#FAF9F6] border border-[#E5E1D8] p-5 rounded space-y-4">
              <div className="flex justify-between items-center border-b border-[#E5E1D8] pb-2.5">
                <div>
                  <h4 className="text-xs uppercase tracking-widest font-extrabold text-[#0F172A]">Evolução de Notas Recentes</h4>
                  <p className="text-[10px] text-slate-400">Linha de aproveitamento percentual ao longo dos simulados</p>
                </div>
                <div className="flex items-center space-x-4 text-[10px] font-mono">
                  <div className="flex items-center space-x-1.5">
                    <span className="h-2.5 w-2.5 bg-[#D4AF37] rounded-full inline-block"></span>
                    <span className="text-slate-600">Seu Percentual</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="h-0.5 w-3 bg-red-400 border-t border-dashed inline-block"></span>
                    <span className="text-slate-500">Mínimo de Aprovação (50%)</span>
                  </div>
                </div>
              </div>

              {/* Responsive SVG Container */}
              <div className="w-full h-36 bg-white border border-[#E5E1D8] p-2 relative rounded flex items-end">
                {/* Visual Y-Axis markers */}
                <div className="absolute left-2 top-2 bottom-2 text-[9px] text-slate-300 font-mono flex flex-col justify-between select-none pointer-events-none border-r border-dashed border-slate-100 pr-2">
                  <span>100%</span>
                  <span>75%</span>
                  <span>50%</span>
                  <span>25%</span>
                  <span>0%</span>
                </div>

                {/* Drawn SVG Polyline Graph */}
                <svg className="w-full h-full pl-10 pr-6 pb-2 pt-4" viewBox="0 0 400 100" preserveAspectRatio="none">
                  {/* Grid Lines */}
                  <line x1="0" y1="25" x2="400" y2="25" stroke="#F1F1ED" strokeWidth="0.5" strokeDasharray="3,3" />
                  <line x1="0" y1="50" x2="400" y2="50" stroke="#F1F1ED" strokeWidth="0.5" />
                  <line x1="0" y1="75" x2="400" y2="75" stroke="#F1F1ED" strokeWidth="0.5" strokeDasharray="3,3" />

                  {/* Cutoff Limit Line (50% is 50px down from top in 100px viewBox) */}
                  <line x1="0" y1="50" x2="400" y2="50" stroke="#EF4444" strokeWidth="0.75" strokeDasharray="4,4" opacity="0.6" />

                  {/* Generate Path Coordinates */}
                  {(() => {
                    const totalPoints = simulatedHistory.length;
                    const step = 400 / (totalPoints - 1 || 1);
                    const coordinates = simulatedHistory.map((s, idx) => {
                      const x = idx * step;
                      // Percentage inverted since SVG 0 is top
                      const y = 100 - s.percentage;
                      return `${x},${y}`;
                    }).join(' ');

                    return (
                      <>
                        {/* Gradient Fill under path */}
                        <polygon
                          points={`0,100 ${coordinates} 400,100`}
                          fill="url(#gold-gradient)"
                          opacity="0.08"
                        />
                        {/* Define gradients */}
                        <defs>
                          <linearGradient id="gold-gradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#D4AF37" />
                            <stop offset="100%" stopColor="#FAF9F6" />
                          </linearGradient>
                        </defs>

                        {/* Polyline path */}
                        <polyline
                          fill="none"
                          stroke="#D4AF37"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          points={coordinates}
                        />

                        {/* Interactive Circle Dots */}
                        {simulatedHistory.map((s, idx) => {
                          const x = idx * step;
                          const y = 100 - s.percentage;
                          return (
                            <g key={idx} className="group/dot cursor-pointer">
                              <circle
                                cx={x}
                                cy={y}
                                r="4"
                                fill="#0F172A"
                                stroke="#D4AF37"
                                strokeWidth="2"
                                className="transition-all hover:r-6"
                              />
                              {/* Overlay values above dot */}
                              <text
                                x={x}
                                y={y - 8}
                                textAnchor="middle"
                                className="text-[8px] font-mono font-bold fill-[#0F172A]"
                              >
                                {s.percentage}%
                              </text>
                            </g>
                          );
                        })}
                      </>
                    );
                  })()}
                </svg>

                {/* X-Axis labels */}
                <div className="absolute bottom-1 left-12 right-6 flex justify-between text-[9px] text-slate-400 font-mono">
                  {simulatedHistory.map((s, idx) => (
                    <span key={idx}>{s.label}</span>
                  ))}
                </div>
              </div>

              {/* Best vs worst subject indicators */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="bg-white border border-[#E5E1D8] p-3 rounded flex items-center space-x-3">
                  <div className="h-8 w-8 rounded bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-sm shrink-0">
                    A+
                  </div>
                  <div>
                    <span className="text-[9px] uppercase tracking-wider text-slate-400 font-mono">Melhor Aproveitamento</span>
                    <h5 className="text-xs font-bold text-[#0F172A]">{bestSubject.discipline} • {bestSubject.rate}% de acertos</h5>
                  </div>
                </div>

                <div className="bg-white border border-[#E5E1D8] p-3 rounded flex items-center space-x-3">
                  <div className="h-8 w-8 rounded bg-red-50 text-red-600 flex items-center justify-center font-bold text-sm shrink-0">
                    D-
                  </div>
                  <div>
                    <span className="text-[9px] uppercase tracking-wider text-slate-400 font-mono">Maior Atenção Requerida</span>
                    <h5 className="text-xs font-bold text-[#0F172A]">{worstSubject.discipline} • {worstSubject.rate}% de acertos</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ----------------- BLOCO 7 — RADAR DE DIFICULDADES (Atenção prioritária) ----------------- */}
          <div className="bg-white border border-[#E5E1D8] p-6 shadow-sm" id="section-weaknesses-radar">
            <div className="flex items-center justify-between border-b border-[#E5E1D8] pb-4 mb-4">
              <div>
                <h3 className="text-xl font-serif font-bold text-[#0F172A] flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                  Matérias que Precisam de Atenção
                </h3>
                <p className="text-xs text-slate-500">Mapeamento automatizado de pontos vulneráveis detectados por seus erros</p>
              </div>
              <span className="text-[9px] font-bold text-red-700 bg-red-50 border border-red-100 px-2.5 py-1 uppercase tracking-wider rounded">
                ALERTA DE DESEMPENHO
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              <div className="border border-[#E5E1D8] p-4 bg-red-50/20 relative rounded flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] font-bold text-red-600 uppercase tracking-widest">Processo Penal</span>
                    <span className="h-2 w-2 rounded-full bg-red-600 animate-ping"></span>
                  </div>
                  <span className="text-xl font-serif font-bold text-[#0F172A] block mt-1.5">48% de Acerto</span>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                    Aproveitamento crítico em <strong>Recursos em Sentido Estrito (RESE)</strong> e prazos recursais no CPP.
                  </p>
                </div>
                <div className="mt-4 pt-2 border-t border-[#E5E1D8]/60 flex items-center justify-between text-[10px]">
                  <span className="font-semibold text-slate-500">Erro: Recursos Criminais</span>
                  <span className="text-red-700 font-extrabold uppercase text-[9px] bg-red-100 px-1.5 py-0.5 rounded">Urgente</span>
                </div>
              </div>

              <div className="border border-[#E5E1D8] p-4 bg-amber-50/20 relative rounded flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] font-bold text-amber-700 uppercase tracking-widest">Direito Tributário</span>
                    <span className="h-2 w-2 rounded-full bg-amber-400"></span>
                  </div>
                  <span className="text-xl font-serif font-bold text-[#0F172A] block mt-1.5">51% de Acerto</span>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                    Dificuldade recorrente no tema de <strong>Limitações Constitucionais ao Poder de Tributar</strong>.
                  </p>
                </div>
                <div className="mt-4 pt-2 border-t border-[#E5E1D8]/60 flex items-center justify-between text-[10px]">
                  <span className="font-semibold text-slate-500">Erro: Imunidades</span>
                  <span className="text-amber-700 font-extrabold uppercase text-[9px] bg-amber-100 px-1.5 py-0.5 rounded">Médio</span>
                </div>
              </div>

              <div className="border border-[#E5E1D8] p-4 bg-[#FAF9F6] relative rounded flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] font-bold text-[#D4AF37] uppercase tracking-widest">Ética Profissional</span>
                    <span className="h-2 w-2 rounded-full bg-slate-400"></span>
                  </div>
                  <span className="text-xl font-serif font-bold text-[#0F172A] block mt-1.5">Revisar Estatuto</span>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                    Embora o percentual médio seja alto, revisar <strong>Infrações e Sanções Disciplinares</strong> garante nota cheia.
                  </p>
                </div>
                <div className="mt-4 pt-2 border-t border-[#E5E1D8]/60 flex items-center justify-between text-[10px]">
                  <span className="font-semibold text-slate-500">Erro: Sanções</span>
                  <span className="text-slate-500 font-extrabold uppercase text-[9px] bg-slate-200 px-1.5 py-0.5 rounded">Prevenção</span>
                </div>
              </div>

            </div>

            <div className="mt-5 p-4 bg-[#FAF9F6] border border-[#E5E1D8] text-xs text-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3 rounded">
              <div className="flex items-center space-x-2.5">
                <Sparkles className="h-4 w-4 text-[#D4AF37] shrink-0" />
                <span>
                  <strong>Ação Sugerida da Inteligência:</strong> Resolver uma bateria rápida de 10 questões do tema <strong>Recursos no CPP</strong> hoje para neutralizar erros.
                </span>
              </div>
              <button
                onClick={() => onNavigateToTab('questoes')}
                className="bg-[#0F172A] hover:bg-slate-800 text-[#D4AF37] hover:text-white px-4 py-2 text-[10px] font-bold uppercase tracking-widest transition-colors shrink-0 rounded"
              >
                BATERIA DE QUESTÕES
              </button>
            </div>
          </div>

        </div>

        {/* COLUNA DIREITA (4 colunas no desktop) - Progresso Semanal, Revisão, Simulados, Avisos */}
        <div className="lg:col-span-4 space-y-8">
          
          {/* ----------------- BLOCO 9 — MOTIVAÇÃO E CONSTÂNCIA (Engajamento) ----------------- */}
          <div className="bg-[#0F172A] text-white p-6 relative overflow-hidden rounded border border-[#0F172A]" id="card-motivation-streak">
            <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-gradient-to-tr from-[#D4AF37]/10 to-transparent rounded-full pointer-events-none"></div>
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-3.5 mb-4">
              <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37]">Constância & Hábitos</span>
              <span className="text-[9px] uppercase font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-900 px-2 py-0.5 rounded flex items-center gap-1">
                <Flame className="h-3.5 w-3.5 fill-current text-amber-500 animate-pulse" />
                RITMO ATIVO
              </span>
            </div>

            <div className="space-y-4">
              <div className="flex items-baseline space-x-2">
                <span className="text-5xl font-serif font-extrabold text-[#D4AF37] tracking-tight">06</span>
                <span className="text-base font-serif italic text-slate-400">dias seguidos</span>
              </div>
              
              <p className="text-xs text-slate-300 leading-relaxed">
                Você manteve seu ritmo de estudo nos últimos 6 dias sem interrupções! A disciplina acumulada é o principal fator de aprovação na 1ª fase.
              </p>

              {/* Day tracker capsules */}
              <div className="flex justify-between gap-1 pt-2">
                {['S', 'T', 'Q', 'Q', 'S', 'S', 'D'].map((day, idx) => {
                  const isCompleted = idx < 6; // Streak is 6 days
                  const isToday = idx === 3; // Let's mark Thursday as today
                  return (
                    <div key={idx} className="flex-1 text-center">
                      <div className={`
                        h-7 flex items-center justify-center font-mono text-xs font-bold border rounded mb-1 transition-all
                        ${isCompleted 
                          ? 'bg-[#D4AF37] text-[#0F172A] border-[#D4AF37]' 
                          : 'bg-slate-900 text-slate-600 border-slate-800'
                        }
                        ${isToday ? 'ring-2 ring-amber-400 ring-offset-2 ring-offset-[#0F172A]' : ''}
                      `}>
                        {day}
                      </div>
                      <span className="text-[8px] text-slate-400 font-bold block truncate">
                        {isToday ? 'Hoje' : ''}
                      </span>
                    </div>
                  );
                })}
              </div>

              <div className="p-3 bg-slate-900 border border-slate-800 rounded">
                <div className="flex justify-between items-center text-xs mb-1.5">
                  <span className="font-bold text-slate-300">Meta de Estudo Diário:</span>
                  <span className="font-bold text-[#D4AF37]">3h</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded overflow-hidden">
                  <div className="bg-[#D4AF37] h-full transition-all" style={{ width: '85%' }}></div>
                </div>
                <span className="text-[9px] text-slate-400 block mt-1">Quase lá! Restam apenas 30 minutos para consolidar a meta de hoje.</span>
              </div>
            </div>
          </div>

          {/* ----------------- BLOCO 3 — PROGRESSO SEMANAL (Gráfico de Rosca) ----------------- */}
          <div className="bg-white border border-[#E5E1D8] p-6 shadow-sm" id="card-weekly-progress">
            <h3 className="text-sm font-bold uppercase tracking-widest text-[#0F172A] border-b border-[#E5E1D8] pb-3.5 mb-4">
              Meta e Progresso Semanal
            </h3>

            {/* Visual Circular indicator of task completion */}
            <div className="py-2 flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-[9px] text-slate-400 uppercase tracking-widest font-bold block">Conclusão do Cronograma</span>
                <span className="text-3xl font-serif font-extrabold text-[#0F172A]">{taskProgressPct}%</span>
                <p className="text-[10px] text-slate-500">
                  Completou <strong>{completedTasksCount}</strong> de <strong>{totalTasks}</strong> tarefas semanais cadastradas.
                </p>
              </div>

              {/* SVG circular progress */}
              <div className="relative flex items-center justify-center shrink-0">
                <svg className="w-16 h-16 transform -rotate-90">
                  <circle cx="32" cy="32" r="28" stroke="#FAF9F6" strokeWidth="4.5" fill="transparent" />
                  <circle 
                    cx="32" 
                    cy="32" 
                    r="28" 
                    stroke="#D4AF37" 
                    strokeWidth="4.5" 
                    fill="transparent" 
                    strokeDasharray={176} 
                    strokeDashoffset={176 - (176 * taskProgressPct) / 100}
                    className="transition-all duration-700 stroke-linecap-round"
                  />
                </svg>
                <span className="absolute text-[10px] font-mono font-bold text-[#0F172A]">
                  {completedTasksCount}/{totalTasks}
                </span>
              </div>
            </div>

            {/* Hours Study progress */}
            <div className="mt-5 pt-4 border-t border-[#E5E1D8] space-y-4">
              <div className="flex justify-between items-baseline">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Carga Horária Estudada</span>
                <span className="text-xs font-mono text-slate-500 font-bold">{progress.weeklyStudyHours}h / {progress.studyHoursGoal}h</span>
              </div>
              <div className="w-full bg-[#FAF9F6] border border-[#E5E1D8] h-3 overflow-hidden rounded-[2px]">
                <div 
                  className="bg-[#0F172A] h-full transition-all duration-500" 
                  style={{ width: `${Math.min(100, (progress.weeklyStudyHours / progress.studyHoursGoal) * 100)}%` }}
                />
              </div>

              {/* Micro counters for lectures and pdfs completed */}
              <div className="grid grid-cols-2 gap-3 pt-1 text-center">
                <div className="p-2.5 bg-[#FAF9F6] border border-[#E5E1D8] rounded">
                  <span className="block text-lg font-bold text-[#0F172A]">{completedLecturesCount}</span>
                  <span className="text-[9px] text-slate-500 uppercase tracking-widest font-semibold block">Aulas Assistidas</span>
                </div>
                <div className="p-2.5 bg-[#FAF9F6] border border-[#E5E1D8] rounded">
                  <span className="block text-lg font-bold text-[#0F172A]">{completedPDFsCount}</span>
                  <span className="text-[9px] text-slate-500 uppercase tracking-widest font-semibold block">PDFs Concluídos</span>
                </div>
              </div>

              {/* Study Hours Manual Logging Form */}
              <div className="bg-[#FAF9F6] border border-[#E5E1D8] p-4 rounded mt-4">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-600 block mb-2.5">
                  Registrar Carga de Estudo Manual
                </span>
                
                {/* Fast buttons */}
                <div className="flex gap-2 mb-3">
                  <button
                    onClick={() => handleQuickAdd(1)}
                    className="flex-1 bg-white hover:bg-[#0F172A] hover:text-white border border-[#E5E1D8] py-1.5 text-xs font-bold text-slate-700 transition-all cursor-pointer rounded flex items-center justify-center space-x-1"
                  >
                    <Plus className="h-3 w-3 text-[#D4AF37]" />
                    <span>+1 hora</span>
                  </button>
                  <button
                    onClick={() => handleQuickAdd(0.5)}
                    className="flex-1 bg-white hover:bg-[#0F172A] hover:text-white border border-[#E5E1D8] py-1.5 text-xs font-bold text-slate-700 transition-all cursor-pointer rounded flex items-center justify-center space-x-1"
                  >
                    <Plus className="h-3 w-3 text-[#D4AF37]" />
                    <span>+30 min</span>
                  </button>
                </div>

                {/* Custom numeric input */}
                <form onSubmit={handleCustomAddSubmit} className="flex gap-2">
                  <input
                    type="number"
                    step="0.1"
                    placeholder="Outra quantia (Ex: 1.5)"
                    value={customHours}
                    onChange={(e) => setCustomHours(e.target.value)}
                    className="flex-1 text-xs border border-[#E5E1D8] rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-[#D4AF37] bg-white text-slate-800"
                  />
                  <button
                    type="submit"
                    className="bg-[#0F172A] text-[#D4AF37] hover:text-white font-bold text-xs px-3.5 py-1.5 hover:bg-slate-800 transition-colors cursor-pointer rounded uppercase tracking-wider"
                  >
                    Add
                  </button>
                </form>

                {showLogSuccess && (
                  <div className="text-[10px] text-emerald-700 font-bold text-center mt-2 animate-pulse">
                    ✓ Horas de estudo registradas com sucesso!
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ----------------- BLOCO 4 — REVISÕES PENDENTES (SRS Inteligente) ----------------- */}
          <div className="bg-white border border-[#E5E1D8] p-6 shadow-sm" id="card-smart-reviews">
            <h3 className="text-sm font-bold uppercase tracking-widest text-[#0F172A] border-b border-[#E5E1D8] pb-3.5 mb-4">
              Revisão Espaçada (SRS)
            </h3>

            <div className="p-4 bg-red-50/20 border border-red-100 text-center space-y-3 rounded relative overflow-hidden">
              <div className="absolute top-0 right-0 h-10 w-10 bg-red-500/5 rounded-bl-full pointer-events-none"></div>
              
              <span className="text-[10px] text-red-600 uppercase tracking-widest font-bold block">Atrasadas e Agendadas</span>
              <span className="block text-4xl font-serif font-extrabold text-red-700">
                10 Fichas
              </span>
              <p className="text-xs text-slate-600 leading-relaxed max-w-xs mx-auto">
                Você possui <strong>3 revisões de 24h atrasadas</strong>! Resolva hoje para mitigar a curva do esquecimento de ontem.
              </p>
              
              <button
                onClick={() => onNavigateToTab('revisao')}
                className="w-full bg-[#0F172A] hover:bg-slate-800 text-[#D4AF37] hover:text-white font-bold text-xs py-2.5 px-4 rounded uppercase tracking-widest transition-all flex items-center justify-center space-x-2 shadow-sm"
              >
                <span>Revisar Fichas Agora</span>
                <ArrowRight className="h-3.5 w-3.5 text-[#D4AF37]" />
              </button>
            </div>

            {/* Systematic review boxes breakdown */}
            <div className="mt-4 space-y-2.5 text-xs text-slate-600">
              <div className="flex justify-between items-center border-b border-slate-50 pb-1.5">
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-red-600 inline-block animate-pulse"></span>
                  <span>⚡ Ciclo de 24h (Urgente)</span>
                </span>
                <span className="font-extrabold text-red-700 bg-red-50 border border-red-100 px-2 py-0.5 rounded text-[10px]">3 cartões</span>
              </div>
              <div className="flex justify-between items-center border-b border-slate-50 pb-1.5">
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-amber-500 inline-block"></span>
                  <span>🗓️ Ciclo de 7 dias</span>
                </span>
                <span className="font-extrabold text-amber-800 bg-amber-50 border border-amber-100 px-2 py-0.5 rounded text-[10px]">5 cartões</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-blue-500 inline-block"></span>
                  <span>📚 Ciclo de 30 dias</span>
                </span>
                <span className="font-extrabold text-slate-600 bg-slate-50 border border-slate-100 px-2 py-0.5 rounded text-[10px]">2 cartões</span>
              </div>
            </div>
          </div>

          {/* ----------------- BLOCO 5 — PRÓXIMO SIMULADO (Ações) ----------------- */}
          <div className="bg-[#FAF9F6] border border-[#E5E1D8] p-6 shadow-sm rounded" id="card-upcoming-simulated">
            <h3 className="text-sm font-bold uppercase tracking-widest text-[#0F172A] border-b border-[#E5E1D8] pb-3.5 mb-4">
              Simulado Oficial Agendado
            </h3>

            <div className="space-y-4">
              <div className="flex items-center justify-between text-[10px]">
                <span className="font-bold text-[#D4AF37] uppercase tracking-wider bg-[#0F172A] px-2 py-0.5 rounded">
                  1ª FASE OAB
                </span>
                <span className="font-mono text-slate-500 font-bold">Sábado, 27/06 às 08:00</span>
              </div>

              <div className="space-y-1">
                <h4 className="text-base font-serif font-bold text-[#0F172A]">
                  Simulado Diagnóstico Geral Especial
                </h4>
                <p className="text-xs text-slate-500 font-mono">Formulação: Padrão FGV Oficial • 80 Questões</p>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed">
                Recomendamos isolamento acústico de 4 horas sem consulta externa para mensurar fielmente seu tempo de prova por questão.
              </p>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => onNavigateToTab('simulados')}
                  className="bg-[#0F172A] hover:bg-slate-800 text-white font-bold text-xs py-2 px-3 transition-colors text-center uppercase tracking-widest rounded cursor-pointer"
                >
                  Iniciar Prova
                </button>
                <button
                  onClick={() => onNavigateToTab('simulados')}
                  className="bg-white hover:bg-slate-100 text-[#0F172A] border border-[#E5E1D8] font-bold text-xs py-2 px-3 transition-colors text-center uppercase tracking-widest rounded cursor-pointer"
                >
                  Ver Instruções
                </button>
              </div>
            </div>
          </div>

          {/* ----------------- BLOCO 8 — ATALHOS RÁPIDOS (Nav Fácil) ----------------- */}
          <div className="bg-white border border-[#E5E1D8] p-6 shadow-sm" id="card-quick-links">
            <h3 className="text-sm font-bold uppercase tracking-widest text-[#0F172A] border-b border-[#E5E1D8] pb-3.5 mb-4">
              Atalhos de Navegação Rápida
            </h3>

            <div className="grid grid-cols-2 gap-2.5">
              
              <button
                onClick={() => onNavigateToTab('fase1')}
                className="p-3.5 bg-[#FAF9F6] border border-[#E5E1D8] hover:border-[#D4AF37] transition-all text-left group rounded"
              >
                <BookOpen className="h-4.5 w-4.5 text-[#D4AF37] mb-2 group-hover:scale-110 transition-transform" />
                <span className="block text-xs font-bold text-[#0F172A]">1ª Fase</span>
                <span className="text-[9px] text-slate-400 block mt-0.5">Vídeos & PDFs</span>
              </button>

              <button
                onClick={() => onNavigateToTab('fase2')}
                className="p-3.5 bg-[#FAF9F6] border border-[#E5E1D8] hover:border-[#D4AF37] transition-all text-left group rounded"
              >
                <Award className="h-4.5 w-4.5 text-[#D4AF37] mb-2 group-hover:scale-110 transition-transform" />
                <span className="block text-xs font-bold text-[#0F172A]">2ª Fase</span>
                <span className="text-[9px] text-slate-400 block mt-0.5">Roteiros Práticos</span>
              </button>

              <button
                onClick={() => onNavigateToTab('questoes')}
                className="p-3.5 bg-[#FAF9F6] border border-[#E5E1D8] hover:border-[#D4AF37] transition-all text-left group rounded"
              >
                <HelpCircle className="h-4.5 w-4.5 text-[#D4AF37] mb-2 group-hover:scale-110 transition-transform" />
                <span className="block text-xs font-bold text-[#0F172A]">Questões</span>
                <span className="text-[9px] text-slate-400 block mt-0.5">Banco de Provas</span>
              </button>

              <button
                onClick={() => onNavigateToTab('simulados')}
                className="p-3.5 bg-[#FAF9F6] border border-[#E5E1D8] hover:border-[#D4AF37] transition-all text-left group rounded"
              >
                <FileText className="h-4.5 w-4.5 text-[#D4AF37] mb-2 group-hover:scale-110 transition-transform" />
                <span className="block text-xs font-bold text-[#0F172A]">Simulados</span>
                <span className="text-[9px] text-slate-400 block mt-0.5">Controle de Tempo</span>
              </button>

              <button
                onClick={() => onNavigateToTab('revisao')}
                className="p-3.5 bg-[#FAF9F6] border border-[#E5E1D8] hover:border-[#D4AF37] transition-all text-left group rounded"
              >
                <Zap className="h-4.5 w-4.5 text-[#D4AF37] mb-2 group-hover:scale-110 transition-transform" />
                <span className="block text-xs font-bold text-[#0F172A]">Revisão</span>
                <span className="text-[9px] text-slate-400 block mt-0.5">Estudo por Fichas</span>
              </button>

              <button
                onClick={() => onNavigateToTab('pecas')}
                className="p-3.5 bg-[#FAF9F6] border border-[#E5E1D8] hover:border-[#D4AF37] transition-all text-left group rounded"
              >
                <BookOpenCheck className="h-4.5 w-4.5 text-[#D4AF37] mb-2 group-hover:scale-110 transition-transform" />
                <span className="block text-xs font-bold text-[#0F172A]">Peças Práticas</span>
                <span className="text-[9px] text-slate-400 block mt-0.5">Peças OAB 2ªF</span>
              </button>

            </div>
            
            <button
              onClick={() => onNavigateToTab('calendario')}
              className="mt-3.5 w-full bg-[#0F172A] hover:bg-slate-800 text-[#D4AF37] hover:text-white text-xs font-bold py-2.5 px-3 text-center uppercase tracking-widest rounded transition-colors flex items-center justify-center space-x-1.5"
            >
              <Calendar className="h-4.5 w-4.5 text-[#D4AF37]" />
              <span>Consultar Calendário OAB</span>
            </button>
          </div>

          {/* ----------------- BLOCO 10 — AVISOS IMPORTANTES (Mural Informativo) ----------------- */}
          <div className="bg-white border border-[#E5E1D8] p-6 shadow-sm rounded" id="section-important-alerts">
            <h3 className="text-sm font-bold uppercase tracking-widest text-[#0F172A] border-b border-[#E5E1D8] pb-3.5 mb-4 flex items-center gap-2">
              <Bell className="h-4.5 w-4.5 text-[#D4AF37]" />
              Mural de Avisos & Lembretes
            </h3>
            
            <div className="space-y-4">
              {alerts.map((al) => (
                <div 
                  key={al.id} 
                  className={`
                    p-4 bg-[#FAF9F6] border-y border-r border-[#E5E1D8] flex flex-col gap-2 rounded
                    ${al.type === 'critical' 
                      ? 'border-l-4 border-l-red-600' 
                      : al.type === 'success' 
                      ? 'border-l-4 border-l-[#D4AF37]' 
                      : 'border-l-4 border-l-sky-600'
                    }
                  `}
                >
                  <div className="flex items-center justify-between">
                    <span className={`
                      text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded
                      ${al.type === 'critical'
                        ? 'bg-red-50 text-red-700'
                        : al.type === 'success'
                        ? 'bg-[#FAF9F6] text-[#D4AF37] border border-[#D4AF37]/50'
                        : 'bg-sky-50 text-sky-700'
                      }
                    `}>
                      {al.tag}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{al.date}</span>
                  </div>

                  <h4 className="text-sm font-bold text-[#0F172A] leading-tight">
                    {al.title}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {al.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
