/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Milestone, 
  Map, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  TrendingUp, 
  Layers, 
  Sliders, 
  Compass, 
  FileText, 
  Briefcase, 
  CheckSquare, 
  Settings, 
  Activity, 
  ChevronRight, 
  Search, 
  Filter, 
  UserCheck, 
  Database, 
  BookOpen, 
  DollarSign, 
  HelpCircle, 
  Sparkles, 
  ClipboardList,
  Target,
  Users
} from 'lucide-react';

// Interfaces
interface BacklogItem {
  id: string;
  module: string;
  title: string;
  scope: 'MVP' | 'Pós-MVP';
  priority: 'A' | 'B' | 'C' | 'D';
  dependency: string;
  done: boolean;
  notes: string;
}

interface RiskItem {
  title: string;
  probability: 'Alta' | 'Média' | 'Baixa';
  impact: 'Alto' | 'Médio' | 'Baixo';
  mitigation: string;
  priority: 'Crítica' | 'Atenção' | 'Monitorar';
}

export default function OABRoadmapOfExecution() {
  const [activeTab, setActiveTab] = useState<'overview' | 'mvp' | 'backlog' | 'execution' | 'checklist' | 'risks' | 'governance'>('overview');
  
  // Interactive Team Scenario Toggle (BLOCO 18)
  const [teamScenario, setTeamScenario] = useState<'enxuta' | 'intermediaria' | 'estruturada'>('intermediaria');
  
  // Dynamic Priority Filter (BLOCO 5)
  const [priorityFilter, setPriorityFilter] = useState<'all' | 'A' | 'B' | 'C' | 'D'>('all');
  
  // Search state for backlog
  const [backlogSearch, setBacklogSearch] = useState<string>('');

  // Interactive Checklist (BLOCO 10)
  const [launchChecklist, setLaunchChecklist] = useState([
    { id: '1', category: 'Produto', task: 'Fluxo completo de cadastro e login de alunos', completed: true },
    { id: '2', category: 'Produto', task: 'Onboarding com inteligência de metas de estudo', completed: true },
    { id: '3', category: 'Produto', task: 'Plano adaptativo gerando dias e matérias corretamente', completed: true },
    { id: '4', category: 'Produto', task: 'Dashboard unificado com progresso e revisões ativas', completed: false },
    { id: '5', category: 'Conteúdo', task: 'Mínimo de 12 matérias com resumos estratégicos publicadas', completed: false },
    { id: '6', category: 'Conteúdo', task: 'Banco de dados com 1.200 questões cadastradas e revisadas', completed: true },
    { id: '7', category: 'Conteúdo', task: '2 Simulados completos da 1ª Fase estruturados', completed: false },
    { id: '8', category: 'Comercial', task: 'Paywall integrado com gateway de assinatura recorrente', completed: false },
    { id: '9', category: 'Comercial', task: 'Landings pages de captura de leads publicadas', completed: true },
    { id: '10', category: 'Operação', task: 'Painel admin operacional para cadastro de novas questões', completed: false },
    { id: '11', category: 'Operação', task: 'Integração de canais de suporte rápido por chat/e-mail', completed: false },
    { id: '12', category: 'Qualidade', task: 'Testes de usabilidade e performance em navegadores móveis', completed: false }
  ]);

  // Backlog Data (BLOCO 7)
  const [backlogItems, setBacklogItems] = useState<BacklogItem[]>([
    { id: 'AC01', module: 'Acesso e conta', title: 'Cadastro, Login & Redefinição de senha via email', scope: 'MVP', priority: 'A', dependency: 'Infra', done: true, notes: 'Garante o controle de acessos inicial.' },
    { id: 'OB01', module: 'Onboarding', title: 'Pesquisa de fase, área da 2ª fase e metas diárias', scope: 'MVP', priority: 'A', dependency: 'AC01', done: true, notes: 'Alimenta o algoritmo de geração de cronogramas.' },
    { id: 'DH01', module: 'Dashboard', title: 'Atalhos rápidos de estudo, metas do dia e progresso total', scope: 'MVP', priority: 'A', dependency: 'OB01', done: true, notes: 'Ponto focal da experiência diária do aluno.' },
    { id: 'PE01', module: 'Plano de estudos', title: 'Geração inteligente do calendário adaptativo', scope: 'MVP', priority: 'A', dependency: 'OB01', done: false, notes: 'Lógica central da trilha adaptativa de 3 Fases.' },
    { id: 'PE02', module: 'Plano de estudos', title: 'Replanejamento automático de dias em atraso', scope: 'MVP', priority: 'B', dependency: 'PE01', done: false, notes: 'Permite reajustar metas sem desespero.' },
    { id: 'BI01', module: 'Biblioteca', title: 'Listagem de matérias, videoaulas e resumos focados', scope: 'MVP', priority: 'A', dependency: 'PE01', done: true, notes: 'Núcleo pedagógico básico.' },
    { id: 'QU01', module: 'Questões', title: 'Resolução de questões com gabarito comentado imediato', scope: 'MVP', priority: 'A', dependency: 'BI01', done: true, notes: 'Treinamento focado por disciplina.' },
    { id: 'SI01', module: 'Simulados', title: 'Simulado diagnóstico com cronômetro integrado', scope: 'MVP', priority: 'A', dependency: 'QU01', done: false, notes: 'Termômetro essencial antes da prova.' },
    { id: 'RE01', module: 'Revisão inteligente', title: 'Algoritmo de repetição espaçada das matérias fracas', scope: 'MVP', priority: 'A', dependency: 'QU01', done: false, notes: 'Fase de Fixação ativa de conteúdo.' },
    { id: 'DE01', module: 'Desempenho', title: 'Gráficos de acertos/erros por disciplina e evolução semanal', scope: 'MVP', priority: 'B', dependency: 'QU01', done: false, notes: 'Feedback visual de performance.' },
    { id: 'CL01', module: 'Calendário OAB', title: 'Cronograma oficial de editais, inscrições e datas de provas', scope: 'MVP', priority: 'B', dependency: 'DH01', done: true, notes: 'Garante urgência e acompanhamento do edital.' },
    { id: 'F201', module: '2ª fase', title: 'Roteiros práticos de peças profissionais e discursivas', scope: 'MVP', priority: 'B', dependency: 'BI01', done: false, notes: 'Para alunos aprovados na 1ª Fase.' },
    { id: 'F202', module: '2ª fase', title: 'Esqueleto estrutural de peças por área de atuação', scope: 'Pós-MVP', priority: 'C', dependency: 'F201', done: false, notes: 'Ferramenta avançada para agilizar a redação.' },
    { id: 'AM01', module: 'Assinatura e monetização', title: 'Paywall integrado com planos, ofertas e cupons', scope: 'MVP', priority: 'A', dependency: 'AC01', done: false, notes: 'Essencial para a validação financeira do negócio.' },
    { id: 'CO01', module: 'Comunidade', title: 'Mural de discussões coletivas dos alunos', scope: 'Pós-MVP', priority: 'C', dependency: 'AC01', done: false, notes: 'Construção de comunidade.' },
    { id: 'SU01', module: 'Suporte', title: 'Canal direto de suporte técnico e pedagógico integrado', scope: 'MVP', priority: 'B', dependency: 'DH01', done: false, notes: 'Reduz churn e atende reclamações.' },
    { id: 'PA01', module: 'Painel admin', title: 'Painel de controle básico para gerenciar banco de questões e usuários', scope: 'MVP', priority: 'A', dependency: 'Infra', done: false, notes: 'Garante a operação pedagógica básica.' },
    { id: 'CG01', module: 'CRM e growth', title: 'Painel CRM de segmentações e réguas automáticas', scope: 'Pós-MVP', priority: 'C', dependency: 'PA01', done: false, notes: 'Evolução da máquina comercial.' },
    { id: 'AN01', module: 'Analytics', title: 'Acompanhamento de métricas de aquisição e conversão', scope: 'MVP', priority: 'B', dependency: 'AM01', done: false, notes: 'Monitoramento de conversões.' }
  ]);

  // Sprints de Execução (BLOCO 9)
  const SPRINTS = [
    {
      number: 1,
      title: 'Fundação & Onboarding',
      duration: '14 Dias',
      objective: 'Estruturar o banco de dados inicial e o fluxo de boas-vindas do aluno.',
      deliverables: [
        'Banco de dados relacional configurado.',
        'Fluxo de Cadastro, Login e Recuperação de senha.',
        'Onboarding interativo coletando fase e interesses.',
        'Esqueleto de navegação móvel e desktop.'
      ],
      criteria: 'O usuário se cadastra, responde às perguntas do onboarding e acessa a Home vazia sem erros.'
    },
    {
      number: 2,
      title: 'Núcleo Pedagógico - Estudo & Biblioteca',
      duration: '14 Dias',
      objective: 'Habilitar o aluno a visualizar o plano de estudos adaptativo e ler os resumos.',
      deliverables: [
        'Algoritmo gerador de Plano de Estudos OAB 3F.',
        'Layout do Dashboard adaptável por progresso.',
        'Área de materiais e videoaulas organizada por disciplina.',
        'Acompanhamento de tópicos concluídos.'
      ],
      criteria: 'O aluno visualiza suas metas semanais e consegue ler o material didático das disciplinas indicadas.'
    },
    {
      number: 3,
      title: 'Treinamento Prático - Questões & Revisões',
      duration: '14 Dias',
      objective: 'Permitir a resolução de questões e acionamento das réguas de revisão inteligente.',
      deliverables: [
        'Motor de resolução de questões com gabarito.',
        'Filtros avançados por matéria e banca (FGV).',
        'Sistema de controle de revisões ativas baseadas em erros.',
        'Logs de progresso acadêmico salvos por usuário.'
      ],
      criteria: 'O aluno responde uma questão, vê se acertou, e as questões erradas são listadas nas pendências de revisão.'
    },
    {
      number: 4,
      title: 'Simulados & Dashboard de Performance',
      duration: '14 Dias',
      objective: 'Entregar ferramentas de autoavaliação diagnóstica e gráficos de performance.',
      deliverables: [
        'Simulado cronometrado com 80 questões de 1ª Fase.',
        'Trilha adaptativa de simulado concluído.',
        'Gráficos de acertos e desempenho por matéria.',
        'Cálculo de pontos fortes e fracos automatizado.'
      ],
      criteria: 'O aluno completa o simulado dentro do tempo e recebe seu ranking de acertos por matéria.'
    },
    {
      number: 5,
      title: 'Validação Comercial - Paywalls & Assinaturas',
      duration: '14 Dias',
      objective: 'Integrar a monetização do aplicativo e criar limites para usuários gratuitos.',
      deliverables: [
        'Barreira de pagamento (Paywall) em recursos avançados.',
        'Checkout simplificado para plano de 1ª Fase e Completo.',
        'Régua de e-mails para carrinhos abandonados.',
        'Painel do usuário para gerenciamento de assinaturas.'
      ],
      criteria: 'Uma tentativa de acessar questões premium abre o paywall, e pagamentos efetuados liberam a conta imediatamente.'
    },
    {
      number: 6,
      title: 'Painel do Administrador & Operação Básica',
      duration: '14 Dias',
      objective: 'Permitir que a equipe pedagógica gerencie o app e atenda os alunos.',
      deliverables: [
        'Painel admin para listagem e edição de alunos.',
        'Interface para cadastro manual de questões e simulados.',
        'Gerenciador de banners promocionais e cupons.',
        'Módulo básico de suporte para chamados integrados.'
      ],
      criteria: 'O admin consegue criar uma nova questão e esta aparece instantaneamente no banco de dados do app.'
    }
  ];

  // Risks Data (BLOCO 15)
  const RISKS: RiskItem[] = [
    {
      title: 'Tentar construir escopo excessivo no MVP',
      probability: 'Alta',
      impact: 'Alto',
      mitigation: 'Congelar funcionalidades da V2 (como comunidade em tempo real e mentoria personalizada individual) e focar estritamente na resolução de questões e cronograma.',
      priority: 'Crítica'
    },
    {
      title: 'Atraso na produção de conteúdo pedagógico',
      probability: 'Média',
      impact: 'Alto',
      mitigation: 'Lançar o MVP focado apenas na 1ª Fase com 12 matérias essenciais já prontas. Subir as matérias acessórias (Ex: Filosofia) progressivamente durante as sprints.',
      priority: 'Atenção'
    },
    {
      title: 'Problemas de conversão no checkout de pagamento',
      probability: 'Média',
      impact: 'Médio',
      mitigation: 'Utilizar integração padrão e robusta com gateways de mercado (Stripe, ASAAS ou Eduzz) sem customização profunda de checkout no início.',
      priority: 'Atenção'
    },
    {
      title: 'Desengajamento rápido dos alunos gratuitos (Chun Precoce)',
      probability: 'Alta',
      impact: 'Médio',
      mitigation: 'Configurar réguas de push e e-mail automatizadas focadas em resgatar o aluno inativo no 2º e 4º dia sem acessar o aplicativo.',
      priority: 'Monitorar'
    }
  ];

  // Dynamic Team Scenario impact computations (BLOCO 18)
  const computedScenarioDetails = useMemo(() => {
    switch (teamScenario) {
      case 'enxuta':
        return {
          title: 'Cenário 1 — Operação Enxuta (Foco em Agilidade)',
          description: 'Voltado para equipes de 1-2 desenvolvedores e 1 produtor de conteúdo. MVP focado puramente na 1ª Fase, com banco de questões básico e plano estático de 90 dias.',
          weeksToLaunch: '6 a 8 semanas',
          mvpScope: 'Apenas 1ª Fase, sem suporte a Peças de 2ª Fase, sem painel de métricas avançado. Suporte integrado via botão simples do WhatsApp.',
          adminNeeds: 'Apenas importador manual em massa via arquivo CSV (sem telas ricas de cadastro).'
        };
      case 'estruturada':
        return {
          title: 'Cenário 3 — Operação Estruturada (Lançamento de Grande Porte)',
          description: 'Time robusto de desenvolvimento, design e equipe pedagógica dedicada. MVP avançado cobrindo 1ª e 2ª Fase simultaneamente, com infraestrutura de CRM completa.',
          weeksToLaunch: '12 a 16 semanas',
          mvpScope: '1ª e 2ª fase com área do aluno premium, controle de revisões inteligente por IA, painel de BI de desempenho avançado e checkout multi-oferta.',
          adminNeeds: 'Admin completo com CRUD avançado de questões, controle financeiro integrado e CRM comercial completo.'
        };
      case 'intermediaria':
      default:
        return {
          title: 'Cenário 2 — Operação Intermediária (Recomendado)',
          description: 'Equipe de 3-4 profissionais. Foco em validar o método adaptativo com excelente experiência de onboarding, banco de questões robusto e paywall integrado.',
          weeksToLaunch: '8 a 10 semanas',
          mvpScope: '1ª Fase completa + esqueleto prático básico para a 2ª Fase. Dashboard funcional de desempenho e suporte básico por chat integrado.',
          adminNeeds: 'Admin básico para cadastro de questões e acompanhamento simples de faturamento e assinaturas.'
        };
    }
  }, [teamScenario]);

  // Filter Backlog items
  const filteredBacklog = useMemo(() => {
    return backlogItems.filter(item => {
      const matchesSearch = item.title.toLowerCase().includes(backlogSearch.toLowerCase()) || 
                            item.module.toLowerCase().includes(backlogSearch.toLowerCase());
      const matchesPriority = priorityFilter === 'all' || item.priority === priorityFilter;
      return matchesSearch && matchesPriority;
    });
  }, [backlogItems, backlogSearch, priorityFilter]);

  // Statistics for backlog progress
  const backlogStats = useMemo(() => {
    const total = backlogItems.length;
    const mvpTotal = backlogItems.filter(i => i.scope === 'MVP').length;
    const mvpDone = backlogItems.filter(i => i.scope === 'MVP' && i.done).length;
    const posMvpTotal = backlogItems.filter(i => i.scope === 'Pós-MVP').length;
    
    return {
      total,
      mvpTotal,
      mvpDone,
      percentMvpDone: Math.round((mvpDone / mvpTotal) * 100),
      posMvpTotal
    };
  }, [backlogItems]);

  // Toggle item in backlog
  const toggleBacklogItem = (id: string) => {
    setBacklogItems(prev => prev.map(item => 
      item.id === id ? { ...item, done: !item.done } : item
    ));
  };

  // Toggle checklist item
  const toggleChecklist = (id: string) => {
    setLaunchChecklist(prev => prev.map(item => 
      item.id === id ? { ...item, completed: !item.completed } : item
    ));
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8 font-sans text-left" id="roadmap-main-container">
      {/* Editorial Header */}
      <div className="border-b border-oab-accent/30 pb-6 mb-8">
        <div className="flex items-center space-x-2 text-oab-accent font-mono text-xs uppercase tracking-widest mb-1.5 font-bold">
          <Milestone className="h-4 w-4 text-oab-accent" />
          <span>Direcionamento Estratégico de Produto</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-display font-bold tracking-tight text-slate-900 leading-tight">
          Roadmap de Execução OAB 3F
        </h1>
        <p className="text-slate-600 mt-2 max-w-4xl text-sm sm:text-base leading-relaxed">
          O plano de ação prático e cronológico para tirar a plataforma do papel. Organize o backlog funcional do MVP, priorize tarefas críticas, 
          mitigue riscos de entrega, gerencie sprints e controle o checklist operacional de lançamento.
        </p>
      </div>

      {/* Main Navigation Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-px" id="roadmap-subtabs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'overview' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Compass className="h-4 w-4" />
          <span>Visão Geral & Fases</span>
        </button>
        <button
          onClick={() => setActiveTab('mvp')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'mvp' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Target className="h-4 w-4" />
          <span>Definição do MVP</span>
        </button>
        <button
          onClick={() => setActiveTab('backlog')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'backlog' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Layers className="h-4 w-4" />
          <span>Backlog de Módulos</span>
        </button>
        <button
          onClick={() => setActiveTab('execution')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'execution' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Sliders className="h-4 w-4" />
          <span>Planejamento de Sprints</span>
        </button>
        <button
          onClick={() => setActiveTab('checklist')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'checklist' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <CheckSquare className="h-4 w-4" />
          <span>Checklist Lançamento</span>
        </button>
        <button
          onClick={() => setActiveTab('risks')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'risks' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <AlertTriangle className="h-4 w-4" />
          <span>Riscos & Gargalos</span>
        </button>
        <button
          onClick={() => setActiveTab('governance')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'governance' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Settings className="h-4 w-4" />
          <span>Governança & V2</span>
        </button>
      </div>

      {/* ==========================================
          TAB 1: VISÃO GERAL & FASES (BLOCO 1 & 6)
          ========================================== */}
      {activeTab === 'overview' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Executive Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-5 border border-slate-200 shadow-sm space-y-2">
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500 block">Camada Crítica (Fase 1 e 2)</span>
              <h4 className="text-base font-bold text-slate-900">Fundação & Núcleo Pedagógico</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Módulos essenciais de cadastro, geração do plano adaptativo diário, leitura de resumos pedagógicos e motor de resolução de questões. Sem isso, o produto não existe.
              </p>
              <span className="inline-block text-[10px] font-mono font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded uppercase mt-2">ESSENCIAL MVP</span>
            </div>

            <div className="bg-white p-5 border border-slate-200 shadow-sm space-y-2">
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500 block">Camada Monetizável (Fase 3)</span>
              <h4 className="text-base font-bold text-slate-900">Assinaturas, Paywalls & Checkout</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Bloqueio inteligente de recursos avançados, apresentação da tabela de planos (1ª, 2ª Fase e Completo) e integração simples com checkout para validação do faturamento.
              </p>
              <span className="inline-block text-[10px] font-mono font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded uppercase mt-2">CRÍTICO LANÇAMENTO</span>
            </div>

            <div className="bg-white p-5 border border-slate-200 shadow-sm space-y-2">
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500 block">Camada Avançada (Fase 4 e 5)</span>
              <h4 className="text-base font-bold text-slate-900">CRM Comercial & 2ª Fase</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Trilhas práticas avançadas por área (Penal, Tributário, etc.), murais de fóruns comunitários, réguas avançadas automatizadas de retargeting e suporte unificado.
              </p>
              <span className="inline-block text-[10px] font-mono font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded uppercase mt-2">PÓS-MVP / EXPANSÃO</span>
            </div>
          </div>

          {/* Interactive Construction Phases Timeline (BLOCO 6 & 7) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-lg font-display font-bold text-slate-900 border-b border-slate-100 pb-3">Linha do Tempo: Fases de Construção do OAB 3F</h3>
            
            <div className="relative border-l-2 border-slate-200 ml-4 pl-6 space-y-8 py-2 font-sans text-xs">
              {/* Phase 1 */}
              <div className="relative">
                <span className="absolute -left-[31px] top-0.5 h-4 w-4 rounded-full bg-[#0F172A] border-4 border-white flex items-center justify-center"></span>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-sm text-slate-950">Fase 1: Fundação Básica do Aplicativo</span>
                    <span className="text-[9px] font-mono font-bold bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded">Sprints 1 e 2</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed max-w-4xl">
                    Foco em criar a estrutura de banco de dados relacional, o onboarding do estudante (coletando interesses, fase de prova e horários livres) e o esqueleto de rotas de navegação. Criação da primeira versão do dashboard pessoal.
                  </p>
                  <div className="flex flex-wrap gap-2 pt-1 text-[10px]">
                    <span className="bg-slate-50 text-slate-500 px-2 py-0.5 border border-slate-100 rounded font-semibold">Autenticação de Usuários</span>
                    <span className="bg-slate-50 text-slate-500 px-2 py-0.5 border border-slate-100 rounded font-semibold">Pesquisa de Onboarding</span>
                    <span className="bg-slate-50 text-slate-500 px-2 py-0.5 border border-slate-100 rounded font-semibold">Tabelas Relacionais</span>
                  </div>
                </div>
              </div>

              {/* Phase 2 */}
              <div className="relative">
                <span className="absolute -left-[31px] top-0.5 h-4 w-4 rounded-full bg-[#0F172A] border-4 border-white flex items-center justify-center"></span>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-sm text-slate-950">Fase 2: O Núcleo Pedagógico Ativo (MVP)</span>
                    <span className="text-[9px] font-mono font-bold bg-rose-100 text-rose-800 px-1.5 py-0.2 rounded">Sprints 3 e 4</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed max-w-4xl">
                    Construção da lógica de geração de cronogramas inteligentes, módulo de leitura dos resumos das matérias prioritárias, biblioteca de videoaulas, motor de resolução de questões (banca FGV) e algoritmos de controle de revisões espaçadas.
                  </p>
                  <div className="flex flex-wrap gap-2 pt-1 text-[10px]">
                    <span className="bg-rose-50 text-rose-700 px-2 py-0.5 border border-rose-100 rounded font-semibold">Geração de Cronograma</span>
                    <span className="bg-rose-50 text-rose-700 px-2 py-0.5 border border-rose-100 rounded font-semibold">Resolução de Questões</span>
                    <span className="bg-rose-50 text-rose-700 px-2 py-0.5 border border-rose-100 rounded font-semibold">Repetição Espaçada</span>
                  </div>
                </div>
              </div>

              {/* Phase 3 */}
              <div className="relative">
                <span className="absolute -left-[31px] top-0.5 h-4 w-4 rounded-full bg-amber-500 border-4 border-white flex items-center justify-center"></span>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-sm text-slate-950">Fase 3: Comercialização & Gateway de Lançamento</span>
                    <span className="text-[9px] font-mono font-bold bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded">Sprint 5</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed max-w-4xl">
                    Implementação dos paywalls e bloqueio de funcionalidades após limite do plano gratuito. Telas de planos integradas, fluxo de checkout limpo com gateway confiável, criação de cupons promocionais e relatórios acadêmico-comerciais básicos.
                  </p>
                  <div className="flex flex-wrap gap-2 pt-1 text-[10px]">
                    <span className="bg-amber-50 text-amber-700 px-2 py-0.5 border border-amber-100 rounded font-semibold">Bloqueio de Paywall</span>
                    <span className="bg-amber-50 text-amber-700 px-2 py-0.5 border border-amber-100 rounded font-semibold">Checkout de Assinatura</span>
                    <span className="bg-amber-50 text-amber-700 px-2 py-0.5 border border-amber-100 rounded font-semibold">Cupons Promocionais</span>
                  </div>
                </div>
              </div>

              {/* Phase 4 */}
              <div className="relative">
                <span className="absolute -left-[31px] top-0.5 h-4 w-4 rounded-full bg-slate-300 border-4 border-white flex items-center justify-center"></span>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-sm text-slate-500">Fase 4: Painel Admin & Operação Escalável</span>
                    <span className="text-[9px] font-mono font-bold bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded">Sprint 6</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed max-w-4xl">
                    Criação do Painel do Administrador integrado para que a equipe pedagógica cadastre novas questões, visualize o andamento e o progresso das turmas, configure banners contextuais e preste suporte rápido.
                  </p>
                  <div className="flex flex-wrap gap-2 pt-1 text-[10px]">
                    <span className="bg-slate-50 text-slate-500 px-2 py-0.5 border border-slate-100 rounded font-semibold">Gestão de Questões</span>
                    <span className="bg-slate-50 text-slate-500 px-2 py-0.5 border border-slate-100 rounded font-semibold">Suporte de Alunos</span>
                    <span className="bg-slate-50 text-slate-500 px-2 py-0.5 border border-slate-100 rounded font-semibold">Controle Financeiro</span>
                  </div>
                </div>
              </div>

              {/* Phase 5 */}
              <div className="relative">
                <span className="absolute -left-[31px] top-0.5 h-4 w-4 rounded-full bg-slate-200 border-4 border-white flex items-center justify-center"></span>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-sm text-slate-400">Fase 5: Expansão, Comunidade & V2</span>
                    <span className="text-[9px] font-mono font-bold bg-slate-100 text-slate-400 px-1.5 py-0.2 rounded">Pós-Lançamento</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed max-w-4xl">
                    Melhorias de gamificação avançada, comunidade interativa integrada por turmas, módulo avançado de 2ª fase robusto com IA de correção para peças de Direito Constitucional, Penal, Tributário e Civil, e funis inteligentes de Upsell para Mentoria VIP.
                  </p>
                  <div className="flex flex-wrap gap-2 pt-1 text-[10px]">
                    <span className="bg-slate-50 text-slate-400 px-2 py-0.5 border border-slate-100 rounded font-semibold">IA Corretora de Peças</span>
                    <span className="bg-slate-50 text-slate-400 px-2 py-0.5 border border-slate-100 rounded font-semibold">Gamificação & Ranking</span>
                    <span className="bg-slate-50 text-slate-400 px-2 py-0.5 border border-slate-100 rounded font-semibold">Fóruns de Discussão</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 2: DEFINIÇÃO DO MVP (BLOCO 2, 3, 4, 11, 12, 13)
          ========================================== */}
      {activeTab === 'mvp' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* MVP Strategy Overview (BLOCO 2) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-lg font-display font-bold text-slate-900 border-b border-slate-100 pb-3">A Estratégia do Mínimo Produto Viável (MVP)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs font-sans">
              <div className="space-y-2.5">
                <span className="text-[10px] uppercase font-mono text-slate-400 font-bold block">1. Objetivo Central do MVP</span>
                <p className="text-slate-700 leading-relaxed text-sm">
                  Validar a aderência prática do método OAB 3F (Estudo Direcionado + Resolução Diária + Revisão Inteligente) por estudantes em preparação ativa para a 1ª Fase do Exame da Ordem, gerando receita inicial com planos recorrentes e coletando métricas de retenção.
                </p>
              </div>
              <div className="space-y-2.5">
                <span className="text-[10px] uppercase font-mono text-slate-400 font-bold block">2. Perfil de Usuário Alvo do MVP</span>
                <p className="text-slate-700 leading-relaxed text-sm">
                  Bacharel ou estudante de Direito cursando o último ano da faculdade, com pouco tempo livre diário, que busca organização pedagógica, foco no que realmente cai e uma plataforma direta para treinar questões comentadas da banca FGV.
                </p>
              </div>
            </div>
          </div>

          {/* MVP Content & Commercial Scope (BLOCO 11 & 12) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Pedagogical Minimum Content */}
            <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
                <BookOpen className="h-5 w-5 text-oab-accent" />
                <h3 className="text-base font-display font-bold text-slate-900">Conteúdo Mínimo Viável (Foco Pedagógico)</h3>
              </div>
              
              <p className="text-xs text-slate-600">
                O equilíbrio ideal entre valor percebido e velocidade de lançamento:
              </p>

              <div className="space-y-2 font-sans text-xs">
                <div className="flex items-start space-x-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="font-bold text-slate-950">12 Disciplinas Essenciais</span>
                    <p className="text-slate-500 text-[10px]">Foco nas matérias com maior número de questões no edital (Ética, Constitucional, Administrativo, Civil, Processo Civil, Penal, Processo Penal, Tributário, Trabalho, Processo do Trabalho, Consumidor, ECA).</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="font-bold text-slate-950">1.200 Questões Comentadas</span>
                    <p className="text-slate-500 text-[10px]">Pelo menos 100 questões comentadas detalhadamente pela equipe pedagógica para cada matéria prioritária.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="font-bold text-slate-950">2 Simulados Diagnósticos de 1ª Fase</span>
                    <p className="text-slate-500 text-[10px]">Simulados contendo as 80 questões distribuídas conforme peso oficial das disciplinas da prova da FGV.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="font-bold text-slate-950">Esqueleto Básico de 2ª Fase</span>
                    <p className="text-slate-500 text-[10px]">Inclusão de área básica de roteiros estruturais de peças apenas para Direito Tributário, Penal e Civil no MVP.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Commercial Minimum Content */}
            <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
                <DollarSign className="h-5 w-5 text-oab-accent" />
                <h3 className="text-base font-display font-bold text-slate-900">Mínimo Comercial Viável (Máquina Comercial)</h3>
              </div>
              
              <p className="text-xs text-slate-600">
                A infraestrutura mínima de vendas necessária para viabilizar as conversões comerciais:
              </p>

              <div className="space-y-2 font-sans text-xs">
                <div className="flex items-start space-x-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="font-bold text-slate-950">Tabela de Planos no App</span>
                    <p className="text-slate-500 text-[10px]">Apresentação unificada do Plano de 1ª Fase, Plano de 2ª Fase e Plano Completo OAB 3F.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="font-bold text-slate-950">Paywalls de Questões Premium</span>
                    <p className="text-slate-500 text-[10px]">Barreiras de pagamento impedindo o acesso à resolução de mais de 10 questões diárias por contas de plano gratuito.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="font-bold text-slate-950">Régua Básica de Conversão por E-mail</span>
                    <p className="text-slate-500 text-[10px]">Disparos automáticos de boas-vindas ao criar conta e lembrete de carrinho abandonado após iniciar checkout de assinatura.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="font-bold text-slate-950">Banners de Upgrade Contextuais</span>
                    <p className="text-slate-500 text-[10px]">Botão de upgrade permanente no menu lateral e banners informando benefícios do plano premium durante o estudo.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* MVP vs PÓS-MVP Breakdown table (BLOCO 3 & 4) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-base font-display font-bold text-slate-900 border-b border-slate-100 pb-2">O que Entra vs. O que Fica de Fora do MVP</h3>
            <p className="text-xs text-slate-600">
              Para proteger o prazo de entrega, delineamos com clareza a barreira técnica entre a primeira versão funcional e as evoluções futuras.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-sans text-xs">
              <div className="border border-emerald-500/10 bg-emerald-50/20 p-4 rounded space-y-3">
                <span className="font-bold text-emerald-800 flex items-center space-x-1.5 uppercase font-mono text-[10px]">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  <span>DENTRO DO MVP (Prioridade Máxima)</span>
                </span>
                <ul className="space-y-2 text-slate-700">
                  <li className="flex items-start space-x-1.5">
                    <span className="font-bold text-slate-900">•</span>
                    <span>Plano de estudos básico gerado via onboarding.</span>
                  </li>
                  <li className="flex items-start space-x-1.5">
                    <span className="font-bold text-slate-900">•</span>
                    <span>Resolução de questões com visualização de comentários.</span>
                  </li>
                  <li className="flex items-start space-x-1.5">
                    <span className="font-bold text-slate-900">•</span>
                    <span>Controle básico de revisões espaçadas pendentes.</span>
                  </li>
                  <li className="flex items-start space-x-1.5">
                    <span className="font-bold text-slate-900">•</span>
                    <span>Telas de paywall, integração de checkout e tabela de preços.</span>
                  </li>
                  <li className="flex items-start space-x-1.5">
                    <span className="font-bold text-slate-900">•</span>
                    <span>Painel admin básico para carregar novos arquivos CSV de questões.</span>
                  </li>
                </ul>
              </div>

              <div className="border border-rose-500/10 bg-rose-50/20 p-4 rounded space-y-3">
                <span className="font-bold text-rose-800 flex items-center space-x-1.5 uppercase font-mono text-[10px]">
                  <XCircle className="h-4 w-4 text-rose-600" />
                  <span>FORA DO MVP (Garantido para a V2/V3)</span>
                </span>
                <ul className="space-y-2 text-slate-700">
                  <li className="flex items-start space-x-1.5">
                    <span className="text-rose-600 font-bold">•</span>
                    <span>IA integrada para correção automática de peças da 2ª Fase.</span>
                  </li>
                  <li className="flex items-start space-x-1.5">
                    <span className="text-rose-600 font-bold">•</span>
                    <span>Fórum de discussões em tempo real para alunos (Comunidade).</span>
                  </li>
                  <li className="flex items-start space-x-1.5">
                    <span className="text-rose-600 font-bold">•</span>
                    <span>Módulo de Gamificação avançada com ranking de pontuação.</span>
                  </li>
                  <li className="flex items-start space-x-1.5">
                    <span className="text-rose-600 font-bold">•</span>
                    <span>Painel CRM de disparo de WhatsApp interno para leads.</span>
                  </li>
                  <li className="flex items-start space-x-1.5">
                    <span className="text-rose-600 font-bold">•</span>
                    <span>Replanejamento automático avançado de calendário por IA.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 3: BACKLOG DE MÓDULOS (BLOCO 5 & 7)
          ========================================== */}
      {activeTab === 'backlog' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Backlog stats */}
          <div className="bg-slate-50 border border-slate-200 p-4 rounded flex flex-wrap justify-between items-center gap-4 font-sans text-xs">
            <div className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-oab-accent" />
              <div>
                <span className="font-bold text-slate-900 block">Progresso do Backlog Técnico</span>
                <span className="text-slate-500 text-[10px]">Foco no MVP: {backlogStats.mvpDone} de {backlogStats.mvpTotal} entregas concluídas</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-center">
                <span className="text-lg font-bold text-slate-900 block font-mono">{backlogStats.percentMvpDone}%</span>
                <span className="text-[9px] uppercase font-mono text-slate-400 block">Pronto MVP</span>
              </div>
              <div className="text-center border-l border-slate-200 pl-4">
                <span className="text-lg font-bold text-slate-900 block font-mono">{backlogStats.posMvpTotal}</span>
                <span className="text-[9px] uppercase font-mono text-slate-400 block">Módulos V2</span>
              </div>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <h3 className="text-lg font-display font-bold text-slate-900">Backlog de Funcionalidades & Requisitos</h3>
              
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="Filtrar por nome ou módulo..."
                    value={backlogSearch}
                    onChange={(e) => setBacklogSearch(e.target.value)}
                    className="pl-9 pr-4 py-1.5 border border-slate-200 rounded text-xs focus:ring-1 focus:ring-oab-accent outline-none w-48 sm:w-64"
                  />
                </div>
              </div>
            </div>

            {/* Quick Priority Filter (BLOCO 5) */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-sans">
              <span className="font-bold text-slate-500 font-mono text-[10px]">Matriz de Prioridade:</span>
              <button
                onClick={() => setPriorityFilter('all')}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold transition-all ${
                  priorityFilter === 'all' 
                    ? 'bg-slate-900 text-white' 
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200/60'
                }`}
              >
                Todos
              </button>
              <button
                onClick={() => setPriorityFilter('A')}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold transition-all ${
                  priorityFilter === 'A' 
                    ? 'bg-rose-600 text-white' 
                    : 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-100/60'
                }`}
              >
                Prioridade A (Crítico MVP)
              </button>
              <button
                onClick={() => setPriorityFilter('B')}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold transition-all ${
                  priorityFilter === 'B' 
                    ? 'bg-amber-600 text-white' 
                    : 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-100/60'
                }`}
              >
                Prioridade B (Lançamento)
              </button>
              <button
                onClick={() => setPriorityFilter('C')}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold transition-all ${
                  priorityFilter === 'C' 
                    ? 'bg-indigo-600 text-white' 
                    : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-100/60'
                }`}
              >
                Prioridade C (Desejável V2)
              </button>
              <button
                onClick={() => setPriorityFilter('D')}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold transition-all ${
                  priorityFilter === 'D' 
                    ? 'bg-slate-500 text-white' 
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200/60'
                }`}
              >
                Prioridade D (Expansão)
              </button>
            </div>

            {/* Backlog Grid list */}
            <div className="overflow-x-auto border border-slate-100 rounded">
              <table className="w-full text-left border-collapse text-xs font-sans">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100 text-[10px] uppercase font-mono text-slate-500">
                    <th className="p-3">ID</th>
                    <th className="p-3">Módulo</th>
                    <th className="p-3">Entregável / Tarefa</th>
                    <th className="p-3 text-center">Fase</th>
                    <th className="p-3 text-center">Prioridade</th>
                    <th className="p-3">Dependências</th>
                    <th className="p-3 text-center">Concluído</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredBacklog.map((item) => {
                    let pBadge = 'bg-slate-100 text-slate-700';
                    if (item.priority === 'A') pBadge = 'bg-rose-100 text-rose-800 font-bold';
                    if (item.priority === 'B') pBadge = 'bg-amber-100 text-amber-800 font-bold';
                    if (item.priority === 'C') pBadge = 'bg-indigo-100 text-indigo-800';

                    return (
                      <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="p-3 font-mono font-bold text-slate-500">{item.id}</td>
                        <td className="p-3 font-semibold text-slate-800">{item.module}</td>
                        <td className="p-3">
                          <span className="font-bold text-slate-950 block">{item.title}</span>
                          <span className="text-[10px] text-slate-400 block">{item.notes}</span>
                        </td>
                        <td className="p-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                            item.scope === 'MVP' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {item.scope}
                          </span>
                        </td>
                        <td className="p-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] ${pBadge}`}>
                            {item.priority}
                          </span>
                        </td>
                        <td className="p-3 text-slate-500 font-mono text-[10px]">{item.dependency}</td>
                        <td className="p-3 text-center">
                          <button
                            onClick={() => toggleBacklogItem(item.id)}
                            className={`p-1 rounded transition-colors ${
                              item.done ? 'text-emerald-600 hover:text-emerald-700' : 'text-slate-300 hover:text-slate-400'
                            }`}
                          >
                            <CheckCircle2 className="h-5 w-5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 4: PLANEJAMENTO DE SPRINTS (BLOCO 8 & 9)
          ========================================== */}
      {activeTab === 'execution' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Ordem de Implementação Técnica (BLOCO 8) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-lg font-display font-bold text-slate-900 border-b border-slate-100 pb-3">Ordem Ideal de Construção & Validação de Produto</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Não tente construir as telas sem planejar a infraestrutura de dados primeiro. Abaixo apresentamos o fluxo operacional sequencial recomendado para os desenvolvedores:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-sans text-xs">
              <div className="p-3.5 border border-slate-200 bg-slate-50/50 rounded-lg space-y-2">
                <span className="font-bold text-rose-700 font-mono text-[10px] uppercase block">1º CONSTRUIR</span>
                <span className="font-bold text-slate-950 block">A Base Relacional & Onboarding</span>
                <p className="text-slate-500 text-[10px] leading-tight">Implementar a estrutura do banco de dados (Drizzle ORM ou Firestore) e o fluxo de cadastro e login. Coletar interesses de prova no onboarding.</p>
              </div>

              <div className="p-3.5 border border-slate-200 bg-slate-50/50 rounded-lg space-y-2">
                <span className="font-bold text-amber-700 font-mono text-[10px] uppercase block">2º CONECTAR</span>
                <span className="font-bold text-slate-950 block">Plano de Estudos & Conteúdo</span>
                <p className="text-slate-500 text-[10px] leading-tight">Vincular o onboarding à geração automática do cronograma em 3 Fases. Carregar resumos didáticos e banco de dados de questões comentadas.</p>
              </div>

              <div className="p-3.5 border border-slate-200 bg-slate-50/50 rounded-lg space-y-2">
                <span className="font-bold text-indigo-700 font-mono text-[10px] uppercase block">3º VALIDAR</span>
                <span className="font-bold text-slate-950 block">Bloqueio de Plano & Gateway</span>
                <p className="text-slate-500 text-[10px] leading-tight">Configurar os paywalls limitando questões gratuitas. Integrar a monetização recorrente e telas de faturamento.</p>
              </div>

              <div className="p-3.5 border border-slate-200 bg-slate-50/50 rounded-lg space-y-2">
                <span className="font-bold text-emerald-700 font-mono text-[10px] uppercase block">4º SOFISTICAR</span>
                <span className="font-bold text-slate-950 block">CRM, Comunidade & IA</span>
                <p className="text-slate-500 text-[10px] leading-tight">Adicionar monitoramento de inatividade no CRM, disparador de e-mails/WhatsApp contextuais e a IA corretora de peças práticas.</p>
              </div>
            </div>
          </div>

          {/* Sprints Timeline list */}
          <div className="space-y-6">
            <h3 className="text-lg font-display font-bold text-slate-900 border-b border-slate-100 pb-3">Cronograma de Sprints (Entrega Quinzenal)</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-sans text-xs">
              {SPRINTS.map((sprint, idx) => (
                <div key={idx} className="bg-white p-5 border border-slate-200 shadow-sm space-y-3 relative overflow-hidden">
                  <div className="absolute top-0 right-0 bg-[#0F172A] text-white font-mono font-bold text-xs px-3 py-1 uppercase rounded-bl">
                    Sprint {sprint.number}
                  </div>
                  
                  <div className="space-y-1 pr-14">
                    <span className="text-[10px] uppercase font-mono font-bold text-oab-accent">{sprint.duration}</span>
                    <h4 className="text-base font-bold text-slate-950">{sprint.title}</h4>
                    <p className="text-slate-600 text-[11px] leading-relaxed italic">"{sprint.objective}"</p>
                  </div>

                  <div className="border-t border-slate-100 pt-3 space-y-2">
                    <span className="font-bold text-slate-800 block text-[10px] uppercase tracking-wider">Entregáveis Críticos:</span>
                    <ul className="space-y-1.5 pl-4 text-slate-600 text-[11px] list-disc">
                      {sprint.deliverables.map((d, i) => (
                        <li key={i}>{d}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded border border-slate-100 space-y-1">
                    <span className="font-bold text-[#D4AF37] block text-[9px] uppercase font-mono tracking-wider">Critério de Pronto (QA):</span>
                    <p className="text-slate-500 text-[10px] leading-tight">{sprint.criteria}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 5: CHECKLIST DE LANÇAMENTO DO MVP (BLOCO 10)
          ========================================== */}
      {activeTab === 'checklist' && (
        <div className="space-y-8 animate-fade-in text-left">
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div className="space-y-1">
                <h3 className="text-lg font-display font-bold text-slate-900">Checklist Operacional Pré-Lançamento (MVP)</h3>
                <p className="text-xs text-slate-600">Acompanhe as metas que precisam estar com status verde para subirmos a aplicação com segurança para produção.</p>
              </div>
              
              <div className="text-right">
                <span className="text-[10px] uppercase font-mono text-slate-400 font-bold block">Progresso Operacional</span>
                <span className="text-2xl font-display font-extrabold text-[#D4AF37] font-mono">
                  {Math.round((launchChecklist.filter(c => c.completed).length / launchChecklist.length) * 100)}%
                </span>
              </div>
            </div>

            {/* Checklist lists by category */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {['Produto', 'Conteúdo', 'Comercial', 'Operação', 'Qualidade'].map((cat, idx) => {
                const items = launchChecklist.filter(i => i.category === cat);
                if (items.length === 0) return null;

                return (
                  <div key={idx} className="space-y-3 font-sans text-xs">
                    <span className="text-[10px] uppercase font-mono text-slate-400 font-bold block border-b border-slate-100 pb-1">{cat}</span>
                    <div className="space-y-2">
                      {items.map((item) => (
                        <div 
                          key={item.id} 
                          onClick={() => toggleChecklist(item.id)}
                          className="flex items-start space-x-3 p-2.5 border border-slate-100 bg-slate-50/50 hover:bg-slate-50 rounded cursor-pointer transition-colors"
                        >
                          <button
                            className={`p-0.5 rounded transition-colors shrink-0 mt-0.5 ${
                              item.completed ? 'text-emerald-600' : 'text-slate-300'
                            }`}
                          >
                            <CheckCircle2 className="h-4.5 w-4.5" />
                          </button>
                          <span className={`text-[11px] leading-snug ${
                            item.completed ? 'line-through text-slate-400' : 'font-bold text-slate-800'
                          }`}>
                            {item.task}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 6: RISCOS & GARGALOS (BLOCO 15)
          ========================================== */}
      {activeTab === 'risks' && (
        <div className="space-y-8 animate-fade-in text-left">
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-lg font-display font-bold text-slate-900 border-b border-slate-100 pb-3">Análise de Riscos de Implementação</h3>
            <p className="text-xs text-slate-600">
              Mapeamos os principais gargalos e armadilhas técnicas que podem atrasar a entrega ou comprometer o sucesso da operação inicial.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-sans text-xs">
              {RISKS.map((risk, idx) => (
                <div key={idx} className="p-4 border border-slate-200 bg-slate-50/50 rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-950 text-sm">{risk.title}</h4>
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase font-mono ${
                      risk.priority === 'Crítica' ? 'bg-rose-100 text-rose-800' : risk.priority === 'Atenção' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {risk.priority}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-[10px] border-t border-b border-slate-200/50 py-2">
                    <div>
                      <span className="text-slate-400 uppercase font-mono block">Probabilidade:</span>
                      <span className="font-bold text-slate-700">{risk.probability}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 uppercase font-mono block">Impacto Comercial:</span>
                      <span className="font-bold text-slate-700">{risk.impact}</span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-mono text-emerald-700 font-bold block">Plano de Mitigação Operacional:</span>
                    <p className="text-slate-600 text-[11px] leading-relaxed">{risk.mitigation}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 7: GOVERNANÇA, EQUIPE & V2 (BLOCO 14, 16, 17, 18, 19, 20)
          ========================================== */}
      {activeTab === 'governance' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Team Scenario Configurator (BLOCO 18) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <div className="border-b border-slate-100 pb-3 space-y-1">
              <h3 className="text-lg font-display font-bold text-slate-900">Plano de Execução por Escala de Equipe</h3>
              <p className="text-xs text-slate-600">Ajuste o tamanho do seu time operacional para simular o escopo e velocidade de lançamento viáveis.</p>
            </div>

            {/* Scenario Buttons */}
            <div className="flex flex-wrap gap-3 text-xs font-sans">
              <button
                onClick={() => setTeamScenario('enxuta')}
                className={`p-3 border text-left rounded-lg transition-all flex-1 min-w-[200px] space-y-1 ${
                  teamScenario === 'enxuta' 
                    ? 'border-[#D4AF37] bg-amber-50/10' 
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <span className="font-bold text-slate-900 block text-xs">Operação Enxuta (Cenário 1)</span>
                <span className="text-[10px] text-slate-500 block">Pouco time, foco total em MVP ultra-rápido para 1ª Fase.</span>
              </button>

              <button
                onClick={() => setTeamScenario('intermediaria')}
                className={`p-3 border text-left rounded-lg transition-all flex-1 min-w-[200px] space-y-1 ${
                  teamScenario === 'intermediaria' 
                    ? 'border-[#D4AF37] bg-amber-50/10' 
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <span className="font-bold text-slate-900 block text-xs">Operação Intermediária (Cenário 2)</span>
                <span className="text-[10px] text-slate-500 block">Equipe de 3-4 profissionais. Foco em UX e paywall ativo.</span>
              </button>

              <button
                onClick={() => setTeamScenario('estruturada')}
                className={`p-3 border text-left rounded-lg transition-all flex-1 min-w-[200px] space-y-1 ${
                  teamScenario === 'estruturada' 
                    ? 'border-[#D4AF37] bg-amber-50/10' 
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <span className="font-bold text-slate-900 block text-xs">Operação Estruturada (Cenário 3)</span>
                <span className="text-[10px] text-slate-500 block">Infraestrutura robusta de faturamento e 2ª Fase completa.</span>
              </button>
            </div>

            {/* Simulated Scenario Details Panel */}
            <div className="p-5 bg-slate-50 border border-slate-200 rounded-lg grid grid-cols-1 md:grid-cols-3 gap-6 font-sans text-xs">
              <div className="space-y-1.5">
                <span className="text-[10px] uppercase font-mono text-slate-400 font-bold block">Expectativa de Prazo</span>
                <p className="text-base font-bold text-slate-950">{computedScenarioDetails.weeksToLaunch}</p>
                <p className="text-slate-500 text-[10px] leading-tight">Tempo necessário de desenvolvimento até o lançamento beta.</p>
              </div>
              <div className="space-y-1.5 border-t md:border-t-0 md:border-l md:border-r border-slate-200 md:px-4">
                <span className="text-[10px] uppercase font-mono text-slate-400 font-bold block">Escopo Viável MVP</span>
                <p className="text-[11px] font-medium text-slate-800 leading-snug">{computedScenarioDetails.mvpScope}</p>
              </div>
              <div className="space-y-1.5">
                <span className="text-[10px] uppercase font-mono text-slate-400 font-bold block">Necessidades no Admin</span>
                <p className="text-[11px] font-medium text-slate-800 leading-snug">{computedScenarioDetails.adminNeeds}</p>
              </div>
            </div>
          </div>

          {/* Validation & Launch Strategy (BLOCO 17) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-base font-display font-bold text-slate-900 border-b border-slate-100 pb-2">Estratégia de Validação Pós-Lançamento (Primeiros 30 Dias)</h3>
            <p className="text-xs text-slate-600">
              Após o lançamento do MVP, a equipe operacional deve monitorar as respostas dos usuários para ajustar a tese de produto:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-sans text-xs">
              <div className="p-3 border border-slate-100 bg-slate-50 rounded space-y-1.5">
                <span className="font-bold text-slate-900 block text-[11px]">Métricas de Ativação</span>
                <p className="text-slate-500 text-[10px] leading-snug">
                  Monitorar o percentual de leads que concluem o onboarding e resolvem pelo menos uma meta diária no primeiro dia de acesso (Meta: {'>'} 65%).
                </p>
              </div>

              <div className="p-3 border border-slate-100 bg-slate-50 rounded space-y-1.5">
                <span className="font-bold text-slate-900 block text-[11px]">Conversão Financeira</span>
                <p className="text-slate-500 text-[10px] leading-snug">
                  Acompanhar se o bloqueio de paywall após limite gratuito estimula a compra imediata de planos sem criar frustrações de uso.
                </p>
              </div>

              <div className="p-3 border border-slate-100 bg-slate-50 rounded space-y-1.5">
                <span className="font-bold text-slate-900 block text-[11px]">Feedback de Conteúdo</span>
                <p className="text-slate-500 text-[10px] leading-snug">
                  Análise das dúvidas de suporte acadêmico para identificar possíveis lacunas pedagógicas ou erros nas revisões espaçadas.
                </p>
              </div>
            </div>
          </div>

          {/* Governance Rules (BLOCO 19) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-base font-display font-bold text-slate-900 border-b border-slate-100 pb-2">Regras de Governança Comercial & Implementação</h3>
            <p className="text-xs text-slate-600">Diretrizes obrigatórias para manter a padronização técnica e escalabilidade operacional do negócio:</p>

            <div className="space-y-3 font-sans text-xs">
              <div className="p-3 border border-slate-100 bg-slate-50 rounded flex justify-between items-center">
                <div className="space-y-0.5">
                  <span className="font-bold text-slate-900 block">Nomenclatura de Campanhas</span>
                  <p className="text-[10px] text-slate-500">Padrão operacional: <code>ANO_EXAME_PRODUTO_CANAL_OFERTA</code> (Ex: <code>2026_EX42_FASE1_FBADS_10OFF</code>).</p>
                </div>
                <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono">OBRIGATÓRIO</span>
              </div>

              <div className="p-3 border border-slate-100 bg-slate-50 rounded flex justify-between items-center">
                <div className="space-y-0.5">
                  <span className="font-bold text-slate-900 block">Controle de Frequência de Mensagens</span>
                  <p className="text-[10px] text-slate-500">Máximo de 1 push notification diário e 3 e-mails semanais por lead para evitar desativações e spam.</p>
                </div>
                <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono">POLÍTICA</span>
              </div>

              <div className="p-3 border border-slate-100 bg-slate-50 rounded flex justify-between items-center">
                <div className="space-y-0.5">
                  <span className="font-bold text-slate-900 block">Critério de Pronto de Nova Questão</span>
                  <p className="text-[10px] text-slate-500">Gabarito preenchido, comentário pedagógico ativo, marcação da banca (FGV) e tags de disciplinas corretas.</p>
                </div>
                <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono">QA PEDAGÓGICO</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
