/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Crown,
  CreditCard,
  Sparkles,
  TrendingUp,
  Coins,
  Percent,
  ShoppingBag,
  Users,
  Check,
  Lock,
  Shield,
  Activity,
  Flame,
  ArrowRight,
  RotateCcw,
  SlidersHorizontal,
  ChevronRight,
  HelpCircle,
  Clock,
  CheckCircle2,
  AlertTriangle,
  FileText,
  BadgePercent,
  Calendar,
  X,
  Smartphone,
  BookOpen,
  Award,
  Zap,
  Tag,
  Plus,
  Trash2,
  RefreshCw,
  Sliders
} from 'lucide-react';

interface MonetizationProps {
  currentPlan: string;
  onUpdatePlan: (plan: string) => void;
  onNavigateToTab: (tab: string) => void;
  onboardingData?: any;
}

// Initial Plans Definition
interface Plan {
  id: string;
  name: string;
  description: string;
  monthlyPrice: number;
  annualPrice: number;
  benefits: string[];
  badge?: string;
  color: string;
  borderColor: string;
  textColor: string;
  btnColor: string;
}

const INITIAL_PLANS: Plan[] = [
  {
    id: 'gratuito',
    name: 'Plano Gratuito / Degustação',
    description: 'Acesso básico e experimental para conhecer a metodologia e trilhas.',
    monthlyPrice: 0,
    annualPrice: 0,
    benefits: [
      'Até 10 questões comentadas por dia',
      'Demonstração de 1 simulado completo da 1ª Fase',
      'Acesso básico ao calendário de estudos',
      'Aulas de demonstração básicas',
      'Análise de desempenho básica',
    ],
    color: 'bg-slate-50 border-slate-200 text-slate-800',
    borderColor: 'border-slate-200',
    textColor: 'text-slate-800',
    btnColor: 'bg-slate-800 hover:bg-slate-900 text-white'
  },
  {
    id: 'fase1',
    name: 'Plano 1ª Fase OAB',
    description: 'Aprovado na 1ª fase com o maior acervo doutrinário e banco de questões.',
    monthlyPrice: 49.90,
    annualPrice: 29.90, // Monthly value when billed annually
    benefits: [
      'Banco de questões 1ª Fase ilimitado',
      'Simulados completos de 1ª Fase com gabarito inteligente',
      'Videoaulas de todas as disciplinas da 1ª Fase',
      'Revisões sistemáticas e Flashcards ilimitados',
      'Biblioteca de Materiais em PDF para 1ª Fase',
      'Calendário inteligente customizado com alertas',
    ],
    badge: 'Mais Focado',
    color: 'bg-blue-50/50 border-blue-200 text-blue-900',
    borderColor: 'border-blue-200',
    textColor: 'text-blue-900',
    btnColor: 'bg-blue-600 hover:bg-blue-700 text-white'
  },
  {
    id: 'fase2',
    name: 'Plano 2ª Fase OAB',
    description: 'Trilha prática voltada para a sua área com correção de peças e teses.',
    monthlyPrice: 69.90,
    annualPrice: 44.90,
    benefits: [
      'Trilha prática avançada para a área escolhida (Ex: Penal, Civil)',
      'Checklists interativos de correção e estrutura de Peças',
      'Discursivas contextualizadas com respostas sugeridas',
      'Modelos estruturados de Peças e Vade Mecum guiado',
      'Simulados práticos da 2ª Fase',
      'Cronograma específico de reta final da 2ª Fase',
    ],
    badge: 'Trilha Prática',
    color: 'bg-emerald-50/50 border-emerald-200 text-emerald-950',
    borderColor: 'border-emerald-200',
    textColor: 'text-emerald-950',
    btnColor: 'bg-emerald-600 hover:bg-emerald-700 text-white'
  },
  {
    id: 'completo',
    name: 'Completo OAB 3F',
    description: 'A experiência premium definitiva: Da 1ª fase à aprovação prática final.',
    monthlyPrice: 89.90,
    annualPrice: 59.90,
    benefits: [
      'Acesso total e irrestrito ao ecossistema OAB 3F',
      'Trilhas integradas de 1ª Fase + 2ª Fase',
      'Análises de Desempenho com IA do Radar de Aprovação',
      'Revisões programadas em intervalos científicos (24h/7d/30d)',
      'Suporte prioritário e correção VIP de Peças práticas',
      'Garantia incondicional de aprovação ou renovação gratuita',
      'Biblioteca de resumos, mapas mentais e legislações facilitadas',
    ],
    badge: 'Recomendado / Melhor Custo-Benefício',
    color: 'bg-slate-900 border-[#D4AF37] text-white',
    borderColor: 'border-[#D4AF37]/60',
    textColor: 'text-white',
    btnColor: 'bg-gradient-to-r from-amber-500 via-[#D4AF37] to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black'
  },
  {
    id: 'reta_final',
    name: 'Plano Reta Final',
    description: 'Treino intensivo para as semanas decisivas antes da prova.',
    monthlyPrice: 39.90,
    annualPrice: 29.90,
    benefits: [
      'Acesso focado nos temas de Altíssima Recorrência',
      'Cronograma de estudos de 30 dias intensivos',
      'Pílulas diárias de revisão e artigos-chave',
      'Maratona de simulados de reta final com ranking',
      'Alertas de datas e avisos críticos',
    ],
    badge: 'Foco Imediato',
    color: 'bg-red-50/50 border-red-200 text-red-950',
    borderColor: 'border-red-200',
    textColor: 'text-red-950',
    btnColor: 'bg-red-600 hover:bg-red-700 text-white'
  },
  {
    id: 'vip',
    name: 'VIP / Mentoria Executiva',
    description: 'Acompanhamento pessoal e correção individualizada pelo corpo docente.',
    monthlyPrice: 199.90,
    annualPrice: 139.90,
    benefits: [
      'Todo o conteúdo do Plano Completo OAB 3F',
      '4 sessões de mentoria individual online',
      'Correção de 8 Peças Profissionais por professores',
      'Grupo VIP exclusivo com dicas diárias de professores',
      'Atendimento prioritário no suporte em até 1 hora',
    ],
    badge: 'Exclusivo VIP',
    color: 'bg-purple-950 border-purple-500 text-white',
    borderColor: 'border-purple-600',
    textColor: 'text-white',
    btnColor: 'bg-purple-600 hover:bg-purple-700 text-white'
  }
];

interface Coupon {
  code: string;
  discountType: 'percentage' | 'fixed';
  value: number;
  expires: string;
  active: boolean;
}

const INITIAL_COUPONS: Coupon[] = [
  { code: 'OAB3F', discountType: 'percentage', value: 15, expires: '2026-12-31', active: true },
  { code: 'APROVADO30', discountType: 'percentage', value: 30, expires: '2026-08-30', active: true },
  { code: 'RETAFINAL', discountType: 'fixed', value: 20, expires: '2026-07-15', active: true },
  { code: 'VIPAPROVADO', discountType: 'percentage', value: 25, expires: '2026-10-10', active: true }
];

interface MarketingCampaign {
  id: string;
  name: string;
  headline: string;
  subheadline: string;
  targetPlanId: string;
  promotionalPrice: number;
  countdownMinutes: number;
  isActive: boolean;
  badge: string;
}

const INITIAL_CAMPAIGNS: MarketingCampaign[] = [
  {
    id: 'reta_final_urgente',
    name: 'Campanha Reta Final Ativa',
    headline: 'CRONÔMETRO ATIVO: Garanta o Plano Reta Final com 40% OFF!',
    subheadline: 'As semanas decisivas chegaram. Estude apenas o que cai com material ultra-focado e simulados.',
    targetPlanId: 'reta_final',
    promotionalPrice: 23.90,
    countdownMinutes: 45,
    isActive: true,
    badge: '🔥 OFERTA DE RETA FINAL'
  },
  {
    id: 'upgrade_segunda_fase',
    name: 'Upgrade 2ª Fase Turbo',
    headline: 'Passou na 1ª Fase? Migração Acelerada para 2ª Fase com Desconto!',
    subheadline: 'Acesso total a peças, modelos estruturados e simulados práticos para garantir sua carteira da OAB.',
    targetPlanId: 'fase2',
    promotionalPrice: 49.90,
    countdownMinutes: 120,
    isActive: false,
    badge: '🎓 SEGUNDA FASE DIRETA'
  }
];

export default function Monetization({
  currentPlan,
  onUpdatePlan,
  onNavigateToTab,
  onboardingData
}: MonetizationProps) {
  // Navigation internal tabs
  const [activeSubTab, setActiveSubTab] = useState<'ofertas' | 'assinatura' | 'admin'>('ofertas');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');
  
  // Plans & pricing state
  const [plans, setPlans] = useState<Plan[]>(() => {
    const saved = localStorage.getItem('oab3f_plans');
    return saved ? JSON.parse(saved) : INITIAL_PLANS;
  });

  // Coupons state
  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem('oab3f_coupons');
    return saved ? JSON.parse(saved) : INITIAL_COUPONS;
  });

  // Campaigns state
  const [campaigns, setCampaigns] = useState<MarketingCampaign[]>(() => {
    const saved = localStorage.getItem('oab3f_campaigns');
    return saved ? JSON.parse(saved) : INITIAL_CAMPAIGNS;
  });

  // Active Campaign Countdown state
  const [countdown, setCountdown] = useState(2700); // 45 minutes in seconds

  useEffect(() => {
    const activeCampaign = campaigns.find(c => c.isActive);
    if (activeCampaign) {
      setCountdown(activeCampaign.countdownMinutes * 60);
    }
  }, [campaigns]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCountdown(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Checkout modal states
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [selectedPlanForCheckout, setSelectedPlanForCheckout] = useState<Plan | null>(null);
  const [checkoutStep, setCheckoutStep] = useState<1 | 2 | 3>(1); // 1: Benefícios/Formato, 2: Cupom & Pagamento, 3: Sucesso
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'credit_card' | 'boleto'>('pix');
  const [creditCardNumber, setCreditCardNumber] = useState('');
  const [creditCardName, setCreditCardName] = useState('');
  const [creditCardExpiry, setCreditCardExpiry] = useState('');
  const [creditCardCVV, setCreditCardCVV] = useState('');
  const [copiedPix, setCopiedPix] = useState(false);

  // Admin simulation stats state
  const [revenueStats, setRevenueStats] = useState(() => {
    const saved = localStorage.getItem('oab3f_revenue_stats');
    if (saved) return JSON.parse(saved);
    
    return {
      totalSubscribers: 1482,
      mrr: 74930,
      conversionRate: 8.4,
      churnRate: 2.1,
      salesHistory: [
        { day: 'Seg', sales: 12, revenue: 890 },
        { day: 'Ter', sales: 18, revenue: 1450 },
        { day: 'Qua', sales: 15, revenue: 1100 },
        { day: 'Qui', sales: 24, revenue: 1950 },
        { day: 'Sexta', sales: 31, revenue: 2600 },
        { day: 'Sáb', sales: 22, revenue: 1700 },
        { day: 'Dom', sales: 28, revenue: 2250 }
      ],
      userList: [
        { id: 1, name: 'Lucas Santos', email: 'lucas.santos@gmail.com', plan: 'gratuito', status: 'Ativo (Trial)', date: '25/06/2026' },
        { id: 2, name: 'Beatriz Costa', email: 'beatriz.costa@hotmail.com', plan: 'completo', status: 'Ativo (Anual)', date: '10/05/2026' },
        { id: 3, name: 'Mariana Oliveira', email: 'mari.oliveira@outlook.com', plan: 'fase1', status: 'Ativo (Mensal)', date: '18/06/2026' },
        { id: 4, name: 'Rodrigo Almeida', email: 'rodrigo.adv@gmail.com', plan: 'fase2', status: 'Ativo (Semestral)', date: '01/06/2026' },
        { id: 5, name: 'Gustavo Ferreira', email: 'gustavo.ferr@gmail.com', plan: 'reta_final', status: 'Ativo (Reta Final)', date: '20/06/2026' },
        { id: 6, name: 'Camila Ribeiro', email: 'camila.ribeiro@uol.com.br', plan: 'vip', status: 'Ativo (Mentoria)', date: '15/06/2026' }
      ]
    };
  });

  // Save admin edits to local storage helper
  const updatePlansInStateAndStorage = (newPlans: Plan[]) => {
    setPlans(newPlans);
    localStorage.setItem('oab3f_plans', JSON.stringify(newPlans));
  };

  const updateCouponsInStateAndStorage = (newCoupons: Coupon[]) => {
    setCoupons(newCoupons);
    localStorage.setItem('oab3f_coupons', JSON.stringify(newCoupons));
  };

  const updateCampaignsInStateAndStorage = (newCampaigns: MarketingCampaign[]) => {
    setCampaigns(newCampaigns);
    localStorage.setItem('oab3f_campaigns', JSON.stringify(newCampaigns));
  };

  // Handle plan upgrade trigger
  const handleOpenCheckout = (plan: Plan) => {
    setSelectedPlanForCheckout(plan);
    setCouponCode('');
    setAppliedCoupon(null);
    setCheckoutStep(1);
    setShowCheckoutModal(true);
  };

  // Apply Coupon Logic
  const handleApplyCoupon = () => {
    const found = coupons.find(c => c.code.toUpperCase() === couponCode.trim().toUpperCase() && c.active);
    if (found) {
      setAppliedCoupon(found);
    } else {
      alert('Cupom inválido, expirado ou inativo.');
    }
  };

  const calculateDiscountedPrice = (plan: Plan) => {
    const basePrice = billingCycle === 'annual' ? plan.annualPrice : plan.monthlyPrice;
    if (!appliedCoupon) return basePrice;
    
    if (appliedCoupon.discountType === 'percentage') {
      return Number((basePrice * (1 - appliedCoupon.value / 100)).toFixed(2));
    } else {
      const discounted = basePrice - appliedCoupon.value;
      return discounted < 0 ? 0 : Number(discounted.toFixed(2));
    }
  };

  // Complete Payment Sim
  const handleCompletePayment = () => {
    if (!selectedPlanForCheckout) return;

    // Simulate completion
    setCheckoutStep(3);
    onUpdatePlan(selectedPlanForCheckout.id);
    
    // Add transaction to dashboard simulated logs
    const pricePaid = calculateDiscountedPrice(selectedPlanForCheckout);
    const billingStr = billingCycle === 'annual' ? 'Anual' : 'Mensal';
    
    // Update local storage transaction count
    const updatedStats = { ...revenueStats };
    updatedStats.totalSubscribers += 1;
    updatedStats.mrr += selectedPlanForCheckout.monthlyPrice;
    
    // Add to sales list
    const currentDay = ['Seg', 'Ter', 'Qua', 'Qui', 'Sexta', 'Sáb', 'Dom'][new Date().getDay() - 1] || 'Qui';
    updatedStats.salesHistory = updatedStats.salesHistory.map(item => {
      if (item.day === currentDay) {
        return { ...item, sales: item.sales + 1, revenue: item.revenue + Math.round(pricePaid) };
      }
      return item;
    });

    setRevenueStats(updatedStats);
    localStorage.setItem('oab3f_revenue_stats', JSON.stringify(updatedStats));
  };

  // Simulating active campaign
  const activeCamp = campaigns.find(c => c.isActive);
  const activeCampPlan = activeCamp ? plans.find(p => p.id === activeCamp.targetPlanId) : null;

  return (
    <div className="space-y-8 pb-16 animate-fade-in" id="monetization-root">
      
      {/* HEADER SECTION WITH DYNAMIC BADGE & TABS */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <span className="text-xs uppercase font-black tracking-widest text-[#D4AF37] flex items-center gap-1.5 font-mono mb-1">
            <Crown className="h-4 w-4 text-[#D4AF37]" /> CONVERSÃO & MONETIZAÇÃO PREMIUM
          </span>
          <h2 className="text-3xl font-serif font-extrabold text-slate-900 tracking-tight">
            Gestão Comercial &amp; Planos <span className="italic font-normal text-slate-500">OAB 3F</span>
          </h2>
          <p className="text-sm text-slate-500">
            Acompanhe planos, controle paywalls contextuais, gerencie campanhas, aplique cupons e monitore o faturamento.
          </p>
        </div>

        {/* Dynamic sub tabs */}
        <div className="bg-slate-100 p-1 rounded-lg flex space-x-1 border border-slate-200 self-start md:self-auto">
          <button
            onClick={() => setActiveSubTab('ofertas')}
            className={`px-4 py-2 text-xs font-bold rounded-md transition-all cursor-pointer ${
              activeSubTab === 'ofertas'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShoppingBag className="h-3.5 w-3.5 inline mr-1.5" /> Planos &amp; Ofertas
          </button>
          <button
            onClick={() => setActiveSubTab('assinatura')}
            className={`px-4 py-2 text-xs font-bold rounded-md transition-all cursor-pointer ${
              activeSubTab === 'assinatura'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Shield className="h-3.5 w-3.5 inline mr-1.5" /> Minha Assinatura
          </button>
          <button
            onClick={() => setActiveSubTab('admin')}
            className={`px-4 py-2 text-xs font-bold rounded-md transition-all cursor-pointer flex items-center ${
              activeSubTab === 'admin'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Sliders className="h-3.5 w-3.5 inline mr-1.5 text-amber-400" /> Painel Admin Comercial
          </button>
        </div>
      </div>

      {/* ----------------- SUBTAB 1: PLANOS & OFERTAS (MAIN CONVERSION SCREEN) ----------------- */}
      {activeSubTab === 'ofertas' && (
        <div className="space-y-10" id="main-sales-funnel">
          
          {/* ACTIVE CAMPAIGN PROMOTIONAL HERO BANNER (Módulo 8) */}
          {activeCamp && activeCampPlan && (
            <div className="bg-slate-950 border-2 border-red-500/40 rounded-xl overflow-hidden shadow-lg p-6 relative">
              <div className="absolute top-0 right-0 p-3">
                <span className="bg-red-500 text-white text-[9px] font-black uppercase tracking-widest px-2.5 py-1 rounded">
                  {activeCamp.badge}
                </span>
              </div>
              <div className="max-w-3xl space-y-3">
                <div className="flex items-center gap-2 text-red-400 font-mono text-xs font-black">
                  <Clock className="h-4 w-4 animate-pulse" /> OFERTA POR TEMPO LIMITADO: {formatTime(countdown)}
                </div>
                <h3 className="text-xl sm:text-2xl font-serif font-black text-white leading-tight">
                  {activeCamp.headline}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
                  {activeCamp.subheadline} O plano ideal para quem quer revisar apenas os pontos fundamentais que a FGV cobra, com simulados integrados.
                </p>
                <div className="pt-2 flex flex-col sm:flex-row sm:items-center gap-4">
                  <div>
                    <span className="text-slate-400 text-[10px] block line-through">
                      De R$ {activeCampPlan.monthlyPrice.toFixed(2)}/mês
                    </span>
                    <span className="text-white text-2xl font-extrabold flex items-baseline gap-1">
                      R$ {activeCamp.promotionalPrice.toFixed(2)} <span className="text-xs text-slate-400 font-normal">/mês no plano especial</span>
                    </span>
                  </div>
                  <button
                    onClick={() => handleOpenCheckout({
                      ...activeCampPlan,
                      monthlyPrice: activeCamp.promotionalPrice,
                      annualPrice: activeCamp.promotionalPrice * 0.8 // Simulate dynamic discount
                    })}
                    className="bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-lg text-xs font-bold flex items-center gap-2 transition-all uppercase tracking-wider shadow shadow-red-600/30 self-start cursor-pointer"
                  >
                    <span>Quero Garantir Meu Desconto</span> <ArrowRight className="h-4 w-4 stroke-[3]" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* HEADLINE PRINCIPAL PERSUASIVA (Módulo 6) */}
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <span className="bg-[#D4AF37]/10 text-[#D4AF37] text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full border border-[#D4AF37]/20 font-mono">
              ★ ESCOLHA SEU PASSO DE APROVAÇÃO ★
            </span>
            <h1 className="text-3xl sm:text-4xl font-serif font-black text-slate-900 leading-tight">
              Tudo o que você precisa para passar na OAB, <span className="italic font-normal text-slate-500">em um só app</span>
            </h1>
            <p className="text-sm text-slate-600 max-w-2xl mx-auto leading-relaxed">
              Cronograma de estudos inteligente, doutrina simplificada, banco com milhares de questões comentadas, simulados oficiais, mapeamento de peças práticas e acompanhamento com o método 3F.
            </p>

            {/* BILLING TOGGLE (Módulo 4) */}
            <div className="pt-4 flex items-center justify-center gap-3">
              <span className={`text-xs font-semibold ${billingCycle === 'monthly' ? 'text-slate-900 font-bold' : 'text-slate-400'}`}>
                Cobrança Mensal
              </span>
              <button
                onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'annual' : 'monthly')}
                className="w-12 h-6 bg-slate-200 hover:bg-slate-300 rounded-full p-1 transition-colors relative focus:outline-none cursor-pointer"
                aria-label="Toggle billing interval"
              >
                <div
                  className={`w-4 h-4 bg-[#D4AF37] rounded-full transition-all duration-300 transform ${
                    billingCycle === 'annual' ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
              <span className={`text-xs font-semibold flex items-center gap-1.5 ${billingCycle === 'annual' ? 'text-slate-900 font-black' : 'text-slate-400'}`}>
                Faturamento Anual <span className="bg-emerald-100 text-emerald-800 text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">Economize até 40%</span>
              </span>
            </div>
          </div>

          {/* GRID DE PLANOS (Módulo 1 & 4) */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
            {plans.map((plan) => {
              const price = billingCycle === 'annual' ? plan.annualPrice : plan.monthlyPrice;
              const isCurrent = currentPlan === plan.id;
              const isRecommended = plan.id === 'completo';
              
              return (
                <div
                  key={plan.id}
                  className={`border-2 rounded-xl flex flex-col justify-between p-6 transition-all duration-200 relative overflow-hidden ${
                    isRecommended
                      ? 'bg-slate-950 text-white border-[#D4AF37] shadow-xl md:scale-105 md:z-10'
                      : 'bg-white text-slate-800 border-slate-200 shadow-md hover:border-slate-300'
                  }`}
                >
                  {/* Recommended / Highlights Badge */}
                  {plan.badge && (
                    <div className="absolute top-0 right-0 pt-2 pr-3">
                      <span className={`text-[9px] uppercase font-black tracking-widest px-2.5 py-0.5 rounded-full ${
                        isRecommended ? 'bg-[#D4AF37] text-slate-900' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {plan.badge}
                      </span>
                    </div>
                  )}

                  <div className="space-y-4">
                    <div className="space-y-1">
                      <h3 className="text-lg font-serif font-black">{plan.name}</h3>
                      <p className={`text-xs ${isRecommended ? 'text-slate-400' : 'text-slate-500'} leading-relaxed`}>
                        {plan.description}
                      </p>
                    </div>

                    {/* Price Tag */}
                    <div className="py-3 border-y border-slate-100/10 dark:border-slate-800">
                      {plan.id === 'gratuito' ? (
                        <div className="text-2xl font-extrabold text-emerald-600">
                          Grátis <span className="text-xs text-slate-400 font-normal block">Acesso de demonstração básica</span>
                        </div>
                      ) : (
                        <div>
                          <span className={`text-[10px] block ${isRecommended ? 'text-slate-400' : 'text-slate-500'}`}>
                            {billingCycle === 'annual' ? 'Billed annually' : 'Billed monthly'}
                          </span>
                          <span className="text-3xl font-serif font-black flex items-baseline gap-1">
                            R$ {price.toFixed(2)}
                            <span className={`text-xs font-normal ${isRecommended ? 'text-slate-400' : 'text-slate-500'}`}>
                              /mês
                            </span>
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Benefits list (Módulo 2) */}
                    <ul className="space-y-2.5 text-xs">
                      {plan.benefits.map((benefit, bIdx) => (
                        <li key={bIdx} className="flex items-start gap-2">
                          <CheckCircle2 className={`h-4 w-4 shrink-0 ${isRecommended ? 'text-[#D4AF37]' : 'text-emerald-500'} mt-0.5`} />
                          <span className={isRecommended ? 'text-slate-300' : 'text-slate-600'}>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-6 mt-6 border-t border-slate-100/10 dark:border-slate-800">
                    {isCurrent ? (
                      <div className="w-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 rounded-lg py-2.5 text-xs font-bold text-center flex items-center justify-center gap-1.5 uppercase font-mono">
                        <Check className="h-4 w-4 stroke-[3]" /> Seu Plano Ativo
                      </div>
                    ) : (
                      <button
                        onClick={() => handleOpenCheckout(plan)}
                        className={`w-full py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${plan.btnColor}`}
                      >
                        {plan.id === 'gratuito' ? 'Utilizar Modo Gratuito' : 'Desbloquear Acesso Completo'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* TABELA COMPARATIVA DETALHADA DE PLANOS (Módulo 15) */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-md">
            <div className="p-5 border-b border-slate-200 bg-slate-50/50">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Comparativo Detalhado de Níveis de Acesso</h3>
              <p className="text-xs text-slate-500 mt-0.5">Analise cada benefício e tome a melhor decisão para o seu cronograma.</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                    <th className="p-4 w-1/3">Recurso / Conteúdo</th>
                    <th className="p-4 text-center">Gratuito</th>
                    <th className="p-4 text-center">1ª Fase</th>
                    <th className="p-4 text-center">2ª Fase</th>
                    <th className="p-4 text-center text-[#D4AF37] bg-slate-900 font-extrabold border-x border-[#D4AF37]/35">Completo OAB 3F</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-700">
                  <tr>
                    <td className="p-4 font-semibold">Resolução de Questões</td>
                    <td className="p-4 text-center text-slate-500">Limitação (10/dia)</td>
                    <td className="p-4 text-center text-emerald-600 font-bold">Ilimitado</td>
                    <td className="p-4 text-center text-slate-400">Não incluso</td>
                    <td className="p-4 text-center text-emerald-400 font-bold bg-slate-950/95 border-x border-[#D4AF37]/30">Ilimitado</td>
                  </tr>
                  <tr>
                    <td className="p-4 font-semibold">Estudo de Peças Práticas</td>
                    <td className="p-4 text-center text-slate-400">Apenas modelos básicos</td>
                    <td className="p-4 text-center text-slate-400">Não incluso</td>
                    <td className="p-4 text-center text-emerald-600 font-bold">Ilimitado</td>
                    <td className="p-4 text-center text-emerald-400 font-bold bg-slate-950/95 border-x border-[#D4AF37]/30">Ilimitado</td>
                  </tr>
                  <tr>
                    <td className="p-4 font-semibold">Simulados da 1ª Fase</td>
                    <td className="p-4 text-center text-slate-500">1 de demonstração</td>
                    <td className="p-4 text-center text-emerald-600 font-bold">Ilimitado</td>
                    <td className="p-4 text-center text-slate-400">Não incluso</td>
                    <td className="p-4 text-center text-emerald-400 font-bold bg-slate-950/95 border-x border-[#D4AF37]/30">Ilimitado</td>
                  </tr>
                  <tr>
                    <td className="p-4 font-semibold">Simulados Discursivos (2ªFase)</td>
                    <td className="p-4 text-center text-slate-400">Bloqueado</td>
                    <td className="p-4 text-center text-slate-400">Não incluso</td>
                    <td className="p-4 text-center text-emerald-600 font-bold">Ilimitado</td>
                    <td className="p-4 text-center text-emerald-400 font-bold bg-slate-950/95 border-x border-[#D4AF37]/30">Ilimitado</td>
                  </tr>
                  <tr>
                    <td className="p-4 font-semibold">Revisões Científicas &amp; Flashcards</td>
                    <td className="p-4 text-center text-slate-400">Apenas 15 cards demo</td>
                    <td className="p-4 text-center text-emerald-600 font-bold">Ilimitado</td>
                    <td className="p-4 text-center text-slate-400">Não incluso</td>
                    <td className="p-4 text-center text-emerald-400 font-bold bg-slate-950/95 border-x border-[#D4AF37]/30">Ilimitado</td>
                  </tr>
                  <tr>
                    <td className="p-4 font-semibold">Radar de Desempenho Inteligente</td>
                    <td className="p-4 text-center text-slate-400">Relatórios simples</td>
                    <td className="p-4 text-center text-emerald-600 font-bold">Relatórios avançados</td>
                    <td className="p-4 text-center text-slate-400">Não incluso</td>
                    <td className="p-4 text-center text-emerald-400 font-bold bg-slate-950/95 border-x border-[#D4AF37]/30">Mapeamento Inteligente</td>
                  </tr>
                  <tr>
                    <td className="p-4 font-semibold">Correção Personalizada de Peças</td>
                    <td className="p-4 text-center text-slate-400">Bloqueado</td>
                    <td className="p-4 text-center text-slate-400">Bloqueado</td>
                    <td className="p-4 text-center text-slate-500">Adicional pago</td>
                    <td className="p-4 text-center text-emerald-400 font-bold bg-slate-950/95 border-x border-[#D4AF37]/30">Incluso (VIP e Completo)</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* SEÇÃO DE GARANTIA E PERGUNTAS FREQUENTES (Módulo 6) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
            {/* Garantia */}
            <div className="bg-slate-50 border border-slate-200 p-6 rounded-xl flex items-start gap-4 shadow-sm">
              <div className="bg-amber-100 text-[#D4AF37] p-3 rounded-lg shadow-inner">
                <Shield className="h-8 w-8" />
              </div>
              <div className="space-y-1.5">
                <h4 className="font-serif font-bold text-slate-900 text-sm">Garantia OAB 3F de Aprovação</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Confiamos tanto no nosso método de fixação que se você assinar o Plano Completo, seguir o cronograma recomendado de metas e por algum motivo não for aprovado, seu acesso é **renovado gratuitamente** até a próxima edição. Sem burocracia.
                </p>
              </div>
            </div>

            {/* Segurança */}
            <div className="bg-slate-50 border border-slate-200 p-6 rounded-xl flex items-start gap-4 shadow-sm">
              <div className="bg-blue-100 text-blue-600 p-3 rounded-lg shadow-inner">
                <Lock className="h-8 w-8" />
              </div>
              <div className="space-y-1.5">
                <h4 className="font-serif font-bold text-slate-900 text-sm">Pagamento Seguro e Processado</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Toda a transação de assinatura é processada em ambiente com criptografia SSL ponta a ponta. Ativação imediata em segundos para PIX e Cartão de Crédito.
                </p>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* ----------------- SUBTAB 2: MINHA ASSINATURA (USER ACCOUNT MANAGEMENT) ----------------- */}
      {activeSubTab === 'assinatura' && (
        <div className="space-y-6" id="user-subscription-panel">
          
          {/* PLAN CARD CURRENT STATE (Módulo 12) */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-md">
            <div className="p-6 bg-slate-900 text-white flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-black tracking-widest text-[#D4AF37] bg-[#D4AF37]/15 border border-[#D4AF37]/25 px-2 py-0.5 rounded-full font-mono">
                    STATUS: ATIVO
                  </span>
                  <span className="text-xs text-slate-400 font-mono">Desde: 25/06/2026</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-serif font-extrabold text-[#D4AF37] flex items-center gap-2">
                  {plans.find(p => p.id === currentPlan)?.name || "Plano Gratuito"}
                </h3>
                <p className="text-xs text-slate-400">
                  {plans.find(p => p.id === currentPlan)?.description}
                </p>
              </div>

              {currentPlan !== 'completo' && currentPlan !== 'vip' && (
                <button
                  onClick={() => handleOpenCheckout(plans.find(p => p.id === 'completo')!)}
                  className="bg-[#D4AF37] hover:bg-amber-500 text-slate-900 px-4 py-2 text-xs font-black rounded-lg flex items-center gap-1.5 cursor-pointer uppercase tracking-wider transition-all"
                >
                  <Crown className="h-4 w-4" /> Upgrade para Plano Completo
                </button>
              )}
            </div>

            <div className="p-6 space-y-6">
              
              {/* Subscription details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                  <span className="block text-[10px] uppercase tracking-widest text-slate-400 font-mono">Duração do Acesso</span>
                  <span className="block text-sm font-extrabold text-slate-800">
                    {currentPlan === 'gratuito' ? 'Acesso Vitalício Básico' : billingCycle === 'annual' ? 'Acesso de 1 Ano (Anual)' : 'Acesso Recorrente (Mensal)'}
                  </span>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                  <span className="block text-[10px] uppercase tracking-widest text-slate-400 font-mono">Próxima Renovação</span>
                  <span className="block text-sm font-extrabold text-slate-800">
                    {currentPlan === 'gratuito' ? 'Sem expiração' : '25/06/2027'}
                  </span>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                  <span className="block text-[10px] uppercase tracking-widest text-slate-400 font-mono">Formato de Cobrança</span>
                  <span className="block text-sm font-extrabold text-slate-800">
                    {currentPlan === 'gratuito' ? 'Gratuito' : 'PIX ou Cartão cadastrado'}
                  </span>
                </div>
              </div>

              {/* Active benefits section */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Benefícios Atualmente Liberados no Seu Perfil</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {plans.find(p => p.id === currentPlan)?.benefits.map((benefit, idx) => (
                    <div key={idx} className="flex items-center gap-2.5 p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700">
                      <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500 shrink-0" />
                      <span>{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions like change plan or cancel (Module 12) */}
              <div className="pt-6 border-t border-slate-200 flex flex-wrap justify-between items-center gap-4">
                <button
                  onClick={() => setActiveSubTab('ofertas')}
                  className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className="h-3.5 w-3.5" /> Trocar de Plano / Alterar Faturamento
                </button>

                {currentPlan !== 'gratuito' && (
                  <button
                    onClick={() => {
                      if (confirm("Tem certeza que deseja cancelar sua renovação? Você perderá acesso às revisões espaçadas programadas e aos simulados exclusivos ao fim do período contratado.")) {
                        onUpdatePlan('gratuito');
                        alert("Sua renovação foi cancelada. Seu plano foi rebaixado para Gratuito.");
                      }
                    }}
                    className="bg-transparent border border-red-200 hover:bg-red-50 text-red-500 hover:text-red-600 px-3 py-1.5 text-xs font-semibold rounded cursor-pointer transition-all"
                  >
                    Cancelar Assinatura / Interromper Renovação
                  </button>
                )}
              </div>

            </div>
          </div>

          {/* HISTÓRICO DE COMPRAS SIMULADO */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            <div className="p-4 border-b border-slate-200 bg-slate-50/50">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Histórico de Transações e Recibos</h3>
            </div>
            <div className="divide-y divide-slate-200">
              {currentPlan === 'gratuito' ? (
                <div className="p-6 text-center text-xs text-slate-400">
                  Nenhuma transação financeira efetuada. Você está utilizando o plano gratuito.
                </div>
              ) : (
                <div className="p-4 flex items-center justify-between text-xs hover:bg-slate-50">
                  <div className="space-y-1">
                    <span className="block font-bold text-slate-800">Assinatura de Plano OAB 3F Ativada</span>
                    <span className="text-[10px] text-slate-400">ID da Transação: #TX-94819-2026</span>
                  </div>
                  <div className="text-right space-y-1">
                    <span className="block font-bold text-slate-800">R$ {plans.find(p => p.id === currentPlan)?.annualPrice.toFixed(2)}/mês</span>
                    <span className="bg-emerald-100 text-emerald-800 text-[9px] px-2 py-0.5 rounded font-bold uppercase">Aprovada via PIX</span>
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>
      )}

      {/* ----------------- SUBTAB 3: PAINEL ADMIN COMERCIAL (SIMULATED CONTROL) ----------------- */}
      {activeSubTab === 'admin' && (
        <div className="space-y-8 animate-fade-in" id="admin-monetization-control">
          
          {/* ANALYTICS & REVENUE STATS (Módulo 19) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            
            {/* Stat 1 */}
            <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-widest font-mono text-slate-400">Total de Assinantes</span>
                <div className="p-2 bg-blue-100 text-blue-600 rounded-lg"><Users className="h-5 w-5" /></div>
              </div>
              <div>
                <span className="block text-2xl font-serif font-black text-slate-900">{revenueStats.totalSubscribers}</span>
                <span className="text-[10px] text-emerald-500 font-bold">▲ +12% em relação ao mês anterior</span>
              </div>
            </div>

            {/* Stat 2 */}
            <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-widest font-mono text-slate-400">MRR (Faturamento Mensal)</span>
                <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg"><Coins className="h-5 w-5" /></div>
              </div>
              <div>
                <span className="block text-2xl font-serif font-black text-slate-900">R$ {revenueStats.mrr.toLocaleString('pt-BR')}</span>
                <span className="text-[10px] text-emerald-500 font-bold">▲ +18% este mês</span>
              </div>
            </div>

            {/* Stat 3 */}
            <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-widest font-mono text-slate-400">Taxa de Conversão</span>
                <div className="p-2 bg-amber-100 text-amber-600 rounded-lg"><TrendingUp className="h-5 w-5" /></div>
              </div>
              <div>
                <span className="block text-2xl font-serif font-black text-slate-900">{revenueStats.conversionRate}%</span>
                <span className="text-[10px] text-slate-500 font-medium">Média do mercado: 4.5%</span>
              </div>
            </div>

            {/* Stat 4 */}
            <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-widest font-mono text-slate-400">Churn Rate (Cancelamento)</span>
                <div className="p-2 bg-red-100 text-red-600 rounded-lg"><Activity className="h-5 w-5" /></div>
              </div>
              <div>
                <span className="block text-2xl font-serif font-black text-slate-900">{revenueStats.churnRate}%</span>
                <span className="text-[10px] text-emerald-500 font-bold">▼ Estável e saudável</span>
              </div>
            </div>

          </div>

          {/* SIMULATED ANALYTICS GRAPH (Módulo 19) */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Histórico de Vendas Diárias (Últimos 7 dias)</h3>
                <p className="text-xs text-slate-400">Acompanhamento de conversão e receita gerada por ofertas de simulados e peças.</p>
              </div>
              <span className="bg-slate-100 text-slate-800 text-[10px] font-black px-2.5 py-1 rounded font-mono">DADOS ATUALIZADOS EM TEMPO REAL</span>
            </div>

            {/* Premium custom SVG chart */}
            <div className="h-44 flex items-end justify-between gap-2 pt-6 px-4">
              {revenueStats.salesHistory.map((item, idx) => {
                const maxRevenue = Math.max(...revenueStats.salesHistory.map(s => s.revenue));
                const heightPercentage = `${(item.revenue / maxRevenue) * 100}%`;
                
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 group cursor-pointer relative">
                    {/* Tooltip on hover */}
                    <div className="absolute bottom-full mb-2 bg-slate-900 text-white text-[9px] px-2 py-1 rounded shadow opacity-0 group-hover:opacity-100 transition-opacity z-10 pointer-events-none whitespace-nowrap text-center">
                      <span className="block font-bold">{item.sales} assinantes</span>
                      <span>R$ {item.revenue} arrecadados</span>
                    </div>

                    <div className="w-full bg-slate-100 hover:bg-slate-200 rounded-md overflow-hidden h-32 flex items-end">
                      <div
                        style={{ height: heightPercentage }}
                        className="w-full bg-gradient-to-t from-slate-800 via-slate-600 to-amber-500 group-hover:to-amber-400 transition-all rounded-b"
                      />
                    </div>
                    <span className="text-[10px] font-bold text-slate-500 font-mono">{item.day}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* GRID OF CONTROLS: PLANS PRICING & CAMPAIGNS (Módulo 18) */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* Control 1: Ajustador de Planos */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Ajuste de Preços de Planos</h3>
                <p className="text-xs text-slate-400">Modifique os valores vigentes da mensalidade e observe os banners contextuais se atualizarem.</p>
              </div>

              <div className="divide-y divide-slate-100">
                {plans.map((plan) => (
                  <div key={plan.id} className="py-3 flex items-center justify-between gap-4">
                    <div className="space-y-0.5">
                      <span className="block font-bold text-xs text-slate-800">{plan.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{plan.id}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div>
                        <label className="text-[9px] text-slate-400 uppercase font-mono block">Mensal</label>
                        <input
                          type="number"
                          value={plan.monthlyPrice}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            const updated = plans.map(p => p.id === plan.id ? { ...p, monthlyPrice: val } : p);
                            updatePlansInStateAndStorage(updated);
                          }}
                          className="border border-slate-300 rounded px-2 py-1 text-xs w-20 text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="text-[9px] text-slate-400 uppercase font-mono block">Anual (Equiv.)</label>
                        <input
                          type="number"
                          value={plan.annualPrice}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            const updated = plans.map(p => p.id === plan.id ? { ...p, annualPrice: val } : p);
                            updatePlansInStateAndStorage(updated);
                          }}
                          className="border border-slate-300 rounded px-2 py-1 text-xs w-20 text-slate-800"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Control 2: Gerenciador de Campanhas Ativas */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Campanhas Comerciais &amp; Urgência</h3>
                <p className="text-xs text-slate-400">Ative ou desative banners persuasivos de reta final e promoções de simulados do ecossistema.</p>
              </div>

              <div className="space-y-4">
                {campaigns.map((camp) => (
                  <div key={camp.id} className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[9px] bg-red-100 text-red-700 font-black px-2 py-0.5 rounded uppercase tracking-wider font-mono">
                          {camp.badge}
                        </span>
                        <h4 className="font-bold text-xs text-slate-800 mt-1">{camp.name}</h4>
                      </div>
                      
                      {/* Toggle Switch */}
                      <button
                        onClick={() => {
                          const updated = campaigns.map(c => {
                            if (c.id === camp.id) {
                              return { ...c, isActive: !c.isActive };
                            }
                            // Only 1 campaign can be active at a time to prevent conflicts
                            return { ...c, isActive: false };
                          });
                          updateCampaignsInStateAndStorage(updated);
                        }}
                        className={`w-10 h-5 rounded-full p-0.5 transition-colors cursor-pointer relative ${
                          camp.isActive ? 'bg-emerald-500' : 'bg-slate-300'
                        }`}
                        aria-label={`Toggle campaign ${camp.name}`}
                      >
                        <div className={`w-4 h-4 bg-white rounded-full transition-all transform ${
                          camp.isActive ? 'translate-x-5' : 'translate-x-0'
                        }`} />
                      </button>
                    </div>

                    <div className="space-y-2 text-xs text-slate-600">
                      <p className="italic">"{camp.headline}"</p>
                      <div className="flex gap-4">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-mono">Preço da Campanha</span>
                          <span className="font-bold text-slate-800">R$ {camp.promotionalPrice.toFixed(2)}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block font-mono">Timer Padrão (Min)</span>
                          <span className="font-bold text-slate-800">{camp.countdownMinutes} minutos</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* GRID OF CONTROLS: COUPONS & DEMO USER PLANS MODIFIERS */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* Control 3: Cupons de Desconto */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Cupons Promocionais Cadastrados</h3>
                  <p className="text-xs text-slate-400">Visualize e insira novos cupons com valores ou percentuais para teste do checkout.</p>
                </div>
                
                {/* Form placeholder to add coupon */}
                <button
                  onClick={() => {
                    const code = prompt("Digite o código do novo cupom:")?.toUpperCase();
                    if (!code) return;
                    const value = parseFloat(prompt("Digite o valor do desconto (Ex: 15 para 15% ou R$ 15):") || "0");
                    const type = confirm("O desconto é em PORCENTAGEM? (Pressione OK para sim, CANCELAR para valor fixo)") ? 'percentage' : 'fixed';
                    
                    const newCoupon: Coupon = {
                      code,
                      discountType: type,
                      value,
                      expires: '2026-12-31',
                      active: true
                    };
                    updateCouponsInStateAndStorage([...coupons, newCoupon]);
                  }}
                  className="bg-slate-900 hover:bg-slate-800 text-white text-[10px] font-black px-2.5 py-1.5 rounded uppercase tracking-wider cursor-pointer flex items-center gap-1"
                >
                  <Plus className="h-3 w-3" /> Adicionar Cupom
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {coupons.map((coupon) => (
                  <div key={coupon.code} className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
                    <div>
                      <span className="font-mono font-black text-xs text-slate-800 bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">
                        {coupon.code}
                      </span>
                      <span className="block text-[10px] text-slate-500 mt-1 font-mono">
                        Desconto: {coupon.discountType === 'percentage' ? `${coupon.value}%` : `R$ ${coupon.value}`}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          const updated = coupons.map(c => c.code === coupon.code ? { ...c, active: !c.active } : c);
                          updateCouponsInStateAndStorage(updated);
                        }}
                        className={`text-[9px] px-1.5 py-0.5 rounded font-black cursor-pointer uppercase ${
                          coupon.active ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {coupon.active ? 'Ativo' : 'Inativo'}
                      </button>

                      <button
                        onClick={() => {
                          if (confirm(`Excluir cupom ${coupon.code}?`)) {
                            const filtered = coupons.filter(c => c.code !== coupon.code);
                            updateCouponsInStateAndStorage(filtered);
                          }
                        }}
                        className="text-red-500 hover:bg-red-50 p-1 rounded transition-colors cursor-pointer"
                        aria-label="Delete coupon"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Control 4: Simulador de Alunos e Teste de Paywall */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Simulador de Acesso (Teste de Bloqueios)</h3>
                <p className="text-xs text-slate-400">
                  Troque o plano do seu aluno ativo nesta lista para testar como os bloqueios de questões, peças e simulados respondem instantaneamente!
                </p>
              </div>

              <div className="p-3 bg-[#D4AF37]/5 border border-[#D4AF37]/20 rounded-lg flex items-center justify-between mb-2">
                <div>
                  <span className="text-[10px] font-black uppercase text-[#D4AF37] font-mono">VOCÊ ESTÁ ACESSANDO COMO:</span>
                  <span className="block font-serif font-black text-xs text-slate-800">poprotaspires@gmail.com</span>
                </div>
                <div>
                  <select
                    value={currentPlan}
                    onChange={(e) => {
                      onUpdatePlan(e.target.value);
                      alert(`Plano alterado para: ${e.target.value.toUpperCase()}. Navegue pelas outras abas do menu para ver as restrições ou recursos liberados.`);
                    }}
                    className="border-2 border-[#D4AF37]/40 bg-white font-bold rounded px-2 py-1 text-xs text-slate-800 cursor-pointer"
                  >
                    <option value="gratuito">Plano Gratuito (Limitado)</option>
                    <option value="fase1">Plano 1ª Fase (Objetivas)</option>
                    <option value="fase2">Plano 2ª Fase (Discursivas)</option>
                    <option value="completo">Plano Completo OAB 3F (Ilimitado)</option>
                    <option value="reta_final">Plano Reta Final</option>
                    <option value="vip">Plano VIP / Mentoria</option>
                  </select>
                </div>
              </div>

              {/* Other mock users list for comprehensive view */}
              <div className="space-y-2 max-h-32 overflow-y-auto divide-y divide-slate-100 pr-1">
                {revenueStats.userList.map((usr) => (
                  <div key={usr.id} className="py-2 flex justify-between items-center text-[11px]">
                    <div className="space-y-0.5">
                      <span className="font-bold text-slate-800 block">{usr.name}</span>
                      <span className="text-slate-400 font-mono">{usr.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono text-[9px]">
                        {usr.plan.toUpperCase()}
                      </span>
                      <span className="text-slate-400">{usr.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>
      )}

      {/* ----------------- CHECKOUT FLOW MODAL (Módulo 10 & 11) ----------------- */}
      {showCheckoutModal && selectedPlanForCheckout && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-xl w-full overflow-hidden border border-slate-200 animate-scale-in" id="checkout-container">
            
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-5 flex justify-between items-center border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Crown className="h-5 w-5 text-[#D4AF37]" />
                <span className="font-serif font-bold text-base tracking-tight">Checkout OAB 3F</span>
              </div>
              <button
                onClick={() => setShowCheckoutModal(false)}
                className="text-slate-400 hover:text-white transition-colors cursor-pointer"
                aria-label="Close checkout"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Checkout content by step */}
            <div className="p-6 space-y-6">
              
              {/* STEP 1: PLAN SELECTION DETAILS */}
              {checkoutStep === 1 && (
                <div className="space-y-4">
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                    <span className="text-[10px] bg-[#D4AF37]/15 text-[#D4AF37] px-2 py-0.5 rounded font-mono font-bold uppercase">
                      Você selecionou
                    </span>
                    <h4 className="font-serif font-black text-lg text-slate-900">{selectedPlanForCheckout.name}</h4>
                    <p className="text-xs text-slate-500 leading-relaxed">{selectedPlanForCheckout.description}</p>
                  </div>

                  <div className="space-y-2">
                    <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">Principais recursos liberados imediatamente:</span>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      {selectedPlanForCheckout.benefits.slice(0, 4).map((b, idx) => (
                        <li key={idx} className="flex items-center gap-1.5 text-slate-600">
                          <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500 shrink-0" />
                          <span className="truncate">{b}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg flex items-start gap-2.5 text-xs text-amber-800">
                    <Shield className="h-4.5 w-4.5 text-amber-600 shrink-0 mt-0.5" />
                    <span>Período de teste / Garantia incondicional ativa de 7 dias com reembolso total.</span>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-mono">VALOR DO PLANO</span>
                      <span className="text-2xl font-serif font-black text-slate-900">
                        R$ {(billingCycle === 'annual' ? selectedPlanForCheckout.annualPrice : selectedPlanForCheckout.monthlyPrice).toFixed(2)}
                        <span className="text-xs text-slate-400 font-normal"> /mês</span>
                      </span>
                    </div>

                    <button
                      onClick={() => setCheckoutStep(2)}
                      className="bg-slate-900 hover:bg-slate-800 text-white px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer"
                    >
                      Seguir para Pagamento <ChevronRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 2: COUPON & SECURE PAYMENT SIMULATION */}
              {checkoutStep === 2 && (
                <div className="space-y-5">
                  
                  {/* COUPON INPUT FIELD (Módulo 9) */}
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-800 uppercase tracking-wider block">Cupom de Desconto</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Ex: APROVADO30"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                        className="border border-slate-300 rounded-lg px-3 py-2 text-xs flex-1 uppercase font-mono"
                      />
                      <button
                        onClick={handleApplyCoupon}
                        className="bg-slate-200 hover:bg-slate-300 text-slate-800 px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider cursor-pointer"
                      >
                        Aplicar
                      </button>
                    </div>
                    {appliedCoupon && (
                      <p className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                        <Tag className="h-3.5 w-3.5" /> Cupom '{appliedCoupon.code}' aplicado com sucesso! Desconto de {appliedCoupon.discountType === 'percentage' ? `${appliedCoupon.value}%` : `R$ ${appliedCoupon.value}`}.
                      </p>
                    )}
                  </div>

                  {/* CHOOSE PAYMENT FORMAT */}
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-800 uppercase tracking-wider block">Forma de Pagamento Segura</label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => setPaymentMethod('pix')}
                        className={`p-3 border-2 rounded-lg text-center flex flex-col items-center gap-1 cursor-pointer transition-all ${
                          paymentMethod === 'pix' ? 'border-[#D4AF37] bg-amber-50/20 font-bold' : 'border-slate-200'
                        }`}
                      >
                        <Zap className="h-5 w-5 text-amber-500" />
                        <span className="text-[10px] uppercase">PIX</span>
                      </button>

                      <button
                        onClick={() => setPaymentMethod('credit_card')}
                        className={`p-3 border-2 rounded-lg text-center flex flex-col items-center gap-1 cursor-pointer transition-all ${
                          paymentMethod === 'credit_card' ? 'border-[#D4AF37] bg-amber-50/20 font-bold' : 'border-slate-200'
                        }`}
                      >
                        <CreditCard className="h-5 w-5 text-blue-500" />
                        <span className="text-[10px] uppercase">Cartão</span>
                      </button>

                      <button
                        onClick={() => setPaymentMethod('boleto')}
                        className={`p-3 border-2 rounded-lg text-center flex flex-col items-center gap-1 cursor-pointer transition-all ${
                          paymentMethod === 'boleto' ? 'border-[#D4AF37] bg-amber-50/20 font-bold' : 'border-slate-200'
                        }`}
                      >
                        <FileText className="h-5 w-5 text-slate-500" />
                        <span className="text-[10px] uppercase">Boleto</span>
                      </button>
                    </div>
                  </div>

                  {/* METHOD-SPECIFIC INTERFACES */}
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg min-h-24 flex flex-col justify-center">
                    
                    {/* PIX Interface */}
                    {paymentMethod === 'pix' && (
                      <div className="space-y-3 text-center">
                        <div className="w-24 h-24 bg-white border border-slate-200 mx-auto rounded flex items-center justify-center p-1.5 shadow-inner">
                          {/* Visual representation of active QR Code */}
                          <div className="w-full h-full bg-slate-100 flex flex-wrap gap-1 p-1">
                            {Array.from({ length: 49 }).map((_, i) => (
                              <div key={i} className={`w-2 h-2 ${i % 3 === 0 || i % 7 === 2 ? 'bg-slate-900' : 'bg-transparent'}`} />
                            ))}
                          </div>
                        </div>
                        <p className="text-[11px] text-slate-500 leading-relaxed">
                          Escaneie o QR Code acima no aplicativo do seu banco ou utilize o código Copia e Cola. A liberação do plano é **imediata**.
                        </p>
                        <button
                          onClick={() => {
                            setCopiedPix(true);
                            setTimeout(() => setCopiedPix(false), 2000);
                          }}
                          className="bg-slate-200 hover:bg-slate-300 text-slate-800 text-[10px] font-black px-3 py-1.5 rounded uppercase tracking-wider cursor-pointer"
                        >
                          {copiedPix ? '✓ Código Copiado!' : 'Copiar Chave Pix Copia e Cola'}
                        </button>
                      </div>
                    )}

                    {/* Credit Card Interface */}
                    {paymentMethod === 'credit_card' && (
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-2">
                          <div className="col-span-2">
                            <label className="text-[9px] uppercase font-mono text-slate-400 block">Número do Cartão</label>
                            <input
                              type="text"
                              placeholder="4000 1234 5678 9010"
                              value={creditCardNumber}
                              onChange={(e) => setCreditCardNumber(e.target.value)}
                              className="border border-slate-300 bg-white rounded px-2.5 py-1.5 text-xs w-full text-slate-800"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] uppercase font-mono text-slate-400 block">Validade</label>
                            <input
                              type="text"
                              placeholder="MM/AA"
                              value={creditCardExpiry}
                              onChange={(e) => setCreditCardExpiry(e.target.value)}
                              className="border border-slate-300 bg-white rounded px-2.5 py-1.5 text-xs w-full text-slate-800"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] uppercase font-mono text-slate-400 block">CVV</label>
                            <input
                              type="password"
                              placeholder="123"
                              value={creditCardCVV}
                              onChange={(e) => setCreditCardCVV(e.target.value)}
                              className="border border-slate-300 bg-white rounded px-2.5 py-1.5 text-xs w-full text-slate-800"
                            />
                          </div>
                          <div className="col-span-2">
                            <label className="text-[9px] uppercase font-mono text-slate-400 block">Nome Impresso no Cartão</label>
                            <input
                              type="text"
                              placeholder="FULANO DE TAL"
                              value={creditCardName}
                              onChange={(e) => setCreditCardName(e.target.value)}
                              className="border border-slate-300 bg-white rounded px-2.5 py-1.5 text-xs w-full text-slate-800 uppercase"
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Boleto Interface */}
                    {paymentMethod === 'boleto' && (
                      <div className="space-y-2 text-center py-2">
                        <FileText className="h-10 w-10 text-slate-400 mx-auto" />
                        <h5 className="font-bold text-xs text-slate-800">Boleto Bancário de Compensação</h5>
                        <p className="text-[11px] text-slate-500 leading-relaxed max-w-sm mx-auto">
                          O boleto será gerado no nome do aluno cadastrado e pode levar até 48 horas úteis para ser compensado após o pagamento.
                        </p>
                      </div>
                    )}

                  </div>

                  {/* PRICE SUMMARY & COMPETE BUTTON */}
                  <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-[10px] text-slate-400 font-mono block">VALOR A PAGAR</span>
                        {appliedCoupon && (
                          <span className="text-[11px] line-through text-slate-400">
                            R$ {(billingCycle === 'annual' ? selectedPlanForCheckout.annualPrice : selectedPlanForCheckout.monthlyPrice).toFixed(2)}
                          </span>
                        )}
                      </div>
                      <span className="text-2xl font-serif font-black text-emerald-600">
                        R$ {calculateDiscountedPrice(selectedPlanForCheckout).toFixed(2)}
                        <span className="text-xs text-slate-400 font-normal"> /mês</span>
                      </span>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => setCheckoutStep(1)}
                        className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider cursor-pointer"
                      >
                        Voltar
                      </button>

                      <button
                        onClick={handleCompletePayment}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow shadow-emerald-600/20 cursor-pointer"
                      >
                        Confirmar &amp; Ativar Plano <Check className="h-4 w-4 stroke-[3]" />
                      </button>
                    </div>
                  </div>

                </div>
              )}

              {/* STEP 3: PAYMENT CONFIRMATION SUCCESS (Módulo 11) */}
              {checkoutStep === 3 && (
                <div className="text-center space-y-5 py-6">
                  <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner animate-pulse">
                    <CheckCircle2 className="h-8 w-8 stroke-[3]" />
                  </div>

                  <div className="space-y-1.5">
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black tracking-widest px-3 py-1 rounded-full font-mono uppercase">
                      PAGAMENTO APROVADO!
                    </span>
                    <h4 className="font-serif font-black text-xl text-slate-900">
                      Seja bem-vindo ao OAB 3F Premium!
                    </h4>
                    <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto">
                      Seu plano <strong className="text-slate-800">{selectedPlanForCheckout.name}</strong> está oficialmente ativo e todos os bloqueios doutrinários foram removidos do seu perfil.
                    </p>
                  </div>

                  {/* List what was unlocked */}
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-xs space-y-2 text-left max-w-md mx-auto">
                    <span className="block font-bold text-slate-700 uppercase tracking-wider text-[10px]">Acesso Ilimitado Liberado:</span>
                    <ul className="grid grid-cols-2 gap-1 text-slate-600 font-medium">
                      <li>• Questões comentadas</li>
                      <li>• Simulados com IA</li>
                      <li>• Peças e Checklists</li>
                      <li>• Revisões Espaçadas</li>
                    </ul>
                  </div>

                  <div className="pt-4">
                    <button
                      onClick={() => {
                        setShowCheckoutModal(false);
                        setActiveSubTab('assinatura');
                        onNavigateToTab('inicio');
                      }}
                      className="bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-lg text-xs font-bold uppercase tracking-widest cursor-pointer w-full shadow-md"
                    >
                      Ir para Painel de Estudos
                    </button>
                  </div>
                </div>
              )}

            </div>

          </div>
        </div>
      )}

    </div>
  );
}
