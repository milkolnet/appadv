/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Search, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  BookOpen, 
  Settings, 
  CreditCard, 
  AlertTriangle 
} from 'lucide-react';
import { SupportFAQ } from '../types';

interface CommunityFAQProps {
  faqs: SupportFAQ[];
  onNeedHelpClick: () => void;
}

export default function CommunityFAQ({ faqs, onNeedHelpClick }: CommunityFAQProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todas');
  const [openFaqId, setOpenFaqId] = useState<string | null>(null);

  const categories = [
    { id: 'Todas', name: 'Todas as Dúvidas', icon: HelpCircle },
    { id: 'Uso do App', name: 'Uso do Aplicativo', icon: Settings },
    { id: 'Sobre o Exame', name: 'Exame OAB', icon: BookOpen },
    { id: 'Repescagem', name: 'Repescagem e Cronogramas', icon: CreditCard },
    { id: 'Conteúdo', name: 'Dúvidas Técnicas', icon: AlertTriangle }
  ];

  const handleToggle = (id: string) => {
    setOpenFaqId(openFaqId === id ? null : id);
  };

  // Filter FAQs
  const filteredFaqs = faqs.filter(faq => {
    const matchesSearch = faq.question.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          faq.answer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'Todas' || faq.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6 animate-fade-in" id="community-faq-workspace">
      {/* Search Header Banner */}
      <div className="bg-slate-900 rounded-xl p-6 text-white relative overflow-hidden shadow-sm">
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#D4AF37]/5 rounded-full filter blur-xl" />
        <div className="max-w-xl space-y-4">
          <span className="bg-[#D4AF37]/20 text-[#D4AF37] text-[9px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full font-mono">
            BASE DE CONHECIMENTO OAB 3F
          </span>
          <h2 className="font-serif font-bold text-xl text-slate-100">Como podemos ajudar você hoje?</h2>
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Digite sua dúvida (ex: simulado, cronograma, repescagem...)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-9 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
            />
          </div>
        </div>
      </div>

      {/* Grid: Categories Sidebar vs Accordions */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Categories Grid (Left) */}
        <div className="md:col-span-4 space-y-2">
          <h3 className="text-[10.5px] font-bold text-slate-400 uppercase tracking-widest px-1">Categorias</h3>
          <div className="flex flex-wrap md:flex-col gap-1.5">
            {categories.map(cat => {
              const Icon = cat.icon;
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    setOpenFaqId(null);
                  }}
                  className={`w-full text-left p-3 rounded-lg text-xs font-semibold flex items-center space-x-2.5 transition-all cursor-pointer border ${
                    isSelected 
                      ? 'bg-slate-900 text-white border-slate-900 shadow-sm' 
                      : 'bg-white hover:bg-slate-50 text-slate-600 border-slate-200'
                  }`}
                >
                  <Icon className={`h-4 w-4 ${isSelected ? 'text-[#D4AF37]' : 'text-slate-400'}`} />
                  <span>{cat.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* FAQ Accordions List (Right) */}
        <div className="md:col-span-8 space-y-3">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <h3 className="text-sm font-black text-slate-800 pb-3 border-b border-slate-100">
              Perguntas Frequentes — {selectedCategory === 'Todas' ? 'Todas' : selectedCategory}
            </h3>

            {filteredFaqs.length === 0 ? (
              <div className="text-center py-10 space-y-2">
                <p className="text-xs text-slate-500 font-semibold">Nenhum artigo encontrado para sua busca.</p>
                <p className="text-[11px] text-slate-400">Tente buscar por termos mais genéricos como "prova" ou "fase".</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {filteredFaqs.map(faq => {
                  const isOpen = openFaqId === faq.id;
                  return (
                    <div 
                      key={faq.id} 
                      className="border border-slate-150 rounded-xl overflow-hidden shadow-xs transition-all"
                    >
                      <button
                        onClick={() => handleToggle(faq.id)}
                        className="w-full text-left p-4 bg-slate-50/50 hover:bg-slate-50/90 flex justify-between items-center transition-colors cursor-pointer"
                      >
                        <span className="text-xs font-bold text-slate-800 pr-4 leading-snug">{faq.question}</span>
                        {isOpen ? (
                          <ChevronUp className="h-4 w-4 text-slate-400 shrink-0" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-slate-400 shrink-0" />
                        )}
                      </button>

                      {isOpen && (
                        <div className="p-4 bg-white border-t border-slate-100 text-xs text-slate-600 leading-relaxed font-medium animate-fade-in">
                          {faq.answer}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Need help footer section */}
          <div className="bg-amber-500/5 border border-amber-500/15 rounded-xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-0.5 text-center sm:text-left">
              <h4 className="text-xs font-bold text-slate-800">Não encontrou o que precisava?</h4>
              <p className="text-[10.5px] text-slate-500 leading-relaxed font-medium">
                Abra um chamado direto com nossa equipe de mentores acadêmicos e suporte pedagógico.
              </p>
            </div>
            <button
              onClick={onNeedHelpClick}
              className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2.5 rounded-lg transition-colors cursor-pointer uppercase tracking-wider shrink-0"
            >
              Falar com Suporte
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
