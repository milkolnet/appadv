/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  FileText,
  BookOpen,
  Map,
  Compass,
  CheckSquare,
  FileDown,
  BookOpenCheck,
  ChevronDown,
  ChevronRight,
  Eye,
  Award,
  Search,
  Star,
  Download,
  Bookmark,
  History,
  FileSpreadsheet,
  AlertTriangle,
  Maximize2,
  SlidersHorizontal,
  Sparkles,
  BookMarked,
  Clock,
  ArrowLeft,
  CheckCircle,
  FolderHeart,
  Grid,
  Scale,
  Library,
  Zap,
  Check,
  AlertCircle,
  HelpCircle,
  RotateCcw
} from 'lucide-react';
import { Discipline, PDFMaterial, StudentProgress } from '../types';

interface StudyMaterialsProps {
  disciplines: Discipline[];
  onSaveActivity: (tab: string, title: string, sectionId?: string, itemId?: string) => void;
  progress: StudentProgress;
  setProgress: React.Dispatch<React.SetStateAction<StudentProgress>>;
}

// Custom interfaces for our extended library
interface LibraryItem {
  id: string;
  title: string;
  discipline: string;
  theme: string;
  phase: '1ª Fase' | '2ª Fase' | 'Reta Final' | 'Ambas';
  type: 'pdf' | 'resumo' | 'mapa' | 'lei_seca' | 'modelo_peca' | 'checklist' | 'reta_final';
  importance: 'Muito Alta' | 'Alta' | 'Média';
  pageCount?: number;
  readTimeMinutes?: number;
  summary: string;
  contentMarkdown?: string; // Rich text simulation for the in-app reader
  articlesList?: string[]; // Specifically for lei_seca
  checklistItems?: string[]; // Specifically for checklists
  pieceStructure?: { section: string; explanation: string }[]; // Specifically for pieces
  commonErrors?: string[]; // Specifically for pieces
}

export default function StudyMaterials({
  disciplines,
  onSaveActivity,
  progress,
  setProgress
}: StudyMaterialsProps) {
  // Navigation for tab panels (Seção 1 - 10)
  // 'inicio' = Seção 1 (Tela principal / Explorar acervo)
  // 'fases' = Seção 2 (Organização por fase)
  // 'pdfs' = Seção 3 (PDFs das Aulas)
  // 'resumos' = Seção 4 (Resumos por disciplina)
  // 'mapas' = Seção 5 (Mapas mentais)
  // 'lei_seca' = Seção 6 (Lei seca organizada)
  // 'segunda_fase' = Seção 7 (Biblioteca 2ª fase)
  // 'modelos' = Seção 8 (Modelos de Peças e checklists)
  // 'reta_final' = Seção 9 (Materiais Reta Final)
  // 'pessoal' = Seção 10 (Favoritos, downloads e histórico)
  const [activeTab, setActiveTab] = useState<'inicio' | 'fases' | 'pdfs' | 'resumos' | 'mapas' | 'lei_seca' | 'segunda_fase' | 'modelos' | 'reta_final' | 'pessoal'>('inicio');

  // Interactive local lists synced to local storage
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('oab3f_mat_favorites');
    return saved ? JSON.parse(saved) : ['res-1', 'map-1', 'lei-1'];
  });

  const [downloads, setDownloads] = useState<string[]>(() => {
    const saved = localStorage.getItem('oab3f_mat_downloads');
    return saved ? JSON.parse(saved) : ['pdf-1'];
  });

  const [completedItems, setCompletedItems] = useState<string[]>(() => {
    const saved = localStorage.getItem('oab3f_mat_completed');
    return saved ? JSON.parse(saved) : ['pdf-1'];
  });

  const [inProgressItems, setInProgressItems] = useState<{ [key: string]: number }>(() => {
    const saved = localStorage.getItem('oab3f_mat_inprogress');
    return saved ? JSON.parse(saved) : { 'res-2': 40 }; // ID to progress percentage
  });

  const [recentlyOpened, setRecentlyOpened] = useState<string[]>(() => {
    const saved = localStorage.getItem('oab3f_mat_recent');
    return saved ? JSON.parse(saved) : ['res-1', 'res-2', 'map-1'];
  });

  // Search and general filter query state (Seção 11)
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDisciplineFilter, setSelectedDisciplineFilter] = useState('Todas');
  const [selectedImportanceFilter, setSelectedImportanceFilter] = useState('Todas');

  // In-app Reader Modal State (Funcionalidade Obrigatória 1)
  const [activeReadingItem, setActiveReadingItem] = useState<LibraryItem | null>(null);
  const [readerProgress, setReaderProgress] = useState(0);

  // Sync state to local storage on modification
  useEffect(() => {
    localStorage.setItem('oab3f_mat_favorites', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem('oab3f_mat_downloads', JSON.stringify(downloads));
  }, [downloads]);

  useEffect(() => {
    localStorage.setItem('oab3f_mat_completed', JSON.stringify(completedItems));
  }, [completedItems]);

  useEffect(() => {
    localStorage.setItem('oab3f_mat_inprogress', JSON.stringify(inProgressItems));
  }, [inProgressItems]);

  useEffect(() => {
    localStorage.setItem('oab3f_mat_recent', JSON.stringify(recentlyOpened));
  }, [recentlyOpened]);

  // Selected Area for 2nd Phase
  const selectedSecondPhaseArea = progress?.selectedSecondPhaseArea || 'Direito Penal';

  // Comprehensive static library of strategic files (Academic/Juridical asset database)
  const libraryItems: LibraryItem[] = useMemo(() => {
    return [
      // PDFs from lectures compiled dynamically + custom curated ones
      {
        id: 'pdf-1',
        title: 'Teoria Geral dos Recursos Criminais',
        discipline: 'Processo Penal',
        theme: 'Recursos',
        phase: 'Ambas',
        type: 'pdf',
        importance: 'Muito Alta',
        pageCount: 28,
        readTimeMinutes: 45,
        summary: 'Resumo estrutural completo abordando o cabimento de apelação, recurso em sentido estrito e prazos recursais no CPP.',
        contentMarkdown: `## Teoria Geral dos Recursos no CPP

Os recursos constituem meios voluntários de impugnação de decisões judiciais, voltados à reforma, invalidação, esclarecimento ou integração dos julgados.

### Princípios Recursais Fundamentais
1. **Duplo Grau de Jurisdição:** Garantia de reexame da decisão por órgão hierarquicamente superior.
2. **Voluntariedade:** A iniciativa da impugnação cabe exclusivamente às partes (exceção feita ao recurso de ofício).
3. **Taxatividade:** Apenas são considerados recursos os meios expressamente previstos em lei federal (Art. 22, I, CF).
4. **Unirrecorribilidade (Singularidade):** Para cada decisão judicial cabe apenas um único recurso adequado.

### Recursos em Espécie e Prazos Críticos
*   **Apelação Criminal (Art. 593, CPP):** Prazo de 5 dias para interposição e 8 dias para apresentação das razões. Cabe de decisões definitivas ou com força de definitivas.
*   **Recurso em Sentido Estrito - RESE (Art. 581, CPP):** Prazo de 5 dias para interposição e 2 dias para razões. Possui efeito regressivo (juízo de retratação em 5 dias).
*   **Embargos de Declaração (Art. 619, CPP):** Prazo de 2 dias. Objeto: ambiguidade, obscuridade, contradição ou omissão.
*   **Carta Testemunhável (Art. 639, CPP):** Prazo de 48 horas.`
      },
      {
        id: 'pdf-2',
        title: 'Estatuto da OAB: Direitos do Advogado Esquematizado',
        discipline: 'Ética Profissional',
        theme: 'Direitos do Advogado',
        phase: '1ª Fase',
        type: 'pdf',
        importance: 'Muito Alta',
        pageCount: 16,
        readTimeMinutes: 25,
        summary: 'Guia visual e analítico do Artigo 7º do Estatuto da Advocacia (Lei 8.906/94), focado em prerrogativas e inviolabilidade de escritórios.',
        contentMarkdown: `## Prerrogativas do Advogado (Art. 7º, Lei 8.906/94)

As prerrogativas profissionais não constituem privilégios pessoais, mas garantias indispensáveis para o amplo exercício da defesa e a proteção do cidadão contra arbítrios estatais.

### 1. Inviolabilidade do Escritório de Advocacia
O local de trabalho, arquivos, dados e comunicações telefônicas ou telemáticas do advogado são invioláveis, desde que relativas ao exercício da profissão.
*   *Exceção:* Busca e apreensão determinada por juiz de forma motivada, acompanhada por representante da OAB, sob pena de nulidade absoluta da diligência.

### 2. Direito de Comunicação com Clientes
Garantia de comunicar-se pessoal e reservadamente com seus clientes, mesmo que presos ou detidos, ainda que considerados incomunicáveis.

### 3. Presença de Representante da OAB em Prisão em Flagrante
O advogado tem o direito de não ser preso em flagrante por motivo ligado ao exercício profissional, salvo em caso de crime inafiançável. A OAB deve ser notificada para que um representante acompanhe a lavratura do auto.`
      },
      {
        id: 'pdf-3',
        title: 'Controle de Constitucionalidade Concentrado',
        discipline: 'Direito Constitucional',
        theme: 'Controle de Constitucionalidade',
        phase: 'Ambas',
        type: 'pdf',
        importance: 'Muito Alta',
        pageCount: 32,
        readTimeMinutes: 50,
        summary: 'Análise minuciosa dos legitimados ativos e efeitos das decisões de ADI, ADC, ADO e ADPF perante o STF.',
        contentMarkdown: `## Controle Concentrado de Constitucionalidade

O controle abstrato de constitucionalidade tem por escopo a defesa objetiva da ordem constitucional, retirando do sistema as normas incompatíveis com a Lei Maior.

### Legitimados Ativos (Art. 103, CF)
Podem propor ADI, ADC, ADO e ADPF:
1.  Presidente da República
2.  Mesa do Senado Federal
3.  Mesa da Câmara dos Deputados
4.  Mesa de Assembleia Legislativa ou da Câmara Legislativa do DF (exige pertinência temática)
5.  Governador de Estado ou do DF (exige pertinência temática)
6.  Procurador-Geral da República
7.  Conselho Federal da OAB (legitimado universal)
8.  Partido Político com representação no Congresso Nacional (legitimado universal)
9.  Confederação Sindical ou Entidade de Classe de âmbito nacional (exige pertinência temática)

### Efeitos das Decisões
*   **Efeito Vinculante:** Obriga os demais órgãos do Poder Judiciário e a Administração Pública direta e indireta (não vincula o próprio STF nem o Poder Legislativo em sua função típica de legislar).
*   **Efeito Erga Omnes:** Aplica-se contra todos.
*   **Efeito Ex Tunc (Regra Geral):** Retroativo à data de promulgação da lei declarada inconstitucional.`
      },

      // SUMMARIES (Seção 4)
      {
        id: 'res-1',
        title: 'Sigilo Profissional: Deveres e Limites Éticos',
        discipline: 'Ética Profissional',
        theme: 'Sigilo Profissional',
        phase: '1ª Fase',
        type: 'resumo',
        importance: 'Muito Alta',
        readTimeMinutes: 12,
        summary: 'Resumo com foco em questões de Ética OAB. Aborda quando o sigilo pode ser quebrado legitimamente.',
        contentMarkdown: `## Sigilo Profissional do Advogado

O sigilo profissional é de ordem pública, decorrendo do direito constitucional de ampla defesa.

### Regra Geral
O advogado é obrigado a manter sigilo sobre todos os fatos de que tome conhecimento no exercício de sua atividade profissional (Art. 35 a 38 do Código de Ética e Disciplina).

### Exceções Legítimas para Quebra de Sigilo
A quebra de sigilo é excepcional e autorizada apenas quando houver:
1.  **Grave ameaça à vida ou à honra do próprio advogado;**
2.  **Autodefesa do advogado** diante de acusações de seu próprio cliente (ex: cobrança de honorários ou representação disciplinar injusta);
3.  **Necessidade de obstar a prática de crime iminente.**

*Dica de Ouro:* A quebra de sigilo deve limitar-se estritamente ao necessário para a defesa ou proteção, não se admitindo a revelação ampla ou indiscriminada de fatos.`
      },
      {
        id: 'res-2',
        title: 'Diferenças de Nulidades Absolutas e Relativas',
        discipline: 'Processo Penal',
        theme: 'Nulidades',
        phase: 'Ambas',
        type: 'resumo',
        importance: 'Alta',
        readTimeMinutes: 10,
        summary: 'Tabela mental expressiva detalhando prejuízos presumidos, preclusão temporal e interesse das partes.',
        contentMarkdown: `## Nulidades no Processo Penal (Art. 563 a 573, CPP)

O sistema de nulidades penais é regido pelo princípio basilar do *Pas de Nullité Sans Grief* (não há nulidade sem prejuízo).

### Nulidade Absoluta
*   **Interesse:** Público. Há violação de norma constitucional ou de princípio estrutural do processo penal (ex: contraditório, ampla defesa).
*   **Prejuízo:** Presumido pela lei.
*   **Arguição:** Pode ser declarada de ofício pelo juiz ou alegada por qualquer das partes a qualquer tempo e grau de jurisdição (não preclui).

### Nulidade Relativa
*   **Interesse:** Predominantemente das partes. Há infração de norma infraconstitucional garantidora de interesse privado (ex: prazos de intimação).
*   **Prejuízo:** Deve ser efetivamente comprovado pela parte prejudicada.
*   **Arguição:** Deve ser alegada no momento oportuno sob pena de preclusão (perda do direito de manifestação) e convalidação do ato.`
      },
      {
        id: 'res-3',
        title: 'Responsabilidade Civil Objetiva do Estado (Art. 37, §6º CF)',
        discipline: 'Direito Administrativo',
        theme: 'Responsabilidade do Estado',
        phase: '1ª Fase',
        type: 'resumo',
        importance: 'Alta',
        readTimeMinutes: 15,
        summary: 'Estudo esquematizado da teoria do risco administrativo, nexo de causalidade e ação de regresso.',
        contentMarkdown: `## Responsabilidade Civil do Estado

O ordenamento jurídico pátrio adota, como regra geral, a **Teoria do Risco Administrativo** para fundamentar a responsabilidade objetiva do Estado.

### Requisitos para Configuração (Sem necessidade de dolo ou culpa)
1.  **Conduta Administrativa:** Ação ou omissão de agente público atuando nessa qualidade.
2.  **Dano Material ou Moral:** Prejuízo efetivo causado a terceiro.
3.  **Nexo de Causalidade:** Relação direta de causa e efeito entre a conduta do Estado e o dano sofrido.

### Causas Excludentes de Responsabilidade
O Estado afasta o dever de indenizar se provar:
*   **Culpa exclusiva da vítima** (se houver culpa concorrente, a indenização é atenuada).
*   **Caso fortuito ou força maior**.
*   **Fato exclusivo de terceiro**.`
      },

      // MINDMAPS (Seção 5)
      {
        id: 'map-1',
        title: 'Fluxo Procedimental do Habeas Corpus',
        discipline: 'Processo Penal',
        theme: 'Ações Constitucionais',
        phase: 'Ambas',
        type: 'mapa',
        importance: 'Muito Alta',
        summary: 'Roteiro visual sequencial das fases do Habeas Corpus impetrado perante o Tribunal de Justiça ou STJ.',
        contentMarkdown: `### 🗺️ MAPA MENTAL: FLUXOGRAMA DO HABEAS CORPUS

                           [ATO COATOR / AMEAÇA À LIBERDADE]
                                          │
                                          ▼
                       [IMPETRAÇÃO DO WRIT (Qualquer Pessoa)]
                                          │
                       ┌──────────────────┴──────────────────┐
                       ▼                                     ▼
             [Petição Inicial Padrão]            [Distribuição Urgente]
                       │                                     │
                       └──────────────────┬──────────────────┘
                                          │
                                          ▼
                        [ANÁLISE DE LIMINAR (Relator/Juiz)]
                                          │
                    ┌─────────────────────┴─────────────────────┐
                    ▼                                           ▼
            [Deferida: Liminar]                       [Indeferida: Segue]
         (Soltura imediata/Salvo Conduto)               (Aguardar Julgamento)
                    │                                           │
                    └─────────────────────┬─────────────────────┘
                                          │
                                          ▼
                   [REQUISIÇÃO DE INFORMAÇÕES À AUTORIDADE COATORA]
                                          │
                                          ▼
                     [PARECER DO MINISTÉRIO PÚBLICO (Custos Legis)]
                                          │
                                          ▼
                         [JULGAMENTO DO MÉRITO PELO ÓRGÃO COLEGIADO]
                                          │
                    ┌─────────────────────┴─────────────────────┐
                    ▼                                           ▼
           [Concedida a Ordem 🎉]                     [Denegada a Ordem ⚠️]
          (Cessação imediata da coação)                 (Cabe Recurso Ordinário)`
      },
      {
        id: 'map-2',
        title: 'Árvore de Cabimento de Recursos Cíveis (CPC)',
        discipline: 'Processo Civil',
        theme: 'Recursos no CPC',
        phase: '1ª Fase',
        type: 'mapa',
        importance: 'Alta',
        summary: 'Estruturação didática e comparativa de Apelação, Agravo de Instrumento, Embargos e Agravo Interno.',
        contentMarkdown: `### 🗺️ MAPA MENTAL: ÁRVORE DE RECURSOS CÍVEIS (Art. 994, CPC)

                        [DECISÃO DO JUIZ DE PRIMEIRO GRAU]
                                        │
             ┌──────────────────────────┴──────────────────────────┐
             ▼                                                     ▼
      [SENTENÇA (Art. 203, §1º)]                         [DECISÃO INTERLOCUTÓRIA]
             │                                                     │
             ▼                                        ┌────────────┴────────────┐
       [APELAÇÃO (Art. 1.009)]                        ▼                         ▼
      • Prazo: 15 dias                         [Urgentem/Rol 1.015]     [Demais Decisões]
      • Efeito suspensivo regra                    │                         │
                                                   ▼                         ▼
                                         [AGRAVO DE INSTRUMENTO]      [Alegar preliminar]
                                         • Prazo: 15 dias             (Nas razões de Apelação)`
      },

      // LEI SECA (Seção 6)
      {
        id: 'lei-1',
        title: 'Direitos Relevantes do Advogado (Estatuto OAB Art. 7º)',
        discipline: 'Ética Profissional',
        theme: 'Prerrogativas',
        phase: '1ª Fase',
        type: 'lei_seca',
        importance: 'Muito Alta',
        summary: 'Os incisos mais sorteados e cobrados na prova da OAB. Ideal para fixação e leitura ativa antes da prova.',
        articlesList: [
          'Art. 7º, I: Exercer, com liberdade, a profissão em todo o território nacional.',
          'Art. 7º, III: Comunicar-se com seus clientes, pessoal e reservadamente, mesmo sem procuração, quando estes se acharem presos.',
          'Art. 7º, VI: Ingressar livremente nas salas de sessões dos tribunais, nas salas de audiência e repartições públicas.',
          'Art. 7º, XI: Reclamar, verbalmente ou por escrito, perante qualquer juízo ou tribunal, contra a inobservância de preceito de lei.',
          'Art. 7º, XX: Retirar-se do recinto onde aguarda pregão após trinta minutos do horário designado, se a autoridade não houver comparecido.'
        ],
        contentMarkdown: `## Estudo Dirigido de Lei Seca: Art. 7º do Estatuto da OAB

Este artigo é a espinha dorsal de ética. Praticamente metade das questões da prova objetiva envolve as garantias do advogado em face de delegados, juízes e promotores.

### Pontos Críticos para Decorar:
*   **Incisos I e III (Garantias Básicas):** Inviolabilidade de documentos e comunicação irrestrita com o preso.
*   **Pregão e Atraso (Inciso XX):** O limite é **30 minutos**. O advogado deve formalizar comunicação por escrito para se retirar legitimamente se o juiz atrasar.
*   **Sustentação Oral (Inciso IX):** Direito de sustentar oralmente as razões de qualquer recurso ou processo judicial, após o voto do relator (nos termos Regimentais).`
      },
      {
        id: 'lei-2',
        title: 'Remédios Constitucionais Essenciais (Art. 5º da CF)',
        discipline: 'Direito Constitucional',
        theme: 'Remédios Constitucionais',
        phase: 'Ambas',
        type: 'lei_seca',
        importance: 'Muito Alta',
        summary: 'Compilado dos remédios mais cobrados pela FGV: Habeas Corpus, Mandado de Segurança, Mandado de Injunção, Habeas Data e Ação Popular.',
        articlesList: [
          'Art. 5º, LXVIII: Conceder-se-á habeas corpus sempre que alguém sofrer ou se achar ameaçado de sofrer violência ou coação em sua liberdade de locomoção.',
          'Art. 5º, LXIX: Conceder-se-á mandado de segurança para proteger direito líquido e certo, não amparado por habeas corpus ou habeas data.',
          'Art. 5º, LXXI: Conceder-se-á mandado de injunção sempre que a falta de norma regulamentadora torne inviável o exercício dos direitos constitucionais.',
          'Art. 5º, LXXII: Conceder-se-á habeas data para assegurar o conhecimento de informações relativas à pessoa do impetrante.',
          'Art. 5º, LXXIII: Qualquer cidadão é parte legítima para propor ação popular que vise a anular ato lesivo ao patrimônio público.'
        ]
      },

      // 2ª FASE SPECIFIC AREA (Seção 7 & 8)
      {
        id: 'peca-1',
        title: `Guia de Estrutura de Peças de ${selectedSecondPhaseArea}`,
        discipline: selectedSecondPhaseArea,
        theme: 'Peças Práticas',
        phase: '2ª Fase',
        type: 'modelo_peca',
        importance: 'Muito Alta',
        summary: 'Roteiro de estruturação padrão com endereçamento, qualificação, fatos, fundamentos jurídicos e pedidos obrigatórios.',
        pieceStructure: [
          { section: '1. Endereçamento (Juízo Ad Quo ou Quem de Direito)', explanation: 'Ex: "Excelentíssimo Senhor Doutor Juiz de Direito da ... Vara Criminal da Comarca de ..."' },
          { section: '2. Qualificação do Autor/Querelante/Requerente', explanation: 'Inserir nome, nacionalidade, estado civil, profissão, RG, CPF, domicílio e residência, com fulcro no artigo legal aplicável.' },
          { section: '3. Dos Fatos (Síntese Objetiva)', explanation: 'Resumo das circunstâncias trazidas pelo problema de forma estritamente conexa, sem inventar fatos novos sob pena de desclassificação da peça.' },
          { section: '4. Dos Fundamentos Jurídicos (Teses e Subteses)', explanation: 'Divisão em preliminares (mérito preliminar, nulidades) e teses de mérito (absorção, atipicidade, causas de exclusão da ilicitude, dosimetria).' },
          { section: '5. Dos Pedidos e Requerimentos', explanation: 'Conexão exata com as teses abordadas no mérito: concessão de alvará, absolvição sumária, anulação do processo, etc.' }
        ],
        commonErrors: [
          'Identificar a peça escrevendo o próprio nome ou criando assinaturas fictícias (zera a prova)',
          'Esquecer de indicar o fundamento legal exato da peça na interposição',
          'Inventar dados que não constavam no enunciado (como nomes de testemunhas, datas ou comarcas fictícias)'
        ],
        contentMarkdown: `## Estrutura Fundamental de Peça Prático-Profissional (2ª Fase)

Garantir uma pontuação excelente na peça prática exige rigor formal. A banca examina principalmente a correspondência de artigos e a lógica formal de apresentação.

### Esqueleto Básico da Interposição:
1.  **Endereçamento** adequado ao órgão competente.
2.  **Qualificação das Partes** com o verbo de ação adequado ("vem respeitosamente interpor...").
3.  **Fundamentação Legal** precisa da interposição (Artigo correspondente do CPC, CPP ou CLT).
4.  **Pedidos de admissão** e remessa das razões recursais ao tribunal superior se aplicável.`
      },
      {
        id: 'peca-2',
        title: `Checklist Definitivo para Peças Práticas de ${selectedSecondPhaseArea}`,
        discipline: selectedSecondPhaseArea,
        theme: 'Checklists de Elementos',
        phase: '2ª Fase',
        type: 'checklist',
        importance: 'Muito Alta',
        summary: 'Os elementos cruciais exigidos pelo gabarito FGV para garantir nota máxima em peças desta disciplina.',
        checklistItems: [
          'Fundamentação exata do endereçamento principal',
          'Qualificação e menção do advogado subscritor com instrumento de procuração',
          'Abordagem expressa das teses preliminares de mérito / processuais',
          'Indicação pontual de súmulas do STF ou STJ aplicáveis',
          'Pedidos de gratuidade judiciária ou prioridade se visíveis no caso prático',
          'Fechamento com Local, Data, Advogado e OAB (sem preencher dados fictícios)'
        ]
      },

      // RETA FINAL (Seção 9)
      {
        id: 'reta-1',
        title: 'Checklist "Não Pode Errar" para Véspera da Prova',
        discipline: 'Geral',
        theme: 'Revisão Intensiva',
        phase: 'Reta Final',
        type: 'reta_final',
        importance: 'Muito Alta',
        summary: 'Compilado ultra objetivo de lembretes administrativos e gatilhos de conteúdo para os últimos 3 dias antes da 1ª Fase.',
        contentMarkdown: `## Checklist de Véspera - Foco Máximo!

Faltando poucas horas para a prova objetiva, o foco deve ser a blindagem mental e a consolidação de temas que representam ganhos garantidos.

### 🛡️ Dicas de Ouro de Ética Profissional (8 Questões):
1.  **Incompatibilidade vs Impedimento:** Incompatibilidade é proibição total (ex: Delegados, Juízes, Gerentes de Banco). Impedimento é proibição parcial, apenas contra quem lhe remunera (ex: Servidores Públicos em geral).
2.  **Publicidade na Advocacia:** É permitida publicidade meramente informativa e sóbria. É vedada a captação de clientela, mercantilização, anúncios em rádio/TV ou panfletagem.
3.  **Sanções Disciplinares:** Censura (infrações leves, primários), Suspensão (reincidência, retenção de autos, desvio de fundos - dura de 30 dias a 12 meses), Exclusão (falsidade ideológica, idoneidade moral de forma reiterada, exige quórum de 2/3 dos membros do Tribunal de Ética).`
      }
    ];
  }, [selectedSecondPhaseArea]);

  // Handle Action: Add material to Favorites
  const handleToggleFavorite = (itemId: string) => {
    setFavorites(prev => {
      const exists = prev.includes(itemId);
      const updated = exists ? prev.filter(id => id !== itemId) : [...prev, itemId];
      onSaveActivity('Materiais', `${exists ? 'Removeu dos' : 'Adicionou aos'} favoritos`, 'Favoritos', itemId);
      return updated;
    });
  };

  // Handle Action: Simulating PDF or Resource Download
  const handleDownload = (item: LibraryItem) => {
    setDownloads(prev => {
      if (!prev.includes(item.id)) {
        return [...prev, item.id];
      }
      return prev;
    });
    alert(`[Download Simulado] O material "${item.title}" foi baixado em PDF de alta qualidade e está disponível offline no seu dispositivo.`);
    onSaveActivity('Materiais', `Realizou download de material`, 'Downloads', item.id);
  };

  // Handle Action: Open Document Reader Modal (Funcionalidade Obrigatória 1 & 3)
  const handleOpenReader = (item: LibraryItem) => {
    setActiveReadingItem(item);
    
    // Add to recently opened list
    setRecentlyOpened(prev => {
      const filtered = prev.filter(id => id !== item.id);
      return [item.id, ...filtered].slice(0, 8); // Keep last 8
    });

    // Determine current progress percentage or start new
    const initialProgress = inProgressItems[item.id] || 0;
    setReaderProgress(initialProgress);
    onSaveActivity('Materiais', `Abriu para leitura dentro do app: ${item.title}`, 'Leitor', item.id);
  };

  // Handle Action: Mark current item as fully completed (Seção 10 / Continuar Leitura)
  const handleMarkAsCompleted = (itemId: string) => {
    setCompletedItems(prev => {
      if (!prev.includes(itemId)) {
        return [...itemId, ...prev];
      }
      return prev;
    });
    setInProgressItems(prev => {
      const copy = { ...prev };
      delete copy[itemId];
      return copy;
    });
    alert("Parabéns! Esse material foi classificado como ESTUDADO e foi contabilizado em sua carga horária de revisão.");
    
    // Auto increment progress study hours for realism
    setProgress(prev => ({
      ...prev,
      weeklyStudyHours: Math.min(prev.weeklyStudyHours + 1, prev.studyHoursGoal)
    }));

    if (activeReadingItem?.id === itemId) {
      setReaderProgress(100);
    }
  };

  // Handle Action: Simulate reader scrolling / reading page progression
  const handleReaderScrollProgress = (increment: number) => {
    if (!activeReadingItem) return;
    setReaderProgress(prev => {
      const next = Math.min(prev + increment, 100);
      setInProgressItems(curr => ({
        ...curr,
        [activeReadingItem.id]: next
      }));
      if (next === 100) {
        // If 100%, mark completed automatically
        if (!completedItems.includes(activeReadingItem.id)) {
          setCompletedItems(currComp => [...currComp, activeReadingItem.id]);
        }
      }
      return next;
    });
  };

  // Reset Reading Statistics
  const handleResetStatistics = () => {
    if (window.confirm("Deseja realmente limpar seu histórico e materiais marcados como estudados? Isso não afetará seus favoritos.")) {
      setCompletedItems([]);
      setInProgressItems({});
      setRecentlyOpened([]);
      setDownloads([]);
      alert("Estatísticas de estudo redefinidas com sucesso!");
    }
  };

  // --- SEÇÃO 12: AUTO RECOMMENDATION ENGINES ---
  // Returns highly targeted recommendation structures based on the student's background
  const automaticRecommendations = useMemo(() => {
    const list = [];
    
    // Recommendation 1: Always recommend the 2ª phase material selected by the student
    const activeP2 = libraryItems.find(item => item.type === 'modelo_peca' && item.discipline === selectedSecondPhaseArea);
    if (activeP2) {
      list.push({
        title: `Guia Crítico: Peças de ${selectedSecondPhaseArea}`,
        reason: `Indicado para sua preparação estratégica de 2ª Fase escolhida.`,
        item: activeP2,
        badge: 'Foco 2ª Fase',
        icon: Scale
      });
    }

    // Recommendation 2: Recommend Ética Profissional due to high strategic value (8 questions)
    const activeEtica = libraryItems.find(item => item.discipline === 'Ética Profissional' && item.type === 'lei_seca');
    if (activeEtica) {
      list.push({
        title: 'Lei Seca Dirigida: Art. 7º Prerrogativas',
        reason: 'Ética garante 10% de toda a prova de 1ª Fase. Dominar prerrogativas é obrigatório.',
        item: activeEtica,
        badge: 'Rendimento OAB',
        icon: ShieldAlertIcon
      });
    }

    // Recommendation 3: Recommend Processo Penal due to recurring question failures
    const activePP = libraryItems.find(item => item.discipline === 'Processo Penal' && item.type === 'mapa');
    if (activePP) {
      list.push({
        title: 'Mapa Mental: Fluxograma do Habeas Corpus',
        reason: 'Tema com altíssimo índice de erro em Processo Penal. Memorize visualmente.',
        item: activePP,
        badge: 'Dificuldade Detectada',
        icon: Map
      });
    }

    return list;
  }, [libraryItems, selectedSecondPhaseArea]);


  // --- SEÇÃO 11: ADVANCED FILTERING LOGIC ---
  const filteredLibraryItems = useMemo(() => {
    return libraryItems.filter(item => {
      // 1. Search Query
      const query = searchQuery.toLowerCase().trim();
      if (query !== '') {
        const matchTitle = item.title.toLowerCase().includes(query);
        const matchDiscipline = item.discipline.toLowerCase().includes(query);
        const matchTheme = item.theme.toLowerCase().includes(query);
        const matchSummary = item.summary.toLowerCase().includes(query);
        if (!matchTitle && !matchDiscipline && !matchTheme && !matchSummary) {
          return false;
        }
      }

      // 2. Discipline Filter
      if (selectedDisciplineFilter !== 'Todas' && item.discipline !== selectedDisciplineFilter) {
        return false;
      }

      // 3. Importance Filter
      if (selectedImportanceFilter !== 'Todas' && item.importance !== selectedImportanceFilter) {
        return false;
      }

      // 4. Tab selection routing
      if (activeTab === 'pdfs' && item.type !== 'pdf') return false;
      if (activeTab === 'resumos' && item.type !== 'resumo') return false;
      if (activeTab === 'mapas' && item.type !== 'mapa') return false;
      if (activeTab === 'lei_seca' && item.type !== 'lei_seca') return false;
      if (activeTab === 'segunda_fase' && item.phase !== '2ª Fase' && item.discipline !== selectedSecondPhaseArea) return false;
      if (activeTab === 'modelos' && item.type !== 'modelo_peca' && item.type !== 'checklist') return false;
      if (activeTab === 'reta_final' && item.phase !== 'Reta Final' && item.type !== 'reta_final') return false;
      if (activeTab === 'pessoal') {
        // Handled in a separate customized screen view for personalization
        return true;
      }

      return true;
    });
  }, [libraryItems, searchQuery, selectedDisciplineFilter, selectedImportanceFilter, activeTab, selectedSecondPhaseArea]);

  // Unique disciplines in library for the drop-down filter
  const uniqueDisciplines = useMemo(() => {
    const list = new Set<string>();
    libraryItems.forEach(item => list.add(item.discipline));
    return ['Todas', ...Array.from(list)];
  }, [libraryItems]);

  return (
    <div id="comprehensive-library-root" className="space-y-6">
      
      {/* HEADER BANNER DESIGN */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-1">
          <div className="text-[10px] uppercase font-black tracking-widest text-oab-accent flex items-center gap-1.5">
            <Library className="h-4.5 w-4.5 text-oab-accent" /> BIBLIOTECA JURÍDICA ESTRATÉGICA
          </div>
          <h2 className="text-2xl font-black font-display text-oab-primary flex items-center gap-2">
            Materiais de Estudo <span className="bg-emerald-100 text-emerald-800 border border-emerald-200 px-2 py-0.5 text-[10px] font-black rounded-lg">OFICIAL</span>
          </h2>
          <p className="text-xs text-slate-500 max-w-2xl">
            Acesse o acervo premium de PDFs, resumos assertivos da lei seca, fluxogramas, modelos e estruturas de peças práticas recomendadas para o exame da OAB.
          </p>
        </div>

        {/* Global Statistics Indicators */}
        <div className="flex gap-4 border-l border-slate-100 pl-6 shrink-0">
          <div className="text-center">
            <span className="text-xs font-bold text-slate-400 block uppercase">Estudados</span>
            <span className="text-lg font-black text-emerald-600 font-mono">{completedItems.length}</span>
          </div>
          <div className="text-center">
            <span className="text-xs font-bold text-slate-400 block uppercase">Favoritos</span>
            <span className="text-lg font-black text-amber-500 font-mono">{favorites.length}</span>
          </div>
          <div className="text-center">
            <span className="text-xs font-bold text-slate-400 block uppercase">Offline</span>
            <span className="text-lg font-black text-blue-500 font-mono">{downloads.length}</span>
          </div>
        </div>
      </div>

      {/* SEARCH AND FILTERS (Seção 11) */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3 shadow-3xs">
        <div className="flex flex-col md:flex-row gap-3">
          
          {/* Dynamic Search Box */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Pesquisar por assunto, lei, peça, artigo ou palavra-chave..."
              className="w-full text-xs font-medium pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-oab-accent/40"
              id="library-search-bar"
            />
          </div>

          {/* Filter 1: Discipline selection */}
          <div className="w-full md:w-56">
            <select
              value={selectedDisciplineFilter}
              onChange={(e) => setSelectedDisciplineFilter(e.target.value)}
              className="w-full text-xs font-bold text-slate-700 p-3 bg-white border border-slate-200 rounded-xl focus:outline-none cursor-pointer"
            >
              <option value="Todas">📚 Todas Disciplinas</option>
              {uniqueDisciplines.filter(d => d !== 'Todas').map(disc => (
                <option key={disc} value={disc}>{disc}</option>
              ))}
            </select>
          </div>

          {/* Filter 2: Importance Selection */}
          <div className="w-full md:w-48">
            <select
              value={selectedImportanceFilter}
              onChange={(e) => setSelectedImportanceFilter(e.target.value)}
              className="w-full text-xs font-bold text-slate-700 p-3 bg-white border border-slate-200 rounded-xl focus:outline-none cursor-pointer"
            >
              <option value="Todas">🔥 Todas Importâncias</option>
              <option value="Muito Alta">🔴 Muito Alta</option>
              <option value="Alta">🟡 Alta</option>
              <option value="Média">🟢 Média</option>
            </select>
          </div>

        </div>

        {/* Short info row */}
        {searchQuery && (
          <div className="text-[11px] font-bold text-slate-500 flex items-center justify-between">
            <span>Resultados encontrados para "{searchQuery}":</span>
            <button 
              onClick={() => { setSearchQuery(''); setSelectedDisciplineFilter('Todas'); setSelectedImportanceFilter('Todas'); }}
              className="text-oab-accent hover:underline font-extrabold cursor-pointer"
            >
              Limpar Pesquisa
            </button>
          </div>
        )}
      </div>

      {/* CORE NAVIGATION SECTIONS (Tabs bar) */}
      <div className="overflow-x-auto pb-1" id="library-main-tabs">
        <div className="flex border-b border-slate-200 whitespace-nowrap min-w-max gap-1">
          {[
            { id: 'inicio', label: '🏛️ Biblioteca Principal' },
            { id: 'fases', label: '🧭 Divisão por Fases' },
            { id: 'pdfs', label: '📺 PDFs das Aulas' },
            { id: 'resumos', label: '📝 Resumos Objetivos' },
            { id: 'mapas', label: '🗺️ Mapas de Fixação' },
            { id: 'lei_seca', label: '⚖️ Lei Seca Organizada' },
            { id: 'segunda_fase', label: `🎓 Biblioteca da 2ªF (${selectedSecondPhaseArea})` },
            { id: 'modelos', label: '📂 Modelos & Checklists' },
            { id: 'reta_final', label: '⚡ Materiais de Reta Final' },
            { id: 'pessoal', label: '👤 Meu Espaço (Histórico)' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                onSaveActivity('Materiais', `Mudou aba de materiais para: ${tab.label}`);
              }}
              className={`
                py-3 px-4 text-xs font-bold transition-all border-b-2 cursor-pointer
                ${activeTab === tab.id 
                  ? 'border-oab-accent text-oab-primary font-black bg-white' 
                  : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-50'}
              `}
              id={`materials-tab-${tab.id}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>


      {/* ========================================================
          SEÇÃO 1: TELA PRINCIPAL DA ÁREA MATERIAIS
          ======================================================== */}
      {activeTab === 'inicio' && (
        <div className="space-y-6">
          
          {/* Section 12: Smart Personalized Recommendations Row */}
          <div className="bg-amber-50/50 border-l-4 border-amber-500 rounded-xl p-5 shadow-3xs space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-amber-500 fill-amber-500 animate-pulse" />
              <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider">Recomendações de Materiais Indicadas pelo seu Radar OAB</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {automaticRecommendations.map((rec, idx) => (
                <div key={idx} className="bg-white rounded-xl p-4 border border-slate-200 flex flex-col justify-between shadow-3xs relative overflow-hidden">
                  <div className="space-y-1.5 z-10">
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] font-black uppercase text-amber-600 bg-amber-50 px-2 py-0.5 rounded-lg">
                        {rec.badge}
                      </span>
                      <rec.icon className="h-4.5 w-4.5 text-slate-300" />
                    </div>
                    <h4 className="text-xs font-extrabold text-slate-850 pt-1 leading-snug">{rec.title}</h4>
                    <p className="text-[10.5px] text-slate-500 leading-relaxed font-medium">{rec.reason}</p>
                  </div>
                  
                  <div className="pt-3 border-t border-slate-100 mt-3 flex justify-between items-center">
                    <span className="text-[9px] text-slate-400 font-mono font-bold">12 min de leitura</span>
                    <button
                      onClick={() => handleOpenReader(rec.item)}
                      className="bg-oab-primary hover:bg-slate-850 text-white font-extrabold text-[10px] px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                    >
                      Estudar Agora
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Access Grid / Shortcuts Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            {[
              { id: 'pdfs', label: 'PDFs das Aulas', desc: 'Aulas teóricas', color: 'bg-blue-50 border-blue-100 text-blue-700' },
              { id: 'resumos', label: 'Resumos Rápidos', desc: 'Revisão assertiva', color: 'bg-indigo-50 border-indigo-100 text-indigo-700' },
              { id: 'mapas', label: 'Mapas Mentais', desc: 'Fixação visual', color: 'bg-amber-50 border-amber-100 text-amber-700' },
              { id: 'lei_seca', label: 'Lei Seca', desc: 'Foco nos artigos', color: 'bg-emerald-50 border-emerald-100 text-emerald-700' },
              { id: 'segunda_fase', label: 'Peças 2ª Fase', desc: selectedSecondPhaseArea, color: 'bg-purple-50 border-purple-100 text-purple-700' },
              { id: 'modelos', label: 'Checklists', desc: 'Erros e estruturas', color: 'bg-teal-50 border-teal-100 text-teal-700' },
              { id: 'reta_final', label: 'Reta Final', desc: 'Véspera de prova', color: 'bg-rose-50 border-rose-100 text-rose-700' },
              { id: 'pessoal', label: 'Meus Favoritos', desc: 'Histórico e salvos', color: 'bg-slate-50 border-slate-200 text-slate-700' }
            ].map(shortcut => (
              <button
                key={shortcut.id}
                onClick={() => setActiveTab(shortcut.id as any)}
                className={`p-3.5 rounded-xl border text-left hover:scale-[1.02] hover:shadow-xs transition-all cursor-pointer ${shortcut.color}`}
              >
                <span className="text-xs font-extrabold block leading-tight">{shortcut.label}</span>
                <span className="text-[9px] text-slate-500 font-medium block mt-0.5">{shortcut.desc}</span>
              </button>
            ))}
          </div>

          {/* Library Overview: Recommended / Newly Added & Favorites split */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left side: Recently added / Hot materials */}
            <div className="lg:col-span-7 bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
              <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                <div className="space-y-0.5">
                  <h3 className="text-sm font-black text-slate-850 flex items-center gap-1.5">
                    <Grid className="h-4.5 w-4.5 text-slate-400" /> Acervo Recente e Mais Procurado
                  </h3>
                  <p className="text-[11px] text-slate-400">Materiais atualizados para a próxima prova da OAB</p>
                </div>
                <button
                  onClick={() => setActiveTab('fases')}
                  className="text-xs font-black text-oab-accent hover:underline flex items-center gap-0.5 cursor-pointer"
                >
                  Ver por fases <ChevronRight className="h-4 w-4" />
                </button>
              </div>

              <div className="space-y-3">
                {libraryItems.slice(0, 4).map((item) => (
                  <div key={item.id} className="p-3.5 rounded-xl border border-slate-200 bg-white flex justify-between items-center gap-3">
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-black uppercase text-oab-accent px-1.5 py-0.5 rounded bg-slate-50">
                          {item.discipline}
                        </span>
                        <span className={`text-[8.5px] font-black uppercase px-1 py-0.2 rounded ${item.importance === 'Muito Alta' ? 'bg-red-50 text-red-600' : 'bg-slate-50 text-slate-500'}`}>
                          {item.importance}
                        </span>
                      </div>
                      <h4 className="text-xs font-extrabold text-slate-800 truncate">{item.title}</h4>
                      <p className="text-[10.5px] text-slate-500 font-medium line-clamp-1">{item.summary}</p>
                    </div>

                    <div className="shrink-0 flex items-center gap-1.5">
                      <button
                        onClick={() => handleToggleFavorite(item.id)}
                        className={`p-1.5 rounded hover:bg-slate-100 cursor-pointer ${favorites.includes(item.id) ? 'text-amber-500' : 'text-slate-300'}`}
                        title="Favoritar"
                      >
                        <Star className="h-4 w-4 fill-current" />
                      </button>
                      <button
                        onClick={() => handleOpenReader(item)}
                        className="bg-slate-100 hover:bg-oab-primary hover:text-white text-slate-700 font-extrabold text-[10px] px-3 py-2 rounded-lg transition-all cursor-pointer"
                      >
                        Abrir
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right side: Favorites and Downloads Quick Drawer */}
            <div className="lg:col-span-5 space-y-6">
              
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                  <h3 className="text-sm font-black text-slate-850 flex items-center gap-1.5">
                    <FolderHeart className="h-4.5 w-4.5 text-amber-500" /> Meus Favoritos ({favorites.length})
                  </h3>
                  <button onClick={() => setActiveTab('pessoal')} className="text-xs font-bold text-oab-accent hover:underline cursor-pointer">
                    Ver todos
                  </button>
                </div>

                {favorites.length === 0 ? (
                  <div className="text-center py-6 text-slate-400 text-xs">
                    Nenhum material favoritado ainda. Toque na estrela para salvar.
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {libraryItems.filter(i => favorites.includes(i.id)).slice(0, 3).map(item => (
                      <div key={item.id} className="p-2.5 rounded-lg border border-slate-100 bg-slate-50/50 flex justify-between items-center">
                        <div className="min-w-0 pr-2">
                          <span className="text-[8.5px] font-black uppercase text-slate-400 block">{item.type} • {item.discipline}</span>
                          <h4 className="text-xs font-extrabold text-slate-800 truncate">{item.title}</h4>
                        </div>
                        <button
                          onClick={() => handleOpenReader(item)}
                          className="bg-white hover:bg-slate-100 border border-slate-200 p-1.5 rounded cursor-pointer shrink-0"
                          title="Ler agora"
                        >
                          <Maximize2 className="h-3.5 w-3.5 text-slate-500" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Continuing study panel */}
              <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-xl p-5 border border-slate-800 shadow-md space-y-4">
                <div className="space-y-1">
                  <h3 className="text-xs font-black tracking-widest uppercase text-amber-400 flex items-center gap-1.5">
                    <Clock className="h-4 w-4" /> Continuar Estudando
                  </h3>
                  <p className="text-[10px] text-slate-400">Leitura interrompida recentemente</p>
                </div>

                {Object.keys(inProgressItems).length === 0 ? (
                  <div className="text-slate-500 text-xs py-2 text-center font-medium">
                    Você leu todos os materiais pendentes ou não começou nenhum!
                  </div>
                ) : (
                  <div>
                    {libraryItems.filter(i => inProgressItems[i.id] !== undefined).slice(0, 1).map(item => {
                      const pct = inProgressItems[item.id];
                      return (
                        <div key={item.id} className="space-y-3">
                          <div className="space-y-1">
                            <h4 className="text-xs font-bold truncate text-slate-100">{item.title}</h4>
                            <span className="text-[9px] text-amber-300 uppercase font-black">{item.discipline}</span>
                          </div>

                          <div className="space-y-1.5">
                            <div className="flex justify-between text-[9px] text-slate-400 font-mono">
                              <span>Progresso da Leitura</span>
                              <span>{pct}%</span>
                            </div>
                            <div className="w-full bg-slate-800 rounded-full h-1.5">
                              <div className="bg-amber-400 h-1.5 rounded-full" style={{ width: `${pct}%` }} />
                            </div>
                          </div>

                          <button
                            onClick={() => handleOpenReader(item)}
                            className="w-full bg-amber-400 hover:bg-amber-500 text-slate-900 font-black text-xs py-2 px-3 rounded-lg flex items-center justify-center gap-1 transition-all cursor-pointer"
                          >
                            <span>Continuar de onde parou ({pct}%)</span>
                            <ChevronRight className="h-4 w-4 stroke-[3]" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </div>
          </div>

        </div>
      )}


      {/* ========================================================
          SEÇÃO 2: BIBLIOTECA POR FASE
          ======================================================== */}
      {activeTab === 'fases' && (
        <div className="space-y-6">
          <div className="space-y-1">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider">Acervo Estruturado por Fase do Exame</h3>
            <p className="text-xs text-slate-500">Navegue de acordo com o estágio da sua preparação</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Bloco A: 1ª Fase */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="bg-blue-100 text-blue-800 border border-blue-200 px-2.5 py-0.5 text-[9px] font-black rounded-lg uppercase">
                    Bloco A — 1ª Fase
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-400">6 materiais</span>
                </div>
                <h4 className="text-sm font-black text-slate-800">Prova Objetiva de Ordem</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Contém resumos focados em disciplinas estratégicas, PDFs das matérias de maior peso (Ética, Constitucional, Processo Penal e Processo Civil) e lei seca orientada.
                </p>
                
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-2">
                  <span className="text-[10px] font-black text-slate-500 uppercase block">Disciplinas Principais</span>
                  <div className="flex flex-wrap gap-1">
                    <span className="text-[9px] bg-white border border-slate-200 px-1.5 py-0.5 rounded font-bold text-slate-600">Ética OAB</span>
                    <span className="text-[9px] bg-white border border-slate-200 px-1.5 py-0.5 rounded font-bold text-slate-600">Direito Constitucional</span>
                    <span className="text-[9px] bg-white border border-slate-200 px-1.5 py-0.5 rounded font-bold text-slate-600">Processo Penal</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  setSelectedImportanceFilter('Todas');
                  setSelectedDisciplineFilter('Todas');
                  setActiveTab('resumos');
                }}
                className="w-full bg-slate-100 hover:bg-oab-primary hover:text-white text-slate-800 font-extrabold text-xs py-2.5 px-4 rounded-xl transition-all cursor-pointer text-center"
              >
                Explorar Materiais de 1ª Fase
              </button>
            </div>

            {/* Bloco B: 2ª Fase */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="bg-purple-100 text-purple-800 border border-purple-200 px-2.5 py-0.5 text-[9px] font-black rounded-lg uppercase">
                    Bloco B — 2ª Fase
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-400">4 materiais</span>
                </div>
                <h4 className="text-sm font-black text-slate-800">Prova Prático-Profissional</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Roteiros de peças estruturadas, modelos prontos de petição inicial, recursos ordinários, defesas prévias, e checklists pontuais do espelho da FGV para sua área escolhida ({selectedSecondPhaseArea}).
                </p>

                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-2">
                  <span className="text-[10px] font-black text-slate-500 uppercase block">Área Escolhida</span>
                  <span className="text-[10.5px] font-bold text-purple-700 flex items-center gap-1">
                    <Scale className="h-4 w-4" /> {selectedSecondPhaseArea}
                  </span>
                </div>
              </div>

              <button
                onClick={() => {
                  setActiveTab('segunda_fase');
                }}
                className="w-full bg-slate-100 hover:bg-oab-primary hover:text-white text-slate-800 font-extrabold text-xs py-2.5 px-4 rounded-xl transition-all cursor-pointer text-center"
              >
                Abrir Biblioteca de 2ª Fase
              </button>
            </div>

            {/* Bloco C: Reta Final */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="bg-rose-100 text-rose-800 border border-rose-200 px-2.5 py-0.5 text-[9px] font-black rounded-lg uppercase">
                    Bloco C — Reta Final
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-400">1 material crítico</span>
                </div>
                <h4 className="text-sm font-black text-slate-800">Véspera de Prova & Desespero</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Lista de "Não pode errar" de Ética Profissional, resumos ultra compactados de Súmulas Vinculantes do STF, checklists administrativos de véspera de prova e dicas de gestão de ansiedade.
                </p>

                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-2">
                  <span className="text-[10px] font-black text-slate-500 uppercase block">Destaque de Aprovação</span>
                  <span className="text-[10px] font-bold text-rose-600 flex items-center gap-1">
                    <Zap className="h-4 w-4 fill-current" /> Os 15 artigos mais cobrados pela FGV
                  </span>
                </div>
              </div>

              <button
                onClick={() => {
                  setActiveTab('reta_final');
                }}
                className="w-full bg-slate-100 hover:bg-oab-primary hover:text-white text-slate-800 font-extrabold text-xs py-2.5 px-4 rounded-xl transition-all cursor-pointer text-center"
              >
                Explorar Reta Final
              </button>
            </div>

          </div>
        </div>
      )}


      {/* ========================================================
          SEÇÃO 3 & 4 & 5 & 6 & 7 & 8 & 9: TAB VIEWS DETAILED
          ======================================================== */}
      {activeTab !== 'inicio' && activeTab !== 'fases' && activeTab !== 'pessoal' && (
        <div className="space-y-4">
          
          {/* Section Info Block */}
          <div className="flex justify-between items-center bg-slate-50 p-3 border border-slate-200 rounded-xl">
            <span className="text-xs font-bold text-slate-600 uppercase">
              {activeTab === 'pdfs' && '📺 Resumos & PDFs de Acompanhamento das Aulas'}
              {activeTab === 'resumos' && '📝 Resumos Jurídicos de Teoria e Prática'}
              {activeTab === 'mapas' && '🗺️ Mapas Mentais de Fixação Visual'}
              {activeTab === 'lei_seca' && '⚖️ Artigos e Legislação Selecionada pela Banca'}
              {activeTab === 'segunda_fase' && `🎓 Materiais da 2ª Fase - Especialidade: ${selectedSecondPhaseArea}`}
              {activeTab === 'modelos' && '📂 Modelos de Peça Prático-Profissional e Checklists'}
              {activeTab === 'reta_final' && '⚡ Reta Final de Revisão de Véspera OAB'}
            </span>
            <span className="text-[10px] font-mono font-bold text-slate-400 bg-white px-2 py-0.5 rounded border border-slate-150">
              {filteredLibraryItems.length} itens encontrados
            </span>
          </div>

          {/* Fallback empty message */}
          {filteredLibraryItems.length === 0 ? (
            <div className="text-center py-16 bg-white border border-slate-200 rounded-xl space-y-3">
              <BookOpenCheck className="h-10 w-10 text-slate-300 mx-auto" />
              <p className="text-slate-500 text-xs font-bold">Nenhum material atende aos filtros de busca atuais nesta seção.</p>
              <button 
                onClick={() => { setSearchQuery(''); setSelectedDisciplineFilter('Todas'); setSelectedImportanceFilter('Todas'); }}
                className="bg-slate-100 text-slate-700 text-[11px] font-black px-4 py-2 rounded-xl border hover:bg-slate-200 cursor-pointer"
              >
                Resetar Filtros de Busca
              </button>
            </div>
          ) : (
            
            /* DYNAMIC RENDERING GRID OF SECTIONS */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredLibraryItems.map((item) => (
                <div 
                  key={item.id} 
                  className={`bg-white rounded-xl p-5 border border-slate-200 shadow-3xs flex flex-col justify-between space-y-4 relative ${completedItems.includes(item.id) ? 'border-emerald-200 bg-emerald-50/5' : ''}`}
                >
                  
                  {/* Item Stamp of completion */}
                  {completedItems.includes(item.id) && (
                    <div className="absolute top-4 right-4 bg-emerald-100 text-emerald-800 border border-emerald-200 text-[8.5px] font-black uppercase px-2 py-0.5 rounded-lg flex items-center gap-1 shadow-3xs">
                      <CheckCircle className="h-3 w-3 stroke-[2.5]" /> Estudado
                    </div>
                  )}

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-black uppercase text-oab-accent bg-slate-50 px-2 py-0.5 rounded">
                        {item.discipline}
                      </span>
                      <span className={`text-[8.5px] font-black uppercase px-1.5 py-0.5 rounded ${item.importance === 'Muito Alta' ? 'bg-red-50 text-red-600' : 'bg-slate-50 text-slate-500'}`}>
                        Importância: {item.importance}
                      </span>
                      <span className="text-[9px] text-slate-400 font-mono">
                        {item.type.toUpperCase()}
                      </span>
                    </div>

                    <h4 className="text-sm font-black text-slate-800 leading-snug">{item.title}</h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-medium">{item.summary}</p>

                    {/* Specific rendering for Lei Seca list of articles */}
                    {item.type === 'lei_seca' && item.articlesList && (
                      <div className="pt-2 space-y-1 bg-slate-50/70 p-2.5 rounded-lg border border-slate-100">
                        <span className="text-[9px] font-black text-slate-400 uppercase block mb-1">Artigos Críticos do Roteiro</span>
                        {item.articlesList.map((art, idx) => (
                          <div key={idx} className="text-[10.5px] text-slate-700 leading-snug font-medium flex gap-1 items-start">
                            <span className="text-emerald-600 font-extrabold shrink-0">✔</span>
                            <span>{art}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Specific rendering for checklist items */}
                    {item.type === 'checklist' && item.checklistItems && (
                      <div className="pt-2 space-y-1 bg-slate-50 p-2.5 rounded-lg">
                        {item.checklistItems.map((cli, idx) => (
                          <div key={idx} className="text-[10.5px] text-slate-600 font-medium flex gap-1 items-center">
                            <CheckSquare className="h-3.5 w-3.5 text-teal-600 shrink-0" />
                            <span>{cli}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Specific piece structural guidelines */}
                    {item.type === 'modelo_peca' && item.pieceStructure && (
                      <div className="pt-2 space-y-1 bg-slate-50 p-2.5 rounded-lg border border-slate-150 text-[10px] text-slate-600">
                        <span className="font-black text-slate-500 uppercase block mb-1">Passos da Estruturação da Peça:</span>
                        {item.pieceStructure.slice(0, 3).map((st, idx) => (
                          <div key={idx} className="flex gap-1.5 border-b border-white pb-1 last:border-0 last:pb-0">
                            <span className="font-bold text-slate-800 shrink-0">{st.section.split(' ')[0]}</span>
                            <span className="truncate">{st.section.split(' ').slice(1).join(' ')}</span>
                          </div>
                        ))}
                        <span className="text-[9px] text-oab-accent font-extrabold block pt-1 hover:underline">Ver os {item.pieceStructure.length} requisitos no leitor...</span>
                      </div>
                    )}

                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-slate-100 mt-2">
                    <span className="text-[10px] text-slate-400 font-mono font-bold">
                      {item.pageCount ? `${item.pageCount} páginas` : item.readTimeMinutes ? `${item.readTimeMinutes} min` : 'Acervo Digital'}
                    </span>
                    
                    <div className="flex gap-1">
                      {/* Favorite Button */}
                      <button
                        onClick={() => handleToggleFavorite(item.id)}
                        className={`p-2 bg-slate-50 hover:bg-slate-100 rounded-lg border transition-colors cursor-pointer ${favorites.includes(item.id) ? 'text-amber-500 border-amber-200 bg-amber-50' : 'text-slate-400 border-slate-150'}`}
                        title="Favoritar"
                      >
                        <Star className="h-3.5 w-3.5 fill-current" />
                      </button>

                      {/* Download button */}
                      <button
                        onClick={() => handleDownload(item)}
                        className={`p-2 bg-slate-50 hover:bg-slate-100 rounded-lg border text-slate-500 border-slate-150 hover:text-blue-600 transition-colors cursor-pointer ${downloads.includes(item.id) ? 'text-blue-600 bg-blue-50 border-blue-200' : ''}`}
                        title="Baixar PDF"
                      >
                        <Download className="h-3.5 w-3.5" />
                      </button>

                      {/* Read Now Main Button */}
                      <button
                        onClick={() => handleOpenReader(item)}
                        className="bg-oab-primary hover:bg-slate-850 text-white font-black text-[11px] py-1.5 px-3.5 rounded-lg transition-colors cursor-pointer"
                      >
                        Abrir no App
                      </button>
                    </div>

                  </div>

                </div>
              ))}
            </div>
          )}

        </div>
      )}


      {/* ========================================================
          SEÇÃO 10: MEU ESPAÇO - FAVORITOS, DOWNLOADS E HISTÓRICO
          ======================================================== */}
      {activeTab === 'pessoal' && (
        <div className="space-y-6">
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="space-y-1">
              <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider">Seu Espaço Pessoal de Estudo</h3>
              <p className="text-xs text-slate-500">Gerencie seus arquivos baixados, favoritos e progresso de leitura</p>
            </div>
            <button
              onClick={handleResetStatistics}
              className="text-xs font-black text-red-600 hover:text-red-800 bg-red-50 hover:bg-red-100 border border-red-150 px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <RotateCcw className="h-4 w-4" /> Redefinir Estatísticas
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Column 1: Favorites */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-3xs space-y-4">
              <h4 className="text-xs font-black uppercase text-amber-500 border-b border-slate-100 pb-2 flex items-center gap-1">
                <Star className="h-4.5 w-4.5 fill-current" /> Favoritados ({favorites.length})
              </h4>
              
              {favorites.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs font-medium">
                  Nenhum arquivo favorito. Navegue pelas guias e toque na estrela.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {libraryItems.filter(item => favorites.includes(item.id)).map(item => (
                    <div key={item.id} className="p-3 rounded-lg border border-slate-150 bg-slate-50/30 hover:bg-slate-50 flex justify-between items-center gap-2">
                      <div className="min-w-0">
                        <span className="text-[8.5px] uppercase font-bold text-slate-400 block">{item.discipline}</span>
                        <h5 className="text-xs font-extrabold text-slate-800 truncate">{item.title}</h5>
                      </div>
                      <div className="flex shrink-0 gap-1">
                        <button 
                          onClick={() => handleToggleFavorite(item.id)}
                          className="text-red-500 hover:text-red-700 p-1 bg-white border rounded cursor-pointer"
                          title="Remover dos favoritos"
                        >
                          <Star className="h-3.5 w-3.5 fill-current" />
                        </button>
                        <button 
                          onClick={() => handleOpenReader(item)}
                          className="bg-oab-primary hover:bg-slate-850 text-white p-1 rounded cursor-pointer"
                        >
                          <Maximize2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Column 2: Offline Downloaded Materials */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-3xs space-y-4">
              <h4 className="text-xs font-black uppercase text-blue-500 border-b border-slate-100 pb-2 flex items-center gap-1">
                <Download className="h-4.5 w-4.5" /> Armazenados Offline ({downloads.length})
              </h4>

              {downloads.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs font-medium">
                  Você não realizou nenhum download simulado ainda.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {libraryItems.filter(item => downloads.includes(item.id)).map(item => (
                    <div key={item.id} className="p-3 rounded-lg border border-slate-150 bg-slate-50/30 flex justify-between items-center gap-2">
                      <div className="min-w-0">
                        <span className="text-[8.5px] uppercase font-bold text-slate-400 block">{item.type.toUpperCase()} • {item.discipline}</span>
                        <h5 className="text-xs font-extrabold text-slate-800 truncate">{item.title}</h5>
                        <span className="text-[9px] text-blue-600 font-bold block mt-0.5">✔ Pronto para visualização offline</span>
                      </div>
                      <button 
                        onClick={() => handleOpenReader(item)}
                        className="bg-blue-600 text-white p-2 rounded-lg cursor-pointer"
                        title="Abrir arquivo offline"
                      >
                        <BookOpen className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Column 3: Studied and Histórico */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-3xs space-y-4">
              <h4 className="text-xs font-black uppercase text-emerald-600 border-b border-slate-100 pb-2 flex items-center gap-1">
                <CheckCircle className="h-4.5 w-4.5" /> Histórico & Estudados ({completedItems.length})
              </h4>

              <div className="space-y-4">
                {/* Micro metrics */}
                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-lg border">
                  <div className="text-center border-r">
                    <span className="text-[9px] text-slate-400 font-black block">Lidos/Concluídos</span>
                    <span className="text-md font-black text-slate-800 font-mono">{completedItems.length}</span>
                  </div>
                  <div className="text-center">
                    <span className="text-[9px] text-slate-400 font-black block">Em Andamento</span>
                    <span className="text-md font-black text-slate-800 font-mono">{Object.keys(inProgressItems).length}</span>
                  </div>
                </div>

                {completedItems.length === 0 ? (
                  <div className="text-center py-6 text-slate-400 text-xs font-medium">
                    Sem leituras concluídas registradas no app.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {libraryItems.filter(item => completedItems.includes(item.id)).map(item => (
                      <div key={item.id} className="p-2.5 rounded-lg border border-slate-100 flex items-center justify-between">
                        <div className="min-w-0 pr-2">
                          <h5 className="text-xs font-extrabold text-slate-800 truncate">{item.title}</h5>
                          <span className="text-[9px] text-emerald-600 font-bold block">Concluído</span>
                        </div>
                        <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

          </div>
        </div>
      )}


      {/* ========================================================
          IN-APP READER MODAL SCREEN (Funcionalidade Obrigatória 1)
          ======================================================== */}
      {activeReadingItem && (
        <div className="fixed inset-0 bg-slate-900/65 flex items-center justify-center z-50 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl border border-slate-100 animate-fade-in">
            
            {/* Header of Reader */}
            <div className="p-5 border-b border-slate-100 bg-slate-50 rounded-t-2xl flex justify-between items-start gap-4 shrink-0">
              <div className="space-y-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-black uppercase text-oab-accent bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    {activeReadingItem.discipline}
                  </span>
                  <span className="text-[9px] font-bold text-slate-400 uppercase font-mono">
                    {activeReadingItem.type}
                  </span>
                </div>
                <h3 className="text-base font-black text-slate-900 leading-tight truncate">{activeReadingItem.title}</h3>
              </div>
              <button 
                onClick={() => setActiveReadingItem(null)}
                className="text-slate-400 hover:text-slate-700 bg-white p-1.5 rounded-lg border cursor-pointer"
                id="btn-close-reader"
              >
                <ArrowLeft className="h-4.5 w-4.5" />
              </button>
            </div>

            {/* Reader Simulated Progress bar */}
            <div className="bg-slate-150 h-1.5 w-full shrink-0">
              <div className="bg-emerald-500 h-1.5 rounded-r" style={{ width: `${readerProgress}%` }} />
            </div>

            {/* Scrollable Document Text Content */}
            <div className="p-6 overflow-y-auto flex-1 space-y-6 select-text text-slate-800 text-xs leading-relaxed" id="reader-scrollable-content">
              
              {/* Document Metadata Table */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div>
                  <span className="text-[9.5px] font-black text-slate-400 uppercase block">Tema</span>
                  <span className="font-bold text-slate-700 text-xs">{activeReadingItem.theme}</span>
                </div>
                <div>
                  <span className="text-[9.5px] font-black text-slate-400 uppercase block">Fase do Exame</span>
                  <span className="font-bold text-slate-700 text-xs">{activeReadingItem.phase}</span>
                </div>
                <div>
                  <span className="text-[9.5px] font-black text-slate-400 uppercase block">Carga Estimada</span>
                  <span className="font-bold text-slate-700 text-xs">{activeReadingItem.readTimeMinutes || 20} minutos</span>
                </div>
              </div>

              {/* Simulated PDF document visual indicator */}
              <div className="border border-slate-200 p-2 text-slate-400 rounded bg-slate-50 flex items-center justify-between text-[10px]">
                <div className="flex items-center gap-1">
                  <FileText className="h-4 w-4 text-rose-500" />
                  <span>Visualizador de PDFs OAB 3F v2.1</span>
                </div>
                <span>Página {Math.floor(readerProgress / 10) + 1} de {activeReadingItem.pageCount || 10}</span>
              </div>

              {/* Rich Markdown Core Simulation */}
              <div className="whitespace-pre-line text-slate-800 leading-relaxed font-serif text-sm px-1 font-medium bg-white">
                {activeReadingItem.contentMarkdown || `Este material é exclusivo para alunos cadastrados na plataforma OAB 3F.\nEle contém resumos compactados, indicações doutrinárias e análises estatísticas das matérias de maior peso.\n\nPor favor, utilize os botões inferiores para avançar a leitura e registrar suas estatísticas de estudo.`}
              </div>

              {/* Render lists dynamically for interactive check items */}
              {activeReadingItem.articlesList && (
                <div className="space-y-2 border-t border-slate-100 pt-4">
                  <h5 className="font-sans font-bold text-xs text-slate-900 uppercase tracking-wide">Artigos do Código e Constituição Recomendados:</h5>
                  <div className="grid grid-cols-1 gap-2">
                    {activeReadingItem.articlesList.map((art, idx) => (
                      <div key={idx} className="p-3 bg-emerald-50/30 border border-emerald-100 rounded-lg flex gap-2">
                        <Check className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5 stroke-[3]" />
                        <span className="font-sans text-xs text-slate-700 font-medium leading-normal">{art}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeReadingItem.checklistItems && (
                <div className="space-y-2 border-t border-slate-100 pt-4">
                  <h5 className="font-sans font-bold text-xs text-slate-900 uppercase tracking-wide">Checklist de Elementos Essenciais da Peça:</h5>
                  <div className="grid grid-cols-1 gap-2">
                    {activeReadingItem.checklistItems.map((item, idx) => (
                      <div key={idx} className="p-3 bg-teal-50/20 border border-teal-100 rounded-lg flex items-center gap-2.5">
                        <CheckSquare className="h-4 w-4 text-teal-600 shrink-0" />
                        <span className="font-sans text-xs text-slate-700 font-medium">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeReadingItem.pieceStructure && (
                <div className="space-y-3 border-t border-slate-100 pt-4">
                  <h5 className="font-sans font-bold text-xs text-slate-900 uppercase tracking-wide">Divisão do Esqueleto da Peça Prática:</h5>
                  <div className="space-y-2">
                    {activeReadingItem.pieceStructure.map((st, idx) => (
                      <div key={idx} className="p-3 border rounded-xl bg-slate-50 font-sans">
                        <h6 className="text-xs font-black text-slate-800">{st.section}</h6>
                        <p className="text-[11px] text-slate-500 mt-0.5 leading-normal font-medium">{st.explanation}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeReadingItem.commonErrors && (
                <div className="space-y-2 border-t border-red-100 pt-4">
                  <h5 className="font-sans font-bold text-xs text-red-600 uppercase tracking-wide flex items-center gap-1">
                    <AlertTriangle className="h-4 w-4 shrink-0" /> Erros Fatais que Eliminam do Exame (Nota Zero):
                  </h5>
                  <div className="grid grid-cols-1 gap-1.5">
                    {activeReadingItem.commonErrors.map((err, idx) => (
                      <div key={idx} className="p-3 bg-red-50 border border-red-100 rounded-lg text-slate-700 text-xs font-medium flex gap-2">
                        <span className="text-red-600 font-black shrink-0">❗</span>
                        <span>{err}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* End of content marker */}
              <div className="text-center py-6 border-t border-slate-150 text-slate-400 font-mono text-[10px]">
                --- FIM DO COMPLEMENTO JURÍDICO ---
              </div>

            </div>

            {/* Reader Controls Footer (Continuidade de Leitura / Mark Studied) */}
            <div className="p-4 border-t border-slate-150 bg-slate-50 rounded-b-2xl flex flex-wrap justify-between items-center gap-3 shrink-0">
              <div className="flex gap-2">
                <button
                  onClick={() => handleReaderScrollProgress(20)}
                  disabled={readerProgress >= 100}
                  className="bg-slate-200 hover:bg-slate-300 disabled:opacity-50 text-slate-800 font-black text-[10.5px] px-3 py-2 rounded-lg transition-colors cursor-pointer"
                >
                  Rolar Página (+20%)
                </button>
                <button
                  onClick={() => handleToggleFavorite(activeReadingItem.id)}
                  className={`p-2 border rounded-lg bg-white ${favorites.includes(activeReadingItem.id) ? 'text-amber-500 border-amber-300' : 'text-slate-400'}`}
                >
                  <Star className="h-4 w-4 fill-current" />
                </button>
              </div>

              <div className="flex gap-2">
                {/* Completion Status button */}
                {completedItems.includes(activeReadingItem.id) ? (
                  <span className="text-xs font-black text-emerald-700 bg-emerald-100/80 border border-emerald-200 px-4 py-2 rounded-lg flex items-center gap-1.5">
                    <CheckCircle className="h-4 w-4" /> Material Estudado
                  </span>
                ) : (
                  <button
                    onClick={() => handleMarkAsCompleted(activeReadingItem.id)}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs py-2 px-4 rounded-lg flex items-center gap-1.5 shadow-sm cursor-pointer transition-colors"
                  >
                    <Check className="h-4 w-4 stroke-[3]" />
                    <span>Marcar como Estudado</span>
                  </button>
                )}
                
                <button
                  onClick={() => setActiveReadingItem(null)}
                  className="bg-slate-800 hover:bg-slate-900 text-white font-black text-xs py-2 px-4 rounded-lg cursor-pointer transition-colors"
                >
                  Fechar Leitor
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}

// Small helper component to keep original files compilable
function ShieldAlertIcon(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={props.className}
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      <line x1="12" y1="8" x2="12" y2="12" />
      <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  );
}

function CalendarRangeIcon(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={props.className}
    >
      <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
      <path d="M17 14h-6" />
      <path d="M13 18H7" />
      <path d="M7 14h.01" />
      <path d="M17 18h.01" />
    </svg>
  );
}
