/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  TrendingUp,
  Award,
  BookOpen,
  Clock,
  Sparkles,
  FileText,
  Bookmark,
  CheckCircle2,
  HelpCircle,
  Lock,
  Flame,
  Activity,
  ShieldAlert,
  ChevronRight,
  TrendingDown,
  Target,
  ArrowUpRight,
  Search,
  Check,
  RotateCcw,
  AlertTriangle,
  Info,
  Layers,
  Sparkle
} from 'lucide-react';
import { StudentProgress, Discipline, Question, SimulatedResult } from '../types';
import { QUESTIONS_BANK } from '../data/mockData';

interface PerformanceProps {
  progress: StudentProgress;
  disciplines: Discipline[];
}

export default function Performance({ progress, disciplines }: PerformanceProps) {
  // Navigation tabs for analytical clarity
  const [activeTab, setActiveTab] = useState<'painel' | 'radar' | 'fase1' | 'fase2' | 'simulados'>('painel');
  const [evolutionPeriod, setEvolutionPeriod] = useState<'semana' | 'mes' | 'geral'>('semana');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'nome' | 'aproveitamento'>('aproveitamento');

  // --- BASE SEED METRICS FOR THE 19 OAB DISCIPLINES ---
  // Realistic base metrics which merge with the live StudentProgress state
  const baselineDisciplines = useMemo(() => {
    return [
      { name: "Ética Profissional", baseSolved: 25, baseCorrect: 21, weight: 8, reviews: 6, progress: 85 },
      { name: "Direito Constitucional", baseSolved: 16, baseCorrect: 12, weight: 6, reviews: 4, progress: 70 },
      { name: "Direito Administrativo", baseSolved: 14, baseCorrect: 9, weight: 6, reviews: 3, progress: 65 },
      { name: "Direito Civil", baseSolved: 18, baseCorrect: 7, weight: 6, reviews: 2, progress: 45 },
      { name: "Processo Civil", baseSolved: 15, baseCorrect: 9, weight: 6, reviews: 4, progress: 55 },
      { name: "Direito Penal", baseSolved: 22, baseCorrect: 16, weight: 6, reviews: 5, progress: 80 },
      { name: "Processo Penal", baseSolved: 18, baseCorrect: 8, weight: 6, reviews: 2, progress: 40 },
      { name: "Direito do Trabalho", baseSolved: 14, baseCorrect: 10, weight: 5, reviews: 4, progress: 75 },
      { name: "Processo do Trabalho", baseSolved: 12, baseCorrect: 7, weight: 5, reviews: 3, progress: 60 },
      { name: "Direito Empresarial", baseSolved: 8, baseCorrect: 3, weight: 5, reviews: 1, progress: 30 },
      { name: "Direito Tributário", baseSolved: 10, baseCorrect: 6, weight: 5, reviews: 2, progress: 50 },
      { name: "Direitos Humanos", baseSolved: 6, baseCorrect: 4, weight: 2, reviews: 1, progress: 60 },
      { name: "ECA", baseSolved: 5, baseCorrect: 3, weight: 2, reviews: 1, progress: 50 },
      { name: "Direito do Consumidor", baseSolved: 6, baseCorrect: 4, weight: 2, reviews: 2, progress: 70 },
      { name: "Direito Ambiental", baseSolved: 4, baseCorrect: 2, weight: 2, reviews: 1, progress: 45 },
      { name: "Direito Internacional", baseSolved: 4, baseCorrect: 1, weight: 2, reviews: 1, progress: 20 },
      { name: "Filosofia do Direito", baseSolved: 4, baseCorrect: 2, weight: 2, reviews: 1, progress: 40 },
      { name: "Direito Previdenciário", baseSolved: 5, baseCorrect: 3, weight: 2, reviews: 1, progress: 55 },
      { name: "Direito Financeiro", baseSolved: 5, baseCorrect: 2, weight: 2, reviews: 1, progress: 35 }
    ];
  }, []);

  // --- DYNAMIC DATA MERGE ---
  // Compile live answered questions from user's progress and overlay onto baseline
  const mergedDisciplines = useMemo(() => {
    // 1. Group actual answered questions in state by discipline
    const liveCounts: { [discipline: string]: { correct: number; total: number } } = {};
    Object.entries(progress.answeredQuestions).forEach(([qId, ans]) => {
      const q = QUESTIONS_BANK.find(question => question.id === qId);
      if (q) {
        if (!liveCounts[q.discipline]) {
          liveCounts[q.discipline] = { correct: 0, total: 0 };
        }
        liveCounts[q.discipline].total += 1;
        if (ans.isCorrect) {
          liveCounts[q.discipline].correct += 1;
        }
      }
    });

    // 2. Map baseline subjects with live answers added
    return baselineDisciplines.map(disc => {
      const live = liveCounts[disc.name] || { correct: 0, total: 0 };
      const totalSolved = disc.baseSolved + live.total;
      const totalCorrect = disc.baseCorrect + live.correct;
      const percentage = totalSolved > 0 ? Math.round((totalCorrect / totalSolved) * 100) : 0;
      
      // Classify status visual (forte, mediana, fraca)
      let status: 'Forte' | 'Mediana' | 'Fraca' = 'Mediana';
      if (percentage >= 70) status = 'Forte';
      else if (percentage < 50) status = 'Fraca';

      // Errors pending (live + estimated base)
      const errorsPending = Math.max(0, (totalSolved - totalCorrect));

      return {
        ...disc,
        solved: totalSolved,
        correct: totalCorrect,
        errorsPending,
        percentage,
        status
      };
    });
  }, [progress.answeredQuestions, baselineDisciplines]);

  // General Metrics Calculations
  const metrics = useMemo(() => {
    const totalSolved = mergedDisciplines.reduce((acc, d) => acc + d.solved, 0);
    const totalCorrect = mergedDisciplines.reduce((acc, d) => acc + d.correct, 0);
    const overallQuizPct = totalSolved > 0 ? Math.round((totalCorrect / totalSolved) * 100) : 0;

    // Total hours, lectures, PDFs, etc.
    const totalHours = 44 + progress.weeklyStudyHours; // Merging study base with progress hours
    const completedLecturesCount = 22 + progress.completedLectures.length;
    const completedPDFsCount = 14 + progress.completedPDFs.length;
    const simulatedExamsCount = progress.simulatedExamsHistory.length;
    const totalRevisionsCompleted = 18 + Object.keys(progress.flashcardBoxes).filter(k => progress.flashcardBoxes[k] >= 3).length;
    const consecutiveDays = 4; // Offensiva streak
    const progressPlanPercentage = 42; // Study schedule completion

    // 2nd phase pieces completed
    const secondPhasePiecesCount = 5 + progress.favoritePieces.length;

    return {
      overallQuizPct,
      totalSolved,
      totalCorrect,
      totalHours,
      completedLecturesCount,
      completedPDFsCount,
      simulatedExamsCount,
      totalRevisionsCompleted,
      consecutiveDays,
      progressPlanPercentage,
      secondPhasePiecesCount
    };
  }, [progress, mergedDisciplines]);

  // --- AUTOMATIC SUMMARY SUMMARY (Seção 1) ---
  const automatedFeedback = useMemo(() => {
    const feedback: string[] = [];
    
    // Check strongest
    const strongest = [...mergedDisciplines].sort((a, b) => b.percentage - a.percentage)[0];
    if (strongest) {
      feedback.push(`Seu desempenho em ${strongest.name} está forte (${strongest.percentage}% de acerto). Aproveite para fixar os conceitos e garantir esse bloco de pontos.`);
    }

    // Check weakest
    const weakest = [...mergedDisciplines].sort((a, b) => a.percentage - b.percentage)[0];
    if (weakest) {
      feedback.push(`${weakest.name} precisa de reforço urgente (${weakest.percentage}% de acerto). Planeje revisões e treine questões direcionadas.`);
    }

    // Check progress goals
    if (progress.weeklyStudyHours < progress.studyHoursGoal) {
      feedback.push(`Você está abaixo da meta semanal (${progress.weeklyStudyHours}h estudadas de ${progress.studyHoursGoal}h planejadas). Que tal dedicar mais 30 minutos hoje?`);
    } else {
      feedback.push(`Excelente ritmo! Você bateu a meta semanal de ${progress.studyHoursGoal} horas de estudo.`);
    }

    // Trend
    feedback.push(`Seu percentual geral evoluiu +4% nas últimas 2 semanas devido ao foco em Ética e Constitucional.`);

    return feedback;
  }, [mergedDisciplines, progress]);

  // --- COGNITIVE RADAR SYSTEM (Seção 5 / Radar OAB) ---
  const radarData = useMemo(() => {
    const sorted = [...mergedDisciplines].sort((a, b) => a.percentage - b.percentage);
    
    // 1. Attention disciplines (bottom 3)
    const attentionSubjects = sorted.filter(d => d.status === 'Fraca').slice(0, 3);
    
    // 2. Strongest subjects (top 3)
    const strongestSubjects = [...mergedDisciplines]
      .sort((a, b) => b.percentage - a.percentage)
      .slice(0, 3);

    // 3. Most incorrect themes (derived from low performance areas)
    const wrongThemes = [
      { discipline: "Direito Civil", theme: "Teoria Geral das Obrigações & Prazos" },
      { discipline: "Processo Penal", theme: "Nulidades Processuais (Art. 564 CPP)" },
      { discipline: "Direito Empresarial", theme: "Títulos de Crédito & Falências" },
      { discipline: "Direito Internacional", theme: "Tratados e Condição Jurídica do Estrangeiro" }
    ];

    // 4. Test risk indicator (Risco de Prova)
    let riskLevel: 'Baixo Risco' | 'Atenção' | 'Alto Risco' = 'Atenção';
    let riskColor = 'text-amber-500 bg-amber-50 border-amber-200';
    let riskDesc = "Você está em ritmo de aprovação, mas disciplinas críticas como Civil e Processo Penal estão vulneráveis. Faça revisões pontuais.";

    const criticalLowCount = mergedDisciplines.filter(d => d.status === 'Fraca' && d.weight >= 6).length;
    if (metrics.overallQuizPct < 50 || criticalLowCount >= 3) {
      riskLevel = 'Alto Risco';
      riskColor = 'text-red-500 bg-red-50 border-red-200';
      riskDesc = "Aproveitamento geral abaixo do ideal ou muitas matérias de grande relevância com rendimento fraco. Risco de não passar na 1ª fase.";
    } else if (metrics.overallQuizPct >= 72 && criticalLowCount === 0) {
      riskLevel = 'Baixo Risco';
      riskColor = 'text-emerald-500 bg-emerald-50 border-emerald-200';
      riskDesc = "Excelente constância e domínio equilibrado. Continue revisando para consolidar sua aprovação com margem de segurança.";
    }

    // 5. Weekly priorities recommendation list
    const weeklyPriorities = [
      { text: `Revisar Ética (${strongestSubjects[0]?.name || 'Prerrogativas'}) para blindar os 8 pontos da prova`, action: "Gabaritar Ética" },
      { text: `Refazer questões de Processo Penal focando no rol de Nulidades`, action: "Estudar Nulidades" },
      { text: `Fazer simulado pendente da 1ª Fase para avaliar o tempo de resolução`, action: "Iniciar Simulado" },
      { text: `Treinar peça prática de recurso na sua área jurídica escolhida`, action: "Treinar Peça" }
    ];

    return {
      attentionSubjects,
      strongestSubjects,
      wrongThemes,
      riskLevel,
      riskColor,
      riskDesc,
      weeklyPriorities
    };
  }, [mergedDisciplines, metrics]);

  // --- SECOND PHASE ANALYTICS (Seção 4) ---
  const secondPhaseData = useMemo(() => {
    const area = progress.selectedSecondPhaseArea || "Direito Penal";
    
    // Mock realistic values calibrated to chosen area
    const studiedPieces = [
      { name: "Petição Inicial / Reclamação", difficulty: "Baixa", mastered: true },
      { name: "Contestação / Defesa Prévia", difficulty: "Média", mastered: true },
      { name: "Recurso Ordinário / Apelação", difficulty: "Alta", mastered: false },
      { name: "Memoriais de Alegações Finais", difficulty: "Alta", mastered: false }
    ];

    const weakPoints = [
      "Fundamentação de preliminares e competência de foro",
      "Dosimetria de indenizações ou especificação de teses acessórias",
      "Indicação precisa de artigos constitucionais fundamentantes"
    ];

    const averagePiecesScore = 7.4;
    const averageDiscursivesScore = 6.8;
    const simuladosCount = 2;

    return {
      area,
      studiedPieces,
      weakPoints,
      averagePiecesScore,
      averageDiscursivesScore,
      simuladosCount
    };
  }, [progress.selectedSecondPhaseArea]);

  // --- SIMULATED HISTORY (Seção 8) ---
  const simuladosHistory = useMemo(() => {
    const history = progress.simulatedExamsHistory;
    const totalSim = history.length;
    const averageScore = totalSim > 0 ? (history.reduce((acc, s) => acc + s.percentage, 0) / totalSim).toFixed(1) : "60.0";
    const bestExam = totalSim > 0 ? [...history].sort((a, b) => b.percentage - a.percentage)[0] : null;
    const latestExam = totalSim > 0 ? history[history.length - 1] : null;

    return {
      history,
      totalSim,
      averageScore,
      bestScore: bestExam ? `${bestExam.percentage}%` : "60%",
      latestScore: latestExam ? `${latestExam.percentage}%` : "60%",
      averageTime: "255 min"
    };
  }, [progress.simulatedExamsHistory]);

  // Sort and filter disciplines list for Section 3
  const filteredAndSortedDisciplines = useMemo(() => {
    let list = mergedDisciplines.filter(d => 
      d.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (sortBy === 'nome') {
      list.sort((a, b) => a.name.localeCompare(b.name));
    } else {
      list.sort((a, b) => b.percentage - a.percentage);
    }

    return list;
  }, [mergedDisciplines, searchTerm, sortBy]);

  return (
    <div id="performance-intelligence-dashboard" className="space-y-6">
      
      {/* Editorial Title Banner */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div className="space-y-1">
          <span className="text-[10px] uppercase font-black tracking-widest text-oab-accent flex items-center gap-1.5">
            <Sparkle className="h-4 w-4 text-oab-accent fill-oab-accent" /> MÉTRICAS DE APROVAÇÃO
          </span>
          <h2 className="text-2xl font-black font-display text-oab-primary">
            Meu Desempenho & Diagnóstico
          </h2>
          <p className="text-xs text-slate-500 max-w-xl">
            Acompanhe em tempo real suas taxas de retenção, estatísticas por matéria, e o simulador inteligente <strong>Radar OAB</strong> para blindar seus pontos fracos.
          </p>
        </div>
        <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 px-4 py-2.5 rounded-xl">
          <Activity className="h-5 w-5 text-oab-accent" />
          <div>
            <div className="text-[9px] font-black text-slate-400 uppercase leading-none">Aproveitamento Geral</div>
            <div className="text-sm font-black text-slate-800 mt-0.5">{metrics.overallQuizPct}% de Acertos</div>
          </div>
        </div>
      </div>

      {/* Internal Subtabs Selector Bar */}
      <div className="overflow-x-auto pb-1" id="performance-subnavigation">
        <div className="flex border-b border-slate-200 whitespace-nowrap min-w-max gap-1">
          {[
            { id: 'painel', label: '📊 Meu Painel Geral' },
            { id: 'radar', label: '📡 Radar OAB (Inteligência)' },
            { id: 'fase1', label: `🎯 1ª Fase (${mergedDisciplines.length} Matérias)` },
            { id: 'fase2', label: `🎓 2ª Fase (${secondPhaseData.area})` },
            { id: 'simulados', label: '📈 Simulados & Evolução' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`
                py-3 px-4 text-xs font-bold transition-all border-b-2 cursor-pointer
                ${activeTab === tab.id 
                  ? 'border-oab-accent text-oab-primary font-extrabold bg-white/40' 
                  : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-100/50'}
              `}
              id={`performance-tab-${tab.id}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.12 }}
          className="space-y-6"
        >

          {/* =========================================
              TAB 1: PAINEL GERAL (MEU DESEMPENHO)
              ========================================= */}
          {activeTab === 'painel' && (
            <div className="space-y-6" id="secao-desempenho-geral">
              
              {/* Seção 1 - Welcome & Automatic Feedback comments */}
              <div className="bg-gradient-to-br from-oab-primary to-slate-850 text-white rounded-xl p-6 border border-slate-800 shadow-sm">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-2">
                    <span className="bg-amber-500/10 border border-amber-500/20 text-oab-accent px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider">
                      Resumo do Conselheiro OAB 3F
                    </span>
                    <h3 className="text-base font-extrabold text-white">Análise do seu ciclo de estudos ativo:</h3>
                    <div className="space-y-2 mt-3">
                      {automatedFeedback.map((comment, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs text-slate-200">
                          <Check className="h-4 w-4 text-oab-accent shrink-0 mt-0.5" />
                          <span>{comment}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-white/5 border border-white/10 p-4 rounded-xl text-center shrink-0 min-w-[160px]">
                    <div className="text-3xl font-black text-oab-accent font-mono tracking-tight">{metrics.consecutiveDays}</div>
                    <div className="text-[9px] font-black uppercase tracking-wider text-slate-300 mt-1">Dias Seguidos Ativo</div>
                    <div className="h-1.5 bg-white/10 rounded-full overflow-hidden mt-3 max-w-[120px] mx-auto">
                      <div className="h-full bg-oab-accent rounded-full" style={{ width: '80%' }}></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Seção 2 - Indicadores Obrigatórios Grid (8 Cards) */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="indicadores-obrigatorios-grid">
                {[
                  { label: "Média Geral de Acertos", val: `${metrics.overallQuizPct}%`, desc: "Taxa global", icon: Award, color: "text-emerald-600 bg-emerald-50 border-emerald-150" },
                  { label: "Horas de Estudo", val: `${metrics.totalHours}h`, desc: "Total acumulado", icon: Clock, color: "text-indigo-600 bg-indigo-50 border-indigo-150" },
                  { label: "Aulas Concluídas", val: metrics.completedLecturesCount, desc: "Vídeos assistidos", icon: BookOpen, color: "text-amber-700 bg-amber-50 border-amber-150" },
                  { label: "Questões Respondidas", val: metrics.totalSolved, desc: "Simuladas + Bancos", icon: HelpCircle, color: "text-slate-700 bg-slate-100/50 border-slate-200" },
                  { label: "Simulados Feitos", val: metrics.simulatedExamsCount, desc: "1ª e 2ª Fase", icon: FileText, color: "text-rose-600 bg-rose-50 border-rose-150" },
                  { label: "Revisões Concluídas", val: metrics.totalRevisionsCompleted, desc: "Ciclos de fixação", icon: RotateCcw, color: "text-teal-600 bg-teal-50 border-teal-150" },
                  { label: "Peças Praticadas", val: metrics.secondPhasePiecesCount, desc: "Peças da 2ª Fase", icon: Layers, color: "text-purple-600 bg-purple-50 border-purple-150" },
                  { label: "Plano de Estudos", val: `${metrics.progressPlanPercentage}%`, desc: "Conclusão da trilha", icon: Target, color: "text-blue-600 bg-blue-50 border-blue-150" }
                ].map((ind, i) => {
                  const Icon = ind.icon;
                  return (
                    <div key={i} className={`p-4 rounded-xl border shadow-2xs transition-all hover:scale-[1.01] ${ind.color}`}>
                      <div className="flex justify-between items-start gap-1">
                        <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 leading-tight block max-w-[120px]">{ind.label}</span>
                        <Icon className="h-4 w-4 opacity-70 shrink-0" />
                      </div>
                      <div className="text-xl font-mono font-black text-slate-850 mt-2 leading-none">{ind.val}</div>
                      <span className="text-[9px] text-slate-400 block mt-1">{ind.desc}</span>
                    </div>
                  );
                })}
              </div>

              {/* Seção 10 - Recomendação Automática de Estudo */}
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Sparkles className="h-5 w-5 text-oab-accent" />
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">Plano Direcionado de Estudos</h4>
                    <h3 className="text-sm font-bold text-slate-800">Ações prioritárias sugeridas pela inteligência</h3>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { title: "Reforçar Direito Civil", desc: "Seu rendimento está abaixo do ideal em Direito Civil. Dedique 45 minutos para estudar obrigações.", action: "Revisar Civil", color: "border-l-4 border-l-red-500" },
                    { title: "Dominar Apelação Cível", desc: "Com base na sua escolha de 2ª fase, a estrutura de apelação precisa ser revisada hoje.", action: "Ver Esqueleto", color: "border-l-4 border-l-amber-500" },
                    { title: "Simular 1ª Fase OAB", desc: "Você tem simulados pendentes. Agende uma sessão de simulação para medir seu tempo de prova.", action: "Iniciar Agora", color: "border-l-4 border-l-indigo-500" }
                  ].map((rec, i) => (
                    <div key={i} className={`p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between min-h-[140px] ${rec.color}`}>
                      <div className="space-y-1.5">
                        <h5 className="text-xs font-extrabold text-slate-800">{rec.title}</h5>
                        <p className="text-[10.5px] text-slate-500 leading-relaxed">{rec.desc}</p>
                      </div>
                      <button className="text-left text-[10px] font-black uppercase tracking-wider text-oab-accent hover:text-amber-600 transition-colors mt-3 flex items-center gap-1 cursor-pointer">
                        {rec.action} <ChevronRight className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* =========================================
              TAB 2: RADAR OAB (ESTUDO INTELIGENTE)
              ========================================= */}
          {activeTab === 'radar' && (
            <div className="space-y-6" id="secao-radar-oab">
              
              {/* Risks and Warning Panel */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                
                {/* Risco de Prova (Gauge) */}
                <div className="md:col-span-4 bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col items-center justify-between text-center min-h-[250px]">
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-black tracking-wider text-slate-400">Mecanismo Analítico</span>
                    <h4 className="text-xs font-bold text-slate-800">Seu Risco Geral de Reprovação</h4>
                  </div>
                  
                  {/* Visual Radial Gauge */}
                  <div className="relative w-32 h-32 flex items-center justify-center">
                    <svg className="w-full h-full transform -rotate-90">
                      <circle cx="64" cy="64" r="50" stroke="#f1f5f9" strokeWidth="10" fill="transparent" />
                      <circle 
                        cx="64" 
                        cy="64" 
                        r="50" 
                        stroke={radarData.riskLevel === 'Alto Risco' ? '#ef4444' : radarData.riskLevel === 'Atenção' ? '#f59e0b' : '#10b981'} 
                        strokeWidth="10" 
                        fill="transparent" 
                        strokeDasharray="314"
                        strokeDashoffset={314 - (314 * metrics.overallQuizPct) / 100} 
                        className="transition-all duration-500"
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-2xl font-black text-slate-850 tracking-tight leading-none">{metrics.overallQuizPct}%</span>
                      <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider mt-1">Aproveitamento</span>
                    </div>
                  </div>

                  <span className={`px-4 py-1.5 rounded-full text-xs font-extrabold uppercase ${radarData.riskColor}`}>
                    {radarData.riskLevel}
                  </span>
                </div>

                {/* Risk Explanation Text Card */}
                <div className="md:col-span-8 bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <h3 className="text-sm font-extrabold text-slate-850 flex items-center gap-1.5">
                      <ShieldAlert className="h-4.5 w-4.5 text-amber-500" /> Detalhes do Alerta do Radar OAB
                    </h3>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {radarData.riskDesc}
                    </p>
                    <div className="grid grid-cols-2 gap-4 pt-2">
                      <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg">
                        <span className="text-[9px] text-slate-400 uppercase font-black block">Pontos Críticos</span>
                        <span className="text-xs font-bold text-rose-600 mt-1 block">Direito Civil & Processo Penal</span>
                      </div>
                      <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg">
                        <span className="text-[9px] text-slate-400 uppercase font-black block">Recomendações Diárias</span>
                        <span className="text-xs font-bold text-indigo-600 mt-1 block">Revisar 45 min de Lei Seca</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-slate-150 pt-3 flex items-center justify-between text-xs">
                    <span className="text-slate-400">Rendimento necessário para aprovação segura:</span>
                    <span className="font-extrabold text-emerald-600">&gt; 65% em simulados</span>
                  </div>
                </div>

              </div>

              {/* Seção 7 - Matérias Fortes e Fracas */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Top 3 Melhores Disciplinas */}
                <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                  <h4 className="text-xs font-black uppercase text-emerald-600 tracking-wider flex items-center gap-1">
                    <TrendingUp className="h-4 w-4" /> Top 3 Melhores Disciplinas
                  </h4>
                  <div className="space-y-3">
                    {radarData.strongestSubjects.map((sub, i) => (
                      <div key={i} className="flex justify-between items-center p-3 bg-emerald-50/20 border border-emerald-100 rounded-lg">
                        <div className="space-y-0.5">
                          <span className="text-xs font-extrabold text-slate-800">{sub.name}</span>
                          <span className="text-[9px] text-slate-400 block">Resolvidas: {sub.solved} questões</span>
                        </div>
                        <span className="text-xs font-mono font-black text-emerald-600">{sub.percentage}%</span>
                      </div>
                    ))}
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg text-[10px] text-slate-500">
                    <strong>Temas mais dominados:</strong> Prerrogativas profissionais, direitos humanos fundamentais, e penas em Direito Penal.
                  </div>
                </div>

                {/* Top 3 Disciplinas Mais Fracas */}
                <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                  <h4 className="text-xs font-black uppercase text-red-500 tracking-wider flex items-center gap-1">
                    <TrendingDown className="h-4 w-4" /> Top 3 Disciplinas Mais Fracas
                  </h4>
                  <div className="space-y-3">
                    {radarData.attentionSubjects.map((sub, i) => (
                      <div key={i} className="flex justify-between items-center p-3 bg-red-50/20 border border-red-100 rounded-lg">
                        <div className="space-y-0.5">
                          <span className="text-xs font-extrabold text-slate-800">{sub.name}</span>
                          <span className="text-[9px] text-slate-400 block">Erros Pendentes: {sub.errorsPending} questões</span>
                        </div>
                        <span className="text-xs font-mono font-black text-red-500">{sub.percentage}%</span>
                      </div>
                    ))}
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg text-[10px] text-slate-500">
                    <strong>Temas recomendados para reforço:</strong> Negócios jurídicos, nulidades processuais penais, e títulos de crédito empresarial.
                  </div>
                </div>

              </div>

              {/* Seção 5.2 - Priorities & Mistakes */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Temas mais errados */}
                <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Temas que exigem mais atenção</h4>
                  <div className="space-y-2.5">
                    {radarData.wrongThemes.map((item, idx) => (
                      <div key={idx} className="p-3 bg-slate-50 border border-slate-100 rounded-lg flex items-start gap-2.5">
                        <div className="h-5 w-5 rounded bg-amber-100 border border-amber-200 text-amber-700 flex items-center justify-center text-[10px] font-black shrink-0">!</div>
                        <div>
                          <span className="text-xs font-extrabold text-slate-850 block">{item.theme}</span>
                          <span className="text-[9.5px] text-slate-400 font-bold uppercase">{item.discipline}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Prioridades da Semana (Action Plan) */}
                <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Prioridades recomendadas para a semana</h4>
                  <div className="space-y-3">
                    {radarData.weeklyPriorities.map((item, idx) => (
                      <div key={idx} className="flex justify-between items-center p-3 border border-slate-150 rounded-lg bg-white shadow-2xs hover:border-amber-300 transition-all">
                        <span className="text-xs text-slate-600 font-semibold">{item.text}</span>
                        <button className="bg-slate-150 hover:bg-oab-accent hover:text-slate-900 text-slate-700 text-[10px] font-black uppercase px-2.5 py-1.5 rounded transition-all shrink-0 cursor-pointer">
                          {item.action}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* =========================================
              TAB 3: DESEMPENHO POR DISCIPLINA (1ª FASE)
              ========================================= */}
          {activeTab === 'fase1' && (
            <div className="space-y-6" id="secao-desempenho-disciplinas">
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                
                {/* Search and Sort controls */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-100 pb-4">
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-800">Painel de 19 Disciplinas Oficiais</h3>
                    <p className="text-xs text-slate-400 mt-0.5">Analise o andamento, acertos e pendências de revisão em cada matéria obrigatória.</p>
                  </div>

                  <div className="flex flex-wrap gap-2 w-full sm:w-auto">
                    <div className="relative flex-1 sm:flex-initial">
                      <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                      <input 
                        type="text"
                        placeholder="Buscar disciplina..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="text-xs pl-8 pr-3 py-2 border border-slate-200 rounded-lg bg-slate-50 focus:outline-none w-full sm:max-w-[180px]"
                      />
                    </div>

                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                      className="text-xs border border-slate-200 rounded-lg p-2 bg-slate-50 focus:outline-none"
                    >
                      <option value="aproveitamento">Ordenar por Aproveitamento</option>
                      <option value="nome">Ordenar por Nome</option>
                    </select>
                  </div>
                </div>

                {/* Grid layout of all 19 subjects */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" id="disciplines-full-deck">
                  {filteredAndSortedDisciplines.map((sub, idx) => (
                    <div key={idx} className="p-4 rounded-xl border border-slate-250 bg-white hover:border-oab-accent shadow-3xs transition-all flex flex-col justify-between space-y-4">
                      
                      {/* Subject identification */}
                      <div className="space-y-1">
                        <div className="flex justify-between items-start">
                          <span className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded
                            ${sub.status === 'Forte' ? 'text-emerald-700 bg-emerald-50' : sub.status === 'Fraca' ? 'text-rose-700 bg-rose-50' : 'text-amber-700 bg-amber-50'}
                          `}>
                            {sub.status}
                          </span>
                          <span className="text-[10px] text-slate-400 font-bold font-mono">OAB Peso: {sub.weight} q.</span>
                        </div>
                        <h4 className="text-xs font-extrabold text-slate-800 font-display mt-1.5">{sub.name}</h4>
                      </div>

                      {/* Stats numbers bar */}
                      <div className="grid grid-cols-3 gap-2 py-1 border-t border-b border-slate-100 text-center text-xs">
                        <div>
                          <span className="text-[9px] font-bold text-slate-400 block uppercase">Resolvidas</span>
                          <span className="font-mono font-bold text-slate-700">{sub.solved}</span>
                        </div>
                        <div>
                          <span className="text-[9px] font-bold text-slate-400 block uppercase">Erros</span>
                          <span className="font-mono font-bold text-rose-600">{sub.errorsPending}</span>
                        </div>
                        <div>
                          <span className="text-[9px] font-bold text-slate-400 block uppercase">Revisões</span>
                          <span className="font-mono font-bold text-indigo-600">{sub.reviews}</span>
                        </div>
                      </div>

                      {/* Progress and percentage visual */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[10.5px]">
                          <span className="text-slate-400">Aproveitamento:</span>
                          <span className={`font-mono font-black ${sub.percentage >= 70 ? 'text-emerald-600' : sub.percentage >= 50 ? 'text-amber-600' : 'text-red-500'}`}>
                            {sub.percentage}%
                          </span>
                        </div>
                        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all duration-300
                              ${sub.status === 'Forte' ? 'bg-emerald-500' : sub.status === 'Fraca' ? 'bg-red-500' : 'bg-amber-500'}
                            `}
                            style={{ width: `${sub.percentage}%` }}
                          />
                        </div>
                      </div>

                    </div>
                  ))}
                </div>

              </div>
            </div>
          )}

          {/* =========================================
              TAB 4: DESEMPENHO 2ª FASE
              ========================================= */}
          {activeTab === 'fase2' && (
            <div className="space-y-6" id="secao-desempenho-2fase">
              
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Area choices and averages */}
                <div className="lg:col-span-4 bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <span className="bg-oab-accent/10 border border-oab-accent/20 text-oab-accent px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider block w-fit">
                      FOCO ATUAL
                    </span>
                    <h3 className="text-lg font-extrabold text-slate-800 leading-snug">{secondPhaseData.area}</h3>
                    <p className="text-xs text-slate-400">Painel específico calibrado com base no cronograma e esqueletos da sua disciplina jurídica.</p>
                  </div>

                  <div className="space-y-3.5 border-t border-slate-100 pt-3">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-500">Peças Estudadas:</span>
                      <span className="text-slate-800 font-bold">{secondPhaseData.studiedPieces.length} peças</span>
                    </div>
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-500">Média em Peças:</span>
                      <span className="text-emerald-600 font-extrabold">{secondPhaseData.averagePiecesScore} / 10.0</span>
                    </div>
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-500">Média em Discursivas:</span>
                      <span className="text-indigo-600 font-extrabold">{secondPhaseData.averageDiscursivesScore} / 10.0</span>
                    </div>
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-500">Simulados Feitos:</span>
                      <span className="text-amber-700 font-bold">{secondPhaseData.simuladosCount} realizados</span>
                    </div>
                  </div>
                </div>

                {/* Piece Mastery Checklist */}
                <div className="lg:col-span-8 bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Desempenho e memorização de peças</h4>
                  
                  <div className="space-y-3">
                    {secondPhaseData.studiedPieces.map((piece, i) => (
                      <div key={i} className="flex justify-between items-center p-3 border border-slate-150 rounded-xl bg-slate-50/40">
                        <div className="space-y-1">
                          <span className="text-xs font-extrabold text-slate-800">{piece.name}</span>
                          <div className="flex gap-2">
                            <span className="text-[9px] text-slate-400">Dificuldade: {piece.difficulty}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {piece.mastered ? (
                            <span className="text-[9.5px] bg-emerald-50 text-emerald-600 font-extrabold px-2.5 py-1 rounded border border-emerald-150 flex items-center gap-1">
                              <Check className="h-3 w-3" /> Dominado
                            </span>
                          ) : (
                            <span className="text-[9.5px] bg-amber-50 text-amber-700 font-extrabold px-2.5 py-1 rounded border border-amber-150 flex items-center gap-1">
                              Falta Prática
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* Weak Points of the second phase chosen area */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Pontos fracos detectados */}
                <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                  <h4 className="text-xs font-black uppercase text-red-500 tracking-wider">Pontos fracos da área jurídica escolhida</h4>
                  <div className="space-y-2.5">
                    {secondPhaseData.weakPoints.map((point, idx) => (
                      <div key={idx} className="p-3 bg-slate-50 border border-slate-100 rounded-lg flex items-start gap-2.5">
                        <AlertTriangle className="h-4.5 w-4.5 text-red-500 shrink-0 mt-0.5" />
                        <span className="text-xs text-slate-600 leading-normal font-medium">{point}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Peças com maior dificuldade */}
                <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                  <h4 className="text-xs font-black uppercase text-amber-700 tracking-wider">Peças que exigem mais treino e revisão</h4>
                  <div className="space-y-2">
                    {[
                      { name: "Apelação Cível ou Penal", desc: "Complexidade nas teses preliminares e preliminares de nulidade" },
                      { name: "Memoriais de Alegações Finais", desc: "Lembrar de todas as teses subsidiárias antes do fechamento" }
                    ].map((item, idx) => (
                      <div key={idx} className="p-3 border border-slate-150 rounded-lg bg-white shadow-2xs">
                        <span className="text-xs font-extrabold text-slate-800 block">{item.name}</span>
                        <p className="text-[10.5px] text-slate-500 mt-0.5">{item.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* =========================================
              TAB 5: EVOLUÇÃO & SIMULADOS
              ========================================= */}
          {activeTab === 'simulados' && (
            <div className="space-y-6" id="secao-simulados-graficos">
              
              {/* Seção 6 - Evolução Semanal e Mensal */}
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-800">Gráficos de Evolução Histórica</h3>
                    <p className="text-xs text-slate-400 mt-0.5">Monitore sua constância, horas de estudo semanais e índice de acertos ao longo do tempo.</p>
                  </div>
                  
                  {/* Selector Period */}
                  <div className="flex gap-1 border border-slate-200 rounded-lg p-1 bg-slate-50 shrink-0 text-xs font-bold">
                    {[
                      { id: 'semana', label: 'Última Semana' },
                      { id: 'mes', label: 'Último Mês' },
                      { id: 'geral', label: 'Histórico Geral' }
                    ].map(period => (
                      <button
                        key={period.id}
                        onClick={() => setEvolutionPeriod(period.id as any)}
                        className={`px-3 py-1.5 rounded-md cursor-pointer transition-colors
                          ${evolutionPeriod === period.id ? 'bg-oab-primary text-white font-extrabold shadow-3xs' : 'text-slate-500 hover:text-slate-700'}
                        `}
                      >
                        {period.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Render corresponding customized SVG chart */}
                <div className="pt-4 h-52 flex flex-col justify-between" id="dynamic-evolution-chart">
                  {evolutionPeriod === 'semana' && (
                    <div className="space-y-3">
                      {/* Responsive bar chart mapping days Mon-Sun */}
                      <div className="grid grid-cols-7 gap-3 h-36 items-end border-b border-slate-100 pb-1">
                        {[
                          { day: "Seg", hrs: 2.0, act: 65 },
                          { day: "Ter", hrs: 3.5, act: 72 },
                          { day: "Qua", hrs: 1.5, act: 60 },
                          { day: "Qui", hrs: 4.0, act: 78 },
                          { day: "Sex", hrs: 2.5, act: 68 },
                          { day: "Sáb", hrs: 5.0, act: 82 },
                          { day: "Dom", hrs: 1.0, act: 60 }
                        ].map((d, i) => (
                          <div key={i} className="flex flex-col items-center gap-1.5 h-full justify-end">
                            <span className="text-[9px] font-bold text-emerald-600">{d.act}%</span>
                            <div 
                              className="w-full bg-indigo-500/20 hover:bg-oab-accent hover:opacity-100 transition-all rounded-t" 
                              style={{ height: `${(d.hrs / 5) * 80}%` }}
                            />
                            <span className="text-[10px] text-slate-400 uppercase font-bold font-mono mt-1">{d.day}</span>
                          </div>
                        ))}
                      </div>
                      <div className="flex gap-4 text-[10px] text-slate-400 justify-center font-bold">
                        <span className="flex items-center gap-1.5"><span className="h-2 w-2 bg-indigo-500 rounded" /> Horas Estudadas (Max: 5h)</span>
                        <span className="flex items-center gap-1.5"><span className="h-2 w-2 bg-emerald-500 rounded" /> Taxa de Acertos</span>
                      </div>
                    </div>
                  )}

                  {evolutionPeriod === 'mes' && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-4 gap-4 h-36 items-end border-b border-slate-100 pb-1">
                        {[
                          { week: "Semana 1", hrs: 12, act: 58 },
                          { week: "Semana 2", hrs: 15, act: 62 },
                          { week: "Semana 3", hrs: 18, act: 64 },
                          { week: "Semana 4", hrs: 22, act: 68 }
                        ].map((w, i) => (
                          <div key={i} className="flex flex-col items-center gap-1.5 h-full justify-end">
                            <span className="text-[10px] font-black text-indigo-600">{w.hrs}h</span>
                            <div 
                              className="w-full bg-emerald-500/30 hover:bg-emerald-500 transition-all rounded-t" 
                              style={{ height: `${(w.act / 100) * 80}%` }}
                            />
                            <span className="text-[10px] text-slate-400 font-bold font-mono mt-1">{w.week}</span>
                          </div>
                        ))}
                      </div>
                      <div className="flex gap-4 text-[10px] text-slate-400 justify-center font-bold">
                        <span className="flex items-center gap-1.5"><span className="h-2 w-2 bg-emerald-500 rounded" /> Aproveitamento médio em questões (%)</span>
                      </div>
                    </div>
                  )}

                  {evolutionPeriod === 'geral' && (
                    <div className="space-y-3">
                      <div className="h-36 flex items-end border-b border-slate-100 pb-1 relative">
                        <svg viewBox="0 0 400 120" className="w-full h-full">
                          <path d="M 10 90 Q 130 65, 230 40 T 390 15" fill="none" stroke="#D4AF37" strokeWidth="3" />
                          <path d="M 10 90 Q 130 65, 230 40 T 390 15 L 390 115 L 10 115 Z" fill="rgba(212, 175, 55, 0.06)" />
                          
                          <circle cx="10" cy="90" r="5" fill="#0F172A" stroke="#D4AF37" strokeWidth="2" />
                          <circle cx="130" cy="72" r="5" fill="#0F172A" stroke="#D4AF37" strokeWidth="2" />
                          <circle cx="230" cy="46" r="5" fill="#0F172A" stroke="#D4AF37" strokeWidth="2" />
                          <circle cx="390" cy="15" r="6" fill="#D4AF37" />
                        </svg>
                        <div className="absolute bottom-1 left-2 text-[10px] text-slate-400 font-bold font-mono">Abril (52%)</div>
                        <div className="absolute bottom-1 right-2 text-[10px] text-slate-400 font-bold font-mono">Maio (68%)</div>
                      </div>
                      <div className="text-center text-[10px] text-slate-400 font-bold">Aproveitamento histórico de simulados (Reta de Crescimento)</div>
                    </div>
                  )}
                </div>
              </div>

              {/* Seção 8 - Histórico e Desempenho em Simulados */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Métricas consolidadas dos Simulados */}
                <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Histórico de Simulados Resolvidos</h4>
                  
                  <div className="grid grid-cols-3 gap-2 text-center text-xs py-1">
                    <div className="p-2 bg-slate-50 rounded-lg">
                      <span className="text-[9px] text-slate-400 block font-bold">Média Notas</span>
                      <span className="text-sm font-extrabold text-emerald-600 mt-1 block">{simuladosHistory.averageScore}%</span>
                    </div>
                    <div className="p-2 bg-slate-50 rounded-lg">
                      <span className="text-[9px] text-slate-400 block font-bold">Melhor Nota</span>
                      <span className="text-sm font-extrabold text-indigo-600 mt-1 block">{simuladosHistory.bestScore}</span>
                    </div>
                    <div className="p-2 bg-slate-50 rounded-lg">
                      <span className="text-[9px] text-slate-400 block font-bold">Último Feito</span>
                      <span className="text-sm font-extrabold text-slate-700 mt-1 block">{simuladosHistory.latestScore}</span>
                    </div>
                  </div>

                  <div className="space-y-3 pt-1">
                    {simuladosHistory.history.map((sim, i) => (
                      <div key={i} className="p-3 border border-slate-150 rounded-lg bg-white flex justify-between items-center text-xs">
                        <div>
                          <span className="font-bold text-slate-800 block leading-snug">{sim.title}</span>
                          <span className="text-[10px] text-slate-400 block mt-0.5">Data: {sim.date} • Tipo: {sim.type}</span>
                        </div>
                        <span className="text-xs font-mono font-black text-indigo-600">{sim.score} / {sim.total} ({sim.percentage}%)</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Seção 9 - Desempenho de Revisão */}
                <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Indicadores do Motor de Revisão</h4>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3.5 bg-slate-50/50 rounded-xl border border-slate-150 text-xs">
                      <div className="flex items-center gap-2">
                        <RotateCcw className="h-4.5 w-4.5 text-indigo-500" />
                        <span className="font-semibold text-slate-700">Revisões Programadas Feitas:</span>
                      </div>
                      <span className="font-mono font-black text-slate-800">{metrics.totalRevisionsCompleted}</span>
                    </div>

                    <div className="flex justify-between items-center p-3.5 bg-slate-50/50 rounded-xl border border-slate-150 text-xs">
                      <div className="flex items-center gap-2">
                        <Sparkles className="h-4.5 w-4.5 text-amber-500" />
                        <span className="font-semibold text-slate-700">Flashcards Memorizados (SRS):</span>
                      </div>
                      <span className="font-mono font-black text-slate-800">{Object.keys(progress.flashcardBoxes).length} revisados</span>
                    </div>

                    <div className="flex justify-between items-center p-3.5 bg-slate-50/50 rounded-xl border border-slate-150 text-xs">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="h-4.5 w-4.5 text-rose-500" />
                        <span className="font-semibold text-slate-700">Erros Sanados no Caderno:</span>
                      </div>
                      <span className="font-mono font-black text-slate-800">12 corrigidos</span>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          )}

        </motion.div>
      </AnimatePresence>
      
    </div>
  );
}
