import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Check,
  Copy,
  Search,
  Zap,
  Sliders,
  DollarSign,
  Settings,
  Bell,
  Clock,
  Target,
  ChevronRight,
  Sparkles,
  Layers,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  FileText,
  Users,
  ShieldAlert,
  Compass,
  ListTodo,
  HelpCircle,
  MessageSquare,
  Activity,
  Code
} from 'lucide-react';

interface PromptItem {
  id: string;
  name: string;
  objective: string;
  moment: string;
  context: string;
  promptText: string;
  expectedResult: string;
  dependencies: string;
  mvpStatus: 'MVP' | 'Pós-MVP';
  priority: 'A' | 'B' | 'C';
}

export default function OABPromptsLibrary() {
  const [activeTab, setActiveTab] = useState<'camada1' | 'camada2' | 'camada3' | 'camada4' | 'camada5' | 'camada6'>('camada1');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedModule, setSelectedModule] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Layer 1 - Blocks configuration
  const masterBlocks = [
    {
      id: 'bloco1',
      title: 'Bloco 1 — Fundação do App',
      objective: 'Estabelecer a identidade base, estrutura de navegação principal e fluxos iniciais de conta.',
      whyOrder: 'Garante que o esqueleto do aplicativo exista antes de qualquer outra tela ser integrada.',
      prerequisites: 'Nenhum. É o ponto de partida do desenvolvimento.',
      deliverables: 'Layout de navegação lateral/inferior, telas de Splash, Boas-Vindas, Login, Cadastro, Recuperação de Senha e Perfil de Configurações.'
    },
    {
      id: 'bloco2',
      title: 'Bloco 2 — Entrada do Aluno (Onboarding)',
      objective: 'Coletar dados de rotina, dificuldades, foco e calcular o perfil de estudo e cronograma personalizado do aluno.',
      whyOrder: 'O OAB 3F é um método adaptativo. Sem o onboarding, o dashboard e as tarefas diárias não têm insumos para personalização.',
      prerequisites: 'Fundação do app (Bloco 1) ativa para salvar e ler os dados no estado local do usuário.',
      deliverables: 'Fluxo interativo de onboarding (7 telas), regras de cálculo de perfil e carregamento de metas.'
    },
    {
      id: 'bloco3',
      title: 'Bloco 3 — Núcleo de Estudo (Dashboard e Plano)',
      objective: 'Disponibilizar a tela inicial de rotina, tarefas ativas do dia, controle de progresso e navegação estratégica.',
      whyOrder: 'É o centro gravitacional do aluno. Reúne todos os dados consolidados do plano ativo.',
      prerequisites: 'Entrada do aluno (Bloco 2) ativa para exibir as tarefas calculadas no onboarding.',
      deliverables: 'Dashboard principal do aluno, lista de tarefas semanais interativa, tela de conclusão de tarefas e painel de replanejamento.'
    },
    {
      id: 'bloco4',
      title: 'Bloco 4 — Núcleo de Treino e Materiais (Questões e Biblioteca)',
      objective: 'Entregar o banco de questões comentadas, simulados periódicos, flashcards de revisão e materiais de apoio.',
      whyOrder: 'Fornece a matéria-prima do estudo ativo do método 3F (questões explicadas e memorização).',
      prerequisites: 'Estrutura base do plano (Bloco 3) integrada para marcar metas de resolução.',
      deliverables: 'Biblioteca de materiais por disciplina, banco de questões com filtros e resolução, cronômetro de simulados e motor de flashcards.'
    },
    {
      id: 'bloco5',
      title: 'Bloco 5 — Núcleo de Prova e Progressão (Calendário e Reta Final)',
      objective: 'Orientar o aluno sobre datas do calendário oficial da FGV, reta final de estudo intensivo e transição para a 2ª Fase.',
      whyOrder: 'Cria senso de urgência cronológica e auxilia na progressão para o fim do ciclo.',
      prerequisites: 'Banco de dados e dashboard do aluno funcionais (Blocos 3 e 4).',
      deliverables: 'Calendário de eventos interativo, alertas críticos de inscrição/provas, checklist de reta final e área da 2ª fase.'
    },
    {
      id: 'bloco6',
      title: 'Bloco 6 — Monetização e Comercial',
      objective: 'Configurar a cobrança, travas de conteúdo gratuito, paywalls contextuais e checkout.',
      whyOrder: 'Garante o retorno financeiro do MVP bloqueando funções avançadas para não pagantes.',
      prerequisites: 'Fluxos do aluno prontos (Blocos 1 a 5) para que existam funções premium a serem bloqueadas de fato.',
      deliverables: 'Telas de planos, paywalls dinâmicos, checkout simulado e modal de upgrade integrado no dashboard.'
    },
    {
      id: 'bloco7',
      title: 'Bloco 7 — Painel Administrativo (Admin e Operação)',
      objective: 'Permitir a gestão de alunos, inserção de conteúdo pedagógico, acompanhamento de suporte e moderação comercial.',
      whyOrder: 'Permite que o professor administre os usuários e insira novos simulados sem precisar alterar código.',
      prerequisites: 'Base de dados consolidada e autenticação do app rodando.',
      deliverables: 'Dashboard administrativo, cadastro de questões/simulados, moderação de tickets de suporte e controle de alunos.'
    },
    {
      id: 'bloco8',
      title: 'Bloco 8 — Growth, Comunicação e Lançamento',
      objective: 'Implementar as ferramentas de marketing, campanhas internas, réguas de e-mail/WhatsApp e banners de ativação.',
      whyOrder: 'Maximiza a conversão e retenção após o app estar funcional e as primeiras campanhas irem ao ar.',
      prerequisites: 'Monetização e painel admin prontos (Blocos 6 e 7).',
      deliverables: 'Gerenciador de banners promocionais, automações de CRM baseadas em comportamento e régua de reengajamento.'
    }
  ];

  // Layer 2 - Base structure prompts
  const basePrompts: PromptItem[] = [
    {
      id: 'base-1',
      name: '1. Estrutura e Navegação Geral (Layout Master)',
      objective: 'Criar o esqueleto do app com navegação por abas ou menu lateral adaptável para o OAB 3F.',
      moment: 'Início absoluto do desenvolvimento.',
      context: 'Você é um Especialista em UI/UX e App Builder. O OAB 3F é um aplicativo educacional focado em alta performance. O layout deve ser limpo, focado na rotina diária do aluno.',
      promptText: `Crie a estrutura de navegação master para o aplicativo "OAB 3F". O design deve usar Tailwind CSS com um fundo elegante em cinza ultra-claro (slate-50).
Implemente um menu lateral esquerdo (ou inferior responsivo em dispositivos móveis) com os seguintes links de navegação e ícones correspondentes da biblioteca Lucide:
- Dashboard (Ícone: LayoutDashboard)
- Meu Plano (Ícone: ListTodo)
- Estudo (Disciplinas da 1ª Fase) (Ícone: BookOpen)
- 2ª Fase (Ícone: Scale)
- Questões (Ícone: ClipboardList)
- Simulados (Ícone: Award)
- Revisão Inteligente (Ícone: RefreshCw)
- Calendário OAB (Ícone: Calendar)
- Desempenho (Ícone: TrendingUp)
- Suporte (Ícone: HelpCircle)
- Premium (Ícone: Sparkles, destacado em tom dourado/amber)

No topo do menu ou barra superior, exiba o logotipo "OAB 3F" com uma tipografia geométrica moderna e um indicador de "Streak de Estudos" (um ícone de fogo com contador de dias seguidos). Deixe uma área de visualização central dinâmica onde as telas respectivas de cada link serão carregadas.`,
      expectedResult: 'Menu lateral fixo na esquerda no desktop, que recolhe em menu inferior ou hambúrguer no mobile, com abas interativas que alternam o componente principal central sem atualizar a página.',
      dependencies: 'Instalação das dependências básicas de ícones (lucide-react).',
      mvpStatus: 'MVP',
      priority: 'A'
    },
    {
      id: 'base-2',
      name: '2. Splash Screen e Tela de Boas-Vindas',
      objective: 'Criar a experiência inicial de entrada que gera impacto visual e chama para a ação.',
      moment: 'Logo após criar a navegação principal.',
      context: 'Tela de introdução que comunica instantaneamente a proposta científica do OAB 3F.',
      promptText: `Crie uma tela de boas-vindas com transição opcional (Splash Screen) para o OAB 3F.
A interface deve ser minimalista e de alto impacto visual, com as seguintes especificações:
- Fundo: Slate-950 ou azul escuro profundo (combinação de cores premium, com gradientes sutis).
- No centro: Logotipo grande e brilhante "OAB 3F" acompanhado da assinatura "Metodologia Científica em 3 Fases".
- Subtítulo curto: "A preparação estatística de alta performance que garante seus 40 pontos na OAB estudando de forma inteligente."
- Botões de ação em destaque:
  1. "Começar Minha Preparação Ativa" (Botão principal grande, cor de destaque âmbar/gold ou esmeralda, com efeito hover brilhante).
  2. "Já tenho uma conta / Entrar" (Botão secundário outline ou transparente).
- Rodapé discreto: "Aprovado por estatística. Validado por dados."`,
      expectedResult: 'Uma tela cheia elegante (full-screen) que serve como recepção do aplicativo antes do login/onboarding.',
      dependencies: 'Nenhum.',
      mvpStatus: 'MVP',
      priority: 'A'
    },
    {
      id: 'base-3',
      name: '3. Tela de Login e Acesso',
      objective: 'Permitir que usuários cadastrados façam login com validação de dados.',
      moment: 'Fluxo imediato de segurança após a tela de boas-vindas.',
      context: 'Formulário focado em clareza, livre de distrações.',
      promptText: `Crie a tela de Login para o OAB 3F.
O design deve conter:
- Card centralizado com fundo branco, bordas arredondadas e sombra suave.
- Título: "Bem-vindo de volta" e subtítulo: "Insira suas credenciais para continuar sua rotina de aprovação."
- Campos de formulário com rótulos e placeholders claros:
  1. E-mail (Placeholder: "seu.email@exemplo.com")
  2. Senha (com botão de olho para mostrar/ocultar senha, e link "Esqueci minha senha" alinhado à direita).
- Caixa de seleção (Checkbox) "Lembrar de mim".
- Botão de ação: "Entrar no Painel do Aluno" (Estilizado em cor preta/slate-900 sólida ou esmeralda, ocupando largura total).
- Opção inferior: "Ainda não tem conta? Crie uma agora".`,
      expectedResult: 'Interface de login limpa e funcional que armazena as credenciais ou aciona o fluxo de autenticação.',
      dependencies: 'Splash Screen (Base-2) para redirecionamento.',
      mvpStatus: 'MVP',
      priority: 'A'
    },
    {
      id: 'base-4',
      name: '4. Tela de Cadastro de Conta',
      objective: 'Coletar os dados cadastrais básicos de novos estudantes.',
      moment: 'Junto à tela de login.',
      context: 'Focado em conversão de novos leads com o mínimo de fricção possível.',
      promptText: `Crie a tela de Cadastro de Novo Aluno para o OAB 3F.
O formulário deve solicitar apenas as informações cruciais para o MVP para manter a taxa de conversão alta:
- Nome Completo (Placeholder: "Seu nome")
- E-mail Principal (Placeholder: "seu@email.com")
- Senha Forte (mínimo de 8 caracteres, com indicador visual de força da senha)
- Confirmação de Senha
- Checkbox de aceite dos Termos de Uso e Política de Privacidade da plataforma.
- Botão "Criar Minha Conta Gratuita" (Largura total, cor verde-esmeralda ou âmbar).
- Link de retorno de fluxo: "Já possui uma conta? Fazer Login".`,
      expectedResult: 'Formulário estruturado com validação de campos (compara senha, checa e-mail válido) que avança para o Onboarding.',
      dependencies: 'Tela de Login (Base-3).',
      mvpStatus: 'MVP',
      priority: 'A'
    },
    {
      id: 'base-5',
      name: '5. Recuperação de Senha',
      objective: 'Disponibilizar o fluxo para envio de e-mail de redefinição de acesso.',
      moment: 'Integrado ao formulário de login.',
      context: 'Fluxo autoexplicativo e seguro.',
      promptText: `Crie a tela de Recuperação de Senha para o OAB 3F.
Requisitos de design e elementos:
- Título claro: "Recuperar sua senha" e subtítulo "Não se preocupe! Insira o e-mail cadastrado que enviaremos as instruções de recuperação instantaneamente."
- Campo de input: E-mail de cadastro.
- Botão principal: "Enviar Link de Recuperação" (slate-900).
- Estado de sucesso (exibido condicionalmente ao clicar no botão): Caixa verde-claro amigável informando "E-mail de recuperação enviado! Verifique sua caixa de entrada e spam."
- Link de retorno rápido: "Voltar para o Login".`,
      expectedResult: 'Componente com controle de estado que simula o envio do link e reorienta o aluno de volta para o login.',
      dependencies: 'Tela de Login (Base-3).',
      mvpStatus: 'MVP',
      priority: 'A'
    },
    {
      id: 'base-6',
      name: '6. Perfil e Configurações de Conta',
      objective: 'Fornecer ao aluno o controle de seus dados pessoais e assinatura.',
      moment: 'Finalização do bloco de fundação.',
      context: 'Painel pessoal acessado a partir da navegação principal.',
      promptText: `Crie a tela de Configurações de Perfil para o OAB 3F.
Divida a página em seções com divisórias claras:
1. Dados Pessoais: Inputs para editar Nome, E-mail, Celular/WhatsApp.
2. Segurança: Alterar senha atual para uma nova senha.
3. Status da Assinatura: Caixa de destaque exibindo o plano atual do usuário ("Plano Gratuito" com botão de Upgrade destacado ou "Plano OAB Premium Ativo" com detalhes de renovação).
4. Preferências de Estudo: Toggles rápidos para ativar/desativar lembretes de estudo via WhatsApp e e-mail.
5. Botão de rodapé: "Salvar Alterações" (feedback de sucesso ao salvar) e botão de perigo outline "Sair da Conta".`,
      expectedResult: 'Interface organizada onde o aluno altera dados cadastrais locais e gerencia o status da sua conta.',
      dependencies: 'Navegação Geral (Base-1).',
      mvpStatus: 'MVP',
      priority: 'A'
    }
  ];

  // Layer 3 - Student Area prompts
  const studentPrompts: PromptItem[] = [
    // Onboarding
    {
      id: 'stud-ob-1',
      name: 'A1. Tela Inicial e Fluxo Geral do Onboarding',
      objective: 'Iniciar a jornada adaptativa do aluno explicando o poder do método OAB 3F.',
      moment: 'Primeiro acesso do aluno após a criação de conta.',
      context: 'Início do fluxo de personalização de estudos.',
      promptText: `Crie a Tela Inicial do fluxo de Onboarding interativo do OAB 3F.
Esta tela deve ter uma estrutura em passos (Passo 1 de 6).
- Título inspirador: "Seja bem-vindo ao OAB 3F, Lucas!"
- Subtítulo: "Vamos estruturar juntos o seu caminho científico rumo aos 40 pontos. Em menos de 2 minutos, nossa inteligência estatística vai mapear sua rotina e criar o seu Cronograma de Estudos Individualizado."
- Detalhes visuais: Três pequenos cards informativos destacando:
  1. "Método Baseado em Dados": Mapeamento das últimas 15 edições da FGV.
  2. "Revisão Espaçada de Erros": Otimização de memorização contra o esquecimento.
  3. "Cronograma Adaptável": Ajustado ao seu tempo livre real.
- Botão destacado no rodapé: "Iniciar Configuração do Meu Plano" que avança para a próxima pergunta.`,
      expectedResult: 'Tela de introdução acolhedora com barra de progresso no topo e botão de início que avança no estado do onboarding.',
      dependencies: 'Cadastro de conta concluído.',
      mvpStatus: 'MVP',
      priority: 'A'
    },
    {
      id: 'stud-ob-2',
      name: 'A2. Perguntas de Diagnóstico (Fase, Tempo, Disciplinas e Metas)',
      objective: 'Capturar os inputs estratégicos do aluno para moldar o plano de ação personalizado.',
      moment: 'Sequência de passos do onboarding.',
      context: 'Fluxo interativo passo a passo.',
      promptText: `Crie as telas de perguntas sequenciais do Onboarding do OAB 3F com barra de progresso ativa no topo. Cada pergunta deve ser exibida uma por vez no mesmo container usando controle de estado do React:
1. Passo 2: "Qual fase do Exame de Ordem você vai focar agora?"
   - Opções interativas com ícones: "1ª Fase (Objetiva - 80 questões)", "2ª Fase (Prática-Profissional e discursivas)".
2. Passo 3: "Quanto tempo real você tem disponível para estudar por dia?"
   - Opções: "Até 1 hora (Foco Reta Final)", "De 1 a 2 horas (Foco Estratégico)", "De 2 a 4 horas (Foco Ideal)", "Mais de 4 horas (Aceleração)".
3. Passo 4: "Quais são as suas 3 maiores disciplinas de dificuldade atualmente?"
   - Permita seleção múltipla de uma lista das principais matérias da FGV (Direito Constitucional, Ética Profissional, Direito Administrativo, Direito Civil, Direito Penal, Direito Tributário, Processo Civil, Processo Penal).
4. Passo 5: "Qual a sua maior dificuldade para manter os estudos?"
   - Opções: "Falta de constância/procrastinação", "Não sei organizar os resumos", "Esqueço o que estudo facilmente", "Falta de tempo".
5. Passo 6: "Qual a sua área pretendida para a 2ª Fase?"
   - Lista das disciplinas elegíveis (Constitucional, Administrativo, Tributário, Penal, Civil, Trabalho, Empresarial).
Cada opção selecionada deve ter feedback visual claro (borda colorida de ativo e ícone de check). Adicione botões "Voltar" e "Continuar" para controlar o avanço.`,
      expectedResult: 'Fluxo dinâmico de 5 passos de perguntas com coleta de respostas integrada no estado e botão de avançar e retroceder.',
      dependencies: 'A1. Tela Inicial do Onboarding.',
      mvpStatus: 'MVP',
      priority: 'A'
    },
    {
      id: 'stud-ob-3',
      name: 'A3. Tela Final "Seu Plano de Estudos Científico está Pronto"',
      objective: 'Apresentar o resultado do diagnóstico do onboarding de forma personalizada para o aluno.',
      moment: 'Conclusão do fluxo de onboarding.',
      context: 'Momento de "Aha! Moment" gerando alta percepção de valor.',
      promptText: `Crie a tela final do Onboarding do OAB 3F (Passo de conclusão).
Esta tela simula o cálculo inteligente e mostra um resumo do plano criado:
- Animação ou ícone de "Sucesso / Carregamento concluído" no topo.
- Título: "Análise Estatística Concluída! Seu Plano Científico está Montado."
- Exibição do Perfil de Aluno calculado dinamicamente com base nas respostas:
  - Exemplo: "Perfil: Estudante Estratégico" ou "Perfil: Foco Reta Final".
  - "Meta Diária de Estudo": Calculada com base no tempo disponível selecionado (ex: "Estudo direcionado de 1h30m por dia").
  - "Foco de Dificuldade": Exibe as matérias selecionadas pelo aluno como ponto de partida da atenção (ex: "Rotina de exercícios otimizada para superar Direito Civil e Constitucional").
  - "Revisão Automática de Erros": Informando que a plataforma agendou revisões automáticas no dashboard.
- Botão gigante no centro: "Acessar Meu Dashboard de Estudos" que salva o estado "onboarding_completed: true" e envia o usuário para a página inicial do app.`,
      expectedResult: 'Uma tela de fechamento de onboarding extremamente satisfatória com visualização personalizada e gatilho de entrada oficial no app.',
      dependencies: 'A2. Perguntas de Diagnóstico.',
      mvpStatus: 'MVP',
      priority: 'A'
    },

    // Dashboard
    {
      id: 'stud-dash-1',
      name: 'B1. Dashboard Principal do Aluno',
      objective: 'Apresentar a central inteligente de estudos diários do OAB 3F.',
      moment: 'Página inicial carregada por padrão após o onboarding.',
      context: 'A tela mais acessada do aplicativo, focada no progresso e constância.',
      promptText: `Crie a tela de Dashboard Principal do Aluno para o OAB 3F.
A tela deve possuir uma estrutura de grade limpa e moderna:
1. Cabeçalho de Boas-Vindas: "Olá, [Nome do Aluno]. Hoje é dia de dar mais um passo rumo aos 40 pontos!" com o status atual do plano ("Semana 2 — Fase de Fixação").
2. Barra de Progresso Semanal: Exibe graficamente o percentual de tarefas cumpridas na semana corrente (ex: "4/10 tarefas concluídas - 40%").
3. Seção Principal: Lista de tarefas rápidas do dia em formato de cartões interativos:
   - Resumo do Dia de Ética Profissional (Leitura do estatuto + 10 questões rápidas) com checkbox de conclusão rápida.
   - Revisão Sistemática de Direito Constitucional (2 flashcards pendentes).
4. Barra Lateral de Métricas Rápidas:
   - Contador de Streak de Estudos (ex: "🔥 5 Dias Seguidos").
   - Total de questões respondidas com taxa de acerto (ex: "🎯 84 questões - 68% acerto").
   - Alerta oficial da OAB: "Faltam 42 dias para a prova da 1ª Fase!".`,
      expectedResult: 'Uma tela central dinâmica com dados fictícios do progresso do aluno, métricas atualizadas e tarefas diárias acionáveis.',
      dependencies: 'Menu de Navegação (Base-1).',
      mvpStatus: 'MVP',
      priority: 'A'
    },

    // Meu Plano
    {
      id: 'stud-plan-1',
      name: 'C1. Tela "Meu Plano" e Cronograma de Tarefas',
      objective: 'Exibir a agenda completa de estudos da semana dividida dia a dia.',
      moment: 'Acessada através da aba "Meu Plano".',
      context: 'Substituição das planilhas estáticas tradicionais por um cronograma interativo.',
      promptText: `Crie a tela "Meu Plano" para o OAB 3F.
Ela deve conter:
- Navegador de dias da semana (Seg, Ter, Qua, Qui, Sex, Sáb, Dom) em formato de abas horizontais. O dia atual deve vir pré-selecionado por padrão.
- Lista de Tarefas Detalhadas do dia selecionado. Cada tarefa deve ser um card expansível contendo:
  - Título da tarefa (ex: "Vídeo-Aula Curta: Controle de Constitucionalidade" ou "Simulado de Ética")
  - Tempo estimado (ex: "45 minutos")
  - Prioridade (Alta, Média ou Baixa, com tags coloridas)
  - Botão de ação: "Começar Agora" (ou "Ver Conteúdo") e Checkbox para concluir a tarefa.
- Seção de Replanejamento Rápido no topo: Um botão "Preciso Replanejar Minha Semana" que abre um diálogo simples para o usuário redistribuir tarefas caso tenha perdido algum dia, preservando a coerência do método.`,
      expectedResult: 'Interface fluida de agenda de estudos, onde o aluno navega entre os dias da semana e interage com as tarefas do cronograma adaptável.',
      dependencies: 'Navegação Geral (Base-1).',
      mvpStatus: 'MVP',
      priority: 'A'
    },

    // Biblioteca
    {
      id: 'stud-lib-1',
      name: 'D1. Tela de Disciplinas e Biblioteca de Conteúdos',
      objective: 'Organizar os materiais teóricos divididos por disciplina.',
      moment: 'Acessada através do menu "Estudo" ou "Biblioteca".',
      context: 'Estrutura de acesso rápido aos materiais sintéticos selecionados.',
      promptText: `Crie a tela principal da Biblioteca de Conteúdos e Disciplinas da 1ª Fase para o OAB 3F.
Requisitos:
- Filtro de busca textual rápido no topo ("Buscar por assunto, lei ou termo").
- Grade de cartões representando as 17 disciplinas da OAB (Priorize as 7 maiores em destaque: Ética, Constitucional, Administrativo, Penal, Processo Penal, Civil, Processo Civil).
- Cada cartão de disciplina deve exibir:
  - Nome da disciplina.
  - Peso estatístico na prova da OAB FGV (ex: "Ética Profissional - 8 questões / Peso Altíssimo").
  - Indicador de progresso do aluno naquela disciplina (ex: "35% concluído").
- Ao clicar em uma disciplina, abra uma gaveta lateral ou expanda o card para mostrar a lista de módulos (ex: "Módulo 1: Direitos e Prerrogativas do Advogado") com botões de acesso a Resumos em PDF e Videoaulas curtas.`,
      expectedResult: 'Diretório completo de disciplinas interativo com indicadores estatísticos de relevância para focar o estudo teórico.',
      dependencies: 'Navegação Geral (Base-1).',
      mvpStatus: 'MVP',
      priority: 'A'
    },

    // Questões
    {
      id: 'stud-quest-1',
      name: 'E1. Motor de Resolução de Questões com Feedback Comentado',
      objective: 'Proporcionar o ambiente prático de resolução de questões oficiais da FGV.',
      moment: 'Aba "Questões" ou ao clicar em tarefas de exercícios.',
      context: 'O principal ativo prático do método 3F para treinar por questões comentadas.',
      promptText: `Crie a interface de resolução de questões para o OAB 3F.
O design deve simular com precisão a experiência de prova:
- Cabeçalho com dados da questão: Banca, Órgão, Exame (ex: "FGV - OAB - XXXV Exame de Ordem") e assunto principal.
- Enunciado da questão formatado em texto legível com bom espaçamento de leitura.
- Lista de 4 alternativas de múltipla escolha (A, B, C, D) interativas. Ao clicar em uma alternativa, exiba uma borda azul.
- Botão principal: "Responder Questão" (slate-900).
- Comportamento de Feedback pós-resolução (ao enviar a resposta):
  - Se correta: Destaque a alternativa em verde, exiba som/animação sutil de acerto.
  - Se incorreta: Destaque a alternativa selecionada em vermelho e sinalize a correta em verde.
  - Exibição de um painel expansível de "Gabarito Comentado": Um texto explicativo curto escrito pelo professor analisando por que a alternativa está correta ou errada, baseando-se na lei seca e jurisprudência.
- Botão "Próxima Questão" e botão "Salvar nos Favoritos" (ícone de estrela) para revisão futura.`,
      expectedResult: 'Área interativa de teste de conhecimentos com gabarito dinâmico e comentários didáticos explicativos instantâneos.',
      dependencies: 'Navegação Geral (Base-1).',
      mvpStatus: 'MVP',
      priority: 'A'
    },

    // Simulados
    {
      id: 'stud-sim-1',
      name: 'F1. Tela de Simulados Gerais OAB com Cronômetro Ativo',
      objective: 'Treinar o aluno contra o cansaço mental sob as condições reais de prova.',
      moment: 'Aba "Simulados".',
      context: 'Testes completos cronometrados de 80 questões ou mini-simulados de 20 questões.',
      promptText: `Crie a tela de Simulados para o OAB 3F.
A página deve possuir duas visões:
1. Tela de Início:
   - Opções de simulados disponíveis: "Simulado Geral FGV Oficial (80 questões - 5 horas de duração)" ou "Mini-Simulado OAB 3F de Fixação (20 questões - 1h30 de duração)".
   - Resumo das instruções importantes da banca: "Celular desligado, controle de tempo rígido, sem consulta".
   - Botão "Iniciar Simulado de Prova".
2. Tela de Resolução Ativa (Acionada após iniciar):
   - Barra de cabeçalho fixa com Cronômetro regressivo ativo em tempo real (ex: "Tempo Restante: 04:59:12").
   - Indicador de questão atual (ex: "Questão 1 de 80").
   - Grade de navegação rápida de questões (botões numerados de 1 a 80 que mudam de cor se respondidos ou pulados, permitindo pular e voltar para qualquer questão).
   - Botão "Finalizar e Entregar Gabarito" com pop-up de confirmação de segurança.`,
      expectedResult: 'Interface imersiva de simulação com contador regressivo real em JavaScript, grade de navegação de respostas e fluxo de finalização.',
      dependencies: 'E1. Motor de Resolução de Questões.',
      mvpStatus: 'MVP',
      priority: 'B'
    },

    // Revisão
    {
      id: 'stud-rev-1',
      name: 'G1. Sistema de Revisão Inteligente e Flashcards',
      objective: 'Quebrar a curva de esquecimento do aluno com o sistema de revisão por cartões de memorização (Flashcards).',
      moment: 'Aba "Revisão Inteligente".',
      context: 'Sistema de memorização ativa baseado em repetição espaçada.',
      promptText: `Crie a interface de Flashcards de memorização ativa para a tela de "Revisão Inteligente" do OAB 3F.
O componente principal deve simular um cartão físico interativo:
- Frente do Cartão: Exiba uma pergunta direta ou conceito de lei (ex: "Qual o prazo máximo estabelecido pelo Estatuto para suspensão preventiva do advogado?").
- Botão "Virar Cartão" (com efeito de rotação 3D suave usando CSS).
- Verso do Cartão (revelado ao clicar): Exibe a resposta direta destacada e fundamentada (ex: "Prazo máximo de 90 dias, mediante processo disciplinar instaurado - Art. 70, §3º da Lei 8.906/94").
- Botões de classificação de facilidade para determinar o espaçamento da próxima revisão:
  1. "Errei / Difícil" (Aparecerá novamente hoje - cor vermelha).
  2. "Lembrei com Esforço" (Aparecerá em 3 dias - cor amarela).
  3. "Fácil / Memorizado" (Aparecerá em 7 dias - cor verde).
- Painel de progresso no topo exibindo "Revisões pendentes hoje: 12 cartões".`,
      expectedResult: 'Um componente de memorização física virtualizado com animação 3D, botões de autopontuação e contadores de fila de revisão.',
      dependencies: 'Navegação Geral (Base-1).',
      mvpStatus: 'MVP',
      priority: 'B'
    },

    // Desempenho
    {
      id: 'stud-perf-1',
      name: 'H1. Painel de Desempenho, Estatísticas e Recomendações',
      objective: 'Apresentar ao aluno o diagnóstico visual de sua evolução com validação matemática.',
      moment: 'Aba "Desempenho".',
      context: 'Mecanismo de feedback científico para reajuste estratégico.',
      promptText: `Crie a tela de Desempenho e Estatísticas do Aluno para o OAB 3F.
Utilize elementos de gráficos visuais (estilizados com Tailwind e dados estruturados ou bibliotecas de gráfico se disponíveis) para exibir:
1. Gráfico de Evolução Geral: Histórico de acertos por semana no formato de curva de crescimento.
2. Análise por Disciplina: Tabela listando as disciplinas e suas respectivas taxas de acerto (com barras horizontais de progresso em cores: verde para >70% de acerto, amarelo para 50-70%, vermelho para <50% de acerto).
3. Painel "Diagnóstico de Aprovação OAB":
   - Mensagem calculada em tempo real (ex: se média de acertos for >55%, exibir "Status: Zona de Aprovação Segura! Mantenha o ritmo de revisões." Caso contrário, exibir "Status: Alerta Vermelho! Você precisa elevar sua média de Ética e Constitucional para garantir os 40 pontos.").
   - Card "Recomendação Estratégica do Dia": "Seu desempenho em Processo Civil caiu 12% nesta semana. Recomendamos resolver 10 questões extras hoje." com CTA direto de início.`,
      expectedResult: 'Painel visualmente atraente de diagnóstico de progresso com estatísticas por disciplina e sugestões adaptativas de foco.',
      dependencies: 'E1. Motor de Resolução de Questões.',
      mvpStatus: 'MVP',
      priority: 'A'
    }
  ];

  // Layer 4 - Monetization prompts
  const monetizationPrompts: PromptItem[] = [
    {
      id: 'mon-1',
      name: '1. Grade Geral de Planos e Ofertas',
      objective: 'Exibir as opções de assinatura do OAB 3F em uma página dedicada para novos leads e não assinantes.',
      moment: 'Acessado ao clicar em "Upgrade" ou ao expirar o trial gratuito.',
      context: 'Página de vendas interna de conversão focada no custo-benefício estratégico.',
      promptText: `Crie a tela de Assinatura e Planos de Venda do OAB 3F.
A estrutura deve apresentar um comparativo limpo entre as ofertas:
- Cabeçalho comercial: "Desbloqueie o passaporte da sua aprovação no Exame de Ordem com validação estatística."
- Switcher para faturamento Mensal vs Anual (com etiqueta de "Economize 45% no Anual").
- Grade contendo 3 planos lado a lado:
  1. "Plano Gratuito" (R$ 0 - Ideal para experimentação limitada a 5 questões/dia).
  2. "OAB Premium 1ª Fase" (O mais vendido, focado em simulados, cronograma ativo de 1ª fase e suporte).
  3. "Plano Completo 3F" (Upgrade máximo, incluindo 1ª + 2ª Fase do Exame e mentoria VIP de Elite).
- Em cada plano, liste os benefícios com ícones de check verde e preço mensal grande em destaque.
- Adicione selos de segurança: "Garantia incondicional de 7 dias" e "Ambiente de pagamento 100% criptografado".`,
      expectedResult: 'Página comercial de alta conversão estruturada em três planos comparativos, com gatilhos de desconto no plano anual.',
      dependencies: 'Navegação Geral (Base-1).',
      mvpStatus: 'MVP',
      priority: 'A'
    },
    {
      id: 'mon-2',
      name: '2. Paywalls Contextuais (Travas de Recursos Premium)',
      objective: 'Estimular o upgrade do usuário bloqueando recursos avançados de forma persuasiva.',
      moment: 'Exibido quando o usuário gratuito tenta abrir simulados completos ou excede 5 questões no dia.',
      context: 'Pop-up ou tela de bloqueio com copy focado em gatilhos de urgência.',
      promptText: `Crie o componente de Paywall Contextual (Barreira de Bloqueio Premium) para o OAB 3F.
Este componente deve ser um modal central elegante ou tela inteira de bloqueio com as especificações:
- Título impactante: "Recurso Exclusivo OAB Premium"
- Subtítulo focado em dores: "Não arrisque sua aprovação por R$ 1,10 por dia. O acesso ilimitado a Simulados Oficiais, Gabaritos Comentados por Professores e Cronograma Adaptável é exclusivo para assinantes Premium."
- Lista curta de valor:
  - "Resolução ilimitada sem travas diárias"
  - "Flashcards automáticos baseados nos seus erros"
  - "Preparação de Reta Final Inteligente"
- CTAs em evidência:
  - Botão principal: "Quero Minha Aprovação Segura - Assinar Premium" (Âmbar ou Esmeralda, pulsante).
  - Botão de fechamento sutil: "Continuar no plano gratuito limitado".`,
      expectedResult: 'Modal de overlay ou barreira de acesso que interrompe o fluxo gratuito com copywriting focado em conversão e botão para o checkout.',
      dependencies: '1. Grade Geral de Planos.',
      mvpStatus: 'MVP',
      priority: 'A'
    },
    {
      id: 'mon-3',
      name: '3. Simulador de Checkout de Compra Segura',
      objective: 'Capturar os dados de pagamento simulando um ambiente real sem fricções.',
      moment: 'Acionado ao clicar em assinar algum plano.',
      context: 'Formulário de pagamento de alta conversão simulando checkout em um clique.',
      promptText: `Crie a tela de Checkout de Compra para o OAB 3F.
O design deve possuir duas colunas:
1. Coluna Esquerda (Dados de Pagamento):
   - Abas para selecionar método: "Cartão de Crédito" ou "Pix de Aprovação Rápida".
   - Se Cartão: Inputs com máscaras para Número do Cartão, Nome do Titular, Validade (MM/AA) e Código de Segurança (CVV), além do seletor de parcelamento (até 12x).
   - Se Pix: Exiba instruções simples para geração de QR Code e chave de cópia.
   - Formulário de dados básicos do comprador: CPF e Telefone.
2. Coluna Direita (Resumo do Pedido):
   - Card cinza exibindo o item comprado (ex: "Assinatura OAB 3F Premium - Plano Anual").
   - Detalhamento de valores: Preço original, desconto aplicado e total final.
   - Botão grande de ação: "Confirmar Pagamento e Liberar Meu Acesso Premium" (cor de destaque verde-esmeralda).
   - Selos de segurança no rodapé (SSL, PCI-DSS).`,
      expectedResult: 'Layout de checkout duplo com visual limpo e campos de validação de pagamento simulado com feedback de aprovação.',
      dependencies: '1. Grade Geral de Planos.',
      mvpStatus: 'MVP',
      priority: 'A'
    },
    {
      id: 'mon-4',
      name: '4. Tela de Confirmação de Compra Concluída',
      objective: 'Parabenizar o aluno pelo investimento em sua carreira e indicar os próximos passos.',
      moment: 'Exibida imediatamente após o checkout aprovado.',
      context: 'Ambiente comemorativo que eleva a endorfina de compra do usuário.',
      promptText: `Crie a tela de Compra Confirmada para o OAB 3F.
A tela deve possuir:
- Ícone grande de check verde brilhante com animação de celebração (ex: confetes sutis).
- Mensagem de parabéns: "Seu acesso Premium está Liberado! Parabéns pela decisão de acelerar sua aprovação profissional."
- Detalhamento do pedido: Número da transação fictício e data do plano.
- Card de Próximos Passos recomendados:
  1. "Passo 1": Refazer o onboarding (caso queira calibrar novamente as metas).
  2. "Passo 2": Resolver seu primeiro simulado com estatísticas ilimitadas.
  3. "Passo 3": Acessar a comunidade de alunos.
- Botão principal: "Ir Para Meu Dashboard Premium" (cor preta sólida/slate-900).`,
      expectedResult: 'Página de sucesso do checkout que redireciona o aluno já com status de plano atualizado para premium.',
      dependencies: '3. Simulador de Checkout.',
      mvpStatus: 'MVP',
      priority: 'A'
    }
  ];

  // Layer 5 - Admin prompts
  const adminPrompts: PromptItem[] = [
    {
      id: 'adm-1',
      name: '1. Painel de Controle e Gestão de Alunos (Admin)',
      objective: 'Visualizar as métricas de conversão comercial e gerenciar a base de dados de alunos cadastrados.',
      moment: 'Acesso restrito do professor/administrador.',
      context: 'Visão macro operacional para administração do OAB 3F.',
      promptText: `Crie a tela do Dashboard de Painel Administrativo para o OAB 3F.
Requisitos estruturais:
1. Cards de Métricas Consolidadas no topo:
   - Total de Alunos Cadastrados
   - Receita Mensal Recorrente (MRR) Simulada
   - Taxa de Conversão de Gratuitos para Premium (LTV)
   - Chamados de Suporte Ativos pendentes
2. Seção de Tabela de Gestão de Alunos contendo as colunas:
   - Aluno (Nome e E-mail)
   - Status do Plano (Badge verde para "Premium Anual", amarela para "Premium Mensal", cinza para "Gratuito")
   - Progresso Geral (porcentagem de tarefas)
   - Ações (Botões rápidos para "Enviar Mensagem via WhatsApp", "Resetar Senha" ou "Alterar Plano Manualmente" para fins de suporte).
3. Buscador de alunos por nome/e-mail e filtro rápido de listagem por plano.`,
      expectedResult: 'Interface administrativa de controle com visão de faturamento, controle de acessos individuais dos alunos e suporte operacional.',
      dependencies: 'Navegação Geral (Base-1).',
      mvpStatus: 'MVP',
      priority: 'A'
    },
    {
      id: 'adm-2',
      name: '2. Cadastro de Questões e Simulados (Admin)',
      objective: 'Cadastrar novos itens no banco de questões e organizar a entrega de simulados.',
      moment: 'No painel administrativo.',
      context: 'Operação de conteúdo simplificada para o gestor pedagógico.',
      promptText: `Crie a tela administrativa de Inserção de Questões e Gestão de Simulados para o OAB 3F.
A tela deve oferecer um formulário detalhado para cadastro:
- Seletor de Disciplina (Estatuto da OAB, Direito Civil, etc.) e assunto específico (ex: "Direitos dos Advogados").
- Input para Enunciado da questão (área de texto rica ou expandida).
- Campos individuais de texto para as alternativas de múltipla escolha: Alternativa A, Alternativa B, Alternativa C, Alternativa D.
- Seletor de Alternativa Correta (A, B, C ou D).
- Área de Comentário do Professor (Explicando o embasamento jurídico e súmulas de forma didática).
- Toggle "Adicionar ao Banco de Simulados Gerais" (Se ativo, permite associar a questão a um simulado oficial com número de ordem).
- Botão principal: "Salvar Questão no Banco de Dados" (com feedback de salvamento).`,
      expectedResult: 'Área do professor para cadastrar novos materiais e expandir a base de dados de treino do MVP.',
      dependencies: '1. Painel de Controle e Gestão de Alunos (Admin).',
      mvpStatus: 'MVP',
      priority: 'A'
    }
  ];

  // Layer 6 - Instructions & Checklist
  const weekCalendar = [
    { week: 'Semana 1', task: 'Base + Login + Cadastro + Onboarding', desc: 'Rode os prompts da Camada 2 (Fundação) e Camada 3 (Módulo A: Onboarding). Deixe a navegação do menu lateral ligada a estados locais.' },
    { week: 'Semana 2', task: 'Dashboard + Plano + Biblioteca', desc: 'Implemente o Dashboard de rotina, tarefas do dia e o diretório de disciplinas e resumos (Módulos B, C e D da Camada 3).' },
    { week: 'Semana 3', task: 'Questões + Simulados + Revisão + Desempenho', desc: 'Monte o motor de questões comentadas, cronômetro de simulados, os flashcards 3D de revisão e os gráficos de desempenho (Módulos E, F, G e H).' },
    { week: 'Semana 4', task: 'Monetização + Banners + Admin + QA', desc: 'Adicione as telas de planos, paywalls, checkout simulado, o painel do professor (Admin) e realize testes gerais de ponta a ponta.' }
  ];

  const reviewChecklist = [
    { id: 'chk-1', text: 'A estrutura de navegação lateral está consistente e altera as telas dinamicamente?' },
    { id: 'chk-2', text: 'O onboarding salva as preferências e calcula o perfil e cronograma de tarefas do aluno?' },
    { id: 'chk-3', text: 'As tarefas diárias podem ser marcadas como concluídas, atualizando o progresso semanal?' },
    { id: 'chk-4', text: 'O motor de questões exibe o feedback correto/incorreto com o comentário expansível?' },
    { id: 'chk-5', text: 'Os flashcards de revisão possuem efeito de virada (flip) e alteram os contadores de caixa?' },
    { id: 'chk-6', text: 'A tela de planos direciona para o checkout simulado e atualiza o status do plano para premium?' },
    { id: 'chk-7', text: 'Os paywalls de bloqueio surgem de forma contextualizada ao tentar usar recursos premium em contas gratuitas?' },
    { id: 'chk-8', text: 'O painel administrativo exibe a listagem de alunos e permite alterar os planos e gerenciar o suporte?' }
  ];

  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  const toggleCheck = (id: string) => {
    setCheckedItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Filter logic for searching prompts
  const allPrompts = useMemo(() => {
    return [...basePrompts, ...studentPrompts, ...monetizationPrompts, ...adminPrompts];
  }, []);

  const filteredPrompts = useMemo(() => {
    return allPrompts.filter(p => {
      const matchSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.objective.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.promptText.toLowerCase().includes(searchQuery.toLowerCase());
      
      if (selectedModule === 'all') return matchSearch;
      if (selectedModule === 'base') return matchSearch && basePrompts.some(bp => bp.id === p.id);
      if (selectedModule === 'student') return matchSearch && studentPrompts.some(sp => sp.id === p.id);
      if (selectedModule === 'monetization') return matchSearch && monetizationPrompts.some(mp => mp.id === p.id);
      if (selectedModule === 'admin') return matchSearch && adminPrompts.some(ap => ap.id === p.id);
      return matchSearch;
    });
  }, [searchQuery, selectedModule, allPrompts]);

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-8 animate-fade-in text-left">
      
      {/* Intro Header */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-800 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 opacity-10 pointer-events-none">
          <BookOpen className="h-64 w-64" />
        </div>
        <div className="relative z-10 space-y-4 max-w-3xl">
          <div className="inline-flex items-center space-x-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 px-3 py-1 rounded-full text-[10px] font-mono uppercase tracking-wider font-bold">
            <Code className="h-3 w-3" />
            <span>Biblioteca Operacional de Engenharia de Prompts</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-display font-black tracking-tight text-white">
            Biblioteca de Micro-Prompts de Implementação <span className="text-amber-400">OAB 3F</span>
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            Seu arquétipo de desenvolvimento por blocos modularizados. Copie e cole os prompts operacionais refinados diretamente no **AppSell AI** para construir a plataforma passo a passo, respeitando a pedagogia de 3 fases, paywalls, onboarding e o painel operacional.
          </p>
        </div>

        {/* Global Layer Navigation tabs */}
        <div className="mt-8 flex flex-wrap gap-2 border-t border-slate-800 pt-6">
          <button
            onClick={() => setActiveTab('camada1')}
            className={`flex items-center space-x-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'camada1' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            <Compass className="h-3.5 w-3.5" />
            <span>1. Plano Mestre</span>
          </button>
          <button
            onClick={() => setActiveTab('camada2')}
            className={`flex items-center space-x-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'camada2' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            <span>2. Estrutura Base</span>
          </button>
          <button
            onClick={() => setActiveTab('camada3')}
            className={`flex items-center space-x-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'camada3' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5" />
            <span>3. Área do Aluno</span>
          </button>
          <button
            onClick={() => setActiveTab('camada4')}
            className={`flex items-center space-x-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'camada4' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            <DollarSign className="h-3.5 w-3.5" />
            <span>4. Monetização</span>
          </button>
          <button
            onClick={() => setActiveTab('camada5')}
            className={`flex items-center space-x-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'camada5' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            <Settings className="h-3.5 w-3.5" />
            <span>5. Admin & Growth</span>
          </button>
          <button
            onClick={() => setActiveTab('camada6')}
            className={`flex items-center space-x-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'camada6' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            <ListTodo className="h-3.5 w-3.5" />
            <span>6. Plano de Uso</span>
          </button>
        </div>
      </div>

      {/* SEARCH / FILTERS GLOBAL (Only displayed on Prompt-based tabs) */}
      {activeTab !== 'camada1' && activeTab !== 'camada6' && (
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative w-full md:max-w-md">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar micro-prompts por palavra-chave..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>
          <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
            <span className="text-[11px] font-bold text-slate-400 self-center shrink-0 uppercase tracking-wider mr-2">Filtro de Escopo:</span>
            <button
              onClick={() => setSelectedModule('all')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                selectedModule === 'all' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Todos ({allPrompts.length})
            </button>
            <button
              onClick={() => setSelectedModule('base')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                selectedModule === 'base' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Base ({basePrompts.length})
            </button>
            <button
              onClick={() => setSelectedModule('student')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                selectedModule === 'student' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Aluno ({studentPrompts.length})
            </button>
            <button
              onClick={() => setSelectedModule('monetization')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                selectedModule === 'monetization' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Comercial ({monetizationPrompts.length})
            </button>
            <button
              onClick={() => setSelectedModule('admin')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                selectedModule === 'admin' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Admin ({adminPrompts.length})
            </button>
          </div>
        </div>
      )}

      {/* =======================================================
          TAB PANEL: CAMADA 1 — PLANO MESTRE DE IMPLEMENTAÇÃO
          ======================================================= */}
      {activeTab === 'camada1' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h3 className="text-lg font-black text-slate-900 mb-2">Estrutura do Plano Mestre de Implementação</h3>
            <p className="text-slate-500 text-xs mb-6">
              Abaixo está o mapa de dependências lógicas que dita a ordem segura para construir o aplicativo **OAB 3F** sem retrabalhos ou perda de integridade funcional. Siga os blocos rigorosamente nesta ordem.
            </p>

            <div className="relative border-l-2 border-slate-200 pl-6 ml-4 space-y-8">
              {masterBlocks.map((b, idx) => (
                <div key={b.id} className="relative group">
                  {/* Number bubble */}
                  <div className="absolute -left-[35px] top-0 h-6 w-6 rounded-full bg-slate-900 text-white flex items-center justify-center font-mono text-xs font-bold ring-4 ring-white">
                    {idx + 1}
                  </div>
                  
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 hover:border-amber-400/60 transition-all space-y-3">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                      <h4 className="text-sm font-black text-slate-900">{b.title}</h4>
                      <span className="bg-slate-200 text-slate-800 font-mono text-[9px] uppercase px-2 py-0.5 rounded font-bold">
                        Bloco Ativo de Sucessão
                      </span>
                    </div>
                    
                    <p className="text-slate-600 text-xs leading-relaxed">{b.objective}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-slate-200/60 pt-3 mt-1 text-[11px] leading-normal">
                      <div>
                        <span className="font-bold text-slate-800 block mb-0.5">Por que essa ordem?</span>
                        <p className="text-slate-500">{b.whyOrder}</p>
                      </div>
                      <div>
                        <span className="font-bold text-slate-800 block mb-0.5">Pré-requisitos:</span>
                        <p className="text-slate-500">{b.prerequisites}</p>
                      </div>
                      <div>
                        <span className="font-bold text-slate-800 block mb-0.5">O que sai pronto?</span>
                        <p className="text-emerald-600 font-medium">{b.deliverables}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =======================================================
          TAB PANEL: CAMADA 2 — ESTRUTURA BASE DO APP
          ======================================================= */}
      {activeTab === 'camada2' && (
        <div className="space-y-6">
          <div className="flex items-center space-x-2 mb-2">
            <Layers className="h-5 w-5 text-amber-500" />
            <h3 className="text-lg font-black text-slate-900">Camada 2 — Estrutura Base e Autenticação</h3>
          </div>
          <p className="text-slate-500 text-xs -mt-4">
            Copie os blocos abaixo para subir a fundação do esqueleto visual, logins, cadastros de novos alunos e recuperação de credenciais.
          </p>

          <div className="space-y-6">
            {filteredPrompts.filter(p => basePrompts.some(bp => bp.id === p.id)).map(p => (
              <PromptCard key={p.id} p={p} onCopy={handleCopyText} copiedId={copiedId} />
            ))}
            {filteredPrompts.filter(p => basePrompts.some(bp => bp.id === p.id)).length === 0 && (
              <EmptyState />
            )}
          </div>
        </div>
      )}

      {/* =======================================================
          TAB PANEL: CAMADA 3 — ÁREA DO ALUNO
          ======================================================= */}
      {activeTab === 'camada3' && (
        <div className="space-y-6">
          <div className="flex items-center space-x-2 mb-2">
            <BookOpen className="h-5 w-5 text-amber-500" />
            <h3 className="text-lg font-black text-slate-900">Camada 3 — Área e Experiência do Aluno</h3>
          </div>
          <p className="text-slate-500 text-xs -mt-4">
            Construa toda a jornada do estudante: desde o questionário inteligente de onboarding, geração automática de planos, até o motor de treino por questões comentadas da FGV.
          </p>

          <div className="space-y-6">
            {filteredPrompts.filter(p => studentPrompts.some(sp => sp.id === p.id)).map(p => (
              <PromptCard key={p.id} p={p} onCopy={handleCopyText} copiedId={copiedId} />
            ))}
            {filteredPrompts.filter(p => studentPrompts.some(sp => sp.id === p.id)).length === 0 && (
              <EmptyState />
            )}
          </div>
        </div>
      )}

      {/* =======================================================
          TAB PANEL: CAMADA 4 — MONETIZAÇÃO E COMERCIAL
          ======================================================= */}
      {activeTab === 'camada4' && (
        <div className="space-y-6">
          <div className="flex items-center space-x-2 mb-2">
            <DollarSign className="h-5 w-5 text-amber-500" />
            <h3 className="text-lg font-black text-slate-900">Camada 4 — Monetização, Paywalls e Checkout</h3>
          </div>
          <p className="text-slate-500 text-xs -mt-4">
            Insira as travas e ofertas comerciais que garantem a sustentabilidade do MVP. Bloqueie ferramentas premium com gatilhos de urgência persuasivos.
          </p>

          <div className="space-y-6">
            {filteredPrompts.filter(p => monetizationPrompts.some(mp => mp.id === p.id)).map(p => (
              <PromptCard key={p.id} p={p} onCopy={handleCopyText} copiedId={copiedId} />
            ))}
            {filteredPrompts.filter(p => monetizationPrompts.some(mp => mp.id === p.id)).length === 0 && (
              <EmptyState />
            )}
          </div>
        </div>
      )}

      {/* =======================================================
          TAB PANEL: CAMADA 5 — ADMIN E GESTÃO
          ======================================================= */}
      {activeTab === 'camada5' && (
        <div className="space-y-6">
          <div className="flex items-center space-x-2 mb-2">
            <Settings className="h-5 w-5 text-amber-500" />
            <h3 className="text-lg font-black text-slate-900">Camada 5 — Painel do Professor (Admin) e Gestão</h3>
          </div>
          <p className="text-slate-500 text-xs -mt-4">
            Prompts operacionais para o gestor cadastrar novas questões oficiais comentadas da OAB e acompanhar os dados cadastrais, financeiros e chamados de suporte dos alunos.
          </p>

          <div className="space-y-6">
            {filteredPrompts.filter(p => adminPrompts.some(ap => ap.id === p.id)).map(p => (
              <PromptCard key={p.id} p={p} onCopy={handleCopyText} copiedId={copiedId} />
            ))}
            {filteredPrompts.filter(p => adminPrompts.some(ap => ap.id === p.id)).length === 0 && (
              <EmptyState />
            )}
          </div>
        </div>
      )}

      {/* =======================================================
          TAB PANEL: CAMADA 6 — PLANO DE USO E CHECKLIST
          ======================================================= */}
      {activeTab === 'camada6' && (
        <div className="space-y-8">
          
          {/* Calendar of implementation */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h3 className="text-base font-black text-slate-900 mb-1 flex items-center gap-2">
              <Calendar className="h-4 w-4 text-amber-500" />
              <span>Cronograma de Execução Semanal do MVP</span>
            </h3>
            <p className="text-slate-500 text-xs mb-4">
              Divida a montagem completa em um ciclo ágil de 4 semanas de acordo com a distribuição estrutural recomendada:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {weekCalendar.map((w, idx) => (
                <div key={idx} className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-2 hover:border-slate-300 transition-all">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] uppercase font-mono tracking-widest text-slate-400 font-bold">{w.week}</span>
                    <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse"></span>
                  </div>
                  <h4 className="text-xs font-black text-slate-900">{w.task}</h4>
                  <p className="text-[10px] text-slate-500 leading-normal">{w.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Adaptability Guideline */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 text-amber-900 space-y-3">
            <div className="flex items-center space-x-2 font-bold text-sm text-amber-800">
              <AlertTriangle className="h-5 w-5" />
              <span>Como contornar limites ou restrições do Builder?</span>
            </div>
            <div className="text-xs leading-relaxed space-y-2 text-amber-850">
              <p>
                <strong>1. Quebra de Lógica Complexa:</strong> Se a ferramenta do App Builder falhar ao gerar telas muito detalhadas (ex: motor de questões completo + gráficos de desempenho + painel admin em uma única etapa), divida a tarefa: peça primeiro para a ferramenta desenhar o layout estático com os botões e textos, e depois rode um prompt focado puramente em programar o clique e os cálculos.
              </p>
              <p>
                <strong>2. Priorização Extrema de Fluxo (Layout & Copy):</strong> Se houver limitações severas de banco de dados no momento, simule os dados no estado local do aplicativo (usando arrays JavaScript/React locais na memória da aba) para garantir que o fluxo de telas de vendas, paywalls e onboarding funcione perfeitamente.
              </p>
              <p>
                <strong>3. Armazenamento Simples:</strong> Para persistência rápida de progresso sem configurar servidores externos complexos, oriente o App Builder a ler e salvar os dados no **localStorage** do próprio navegador do aluno. Isso simula perfeitamente uma banco ativo e funciona de forma independente offline.
              </p>
            </div>
          </div>

          {/* Interactive QA Checklist */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h3 className="text-base font-black text-slate-900 mb-1 flex items-center gap-2">
              <ListTodo className="h-4.5 w-4.5 text-slate-900" />
              <span>Checklist de Homologação de Micro-Prompts</span>
            </h3>
            <p className="text-slate-500 text-xs mb-4">
              Use este checklist interativo para validar se o App Builder gerou a funcionalidade de forma correta e coerente com as especificações do OAB 3F:
            </p>

            <div className="space-y-2.5">
              {reviewChecklist.map((item) => {
                const isChecked = !!checkedItems[item.id];
                return (
                  <label
                    key={item.id}
                    className={`flex items-start space-x-3 p-3 rounded-lg border transition-all cursor-pointer ${
                      isChecked ? 'bg-emerald-50/50 border-emerald-200 text-slate-800' : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => toggleCheck(item.id)}
                      className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500 h-4 w-4 shrink-0"
                    />
                    <div className="space-y-0.5">
                      <span className={`text-xs font-medium ${isChecked ? 'line-through text-slate-500' : ''}`}>
                        {item.text}
                      </span>
                    </div>
                  </label>
                );
              })}
            </div>
            
            {/* Checklist progress tracker footer */}
            <div className="border-t border-slate-100 mt-5 pt-4 flex justify-between items-center text-[10px] font-mono text-slate-500">
              <span>Progresso de Homologação</span>
              <span className="font-bold text-slate-900">
                {Object.values(checkedItems).filter(Boolean).length} de {reviewChecklist.length} itens validados
              </span>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}

interface PromptCardProps {
  key?: any;
  p: PromptItem;
  onCopy: (text: string, id: string) => void;
  copiedId: string | null;
}

// Subcomponent: Card holding individual prompts
function PromptCard({ p, onCopy, copiedId }: PromptCardProps) {
  const isCopied = copiedId === p.id;
  
  return (
    <div className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl overflow-hidden shadow-sm hover:shadow transition-all space-y-4">
      
      {/* Header card info */}
      <div className="bg-slate-50 px-5 py-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="space-y-1">
          <h4 className="text-xs font-black text-slate-900 uppercase tracking-tight">{p.name}</h4>
          <p className="text-[10px] text-slate-400"><strong>Momento de Uso:</strong> {p.moment}</p>
        </div>
        <div className="flex items-center gap-1.5 self-start sm:self-center shrink-0">
          <span className={`text-[9px] font-bold px-2 py-0.5 rounded font-mono ${
            p.priority === 'A' ? 'bg-red-50 text-red-700 border border-red-100' :
            p.priority === 'B' ? 'bg-amber-50 text-amber-700 border border-amber-100' :
            'bg-slate-100 text-slate-700'
          }`}>
            Prioridade {p.priority}
          </span>
          <span className="text-[9px] font-bold bg-slate-200 text-slate-850 px-2 py-0.5 rounded font-mono">
            {p.mvpStatus}
          </span>
        </div>
      </div>

      {/* Body specifications */}
      <div className="px-5 space-y-3.5">
        
        {/* Objective */}
        <div>
          <span className="text-[10px] font-bold text-slate-400 block mb-0.5 uppercase tracking-wider">Objetivo do Bloco:</span>
          <p className="text-slate-600 text-xs">{p.objective}</p>
        </div>

        {/* Minimal Context */}
        <div className="bg-slate-50/70 border border-slate-200/50 p-3 rounded-lg text-[11px] text-slate-500 leading-normal">
          <span className="font-bold text-slate-700 block mb-0.5">Contexto sugerido para o Builder:</span>
          {p.context}
        </div>

        {/* Ready to copy-paste Prompt block */}
        <div className="relative">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider flex items-center gap-1">
              <Zap className="h-3 w-3" />
              <span>Prompt de Cópia Operacional</span>
            </span>
            <button
              onClick={() => onCopy(p.promptText, p.id)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all ${
                isCopied 
                  ? 'bg-emerald-600 text-white' 
                  : 'bg-slate-900 text-white hover:bg-slate-800'
              }`}
            >
              {isCopied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
              <span>{isCopied ? 'Copiado!' : 'Copiar Prompt'}</span>
            </button>
          </div>
          
          <pre className="w-full bg-slate-950 text-slate-200 font-mono text-[10.5px] p-4 rounded-xl border border-slate-800 overflow-x-auto whitespace-pre-wrap leading-normal block max-h-[220px] overflow-y-auto">
            {p.promptText}
          </pre>
        </div>

        {/* Expected outcomes & Dependencies */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-slate-100 pt-3 text-[11px] leading-normal pb-4">
          <div>
            <span className="font-bold text-slate-800 block mb-0.5">Resultado Esperado no App Builder:</span>
            <p className="text-slate-500">{p.expectedResult}</p>
          </div>
          <div>
            <span className="font-bold text-slate-800 block mb-0.5">Dependências Técnicas:</span>
            <p className="text-slate-500">{p.dependencies}</p>
          </div>
        </div>

      </div>

    </div>
  );
}

function EmptyState() {
  return (
    <div className="bg-slate-50 border border-dashed border-slate-300 rounded-xl p-8 text-center space-y-2">
      <AlertTriangle className="h-8 w-8 text-slate-400 mx-auto" />
      <h4 className="text-xs font-bold text-slate-700">Nenhum prompt encontrado</h4>
      <p className="text-[10px] text-slate-500 max-w-xs mx-auto">Tente ajustar seus termos de busca ou mude a categoria de escopo no filtro.</p>
    </div>
  );
}
