/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Sparkles,
  Award,
  BookOpen,
  Calendar,
  CheckCircle,
  Clock,
  Compass,
  ArrowRight,
  ArrowLeft,
  ChevronRight,
  User,
  Activity,
  Target,
  Bell,
  SlidersHorizontal,
  Scale,
  Shield,
  HelpCircle,
  AlertCircle,
  FileText,
  Flame,
  Check,
  Zap,
  RefreshCw,
  TrendingUp,
  RotateCcw,
  LayoutDashboard
} from 'lucide-react';
import { StudentProgress, WeeklyTask } from '../types';

interface OnboardingProps {
  onComplete: (data: OnboardingData) => void;
  onSkip?: () => void;
  currentName?: string;
  currentSecondPhaseArea?: string;
}

export interface OnboardingData {
  studentName: string;
  selectedFase: '1a_fase' | '2a_fase' | 'completo' | 'indeciso';
  situacaoAtual: 'iniciante' | 'intermediario' | 'reta_final' | 'repetente' | 'foco_2a_fase';
  horasPorDia: 'ate_1h' | '1h_2h' | '2h_4h' | 'mais_4h';
  diasEstudo: string[]; // e.g. ["Segunda", "Terça", ...]
  estudoBloco: 'curtos' | 'longos';
  estudoTurno: 'manha' | 'tarde' | 'noite' | 'variado';
  areaSegundaFase: string;
  proximidadeProva: 'proxima' | 'ate_3m' | '3_6m' | 'mais_6m' | 'nao_sei';
  metaPrincipal: 'passar_1a' | 'passar_2a' | 'organizar_rotina' | 'melhorar_questoes' | 'dominar_pecas' | 'revisao_intensiva';
  disciplinasDificuldade: string[];
  errarFoco: 'teoria' | 'interpretacao' | 'pratica';
  constanciaDificuldade: boolean;
  notificacoesConfig: string[];
  notificacaoIntensidade: 'leve' | 'moderada' | 'intensa';
  notificacaoHorario: string;
  perfilCalculado: string;
}

export default function Onboarding({ onComplete, onSkip, currentName = 'Lucas Santos', currentSecondPhaseArea = 'Direito Penal' }: OnboardingProps) {
  // We have 11 interactive steps before generating the final dashboard
  const [step, setStep] = useState(1);
  
  // State for all onboarding data answers
  const [studentName, setStudentName] = useState(currentName);
  const [selectedFase, setSelectedFase] = useState<'1a_fase' | '2a_fase' | 'completo' | 'indeciso'>('1a_fase');
  const [situacaoAtual, setSituacaoAtual] = useState<'iniciante' | 'intermediario' | 'reta_final' | 'repetente' | 'foco_2a_fase'>('iniciante');
  const [horasPorDia, setHorasPorDia] = useState<'ate_1h' | '1h_2h' | '2h_4h' | 'mais_4h'>('2h_4h');
  const [diasEstudo, setDiasEstudo] = useState<string[]>(['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta']);
  const [estudoBloco, setEstudoBloco] = useState<'curtos' | 'longos'>('curtos');
  const [estudoTurno, setEstudoTurno] = useState<'manha' | 'tarde' | 'noite' | 'variado'>('noite');
  const [areaSegundaFase, setAreaSegundaFase] = useState(currentSecondPhaseArea);
  const [proximidadeProva, setProximidadeProva] = useState<'proxima' | 'ate_3m' | '3_6m' | 'mais_6m' | 'nao_sei'>('3_6m');
  const [metaPrincipal, setMetaPrincipal] = useState<'passar_1a' | 'passar_2a' | 'organizar_rotina' | 'melhorar_questoes' | 'dominar_pecas' | 'revisao_intensiva'>('organizar_rotina');
  
  // Diagnostic of difficulties
  const [disciplinasDificuldade, setDisciplinasDificuldade] = useState<string[]>(['Direito Civil', 'Processo Penal']);
  const [errarFoco, setErrarFoco] = useState<'teoria' | 'interpretacao' | 'pratica'>('teoria');
  const [constanciaDificuldade, setConstanciaDificuldade] = useState(false);
  
  // Notification preferences
  const [notificacoesConfig, setNotificacoesConfig] = useState<string[]>(['diario', 'revisao', 'meta']);
  const [notificacaoIntensidade, setNotificacaoIntensidade] = useState<'leve' | 'moderada' | 'intensa'>('moderada');
  const [notificacaoHorario, setNotificacaoHorario] = useState('20:00');

  // Loading animation state for Step 11 (Plano generation)
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationMessage, setGenerationMessage] = useState('Processando dados...');

  // Navigation handlers
  const handleNext = () => {
    if (step === 1 && !studentName.trim()) {
      alert("Por favor, informe seu nome para iniciarmos a personalização do acervo.");
      return;
    }

    // Skip area choosing if student isn't doing 2ª Fase or completo
    if (step === 4 && selectedFase === '1a_fase') {
      setStep(6); // Skip Etapa 5 (area selection)
      return;
    }

    if (step === 10) {
      // Go to Etapa 11: Auto plan generation loading screen
      setStep(11);
      triggerPlanGeneration();
      return;
    }

    setStep(prev => prev + 1);
  };

  const handleBack = () => {
    if (step === 6 && selectedFase === '1a_fase') {
      setStep(4); // Skip back over area selection
      return;
    }
    setStep(prev => Math.max(prev - 1, 1));
  };

  // Automated plan generation simulator (Etapa 11)
  const triggerPlanGeneration = () => {
    setIsGeneratingPlan(true);
    setGenerationProgress(10);
    setGenerationMessage('Diagnosticando seu nível atual com base nas respostas...');

    const messages = [
      { prg: 30, msg: 'Priorizando disciplinas e temas estratégicos na 1ª Fase...' },
      { prg: 50, msg: `Configurando sua biblioteca de 2ª Fase em ${areaSegundaFase}...` },
      { prg: 70, msg: 'Montando cronograma de estudos diário personalizado...' },
      { prg: 90, msg: 'Sincronizando banco de questões recorrentes e metas...' },
      { prg: 100, msg: 'Seu ecossistema OAB 3F está pronto para aprovação!' }
    ];

    messages.forEach((stepInfo, idx) => {
      setTimeout(() => {
        setGenerationProgress(stepInfo.prg);
        setGenerationMessage(stepInfo.msg);
        
        if (stepInfo.prg === 100) {
          setTimeout(() => {
            setIsGeneratingPlan(false);
            // Execute onComplete callback
            onComplete({
              studentName: studentName.trim(),
              selectedFase,
              situacaoAtual,
              horasPorDia,
              diasEstudo,
              estudoBloco,
              estudoTurno,
              areaSegundaFase,
              proximidadeProva,
              metaPrincipal,
              disciplinasDificuldade,
              errarFoco,
              constanciaDificuldade,
              notificacoesConfig,
              notificacaoIntensidade,
              notificacaoHorario,
              perfilCalculado: calculateStudentProfile()
            });
          }, 1200);
        }
      }, (idx + 1) * 800);
    });
  };

  // Toggle list helpers
  const handleToggleDay = (day: string) => {
    setDiasEstudo(prev =>
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  const handleToggleDifficulty = (discipline: string) => {
    setDisciplinasDificuldade(prev =>
      prev.includes(discipline) ? prev.filter(d => d !== discipline) : [...prev, discipline]
    );
  };

  const handleToggleNotification = (notifId: string) => {
    setNotificacoesConfig(prev =>
      prev.includes(notifId) ? prev.filter(n => n !== notifId) : [...prev, notifId]
    );
  };

  // Calculate Student Profile automatically (Perfis Reconhecidos)
  const calculateStudentProfile = () => {
    if (selectedFase === '2a_fase' || situacaoAtual === 'foco_2a_fase') {
      return 'Aluno aprovado na 1ª fase e focado na 2ª';
    }
    if (selectedFase === 'completo') {
      return 'Aluno que quer trilha completa';
    }
    if (proximidadeProva === 'proxima' || proximidadeProva === 'ate_3m') {
      return 'Aluno em reta final da 1ª fase';
    }
    if (situacaoAtual === 'repetente') {
      return 'Repetente da 1ª fase';
    }
    if (horasPorDia === 'ate_1h') {
      return 'Aluno com pouco tempo disponível';
    }
    if (constanciaDificuldade) {
      return 'Aluno com dificuldade de constância';
    }
    if (selectedFase === 'indeciso') {
      return 'Aluno desorganizado que precisa de plano guiado';
    }
    return 'Iniciante da 1ª fase';
  };

  const currentProfile = calculateStudentProfile();

  // Mapping readable objectives
  const objectivesMap = {
    passar_1a: 'Garantir aprovação na 1ª fase objetiva',
    passar_2a: 'Garantir aprovação na 2ª fase discursiva',
    organizar_rotina: 'Organizar rotina de estudos cronológica',
    melhorar_questoes: 'Melhorar aproveitamento de acertos em questões',
    dominar_pecas: 'Dominar confecção de peças prático-profissionais',
    revisao_intensiva: 'Fazer revisão intensiva de reta final'
  };

  const faseMap = {
    '1a_fase': '1ª Fase (Objetiva)',
    '2a_fase': '2ª Fase (Prático-Profissional)',
    'completo': 'Ambas as Fases (Ecossistema Completo)',
    'indeciso': 'Ainda não sei como me organizar'
  };

  const situacaoMap = {
    'iniciante': 'Iniciante (Começando do Zero)',
    'intermediario': 'Intermediário (Já estudei antes)',
    'reta_final': 'Reta Final (Foco na Véspera)',
    'repetente': 'Repetente (Refazendo o Exame)',
    'foco_2a_fase': 'Especialista (Aprovado na 1ª)'
  };

  const hoursGoalMap = {
    ate_1h: 'Até 1 hora/dia',
    '1h_2h': '1 a 2 horas/dia',
    '2h_4h': '2 a 4 horas/dia',
    mais_4h: 'Mais de 4 horas/dia'
  };

  return (
    <div className="min-h-[85vh] bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col md:flex-row relative">
      
      {/* LEFT ACCENT PANEL: Brand motivation */}
      <div className="w-full md:w-80 bg-slate-900 p-8 text-white flex flex-col justify-between relative overflow-hidden shrink-0">
        <div className="absolute inset-0 bg-radial-gradient from-oab-accent/15 via-transparent to-transparent opacity-60 pointer-events-none" />
        
        <div className="space-y-6 z-10">
          <div className="inline-flex items-center gap-2 bg-oab-accent/15 border border-oab-accent/35 text-oab-accent px-3 py-1 rounded-full text-xs font-black tracking-widest uppercase">
            <Scale className="h-4 w-4" /> OAB 3F
          </div>
          
          <div className="space-y-2">
            <h2 className="text-2xl font-black font-display tracking-tight leading-tight">
              Método Inteligente <span className="text-oab-accent">3F</span> de Aprovação
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed font-medium">
              Foco, Força e Fé jurídica. Nossa inteligência integrada mapeia suas vulnerabilidades, desenha seu cronograma e entrega o acervo perfeito para garantir sua carteira da OAB.
            </p>
          </div>
        </div>

        <div className="space-y-4 pt-8 border-t border-slate-800 z-10">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold">
              ✓
            </div>
            <div>
              <span className="block text-xs font-bold">Diagnóstico Ativo</span>
              <span className="text-[10px] text-slate-400">Geração de plano em tempo real</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-bold">
              ★
            </div>
            <div>
              <span className="block text-xs font-bold">Biblioteca Premium</span>
              <span className="text-[10px] text-slate-400">PDFs, mapas e lei seca assertivos</span>
            </div>
          </div>

          <p className="text-[10px] text-slate-500 text-center font-mono pt-4">
            Aprovação Garantida • Exame de Ordem
          </p>
        </div>
      </div>

      {/* RIGHT MAIN PANEL: Onboarding questionnaires */}
      <div className="flex-1 p-6 md:p-10 flex flex-col justify-between bg-white">
        
        {/* STEP PROGRESS INDICATOR */}
        {step <= 10 && (
          <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
            <div className="flex items-center gap-3">
              <span className="text-[11px] font-black uppercase text-slate-400 font-mono">
                Passo {step} de 10
              </span>
              <div className="h-2 w-48 bg-slate-100 rounded-full overflow-hidden hidden sm:block">
                <div 
                  className="bg-oab-accent h-full transition-all duration-300"
                  style={{ width: `${(step / 10) * 100}%` }}
                />
              </div>
            </div>

            {/* Skip Option (Funcionalidade Obrigatória 2) */}
            <button
              onClick={onSkip}
              className="text-xs text-slate-400 hover:text-slate-600 font-extrabold cursor-pointer hover:underline"
            >
              Pular Onboarding e Explorar
            </button>
          </div>
        )}

        {/* COMPONENT ROUTER PER STEP */}
        <div className="flex-1 py-4">
          
          {/* STEP 1: WELCOME SCREEN */}
          {step === 1 && (
            <div className="space-y-6 max-w-xl animate-fade-in">
              <div className="space-y-2">
                <h3 className="text-3xl font-black text-slate-850 font-display tracking-tight">
                  Seja muito bem-vindo ao <span className="text-oab-primary">OAB 3F</span>
                </h3>
                <p className="text-sm text-slate-500 leading-relaxed font-medium">
                  Nós não apenas entregamos cronogramas, nós diagnosticamos suas maiores dificuldades jurídicas e preparamos um plano de combate cirúrgico para a sua aprovação.
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-150 rounded-xl p-5 space-y-4">
                <label className="block text-xs font-black text-slate-700 uppercase tracking-wider">
                  Como gostaria de ser chamado pelo aplicativo?
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    placeholder="Seu nome completo ou apelido..."
                    className="w-full text-xs font-bold pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-oab-accent/40 text-slate-800"
                    id="onboarding-input-name"
                  />
                </div>
                <span className="text-[11px] text-slate-400 block font-medium">
                  * Este nome será exibido nos seus relatórios de desempenho, calendários e saudações oficiais.
                </span>
              </div>

              <div className="space-y-2 text-slate-500 text-xs">
                <p className="flex items-center gap-2 font-medium">
                  <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0" />
                  <span>Em poucos passos, seu plano de estudos será totalmente personalizado.</span>
                </p>
                <p className="flex items-center gap-2 font-medium">
                  <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0" />
                  <span>Configuração de trilhas exclusivas para a 1ª fase e 2ª fase.</span>
                </p>
              </div>
            </div>
          )}


          {/* STEP 2: CHOOSE PHASE (Etapa 2) */}
          {step === 2 && (
            <div className="space-y-5 max-w-xl">
              <div className="space-y-1.5">
                <h3 className="text-xl font-black text-slate-850 font-display">Para qual fase da OAB você está se preparando?</h3>
                <p className="text-xs text-slate-500 font-medium">Escolha a alternativa que melhor define seu momento atual na prova da Ordem.</p>
              </div>

              <div className="space-y-3 pt-2">
                {[
                  { id: '1a_fase', title: 'Estou me preparando para a 1ª fase', desc: 'Foco exclusivo na prova objetiva de 80 questões, ética, teoria e simulados rápidos.', icon: BookOpen },
                  { id: '2a_fase', title: 'Fui aprovado na 1ª fase e vou para a 2ª fase', desc: 'Trilha estratégica voltada para sua área escolhida, redação de peças e discursivas.', icon: Award },
                  { id: 'completo', title: 'Quero estudar 1ª e 2ª fase juntas', desc: 'Acesso completo ao ecossistema unificado para garantir tranquilidade nas duas etapas.', icon: Scale },
                  { id: 'indeciso', title: 'Ainda não sei exatamente como me organizar', desc: 'Orientação diagnóstica do aplicativo para quem está com dúvidas sobre por onde começar.', icon: Compass }
                ].map((opt) => {
                  const Icon = opt.icon;
                  const isSel = selectedFase === opt.id;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => setSelectedFase(opt.id as any)}
                      className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-3 cursor-pointer
                        ${isSel 
                          ? 'border-oab-accent bg-amber-50/20 shadow-xs' 
                          : 'border-slate-200 bg-white hover:bg-slate-50'}`}
                    >
                      <div className={`p-2 rounded-lg shrink-0 ${isSel ? 'bg-oab-accent/10 text-oab-accent' : 'bg-slate-100 text-slate-400'}`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="space-y-0.5">
                        <span className="block text-xs font-black text-slate-800">{opt.title}</span>
                        <span className="block text-[11px] text-slate-500 font-medium leading-relaxed">{opt.desc}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}


          {/* STEP 3: CURRENT MOMENT SITUATION (Etapa 3) */}
          {step === 3 && (
            <div className="space-y-5 max-w-xl">
              <div className="space-y-1.5">
                <h3 className="text-xl font-black text-slate-850 font-display">Qual é a sua situação jurídica de estudos hoje?</h3>
                <p className="text-xs text-slate-500 font-medium">Isso nos ajuda a calibrar a intensidade teórica de seus materiais recomendados.</p>
              </div>

              <div className="space-y-3 pt-2">
                {[
                  { id: 'iniciante', title: 'Iniciante (Começando do Zero)', desc: 'Preciso de bases teóricas sólidas, vídeo-aulas introdutórias e resumos passo-a-passo.' },
                  { id: 'intermediario', title: 'Intermediário (Já estudei ou tenho bases)', desc: 'Quero otimizar o tempo focando em resolver questões e revisar pontos falhos de lei seca.' },
                  { id: 'reta_final', title: 'Reta Final (Exame iminente)', desc: 'Revisão intensiva de alta probabilidade ("não posso errar") e resumos esquemáticos de véspera.' },
                  { id: 'repetente', title: 'Repetente (Vou refazer a prova)', desc: 'Estudo focado exclusivamente em mapear erros passados e treinar exames anteriores com simulados.' },
                  { id: 'foco_2a_fase', title: 'Foco na 2ª Fase (Aprovado na 1ª)', desc: 'Treinamento exaustivo de peças, checklists de gabarito e teses discursivas aplicadas.' }
                ].map((opt) => {
                  const isSel = situacaoAtual === opt.id;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => setSituacaoAtual(opt.id as any)}
                      className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-3 cursor-pointer
                        ${isSel 
                          ? 'border-oab-accent bg-amber-50/20 shadow-xs' 
                          : 'border-slate-200 bg-white hover:bg-slate-50'}`}
                    >
                      <div className="pt-0.5 shrink-0">
                        <div className={`h-4.5 w-4.5 rounded-full border flex items-center justify-center ${isSel ? 'border-oab-accent bg-oab-accent' : 'border-slate-300 bg-white'}`}>
                          {isSel && <div className="h-2 w-2 rounded-full bg-oab-primary" />}
                        </div>
                      </div>
                      <div className="space-y-0.5">
                        <span className="block text-xs font-black text-slate-800">{opt.title}</span>
                        <span className="block text-[11px] text-slate-500 font-medium leading-relaxed">{opt.desc}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}


          {/* STEP 4: TIME AVAILABILITY STUDY PLAN (Etapa 4) */}
          {step === 4 && (
            <div className="space-y-5 max-w-xl">
              <div className="space-y-1.5">
                <h3 className="text-xl font-black text-slate-850 font-display">Qual é a sua disponibilidade real para os estudos?</h3>
                <p className="text-xs text-slate-500 font-medium">Seja realista. É melhor 1 hora constante do que 4 horas esporádicas.</p>
              </div>

              <div className="space-y-4 pt-2">
                
                {/* 1. Hours daily selection */}
                <div className="space-y-2">
                  <label className="block text-[10px] font-black uppercase text-slate-500 font-mono">1. Horas de estudo por dia:</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'ate_1h', label: 'Até 1h por dia', desc: 'Foco ultra produtivo' },
                      { id: '1h_2h', label: '1h a 2h por dia', desc: 'Estudo equilibrado' },
                      { id: '2h_4h', label: '2h a 4h por dia', desc: 'Estudo intensivo' },
                      { id: 'mais_4h', label: 'Mais de 4h por dia', desc: 'Dedicação total' }
                    ].map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setHorasPorDia(opt.id as any)}
                        className={`p-3 rounded-xl border text-left cursor-pointer transition-all
                          ${horasPorDia === opt.id ? 'border-oab-accent bg-amber-50/15' : 'border-slate-200 bg-white'}`}
                      >
                        <span className="block text-xs font-black text-slate-850">{opt.label}</span>
                        <span className="block text-[10px] text-slate-400 font-medium">{opt.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 2. Days selection */}
                <div className="space-y-2">
                  <label className="block text-[10px] font-black uppercase text-slate-500 font-mono">2. Quais dias você deseja estudar?</label>
                  <div className="flex flex-wrap gap-1.5">
                    {['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'].map((day) => {
                      const active = diasEstudo.includes(day);
                      return (
                        <button
                          key={day}
                          type="button"
                          onClick={() => handleToggleDay(day)}
                          className={`px-3 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer border
                            ${active 
                              ? 'bg-oab-primary text-white border-oab-primary shadow-3xs' 
                              : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'}`}
                        >
                          {day}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 3. Shift preferences */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-black uppercase text-slate-500 font-mono">3. Período preferido:</label>
                    <select
                      value={estudoTurno}
                      onChange={(e) => setEstudoTurno(e.target.value as any)}
                      className="w-full text-xs font-bold text-slate-700 p-2.5 bg-white border border-slate-200 rounded-lg focus:outline-none cursor-pointer"
                    >
                      <option value="manha">🌅 Manhã</option>
                      <option value="tarde">☀️ Tarde</option>
                      <option value="noite">🌙 Noite</option>
                      <option value="variado">🔄 Variado / Flexível</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-black uppercase text-slate-500 font-mono">4. Método de blocos:</label>
                    <select
                      value={estudoBloco}
                      onChange={(e) => setEstudoBloco(e.target.value as any)}
                      className="w-full text-xs font-bold text-slate-700 p-2.5 bg-white border border-slate-200 rounded-lg focus:outline-none cursor-pointer"
                    >
                      <option value="curtos">⏱️ Curtos (Pomodoro 25min)</option>
                      <option value="longos">🧠 Longos (Foco Imersivo 1h+)</option>
                    </select>
                  </div>
                </div>

              </div>
            </div>
          )}


          {/* STEP 5: 2ª FASE AREA SELECTION (Etapa 5) - Conditional */}
          {step === 5 && (
            <div className="space-y-5 max-w-xl">
              <div className="space-y-1.5">
                <h3 className="text-xl font-black text-slate-850 font-display flex items-center gap-2">
                  <Scale className="h-5.5 w-5.5 text-oab-accent" /> Escolha sua Área da 2ª Fase
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Selecione com sabedoria. Isso ativará automaticamente sua trilha de peças, discursivas estruturadas e artigos-chave recomendados na biblioteca.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                {[
                  { name: 'Direito Penal', icon: '🔴', desc: 'Foco em crimes, inquéritos e teses defensivas.' },
                  { name: 'Direito do Trabalho', icon: '🔵', desc: 'Trata de reclamações trabalhistas e recursos CLT.' },
                  { name: 'Direito Constitucional', icon: '🟡', desc: 'Mandados, ADIs e garantias fundamentais.' },
                  { name: 'Direito Civil', icon: '🟢', desc: 'Obrigações, contratos, família e petição inicial.' },
                  { name: 'Direito Administrativo', icon: '🟠', desc: 'Licitações, servidores públicos e ações.' },
                  { name: 'Direito Tributário', icon: '🟣', desc: 'Impostos, taxas e execuções fiscais.' },
                  { name: 'Direito Empresarial', icon: '⚫', desc: 'Sociedades, falências e propriedade industrial.' }
                ].map((area) => {
                  const isSel = areaSegundaFase === area.name;
                  return (
                    <button
                      key={area.name}
                      onClick={() => setAreaSegundaFase(area.name)}
                      className={`p-3 rounded-xl border text-left flex items-start gap-2.5 cursor-pointer transition-all
                        ${isSel 
                          ? 'border-oab-accent bg-amber-50/10 shadow-xs ring-1 ring-oab-accent/30' 
                          : 'border-slate-200 bg-white hover:bg-slate-50'}`}
                    >
                      <span className="text-lg shrink-0 pt-0.5">{area.icon}</span>
                      <div className="space-y-0.5">
                        <span className="block text-xs font-black text-slate-800">{area.name}</span>
                        <span className="block text-[10px] text-slate-400 font-medium leading-relaxed">{area.desc}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}


          {/* STEP 6: EXAM DATE OR JUBILEE PROXIMITY (Etapa 6) */}
          {step === 6 && (
            <div className="space-y-5 max-w-xl">
              <div className="space-y-1.5">
                <h3 className="text-xl font-black text-slate-850 font-display">Quando será a sua prova da OAB?</h3>
                <p className="text-xs text-slate-500 font-medium">Precisamos dessa estimativa de tempo para calibrar os ciclos de simulados e intensidade de revisões.</p>
              </div>

              <div className="space-y-3 pt-2">
                {[
                  { id: 'proxima', title: 'Vou prestar a próxima prova iminente', desc: 'Carga horária e ritmo focados em resumos esquematizados e lei seca crítica de véspera.' },
                  { id: 'ate_3m', title: 'Daqui a aproximadamente 3 meses', desc: 'Trilha equilibrada de absorção de teoria e alta densidade de simulados semanais.' },
                  { id: '3_6m', title: 'Daqui a 3 a 6 meses', desc: 'Estudo sólido e completo. Ótimo ritmo para sedimentação contínua de conteúdos.' },
                  { id: 'mais_6m', title: 'Mais de 6 meses', desc: 'Estudo de médio-longo prazo para quem deseja criar uma base jurídica de excelência.' },
                  { id: 'nao_sei', title: 'Ainda não tenho data definida', desc: 'Acompanhamento flexível e adaptável conforme seu ritmo de evolução individual.' }
                ].map((opt) => {
                  const isSel = proximidadeProva === opt.id;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => setProximidadeProva(opt.id as any)}
                      className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-3 cursor-pointer
                        ${isSel 
                          ? 'border-oab-accent bg-amber-50/20 shadow-xs' 
                          : 'border-slate-200 bg-white hover:bg-slate-50'}`}
                    >
                      <div className="pt-0.5 shrink-0">
                        <div className={`h-4.5 w-4.5 rounded-full border flex items-center justify-center ${isSel ? 'border-oab-accent bg-oab-accent' : 'border-slate-300 bg-white'}`}>
                          {isSel && <div className="h-2 w-2 rounded-full bg-oab-primary" />}
                        </div>
                      </div>
                      <div className="space-y-0.5">
                        <span className="block text-xs font-black text-slate-800">{opt.title}</span>
                        <span className="block text-[11px] text-slate-500 font-medium leading-relaxed">{opt.desc}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}


          {/* STEP 7: OBJECTIVES AND METRICS (Etapa 7) */}
          {step === 7 && (
            <div className="space-y-5 max-w-xl">
              <div className="space-y-1.5">
                <h3 className="text-xl font-black text-slate-850 font-display">Qual é o seu objetivo principal com o OAB 3F?</h3>
                <p className="text-xs text-slate-500 font-medium">Isso ditará os atalhos exibidos prioritariamente no seu painel principal.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                {[
                  { id: 'passar_1a', title: 'Passar na 1ª fase', desc: 'Objetivo focado em atingir os 40 pontos na prova objetiva.' },
                  { id: 'passar_2a', title: 'Aprovação na 2ª fase', desc: 'Foco exclusivo na aprovação prático-profissional.' },
                  { id: 'organizar_rotina', title: 'Organizar minha rotina', desc: 'Preciso de um cronograma sequencial de tarefas diárias.' },
                  { id: 'melhorar_questoes', title: 'Melhorar nas questões', desc: 'Quero dominar as pegadinhas recorrentes da banca FGV.' },
                  { id: 'dominar_pecas', title: 'Dominar confecção de peças', desc: 'Aprender estruturas formais, pedidos e teses da 2ª Fase.' },
                  { id: 'revisao_intensiva', title: 'Revisão Intensiva', desc: 'Ideal para quem tem poucas semanas antes do exame.' }
                ].map((opt) => {
                  const isSel = metaPrincipal === opt.id;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => setMetaPrincipal(opt.id as any)}
                      className={`p-3.5 rounded-xl border text-left flex flex-col justify-between cursor-pointer transition-all h-28
                        ${isSel 
                          ? 'border-oab-accent bg-amber-50/10 shadow-xs ring-1 ring-oab-accent/30' 
                          : 'border-slate-200 bg-white hover:bg-slate-50'}`}
                    >
                      <span className="block text-xs font-black text-slate-850">{opt.title}</span>
                      <span className="block text-[10.5px] text-slate-400 font-medium leading-relaxed pt-1">{opt.desc}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}


          {/* STEP 8: DIAGNOSTIC OF DIFFICULTIES (Etapa 8) - Optional */}
          {step === 8 && (
            <div className="space-y-5 max-w-xl">
              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-black text-slate-850 font-display">Diagnóstico Rápido de Dificuldades</h3>
                  <span className="text-[10px] bg-slate-100 text-slate-500 font-bold px-2 py-0.5 rounded-lg">OPCIONAL</span>
                </div>
                <p className="text-xs text-slate-500 font-medium">Selecione áreas onde sente maior vulnerabilidade jurídica para priorizarmos revisões.</p>
              </div>

              <div className="space-y-4 pt-2">
                
                {/* 1. Subjects multiselect */}
                <div className="space-y-2">
                  <label className="block text-[10px] font-black uppercase text-slate-500 font-mono">1. Quais disciplinas você sente mais dificuldade?</label>
                  <div className="flex flex-wrap gap-1.5">
                    {['Direito Civil', 'Processo Civil', 'Direito Penal', 'Processo Penal', 'Ética Profissional', 'Direito Constitucional', 'Direito Administrativo', 'Direito do Trabalho'].map((disc) => {
                      const active = disciplinasDificuldade.includes(disc);
                      return (
                        <button
                          key={disc}
                          type="button"
                          onClick={() => handleToggleDifficulty(disc)}
                          className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer border
                            ${active 
                              ? 'bg-amber-100 text-amber-800 border-amber-300 shadow-3xs' 
                              : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'}`}
                        >
                          {disc}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Failure mode */}
                <div className="space-y-2">
                  <label className="block text-[10px] font-black uppercase text-slate-500 font-mono">2. Onde você costuma cometer mais erros?</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'teoria', label: 'Teoria/Falta Base', desc: 'Esqueço conceitos' },
                      { id: 'interpretacao', label: 'Interpretação', desc: 'Pegadinhas do caso' },
                      { id: 'pratica', label: 'Fundamentos/Prática', desc: 'Falta achar artigos' }
                    ].map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setErrarFoco(opt.id as any)}
                        className={`p-2 rounded-xl border text-left cursor-pointer transition-all
                          ${errarFoco === opt.id ? 'border-amber-300 bg-amber-50/10' : 'border-slate-200 bg-white'}`}
                      >
                        <span className="block text-[11px] font-bold text-slate-850">{opt.label}</span>
                        <span className="block text-[9.5px] text-slate-400 font-medium leading-none pt-0.5">{opt.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 3. Consistency toggle */}
                <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="block text-xs font-black text-slate-800">Dificuldade em manter a constância de estudos?</span>
                    <span className="block text-[10.5px] text-slate-500 font-medium">Marque se você costuma procrastinar ou parar na metade da semana.</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setConstanciaDificuldade(!constanciaDificuldade)}
                    className={`h-6 w-11 rounded-full p-1 transition-colors cursor-pointer outline-none ${constanciaDificuldade ? 'bg-oab-accent' : 'bg-slate-300'}`}
                  >
                    <div className={`bg-white h-4 w-4 rounded-full shadow-md transition-transform ${constanciaDificuldade ? 'translate-x-5' : 'translate-x-0'}`} />
                  </button>
                </div>

              </div>
            </div>
          )}


          {/* STEP 9: NOTIFICATIONS PREFERENCES (Etapa 9) */}
          {step === 9 && (
            <div className="space-y-5 max-w-xl">
              <div className="space-y-1.5">
                <h3 className="text-xl font-black text-slate-850 font-display">Como gostaria de ser alertado pelo app?</h3>
                <p className="text-xs text-slate-500 font-medium">Os alertas mantêm sua disciplina ativa. Personalize para não sobrecarregar sua rotina.</p>
              </div>

              <div className="space-y-4 pt-2">
                
                {/* 1. Alerts checklist */}
                <div className="space-y-2">
                  <label className="block text-[10px] font-black uppercase text-slate-500 font-mono">1. Quais avisos deseja receber por e-mail ou push?</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'diario', label: '🌅 Lembrete diário de tarefas', desc: 'Dispara no início do dia' },
                      { id: 'revisao', label: '🔄 Alerta de revisão agendada', desc: 'Avisos de flashcards' },
                      { id: 'simulado', label: '📝 Alerta de simulados', desc: 'Indicação de simulados' },
                      { id: 'prazo', label: '⚖️ Prazos e inscrições OAB', desc: 'Alertas cruciais do calendário' }
                    ].map((opt) => {
                      const active = notificacoesConfig.includes(opt.id);
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => handleToggleNotification(opt.id)}
                          className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex items-start gap-2.5
                            ${active ? 'border-oab-accent bg-amber-50/10' : 'border-slate-200 bg-white'}`}
                        >
                          <div className={`h-4 w-4 rounded border mt-0.5 flex items-center justify-center shrink-0 ${active ? 'bg-oab-accent border-oab-accent text-oab-primary' : 'bg-white border-slate-300'}`}>
                            {active && <Check className="h-3.5 w-3.5 stroke-[4]" />}
                          </div>
                          <div>
                            <span className="block text-xs font-black text-slate-850">{opt.label}</span>
                            <span className="block text-[10px] text-slate-400 font-medium leading-none pt-0.5">{opt.desc}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Notification Intensity */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-black uppercase text-slate-500 font-mono">2. Intensidade dos alertas:</label>
                    <div className="flex rounded-lg border border-slate-200 p-1 bg-slate-50">
                      {[
                        { id: 'leve', label: 'Leve' },
                        { id: 'moderada', label: 'Moderada' },
                        { id: 'intensa', label: 'Foco Total' }
                      ].map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setNotificacaoIntensidade(item.id as any)}
                          className={`flex-1 py-1.5 text-center text-[11px] font-black rounded-md transition-all cursor-pointer
                            ${notificacaoIntensidade === item.id ? 'bg-white text-oab-primary shadow-3xs' : 'text-slate-400'}`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-black uppercase text-slate-500 font-mono">3. Horário preferido do lembrete:</label>
                    <input
                      type="time"
                      value={notificacaoHorario}
                      onChange={(e) => setNotificacaoHorario(e.target.value)}
                      className="w-full text-xs font-bold text-slate-700 p-2.5 bg-white border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                </div>

              </div>
            </div>
          )}


          {/* STEP 10: USER PROFILE DIAGNOSTIC RESUME (Etapa 10) */}
          {step === 10 && (
            <div className="space-y-5 max-w-xl">
              <div className="space-y-1">
                <div className="text-[10px] uppercase font-black text-oab-accent tracking-widest flex items-center gap-1">
                  <Sparkles className="h-4 w-4" /> DIAGNÓSTICO DE PREPARAÇÃO CONCLUÍDO
                </div>
                <h3 className="text-xl font-black text-slate-850 font-display">Tudo pronto! Aqui está o seu Perfil OAB 3F</h3>
                <p className="text-xs text-slate-500 font-medium">Revisamos suas respostas e montamos o seguinte esqueleto tático para a sua aprovação:</p>
              </div>

              {/* Profile Resume Card Display */}
              <div className="bg-slate-900 text-white rounded-xl p-5 border border-slate-800 shadow-md space-y-4">
                
                <div className="flex justify-between items-start border-b border-slate-800 pb-3">
                  <div>
                    <span className="block text-[9px] uppercase font-black text-oab-accent tracking-wider font-mono">Seu Perfil Jurídico</span>
                    <span className="text-sm font-black text-white">{currentProfile}</span>
                  </div>
                  <span className="bg-oab-accent text-oab-primary text-[10px] font-black px-2.5 py-0.5 rounded-full">
                    Aprovado OAB
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-y-3 gap-x-6 text-xs">
                  <div>
                    <span className="block text-[10px] text-slate-400 font-semibold uppercase">Estudante</span>
                    <span className="font-extrabold text-white">{studentName}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-400 font-semibold uppercase">Fase Alvo</span>
                    <span className="font-extrabold text-white">{faseMap[selectedFase]}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-400 font-semibold uppercase">Carga Horária</span>
                    <span className="font-extrabold text-white font-mono">{hoursGoalMap[horasPorDia]}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-400 font-semibold uppercase">Meta Principal</span>
                    <span className="font-extrabold text-white">{objectivesMap[metaPrincipal]}</span>
                  </div>

                  {selectedFase !== '1a_fase' && (
                    <div className="col-span-2">
                      <span className="block text-[10px] text-slate-400 font-semibold uppercase">Área 2ª Fase</span>
                      <span className="font-extrabold text-oab-accent">{areaSegundaFase}</span>
                    </div>
                  )}
                </div>

                <div className="border-t border-slate-800 pt-3 flex gap-2 items-center text-[11px] text-slate-400">
                  <Activity className="h-4 w-4 text-emerald-400" />
                  <span>Dificuldades declaradas em: <strong className="text-white">{disciplinasDificuldade.join(', ') || 'Nenhuma'}</strong>.</span>
                </div>
              </div>

              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs text-emerald-800 font-medium">
                <CheckCircle className="h-4.5 w-4.5 text-emerald-500 shrink-0" />
                <span>"Seu plano OAB 3F está pronto. Montamos um cronograma inicial de preparação para que você comece com foco."</span>
              </div>
            </div>
          )}


          {/* STEP 11: LOADING ANIMATION PLAN GENERATOR (Etapa 11) */}
          {step === 11 && (
            <div className="space-y-6 max-w-xl text-center py-10">
              <div className="inline-block relative">
                <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-oab-accent" />
                <Sparkles className="absolute inset-0 m-auto h-6 w-6 text-oab-accent animate-pulse" />
              </div>

              <div className="space-y-2">
                <h3 className="text-xl font-black text-slate-850">Gerando seu Plano Inicial Personalizado...</h3>
                <p className="text-xs text-slate-500 font-mono font-bold text-center h-4 text-oab-accent">
                  {generationMessage}
                </p>
              </div>

              <div className="max-w-xs mx-auto bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div 
                  className="bg-oab-accent h-full transition-all duration-300"
                  style={{ width: `${generationProgress}%` }}
                />
              </div>

              <p className="text-[11px] text-slate-400 italic">
                Nossos robôs acadêmicos estão customizando seu cronograma, adicionando as disciplinas e dividindo seus blocos de revisão para maximizar seus acertos.
              </p>
            </div>
          )}

        </div>

        {/* BOTTOM STEP CONTROLLERS */}
        {step <= 10 && (
          <div className="border-t border-slate-100 pt-5 mt-6 flex justify-between items-center">
            
            {/* Back Button */}
            {step > 1 ? (
              <button
                type="button"
                onClick={handleBack}
                className="flex items-center gap-1 text-xs font-bold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" /> Voltar anterior
              </button>
            ) : (
              <div />
            )}

            {/* Next / Proceed Button */}
            <button
              type="button"
              onClick={handleNext}
              className="bg-oab-primary hover:bg-slate-850 text-white font-black text-xs px-5 py-3 rounded-xl flex items-center gap-1.5 transition-all shadow-xs hover:shadow-sm cursor-pointer"
              id="onboarding-next-btn"
            >
              {step === 10 ? 'Concluir e Gerar Meu Plano' : 'Continuar'} <ArrowRight className="h-4 w-4" />
            </button>

          </div>
        )}

      </div>

    </div>
  );
}
