/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  RotateCcw,
  Sparkles,
  Search,
  BookOpen,
  Edit2,
  CheckCircle2,
  ChevronRight,
  HelpCircle,
  TrendingUp,
  XCircle,
  FileText,
  Star,
  Book,
  FileCode,
  Award,
  AlertCircle,
  Calendar,
  Flame,
  Check,
  CheckSquare,
  RefreshCw,
  Sliders,
  Target,
  Activity,
  ChevronDown,
  Trash2,
  Info,
  AlertTriangle,
  ArrowRight,
  SlidersHorizontal,
  Bookmark
} from 'lucide-react';
import { Flashcard, Question, StudentProgress, SimulatedResult } from '../types';
import {
  PHASE2_LEGAL_AREAS,
  PHASE2_PIECES_BY_AREA,
  PHASE2_DISCURSIVES_BY_AREA,
  PHASE2_SIMULADOS_BY_AREA,
  Phase2Piece,
  Phase2Discursive
} from '../data/phase2Data';

interface SmartRevisionProps {
  flashcards: Flashcard[];
  questions: Question[];
  progress: StudentProgress;
  onUpdateFlashcardBox: (cardId: string, increment: number) => void;
  onSavePieceNote: (pieceId: string, note: string) => void;
  onSaveActivity: (tab: string, title: string, sectionId?: string, itemId?: string) => void;
}

// Curated top legislation segments for Secao 6 (Lei Seca)
const TOP_OAB_ARTICLES = [
  {
    id: "art-1",
    discipline: "Ética Profissional",
    article: "Art. 7º, Lei 8.906/94 (Estatuto da Advocacia)",
    summary: "Direitos do Advogado: Garante a inviolabilidade do escritório ou local de trabalho, o sigilo profissional absoluto, a comunicação reservada com cliente preso e a presença de representante da OAB em caso de prisão em flagrante por motivo profissional.",
    text: "Art. 7º São direitos do advogado:\nI - exercer, com liberdade, a profissão em todo o território nacional;\nII - ter respeitada, em nome da liberdade de defesa e do sigilo profissional, a inviolabilidade de seu escritório ou local de trabalho, de seus instrumentos de trabalho, de sua correspondência escrita, eletrônica, telefônica e telemática, desde que relativas ao exercício da advocacia;\nIII - comunicar-se com seus clientes, pessoal e reservadamente, mesmo sem procuração, quando estes se acharem presos, detidos ou recolhidos em estabelecimentos civis ou militares, ainda que considerados incomunicáveis.",
    category: "Extrema Importância",
    tip: "A inviolabilidade é relativa: pode ser afastada por decisão judicial fundamentada se houver indício de autoria de crime pelo próprio advogado."
  },
  {
    id: "art-2",
    discipline: "Direito Constitucional",
    article: "Art. 5º, LXIX, CF/88",
    summary: "Mandado de Segurança Individual: Cabível para proteger direito líquido e certo, não amparado por habeas corpus ou habeas data, contra ato ilegal ou com abuso de poder de autoridade pública.",
    text: "Art. 5º, LXIX - conceder-se-á mandado de segurança para proteger direito líquido e certo, não amparado por habeas corpus ou habeas data, quando o responsável pela ilegalidade ou abuso de poder for autoridade pública ou agente de pessoa jurídica no exercício de atribuições do Poder Público;",
    category: "Muito Alta",
    tip: "Direito líquido e certo é aquele que pode ser comprovado de imediato, por documentos pré-constituídos. Não se admite dilação probatória!"
  },
  {
    id: "art-3",
    discipline: "Direito Penal",
    article: "Art. 25, Código Penal",
    summary: "Legítima Defesa: Causa de exclusão da ilicitude baseada no uso moderado dos meios necessários para repelir injusta agressão, atual ou iminente, a direito seu ou alheio.",
    text: "Art. 25 - Entende-se em legítima defesa quem, usando moderadamente dos meios necessários, repele injusta agressão, atual ou iminente, a direito seu ou de outrem.",
    category: "Alta Importância",
    tip: "Exige proporcionalidade (uso moderado). Agressão passada não autoriza legítima defesa, pois seria vingança. Agressão futura de forma remota exige preventivos judiciais, não autotutela."
  },
  {
    id: "art-4",
    discipline: "Direito do Trabalho",
    article: "Art. 840, § 1º, CLT",
    summary: "Requisitos da Inicial Trabalhista: Impõe a necessidade de indicação de valor líquidado para todos os pedidos formulados sob o rito ordinário ou sumaríssimo.",
    text: "Art. 840, § 1º Sendo escrita, a reclamação deverá conter a designação do juízo, a qualificação do reclamante e do reclamado, a breve exposição dos fatos de que resulte o dissídio, o pedido, que deverá ser certo, determinado e com indicação de seu valor, a data e a assinatura do reclamante ou de seu representante.",
    category: "Extrema Importância",
    tip: "Esquecer de liquidar qualquer pedido na inicial gera extinção imediata sem resolução do mérito em relação ao pleito ilíquido."
  },
  {
    id: "art-5",
    discipline: "Processo Civil",
    article: "Art. 319, CPC",
    summary: "Requisitos Gerais da Inicial Cível: Endereçamento, qualificação exata com estado civil e e-mail, fatos e fundamentos, pedidos líquidos e pedido de conciliação.",
    text: "Art. 319. A petição inicial indicará:\nI - o juízo a que é dirigida;\nII - os nomes, os prenomes, o estado civil, a existência de união estável, a profissão, o CPF ou CNPJ, o endereço eletrônico e o domicílio e a residência do autor e do réu;\nIII - o fato e os fundamentos jurídicos do pedido;\nIV - o pedido com as suas especificações;\nV - o valor da causa;\nVI - as provas com que o autor pretende demonstrar a verdade dos fatos alegados;\nVII - a opção do autor pela realização ou não da audiência de conciliação ou de mediação.",
    category: "Muito Alta",
    tip: "Na OAB, nunca invente dados fictícios para a qualificação se o enunciado não forneceu. Use reticências (...) ou termos genéricos."
  }
];

export default function SmartRevision({
  flashcards,
  questions,
  progress,
  onUpdateFlashcardBox,
  onSavePieceNote,
  onSaveActivity
}: SmartRevisionProps) {
  // 9 Subtabs Manager
  const [activeSubtab, setActiveSubtab] = useState<
    'inicio' | 'programadas' | 'flashcards' | 'caderno_erros' | 'questoes_erradas' | 'lei_seca' | 'fase2' | 'recuperacao' | 'historico'
  >('inicio');

  // Scheduled Revisions state
  const [scheduledRevisions, setScheduledRevisions] = useState(() => {
    const saved = localStorage.getItem('oab3f_scheduled_revisions');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback below
      }
    }
    return [
      {
        id: "rev-1",
        timeline: "24h",
        discipline: "Ética Profissional",
        theme: "Incompatibilidades e Impedimentos",
        type: "Aula",
        date: "Amanhã",
        status: "Pendente",
        details: "Revisão dos arts. 27 a 30 do Estatuto da OAB. Lembre-se: Incompatibilidade é proibição total; Impedimento é proibição parcial (ex: servidores públicos contra a Fazenda)."
      },
      {
        id: "rev-2",
        timeline: "24h",
        discipline: "Direito Constitucional",
        theme: "Controle de Constitucionalidade",
        type: "Questão",
        date: "Hoje",
        status: "Atrasada",
        details: "Rever os legitimados do art. 103 da CF para propor ADI, ADC e ADO. Mnemônico dos 3 'Mesas', 3 'Chefes', 3 'Sociedades'."
      },
      {
        id: "rev-3",
        timeline: "7d",
        discipline: "Direito Penal",
        theme: "Crimes contra a Vida",
        type: "Lei seca",
        date: "Há 2 dias",
        status: "Atrasada",
        details: "Revisão do homicídio qualificado (Art. 121, § 2º, CP) e do feminicídio. Atentar para as causas de aumento de pena."
      },
      {
        id: "rev-4",
        timeline: "7d",
        discipline: "Direito do Trabalho",
        theme: "Recurso Ordinário",
        type: "Peça",
        date: "Em 3 dias",
        status: "Pendente",
        details: "Estrutura do recurso ordinário trabalhista. Foco especial nas custas processuais e depósito recursal."
      },
      {
        id: "rev-5",
        timeline: "30d",
        discipline: "Direito Civil",
        theme: "Teoria Geral dos Contratos",
        type: "Discursiva",
        date: "Em 12 dias",
        status: "Pendente",
        details: "Conceitos de função social do contrato, pacta sunt servanda e vícios redibitórios."
      },
      {
        id: "rev-6",
        timeline: "30d",
        discipline: "Direito Administrativo",
        theme: "Licitações (Lei 14.133/21)",
        type: "Lei seca",
        date: "Ontem",
        status: "Atrasada",
        details: "Principais modalidades de licitação: Concorrência, Concurso, Leilão, Pregão e Diálogo Competitivo. Tomada de preços foi extinta!"
      }
    ];
  });

  // Save scheduled reviews
  useEffect(() => {
    localStorage.setItem('oab3f_scheduled_revisions', JSON.stringify(scheduledRevisions));
  }, [scheduledRevisions]);

  // Flashcards state
  const [fcDiscipline, setFcDiscipline] = useState<string>('Todas');
  const [fcArea, setFcArea] = useState<string>('Todas');
  const [fcFilter, setFcFilter] = useState<'todos' | 'favoritos' | 'pendentes' | 'dificeis'>('todos');
  const [fcSearch, setFcSearch] = useState<string>('');
  const [currentCardIdx, setCurrentCardIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);

  // User notes and active legislation reading
  const [selectedArticle, setSelectedArticle] = useState(TOP_OAB_ARTICLES[0]);
  const [articleNotes, setArticleNotes] = useState(progress.notes[TOP_OAB_ARTICLES[0].id] || '');
  const [readArticles, setReadArticles] = useState<string[]>(() => {
    const saved = localStorage.getItem('oab3f_read_articles');
    return saved ? JSON.parse(saved) : [];
  });

  // Personal Error Log (Caderno de erros pessoal)
  const [userErrors, setUserErrors] = useState<{ id: string; discipline: string; theme: string; errorType: string; explanation: string; date: string }[]>(() => {
    const saved = localStorage.getItem('oab3f_user_errors');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return [
      {
        id: "err-init-1",
        discipline: "Direito Civil",
        theme: "Contratos",
        errorType: "Esquecimento de Artigo",
        explanation: "Confundi o prazo de vício redibitório de bem móvel (30 dias) com bem imóvel (1 ano) nos termos do art. 445 do CC.",
        date: "2026-06-24"
      },
      {
        id: "err-init-2",
        discipline: "Processo Penal",
        theme: "Recursos",
        errorType: "Falha de Prazo",
        explanation: "Esqueci que o prazo para interpor apelação criminal é de 5 dias, mas as razões recursais podem ser oferecidas em 8 dias (Art. 600, CPP).",
        date: "2026-06-23"
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('oab3f_user_errors', JSON.stringify(userErrors));
  }, [userErrors]);

  const [newErrorDiscipline, setNewErrorDiscipline] = useState('Direito Civil');
  const [newErrorTheme, setNewErrorTheme] = useState('');
  const [newErrorType, setNewErrorType] = useState('Interpretação');
  const [newErrorExpl, setNewErrorExpl] = useState('');
  const [showAddErrorForm, setShowAddErrorForm] = useState(false);

  // Phase 1 Questões Erradas States
  const [selectedWrongQuestDiscipline, setSelectedWrongQuestDiscipline] = useState('Todas');
  const [redoingQuestionId, setRedoingQuestionId] = useState<string | null>(null);
  const [selectedRedoOption, setSelectedRedoOption] = useState<number | null>(null);
  const [redoResult, setRedoResult] = useState<'correto' | 'incorreto' | null>(null);

  // Active P2 Discursiva Draft state
  const [activeP2DiscursiveId, setActiveP2DiscursiveId] = useState<string | null>(null);
  const [discursiveAnswers, setDiscursiveAnswers] = useState<{ [key: string]: string }>(() => {
    const saved = localStorage.getItem('oab3f_p2_discursive_answers');
    return saved ? JSON.parse(saved) : {};
  });
  const [showEspelhoId, setShowEspelhoId] = useState<string | null>(null);
  const [p2DiscursivasRevisadas, setP2DiscursivasRevisadas] = useState<string[]>(() => {
    const saved = localStorage.getItem('oab3f_p2_discursivas_revisadas');
    return saved ? JSON.parse(saved) : [];
  });

  // Active Phase 2 Piece state
  const [viewingPiece, setViewingPiece] = useState<Phase2Piece | null>(null);
  const [pieceMastery, setPieceMastery] = useState<{ [key: string]: boolean }>({});

  // Trigger select phase 2 area if clicked
  const handleSelectP2AreaInRevision = (area: string) => {
    progress.selectedSecondPhaseArea = area;
    localStorage.setItem('oab3f_progress', JSON.stringify(progress));
    onSaveActivity('Revisão', `Selecionou área jurídica para 2ª Fase: ${area}`);
  };

  // Scheduled revision action handlers
  const [selectedReviewSession, setSelectedReviewSession] = useState<typeof scheduledRevisions[0] | null>(null);

  const handleMarkReviewCompleted = (id: string) => {
    setScheduledRevisions(prev => prev.map(rev => {
      if (rev.id === id) {
        return { ...rev, status: 'Concluída' };
      }
      return rev;
    }));
    setSelectedReviewSession(null);
    onSaveActivity('Revisão', `Concluiu revisão programada ID: ${id}`);
  };

  // Flashcards SRS grading
  const handleSRSVote = (cardId: string, level: 'errei' | 'regular' | 'acertei') => {
    let increment = 0;
    if (level === 'errei') increment = -1;
    if (level === 'acertei') increment = 1;
    
    onUpdateFlashcardBox(cardId, increment);
    setFlipped(false);
    
    // Move to next card
    if (currentCardIdx < filteredFlashcards.length - 1) {
      setCurrentCardIdx(currentCardIdx + 1);
    } else {
      setCurrentCardIdx(0);
    }
    onSaveActivity('Revisão', `Classificou memorização SRS como: ${level}`);
  };

  // Legislation handlers
  const handleSelectArticle = (art: typeof TOP_OAB_ARTICLES[0]) => {
    setSelectedArticle(art);
    setArticleNotes(progress.notes[art.id] || '');
  };

  const handleSaveArticleNote = () => {
    onSavePieceNote(selectedArticle.id, articleNotes);
    onSaveActivity('Revisão', `Salvou anotações no artigo ${selectedArticle.article}`);
  };

  const handleToggleArticleRead = (id: string) => {
    let next: string[];
    if (readArticles.includes(id)) {
      next = readArticles.filter(a => a !== id);
    } else {
      next = [...readArticles, id];
    }
    setReadArticles(next);
    localStorage.setItem('oab3f_read_articles', JSON.stringify(next));
    onSaveActivity('Revisão', `Marcou artigo ${id} como lido/revisado`);
  };

  // Add personal error
  const handleAddPersonalError = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newErrorTheme.trim() || !newErrorExpl.trim()) return;

    const newErr = {
      id: "err-user-" + Date.now(),
      discipline: newErrorDiscipline,
      theme: newErrorTheme,
      errorType: newErrorType,
      explanation: newErrorExpl,
      date: new Date().toISOString().split('T')[0]
    };

    setUserErrors([newErr, ...userErrors]);
    setNewErrorTheme('');
    setNewErrorExpl('');
    setShowAddErrorForm(false);
    onSaveActivity('Revisão', `Adicionou erro pessoal ao caderno: ${newErr.theme}`);
  };

  const handleDeletePersonalError = (id: string) => {
    setUserErrors(prev => prev.filter(e => e.id !== id));
    onSaveActivity('Revisão', `Deletou erro do caderno pessoal`);
  };

  // Phase 1 incorrect questions filtering
  const incorrectQuestions = questions.filter(q => {
    const ans = progress.answeredQuestions[q.id];
    return ans && !ans.isCorrect;
  });

  const filteredIncorrectQuestions = incorrectQuestions.filter(q => {
    if (selectedWrongQuestDiscipline === 'Todas') return true;
    return q.discipline === selectedWrongQuestDiscipline;
  });

  const handleRedoQuestionSubmit = (q: Question) => {
    if (selectedRedoOption === null) return;
    const isCorrect = selectedRedoOption === q.correctIndex;
    
    if (isCorrect) {
      setRedoResult('correto');
      // If student gets it correct now, let's update progress so it is marked correct!
      progress.answeredQuestions[q.id] = {
        selectedOption: selectedRedoOption,
        isCorrect: true,
        timestamp: new Date().toISOString()
      };
      localStorage.setItem('oab3f_progress', JSON.stringify(progress));
    } else {
      setRedoResult('incorreto');
    }
    onSaveActivity('Revisão', `Refez questão errada. Resultado: ${isCorrect ? 'Correto' : 'Incorreto'}`);
  };

  const handleMarkQuestionAsRevised = (qId: string) => {
    // Simply mark it as correct or remove from wrong database by flagging correct: true
    progress.answeredQuestions[qId] = {
      selectedOption: 0,
      isCorrect: true,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('oab3f_progress', JSON.stringify(progress));
    onSaveActivity('Revisão', `Marcou questão como revisada e sanada`);
  };

  // Flashcards Filtering
  const filteredFlashcards = flashcards.filter(fc => {
    if (fcDiscipline !== 'Todas' && fc.discipline !== fcDiscipline) return false;
    if (fcArea !== 'Todas' && fc.discipline !== fcArea) return false; // assuming matches area name
    
    // Search
    if (fcSearch.trim() !== '') {
      const s = fcSearch.toLowerCase();
      const matches = fc.front.toLowerCase().includes(s) || fc.back.toLowerCase().includes(s) || (fc.theme && fc.theme.toLowerCase().includes(s));
      if (!matches) return false;
    }

    // Sub-filters
    if (fcFilter === 'favoritos') {
      return progress.completedFlashcards.includes(fc.id); // representing favorites as completed or boxes
    }
    if (fcFilter === 'pendentes') {
      const box = progress.flashcardBoxes[fc.id] || 1;
      return box < 4;
    }
    if (fcFilter === 'dificeis') {
      const box = progress.flashcardBoxes[fc.id] || 1;
      return box === 1;
    }

    return true;
  });

  // Safe Index Reset for Flashcards
  useEffect(() => {
    setCurrentCardIdx(0);
    setFlipped(false);
  }, [fcDiscipline, fcArea, fcFilter, fcSearch]);

  // Recalculate dynamic statistics
  const pendingCount = scheduledRevisions.filter(r => r.status === 'Pendente').length;
  const delayedCount = scheduledRevisions.filter(r => r.status === 'Atrasada').length;
  const completedCount = scheduledRevisions.filter(r => r.status === 'Concluída').length;
  const flashcardsReviewedCount = Object.keys(progress.flashcardBoxes).length;

  // Recovery Track States
  const [activeRecoveryTrack, setActiveRecoveryTrack] = useState<string | null>(null);
  const [recoveryProgress, setRecoveryProgress] = useState<{ [key: string]: boolean }>({});

  const RECOVERY_TRACKS = [
    {
      id: "track-penal",
      discipline: "Processo Penal",
      performance: "45%",
      severity: "critical",
      title: "Recuperação Crítica - Nulidades e Recursos",
      suggestedActions: [
        { id: "act-1", text: "Estudar Súmula Vinculante 14 do STF (Acesso a Inquérito)", type: "Lei Seca" },
        { id: "act-2", text: "Revisar Rol de Nulidades do Art. 564 do CPP", type: "Teoria" },
        { id: "act-3", text: "Responder 5 Flashcards de Recursos Penais", type: "Flashcard" },
        { id: "act-4", text: "Refazer 2 Questões Objetivas sobre Apelação Criminal", type: "Prática" }
      ]
    },
    {
      id: "track-tributario",
      discipline: "Direito Tributário",
      performance: "58%",
      severity: "warning",
      title: "Reforço de Desempenho - Crédito e Limitações",
      suggestedActions: [
        { id: "act-5", text: "Revisar as Limitações do Art. 150 da CF/88", type: "Lei Seca" },
        { id: "act-6", text: "Memorizar as hipóteses de Suspensão de Crédito (Art. 151 CTN)", type: "Mnemônicos" },
        { id: "act-7", text: "Fazer simulação de discursiva de Mandado de Segurança", type: "2ª Fase" }
      ]
    },
    {
      id: "track-trabalho-p2",
      discipline: "Trabalho 2ª Fase",
      performance: "62%",
      severity: "warning",
      title: "Trilha Prática - Estrutura do Recurso Ordinário",
      suggestedActions: [
        { id: "act-8", text: "Assinar o Checklist de Pedidos do RO", type: "Checklist" },
        { id: "act-9", text: "Estudar o cabimento das custas e depósito recursal", type: "Regras" },
        { id: "act-10", text: "Revisar Súmula 212 do TST sobre Ônus da Prova", type: "Jurisprudência" }
      ]
    }
  ];

  const handleToggleRecoveryAction = (trackId: string, actId: string) => {
    const key = `${trackId}-${actId}`;
    const next = { ...recoveryProgress, [key]: !recoveryProgress[key] };
    setRecoveryProgress(next);

    // Check if track is completed
    const track = RECOVERY_TRACKS.find(t => t.id === trackId);
    if (track) {
      const allDone = track.suggestedActions.every(act => next[`${trackId}-${act.id}`]);
      if (allDone) {
        onSaveActivity('Revisão', `Concluiu trilha de recuperação para: ${track.discipline}`);
      }
    }
  };

  // Phase 2 Selected Area Data
  const selectedArea = progress.selectedSecondPhaseArea || "Direito Penal";
  const p2Pieces = PHASE2_PIECES_BY_AREA[selectedArea] || [];
  const p2Discursivas = PHASE2_DISCURSIVES_BY_AREA[selectedArea] || [];

  const handleSaveDiscursiveDraft = (id: string, text: string) => {
    const next = { ...discursiveAnswers, [id]: text };
    setDiscursiveAnswers(next);
    localStorage.setItem('oab3f_p2_discursive_answers', JSON.stringify(next));
  };

  const handleToggleP2DiscursiveRevised = (id: string) => {
    let next: string[];
    if (p2DiscursivasRevisadas.includes(id)) {
      next = p2DiscursivasRevisadas.filter(x => x !== id);
    } else {
      next = [...p2DiscursivasRevisadas, id];
    }
    setP2DiscursivasRevisadas(next);
    localStorage.setItem('oab3f_p2_discursivas_revisadas', JSON.stringify(next));
    onSaveActivity('Revisão', `Revisou questão discursiva da 2ª Fase: ${id}`);
  };

  return (
    <div id="smart-revision-root" className="space-y-6">
      
      {/* Editorial Header */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <span className="text-xs uppercase font-black tracking-widest text-oab-accent flex items-center gap-1.5">
            <Sparkles className="h-4 w-4" /> RECURSO DE ALTO RENDIMENTO
          </span>
          <h2 className="text-2xl font-extrabold font-display text-oab-primary">
            Revisão Inteligente
          </h2>
          <p className="text-xs text-slate-500 max-w-xl">
            Retenção de conteúdo sistemática baseada em repetição espaçada, correção cirúrgica do caderno de erros e simulação ativa da 2ª fase jurídica escolhida.
          </p>
        </div>
        <div className="flex items-center gap-4 bg-slate-50 border border-slate-200 px-4 py-3 rounded-xl">
          <div className="flex items-center gap-1.5 text-amber-650">
            <Flame className="h-5 w-5 text-amber-500 fill-amber-500" />
            <div className="text-left">
              <div className="text-xs font-black text-slate-400 uppercase leading-none">Racha Constância</div>
              <div className="text-sm font-extrabold text-slate-800">4 dias seguidos</div>
            </div>
          </div>
          <div className="h-6 w-px bg-slate-200"></div>
          <div className="text-left">
            <div className="text-xs font-black text-slate-400 uppercase leading-none">Meta Diária</div>
            <div className="text-xs font-bold text-emerald-600 mt-1">Concluída (100%)</div>
          </div>
        </div>
      </div>

      {/* 9 Section Subtabs Submenu Bar */}
      <div className="overflow-x-auto pb-1" id="revisao-navigation-panel">
        <div className="flex border-b border-slate-200 whitespace-nowrap min-w-max gap-1">
          {[
            { id: 'inicio', label: '📊 Resumo Geral' },
            { id: 'programadas', label: `📅 Revisões Programadas (${pendingCount + delayedCount})` },
            { id: 'flashcards', label: '🎴 Flashcards (SRS)' },
            { id: 'caderno_erros', label: `📕 Caderno de Erros (${incorrectQuestions.length + userErrors.length})` },
            { id: 'questoes_erradas', label: '❓ Questões Erradas' },
            { id: 'lei_seca', label: '⚖️ Lei Seca' },
            { id: 'fase2', label: `🎓 Revisão 2ª Fase (${selectedArea})` },
            { id: 'recuperacao', label: '⚡ Trilhas de Recuperação' },
            { id: 'historico', label: '📈 Histórico & Constância' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveSubtab(tab.id as any);
                onSaveActivity('Revisão', `Navegou para submenu: ${tab.label}`);
              }}
              className={`
                py-3 px-4 text-xs font-bold transition-all border-b-2 cursor-pointer
                ${activeSubtab === tab.id 
                  ? 'border-oab-accent text-oab-primary font-extrabold bg-white/40' 
                  : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-100/50'}
              `}
              id={`tab-rev-${tab.id}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* RENDER ACTIVE TAB WITH ANIMATEPRESENCE */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeSubtab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.15 }}
          className="space-y-6"
        >
          
          {/* =========================================
              SEÇÃO 1 - TELA INICIAL DA REVISÃO
              ========================================= */}
          {activeSubtab === 'inicio' && (
            <div className="space-y-6" id="secao-revisao-inicio">
              
              {/* Main CTA Block */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-8 bg-gradient-to-br from-oab-primary to-slate-800 text-white rounded-xl p-6 border border-slate-700 shadow flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <span className="bg-amber-500/10 border border-amber-500/20 text-amber-400 px-2.5 py-0.5 rounded text-[10px] uppercase font-black tracking-wider">
                      RECOMENDADO PARA HOJE
                    </span>
                    <h3 className="text-lg md:text-xl font-bold font-display text-white">
                      Seu ciclo de estudos está agendado e pronto!
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed max-w-lg">
                      O sistema OAB 3F organizou <strong>{pendingCount} revisões pendentes</strong> e identificou <strong>{delayedCount} tarefas atrasadas</strong> na fila de retenção. Iniciar a sessão agora evita que a curva de esquecimento debilite seu progresso.
                    </p>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <button
                      onClick={() => setActiveSubtab('programadas')}
                      className="bg-oab-accent hover:bg-amber-500 text-slate-900 font-bold text-xs px-5 py-3 rounded-lg flex items-center justify-center gap-1.5 shadow transition-colors cursor-pointer"
                      id="btn-rev-start-now"
                    >
                      <RotateCcw className="h-4 w-4" /> Revisar Agora ({pendingCount + delayedCount} itens)
                    </button>
                    <button
                      onClick={() => setActiveSubtab('flashcards')}
                      className="bg-white/10 hover:bg-white/15 border border-white/10 text-white font-bold text-xs px-5 py-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Sparkles className="h-4 w-4 text-oab-accent" /> Praticar Flashcards ({flashcards.length})
                    </button>
                  </div>
                </div>

                {/* Dashboard Side Info */}
                <div className="lg:col-span-4 bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                    <Activity className="h-4 w-4 text-oab-accent" /> Desempenho Médio da 2ª Fase
                  </h4>
                  <div className="space-y-3">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Área Selecionada:</span>
                      <span className="font-extrabold text-oab-primary">{selectedArea}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Média em Simulados:</span>
                      <span className="font-bold text-emerald-600">7.2 / 10.0 (Aprovado)</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Peças Estudadas:</span>
                      <span className="font-bold text-slate-700">{p2Pieces.length} peças</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Discursivas Respondidas:</span>
                      <span className="font-bold text-slate-700">{Object.keys(discursiveAnswers).length} resolvidas</span>
                    </div>
                  </div>
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[10px] text-slate-400">Trilha 2ª fase concluída:</span>
                    <span className="text-xs font-black text-oab-accent">35%</span>
                  </div>
                </div>
              </div>

              {/* Grid de Métricas Rápidas */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {[
                  { label: "Pendentes Hoje", val: pendingCount, color: "text-oab-accent", bg: "bg-amber-50" },
                  { label: "Atrasadas", val: delayedCount, color: "text-rose-600 font-black", bg: "bg-rose-50/50" },
                  { label: "Concluídas (Semana)", val: completedCount + 12, color: "text-emerald-600", bg: "bg-emerald-50/30" },
                  { label: "Flashcards SRS", val: flashcardsReviewedCount, color: "text-indigo-600", bg: "bg-indigo-50/30" },
                  { label: "Erros Pendentes", val: incorrectQuestions.length + userErrors.length, color: "text-red-500", bg: "bg-red-50/30" },
                  { label: "Peças a Revisitar", val: 2, color: "text-slate-700", bg: "bg-slate-100/50" }
                ].map((st, i) => (
                  <div key={i} className={`p-4 rounded-xl border border-slate-200 shadow-xs text-center ${st.bg}`}>
                    <div className="text-xl font-extrabold font-mono tracking-tight leading-none mb-1 text-slate-800">{st.val}</div>
                    <div className="text-[10px] uppercase font-black text-slate-400 tracking-wider leading-tight">{st.label}</div>
                  </div>
                ))}
              </div>

              {/* Direct Links cards matching Section 1 prompt requirements */}
              <div className="space-y-2">
                <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Acesso Direto aos Módulos</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
                  {[
                    { id: 'programadas', title: 'Revisão 24h', desc: 'Recentes na fila', icon: RotateCcw, bg: 'bg-white hover:border-amber-300' },
                    { id: 'programadas', title: 'Revisão 7 dias', desc: 'Retenção média', icon: Calendar, bg: 'bg-white hover:border-amber-300' },
                    { id: 'programadas', title: 'Revisão 30 dias', desc: 'Saturação final', icon: Target, bg: 'bg-white hover:border-amber-300' },
                    { id: 'caderno_erros', title: 'Caderno de Erros', desc: 'Sanar falhas', icon: Book, bg: 'bg-rose-50/10 border-rose-100 hover:border-rose-300' },
                    { id: 'flashcards', title: 'Flashcards', desc: 'Memorização', icon: Sparkles, bg: 'bg-indigo-50/10 border-indigo-100 hover:border-indigo-300' },
                    { id: 'lei_seca', title: 'Lei Seca', desc: 'Artigos cobrados', icon: FileText, bg: 'bg-white hover:border-amber-300' },
                    { id: 'fase2', title: 'Prova 2ª Fase', desc: 'Peças e discursivas', icon: FileCode, bg: 'bg-amber-50/10 border-amber-100 hover:border-amber-400' }
                  ].map((card, i) => {
                    const Icon = card.icon;
                    return (
                      <div
                        key={i}
                        onClick={() => {
                          setActiveSubtab(card.id as any);
                          onSaveActivity('Revisão', `Navegou para módulo rápido: ${card.title}`);
                        }}
                        className={`p-4.5 rounded-xl border border-slate-200 transition-all cursor-pointer group shadow-2xs flex flex-col justify-between min-h-[120px] ${card.bg}`}
                      >
                        <div className="p-2 w-fit rounded-lg bg-slate-50 group-hover:bg-amber-50 group-hover:text-oab-accent transition-colors">
                          <Icon className="h-4 w-4 text-slate-500" />
                        </div>
                        <div className="space-y-0.5 mt-2">
                          <h5 className="text-xs font-extrabold text-slate-800">{card.title}</h5>
                          <p className="text-[9.5px] text-slate-400">{card.desc}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          )}

          {/* =========================================
              SEÇÃO 2 - REVISÕES PROGRAMADAS (SISTEMA DE TEMPO)
              ========================================= */}
          {activeSubtab === 'programadas' && (
            <div className="space-y-6" id="secao-revisoes-programadas">
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <h3 className="text-base font-extrabold text-slate-850">Cronograma de Revisões Ativas</h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Itens gerados automaticamente após seu estudo inicial, respeitando a curva de esquecimento de Ebbinghaus (24h, 7 dias e 30 dias).
                    </p>
                  </div>
                  
                  {/* Legend filter */}
                  <div className="flex flex-wrap gap-2 text-xs">
                    <span className="px-2.5 py-1 bg-rose-100 text-rose-700 font-extrabold rounded">Atrasadas: {delayedCount}</span>
                    <span className="px-2.5 py-1 bg-amber-100 text-amber-750 font-extrabold rounded">Pendentes: {pendingCount}</span>
                    <span className="px-2.5 py-1 bg-emerald-100 text-emerald-700 font-extrabold rounded">Concluídas: {completedCount}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                  
                  {/* Bloco A: 24h */}
                  <div className="space-y-4">
                    <div className="border-b border-slate-100 pb-2 flex items-center justify-between">
                      <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                        <Flame className="h-3.5 w-3.5 text-rose-500" /> Bloco A — Revisão 24h
                      </h4>
                      <span className="text-[10px] bg-slate-50 px-2 py-0.5 rounded font-bold text-slate-500">
                        Pós-Estudo Imediato
                      </span>
                    </div>
                    <div className="space-y-3">
                      {scheduledRevisions.filter(r => r.timeline === '24h').map(rev => (
                        <div 
                          key={rev.id} 
                          className={`p-3.5 rounded-lg border text-xs transition-all flex flex-col justify-between space-y-2.5 min-h-[130px]
                            ${rev.status === 'Atrasada' ? 'bg-rose-50/10 border-rose-100' : rev.status === 'Concluída' ? 'bg-emerald-50/5 border-emerald-100' : 'bg-white border-slate-200'}
                          `}
                        >
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[9px] uppercase font-black tracking-wider text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">
                                {rev.discipline}
                              </span>
                              <span className={`text-[9px] font-black uppercase tracking-widest ${rev.status === 'Atrasada' ? 'text-rose-600 animate-pulse' : rev.status === 'Concluída' ? 'text-emerald-600' : 'text-slate-400'}`}>
                                {rev.status}
                              </span>
                            </div>
                            <h5 className="font-extrabold text-slate-800 leading-snug">{rev.theme}</h5>
                            <p className="text-[10px] text-slate-400">Tipo: {rev.type} • Agendado: {rev.date}</p>
                          </div>
                          
                          {rev.status !== 'Concluída' ? (
                            <button
                              onClick={() => setSelectedReviewSession(rev)}
                              className="w-full text-center py-1.5 text-[10px] font-extrabold uppercase tracking-wider bg-slate-100 hover:bg-oab-accent hover:text-slate-900 text-slate-600 rounded transition-colors cursor-pointer"
                            >
                              Revisar Conteúdo
                            </button>
                          ) : (
                            <div className="flex items-center gap-1 text-[10px] text-emerald-600 font-extrabold uppercase">
                              <Check className="h-3.5 w-3.5" /> Revisado
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Bloco B: 7 dias */}
                  <div className="space-y-4">
                    <div className="border-b border-slate-100 pb-2 flex items-center justify-between">
                      <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5 text-oab-accent" /> Bloco B — Revisão 7 dias
                      </h4>
                      <span className="text-[10px] bg-slate-50 px-2 py-0.5 rounded font-bold text-slate-500">
                        Consolidação de Memória
                      </span>
                    </div>
                    <div className="space-y-3">
                      {scheduledRevisions.filter(r => r.timeline === '7d').map(rev => (
                        <div 
                          key={rev.id} 
                          className={`p-3.5 rounded-lg border text-xs transition-all flex flex-col justify-between space-y-2.5 min-h-[130px]
                            ${rev.status === 'Atrasada' ? 'bg-rose-50/10 border-rose-100' : rev.status === 'Concluída' ? 'bg-emerald-50/5 border-emerald-100' : 'bg-white border-slate-200'}
                          `}
                        >
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[9px] uppercase font-black tracking-wider text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">
                                {rev.discipline}
                              </span>
                              <span className={`text-[9px] font-black uppercase tracking-widest ${rev.status === 'Atrasada' ? 'text-rose-600' : rev.status === 'Concluída' ? 'text-emerald-600' : 'text-slate-400'}`}>
                                {rev.status}
                              </span>
                            </div>
                            <h5 className="font-extrabold text-slate-800 leading-snug">{rev.theme}</h5>
                            <p className="text-[10px] text-slate-400">Tipo: {rev.type} • Agendado: {rev.date}</p>
                          </div>
                          
                          {rev.status !== 'Concluída' ? (
                            <button
                              onClick={() => setSelectedReviewSession(rev)}
                              className="w-full text-center py-1.5 text-[10px] font-extrabold uppercase tracking-wider bg-slate-100 hover:bg-oab-accent hover:text-slate-900 text-slate-600 rounded transition-colors cursor-pointer"
                            >
                              Revisar Conteúdo
                            </button>
                          ) : (
                            <div className="flex items-center gap-1 text-[10px] text-emerald-600 font-extrabold uppercase">
                              <Check className="h-3.5 w-3.5" /> Revisado
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Bloco C: 30 dias */}
                  <div className="space-y-4">
                    <div className="border-b border-slate-100 pb-2 flex items-center justify-between">
                      <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                        <Target className="h-3.5 w-3.5 text-indigo-500" /> Bloco C — Revisão 30 dias
                      </h4>
                      <span className="text-[10px] bg-slate-50 px-2 py-0.5 rounded font-bold text-slate-500">
                        Manutenção Reta Final
                      </span>
                    </div>
                    <div className="space-y-3">
                      {scheduledRevisions.filter(r => r.timeline === '30d').map(rev => (
                        <div 
                          key={rev.id} 
                          className={`p-3.5 rounded-lg border text-xs transition-all flex flex-col justify-between space-y-2.5 min-h-[130px]
                            ${rev.status === 'Atrasada' ? 'bg-rose-50/10 border-rose-100' : rev.status === 'Concluída' ? 'bg-emerald-50/5 border-emerald-100' : 'bg-white border-slate-200'}
                          `}
                        >
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[9px] uppercase font-black tracking-wider text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">
                                {rev.discipline}
                              </span>
                              <span className={`text-[9px] font-black uppercase tracking-widest ${rev.status === 'Atrasada' ? 'text-rose-600' : rev.status === 'Concluída' ? 'text-emerald-600' : 'text-slate-400'}`}>
                                {rev.status}
                              </span>
                            </div>
                            <h5 className="font-extrabold text-slate-800 leading-snug">{rev.theme}</h5>
                            <p className="text-[10px] text-slate-400">Tipo: {rev.type} • Agendado: {rev.date}</p>
                          </div>
                          
                          {rev.status !== 'Concluída' ? (
                            <button
                              onClick={() => setSelectedReviewSession(rev)}
                              className="w-full text-center py-1.5 text-[10px] font-extrabold uppercase tracking-wider bg-slate-100 hover:bg-oab-accent hover:text-slate-900 text-slate-600 rounded transition-colors cursor-pointer"
                            >
                              Revisar Conteúdo
                            </button>
                          ) : (
                            <div className="flex items-center gap-1 text-[10px] text-emerald-600 font-extrabold uppercase">
                              <Check className="h-3.5 w-3.5" /> Revisado
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              </div>
            </div>
          )}

          {/* =========================================
              SEÇÃO 3 - FLASHCARDS (MEMORIZAÇÃO SRS)
              ========================================= */}
          {activeSubtab === 'flashcards' && (
            <div className="space-y-6" id="secao-flashcards-srs">
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-150 pb-4">
                  <div>
                    <h3 className="text-base font-extrabold text-slate-800">Módulo de Memorização Espaçada (Flashcards SRS)</h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Filtre cartões de lei, peças e teses jurídicas para autoavaliação com repetição programada.
                    </p>
                  </div>
                  
                  {/* Select filters */}
                  <div className="flex flex-wrap gap-2">
                    <select 
                      value={fcDiscipline}
                      onChange={(e) => setFcDiscipline(e.target.value)}
                      className="text-xs border border-slate-200 rounded-lg p-2 bg-slate-50 focus:outline-none"
                    >
                      <option value="Todas">Disciplinas (1ª Fase)</option>
                      <option value="Ética Profissional">Ética Profissional</option>
                      <option value="Direito Constitucional">Direito Constitucional</option>
                      <option value="Direito Penal">Direito Penal</option>
                      <option value="Direito Civil">Direito Civil</option>
                      <option value="Direito do Trabalho">Direito do Trabalho</option>
                    </select>

                    <select
                      value={fcArea}
                      onChange={(e) => setFcArea(e.target.value)}
                      className="text-xs border border-slate-200 rounded-lg p-2 bg-slate-50 focus:outline-none"
                    >
                      <option value="Todas">Área da 2ª Fase</option>
                      {PHASE2_LEGAL_AREAS.map(ar => (
                        <option key={ar} value={ar}>{ar}</option>
                      ))}
                    </select>

                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Buscar termo..."
                        value={fcSearch}
                        onChange={(e) => setFcSearch(e.target.value)}
                        className="text-xs pl-8 pr-3 py-2 border border-slate-200 rounded-lg bg-slate-50 focus:outline-none max-w-[150px]"
                      />
                    </div>
                  </div>
                </div>

                {/* Tag Buttons for quick filters */}
                <div className="flex flex-wrap gap-2 text-xs">
                  <button 
                    onClick={() => setFcFilter('todos')} 
                    className={`px-3 py-1 rounded border cursor-pointer ${fcFilter === 'todos' ? 'bg-oab-primary text-white font-bold' : 'bg-slate-50 text-slate-600'}`}
                  >
                    Todos os Flashcards
                  </button>
                  <button 
                    onClick={() => setFcFilter('favoritos')} 
                    className={`px-3 py-1 rounded border cursor-pointer flex items-center gap-1 ${fcFilter === 'favoritos' ? 'bg-amber-100 text-amber-800 font-bold border-amber-300' : 'bg-slate-50 text-slate-600'}`}
                  >
                    <Star className="h-3 w-3 fill-amber-400 text-amber-400" /> Seus Favoritos
                  </button>
                  <button 
                    onClick={() => setFcFilter('pendentes')} 
                    className={`px-3 py-1 rounded border cursor-pointer ${fcFilter === 'pendentes' ? 'bg-slate-100 text-slate-700 font-bold' : 'bg-slate-50 text-slate-600'}`}
                  >
                    Pendentes de Caixa alta (Box &lt; 4)
                  </button>
                  <button 
                    onClick={() => setFcFilter('dificeis')} 
                    className={`px-3 py-1 rounded border cursor-pointer flex items-center gap-1 ${fcFilter === 'dificeis' ? 'bg-red-50 text-red-700 font-bold border-red-150' : 'bg-slate-50 text-slate-600'}`}
                  >
                    Mais Difíceis (Caixa 1)
                  </button>
                </div>

                {/* Flashcards Carousel */}
                {filteredFlashcards.length === 0 ? (
                  <div className="text-center py-12 text-slate-450 border border-dashed border-slate-200 rounded-xl">
                    <AlertCircle className="h-8 w-8 text-slate-350 mx-auto mb-2" />
                    <p className="text-xs font-bold">Nenhum flashcard localizado para os filtros atuais.</p>
                    <p className="text-[10px] text-slate-400 mt-1">Altere a disciplina ou remova a busca por termos para restabelecer os cartões.</p>
                  </div>
                ) : (
                  <div className="max-w-xl mx-auto space-y-4 py-4">
                    
                    <div className="flex justify-between items-center text-xs text-slate-450 font-medium">
                      <span>Cartão <strong>{currentCardIdx + 1}</strong> de <strong>{filteredFlashcards.length}</strong></span>
                      <span className="text-[10px] bg-indigo-50 border border-indigo-100 text-indigo-600 px-2.5 py-0.5 rounded font-black tracking-wider uppercase">
                        {filteredFlashcards[currentCardIdx].discipline}
                      </span>
                    </div>

                    {/* Dynamic Flipping box with motion */}
                    <motion.div
                      layout
                      onClick={() => setFlipped(!flipped)}
                      className={`min-h-[220px] rounded-xl p-6 border shadow-sm flex flex-col justify-between cursor-pointer transition-all duration-200 select-none text-center
                        ${flipped ? 'bg-oab-primary text-white border-oab-primary shadow-md' : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'}
                      `}
                      id="card-body-flip"
                    >
                      <div className="text-[9px] uppercase font-black tracking-wider text-oab-accent">
                        {flipped ? "Gabarito Legal / Resposta Verso" : "Pergunta de Memorização Frente"}
                      </div>

                      <div className="py-6 font-display text-sm md:text-base font-bold leading-relaxed px-4">
                        {flipped ? filteredFlashcards[currentCardIdx].back : filteredFlashcards[currentCardIdx].front}
                      </div>

                      <div className="text-[9.5px] text-slate-400 font-medium italic">
                        {flipped 
                          ? `Legislação: ${filteredFlashcards[currentCardIdx].lawArticle || 'Constituição/Códigos'}` 
                          : "Toque no cartão para revelar o verso"
                        }
                      </div>
                    </motion.div>

                    {/* Actions and SRS grading */}
                    <div className="space-y-4 pt-2">
                      {flipped ? (
                        <div className="grid grid-cols-3 gap-3 animate-fadeIn">
                          <button
                            onClick={() => handleSRSVote(filteredFlashcards[currentCardIdx].id, 'errei')}
                            className="bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 py-3 rounded-lg text-xs font-bold transition-all cursor-pointer"
                          >
                            Errei (Caixa 1)
                          </button>
                          <button
                            onClick={() => handleSRSVote(filteredFlashcards[currentCardIdx].id, 'regular')}
                            className="bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-750 py-3 rounded-lg text-xs font-bold transition-all cursor-pointer"
                          >
                            Médio (Fila)
                          </button>
                          <button
                            onClick={() => handleSRSVote(filteredFlashcards[currentCardIdx].id, 'acertei')}
                            className="bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-600 py-3 rounded-lg text-xs font-bold transition-all cursor-pointer"
                          >
                            Fácil (Concluído)
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setFlipped(true)}
                          className="w-full bg-oab-primary hover:bg-slate-850 text-white font-bold py-3 rounded-lg text-xs shadow transition-colors cursor-pointer"
                        >
                          Revelar Resposta
                        </button>
                      )}

                      <div className="p-3 bg-slate-50 border border-slate-150 rounded-lg text-[10px] text-slate-500 text-center leading-relaxed">
                        <strong>Sistema SRS (SuperMemo):</strong> Cartões classificados como &ldquo;Fácil&rdquo; são agendados em caixas distantes. Cartões que você erra retornam à Caixa 1 para revisão prioritária imediata.
                      </div>
                    </div>

                  </div>
                )}
              </div>
            </div>
          )}

          {/* =========================================
              SEÇÃO 4 - CADERNO DE ERROS (AUTOMÁTICO E MANUAL)
              ========================================= */}
          {activeSubtab === 'caderno_erros' && (
            <div className="space-y-6" id="secao-caderno-erros">
              
              {/* Warnings and stats box */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Left Side: stats analysis */}
                <div className="lg:col-span-4 bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                    <AlertTriangle className="h-4 w-4 text-rose-500" /> Diagnóstico de Pontos Críticos
                  </h4>
                  
                  <div className="space-y-3">
                    <div className="p-3 bg-red-50/40 border border-red-100 rounded text-xs">
                      <span className="font-extrabold text-red-600 block">Matérias com mais erros na 1ª Fase:</span>
                      <p className="text-slate-500 text-[10.5px] mt-0.5">
                        • <strong>Direito Civil</strong>: 1 erro detectado<br />
                        • <strong>Processo Penal</strong>: 1 erro detectado
                      </p>
                    </div>

                    <div className="p-3 bg-amber-50/40 border border-amber-100 rounded text-xs">
                      <span className="font-extrabold text-amber-700 block">Temas que precisam de recuperação:</span>
                      <p className="text-slate-500 text-[10.5px] mt-0.5">
                        • Teoria dos Bens Recorrentes<br />
                        • Fundamentos Processuais de Nulidades (CPP)
                      </p>
                    </div>

                    <div className="p-3 bg-slate-50 border border-slate-150 rounded text-xs">
                      <span className="font-extrabold text-slate-800 block">Erros Críticos da 2ª Fase ({selectedArea}):</span>
                      <p className="text-slate-500 text-[10.5px] mt-0.5">
                        • Omissão de fundamentação legal exata em teses subsidiárias.<br />
                        • Erros na liquidação de pedidos (CLT) ou formalidades recursais (CPC/CPP).
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setShowAddErrorForm(true)}
                    className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs py-2.5 rounded transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    Adicionar Registro Manual
                  </button>
                </div>

                {/* Right Side: Incorrect notebook list */}
                <div className="lg:col-span-8 space-y-6">
                  
                  {/* Form to add custom error log */}
                  {showAddErrorForm && (
                    <form onSubmit={handleAddPersonalError} className="bg-amber-50/15 border border-amber-200 rounded-xl p-5 shadow-sm space-y-3 animate-fadeIn">
                      <div className="flex justify-between items-center border-b border-amber-150 pb-2">
                        <span className="text-xs font-extrabold text-amber-800 flex items-center gap-1">
                          <Book className="h-4 w-4" /> Registrar Erro Manual de Simulado/Caderno
                        </span>
                        <button type="button" onClick={() => setShowAddErrorForm(false)} className="text-slate-400 hover:text-slate-600 text-xs">Cancelar</button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                        <div>
                          <label className="block text-slate-500 mb-1 font-bold">Disciplina:</label>
                          <select 
                            value={newErrorDiscipline} 
                            onChange={(e) => setNewErrorDiscipline(e.target.value)}
                            className="w-full border border-slate-200 bg-white p-2 rounded"
                          >
                            <option value="Direito Civil">Direito Civil</option>
                            <option value="Processo Civil">Processo Civil</option>
                            <option value="Direito Penal">Direito Penal</option>
                            <option value="Processo Penal">Processo Penal</option>
                            <option value="Direito do Trabalho">Direito do Trabalho</option>
                            <option value="Ética Profissional">Ética Profissional</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-slate-500 mb-1 font-bold">Tema específico:</label>
                          <input 
                            type="text" 
                            required
                            placeholder="Ex: Dosimetria, Prescrição" 
                            value={newErrorTheme} 
                            onChange={(e) => setNewErrorTheme(e.target.value)}
                            className="w-full border border-slate-200 bg-white p-2 rounded focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-500 mb-1 font-bold">Natureza da falha:</label>
                          <select 
                            value={newErrorType} 
                            onChange={(e) => setNewErrorType(e.target.value)}
                            className="w-full border border-slate-200 bg-white p-2 rounded"
                          >
                            <option value="Interpretação">Interpretação do Problema</option>
                            <option value="Esquecimento de Artigo">Esquecimento de Artigo</option>
                            <option value="Falha de Prazo">Falha de Prazo</option>
                            <option value="Pegadinha da Banca">Pegadinha da Banca</option>
                          </select>
                        </div>
                      </div>

                      <div className="text-xs">
                        <label className="block text-slate-500 mb-1 font-bold">Explicação detalhada / Correção do erro:</label>
                        <textarea 
                          required
                          placeholder="Descreva o que errou, por que errou e qual a resposta correta embasada em lei..." 
                          value={newErrorExpl} 
                          onChange={(e) => setNewErrorExpl(e.target.value)}
                          className="w-full border border-slate-200 bg-white p-2.5 rounded focus:outline-none"
                          rows={3}
                        />
                      </div>

                      <button type="submit" className="bg-oab-primary hover:bg-slate-850 text-white font-bold text-xs px-4 py-2 rounded shadow transition-colors cursor-pointer">
                        Salvar no Caderno de Erros
                      </button>
                    </form>
                  )}

                  <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                    <h3 className="text-base font-extrabold text-slate-800">Caderno do Aluno: Erros Registrados</h3>
                    
                    <div className="space-y-4">
                      {userErrors.map(err => (
                        <div key={err.id} className="p-4 rounded-lg border border-slate-150 space-y-2.5">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="text-[9px] uppercase font-black bg-rose-50 border border-rose-100 text-rose-600 px-2 py-0.5 rounded">
                                {err.discipline}
                              </span>
                              <span className="text-[10px] text-slate-400">{err.date}</span>
                            </div>
                            <button 
                              onClick={() => handleDeletePersonalError(err.id)}
                              className="text-slate-300 hover:text-rose-600 transition-colors p-1"
                              title="Remover erro"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                          <div className="text-xs">
                            <span className="font-extrabold text-slate-800">Tema: {err.theme}</span>
                            <span className="mx-2 text-slate-300">|</span>
                            <span className="text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded text-[10px]">{err.errorType}</span>
                          </div>
                          <p className="text-xs text-slate-600 italic bg-slate-50/50 p-3 border border-slate-100 rounded leading-relaxed">
                            {err.explanation}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

              </div>
            </div>
          )}

          {/* =========================================
              SEÇÃO 5 - REVISÃO DE QUESTÕES ERRADAS (1ª FASE)
              ========================================= */}
          {activeSubtab === 'questoes_erradas' && (
            <div className="space-y-6" id="secao-questoes-erradas">
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <h3 className="text-base font-extrabold text-slate-800">Repetidor Dinâmico de Questões Incorretas</h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Para gabaritar a prova objetiva, refaça todas as questões erradas. Elas saem desta fila se você acertar na nova tentativa!
                    </p>
                  </div>

                  <select
                    value={selectedWrongQuestDiscipline}
                    onChange={(e) => setSelectedWrongQuestDiscipline(e.target.value)}
                    className="text-xs border border-slate-200 rounded-lg p-2 bg-slate-50 focus:outline-none"
                  >
                    <option value="Todas">Filtrar por Disciplina</option>
                    <option value="Direito Civil">Direito Civil</option>
                    <option value="Direito Penal">Direito Penal</option>
                    <option value="Estatuto da OAB">Estatuto da OAB</option>
                  </select>
                </div>

                {filteredIncorrectQuestions.length === 0 ? (
                  <div className="text-center py-12 text-slate-400">
                    <CheckCircle2 className="h-10 w-10 text-emerald-500 mx-auto mb-2" />
                    <p className="text-xs font-bold text-slate-700">Fila limpa! Você não possui nenhuma questão errada registrada.</p>
                    <p className="text-[10px] text-slate-400 mt-1">Ótimo trabalho. Continue respondendo questões no banco geral para exercitar.</p>
                  </div>
                ) : (
                  <div className="space-y-5">
                    {filteredIncorrectQuestions.map((q) => (
                      <div key={q.id} className="p-4 rounded-lg border border-red-100 bg-red-50/5 space-y-3">
                        <div className="flex items-center justify-between border-b border-red-100/30 pb-2">
                          <span className="text-[9.5px] uppercase font-black bg-rose-50 border border-rose-100 text-rose-600 px-2 py-0.5 rounded">
                            {q.discipline} • {q.theme}
                          </span>
                          <span className="text-xs font-mono text-slate-400">{q.exam}</span>
                        </div>

                        <p className="text-xs text-slate-800 font-semibold leading-relaxed">
                          {q.statement}
                        </p>

                        <div className="bg-white p-4 border border-slate-150 rounded text-xs text-slate-600 space-y-2">
                          <span className="font-extrabold text-slate-800 block">Exposição da Resolução Anterior:</span>
                          <p className="text-slate-500 italic">Sua resposta constou como incorreta. Veja o gabarito comentado abaixo:</p>
                          <p className="bg-slate-50 p-2 border-l-2 border-amber-400 leading-relaxed text-[11px] text-slate-700">
                            <strong>Gabarito Oficial:</strong> Opção {String.fromCharCode(65 + q.correctIndex)}) {q.options[q.correctIndex]}
                          </p>
                          <p className="text-[11.5px] mt-2 leading-relaxed text-slate-600">
                            <strong>Explicação Acadêmica:</strong> {q.explanation}
                          </p>
                        </div>

                        <div className="flex gap-3 pt-2">
                          <button
                            onClick={() => {
                              setRedoingQuestionId(q.id);
                              setSelectedRedoOption(null);
                              setRedoResult(null);
                            }}
                            className="bg-oab-primary hover:bg-slate-850 text-white font-bold text-xs px-4.5 py-2.5 rounded shadow cursor-pointer transition-colors"
                          >
                            Tentar Novamente (Refazer)
                          </button>
                          <button
                            onClick={() => handleMarkQuestionAsRevised(q.id)}
                            className="bg-slate-150 hover:bg-slate-200 text-slate-700 font-bold text-xs px-4 py-2.5 rounded cursor-pointer transition-colors"
                          >
                            Marcar como Sanada (Remover)
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* =========================================
              SEÇÃO 6 - LEI SECA E REVISÃO RÁPIDA
              ========================================= */}
          {activeSubtab === 'lei_seca' && (
            <div className="space-y-6" id="secao-lei-seca">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Left Side: Article List */}
                <div className="lg:col-span-4 bg-white rounded-xl p-4 border border-slate-200 shadow-sm space-y-3 h-fit">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Artigos Essenciais OAB</h4>
                  <p className="text-[10px] text-slate-400 leading-tight">Artigos da lei seca historicamente mais cobrados pela FGV.</p>
                  
                  <div className="space-y-2 pt-2">
                    {TOP_OAB_ARTICLES.map((art) => {
                      const isSelected = selectedArticle.id === art.id;
                      const isRead = readArticles.includes(art.id);
                      return (
                        <div
                          key={art.id}
                          onClick={() => handleSelectArticle(art)}
                          className={`p-3 rounded border text-xs cursor-pointer transition-all flex justify-between items-start gap-2
                            ${isSelected ? 'bg-oab-primary border-oab-primary text-white font-bold' : 'bg-slate-50 border-slate-150 text-slate-700 hover:bg-slate-100'}
                          `}
                        >
                          <div>
                            <span className={`text-[9px] uppercase font-black block mb-0.5 ${isSelected ? 'text-oab-accent' : 'text-slate-400'}`}>
                              {art.discipline}
                            </span>
                            {art.article}
                          </div>
                          {isRead && <CheckSquare className={`h-4.5 w-4.5 shrink-0 ${isSelected ? 'text-oab-accent' : 'text-emerald-600'}`} />}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Right Side: Law Reader & custom notes */}
                <div className="lg:col-span-8 space-y-6">
                  <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                    <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                      <div>
                        <span className="text-[9.5px] uppercase font-black text-oab-accent tracking-widest block">LEITURA ESQUEMATIZADA DE DISPOSITIVO</span>
                        <h3 className="text-base font-extrabold text-slate-800 mt-1">{selectedArticle.article}</h3>
                      </div>
                      <button
                        onClick={() => handleToggleArticleRead(selectedArticle.id)}
                        className={`text-xs font-bold px-3 py-1.5 rounded border transition-all flex items-center gap-1 cursor-pointer
                          ${readArticles.includes(selectedArticle.id) 
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-700' 
                            : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'}
                        `}
                      >
                        <Check className="h-4.5 w-4.5" /> 
                        {readArticles.includes(selectedArticle.id) ? 'Revisado!' : 'Marcar como Lido'}
                      </button>
                    </div>

                    <div className="p-4.5 bg-amber-50/20 border border-amber-100 rounded text-xs font-mono text-slate-800 leading-relaxed whitespace-pre-wrap">
                      {selectedArticle.text}
                    </div>

                    <div className="p-3.5 bg-slate-50 border border-slate-200 rounded text-[11px] leading-relaxed text-slate-600">
                      <strong>Orientação da Mentoria:</strong> {selectedArticle.tip}
                    </div>

                    <div className="space-y-2 pt-2 border-t border-slate-100">
                      <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Anotações do Aluno para este Artigo</h4>
                      <div className="flex gap-2">
                        <textarea
                          placeholder="Digite mnemônicos, súmulas correlatas ou exceções do artigo..."
                          value={articleNotes}
                          onChange={(e) => setArticleNotes(e.target.value)}
                          className="flex-1 text-xs border border-slate-200 rounded p-2.5 focus:outline-none bg-slate-50/50"
                          rows={3}
                        />
                        <button
                          onClick={handleSaveArticleNote}
                          className="bg-oab-primary hover:bg-slate-850 text-white font-bold text-xs px-4 rounded flex flex-col justify-center items-center cursor-pointer shrink-0 transition-colors"
                        >
                          <Edit2 className="h-4 w-4 mb-1" />
                          <span>Salvar</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* =========================================
              SEÇÃO 7 - REVISÃO DA 2ª FASE
              ========================================= */}
          {activeSubtab === 'fase2' && (
            <div className="space-y-6" id="secao-revisao-fase2">
              
              {/* Dynamic Juridical Area header */}
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-black text-oab-accent tracking-widest">PREPARAÇÃO DE PEÇA E DISCURSIVAS</span>
                    <h3 className="text-lg font-extrabold text-slate-800 font-display">Área Ativa: {selectedArea}</h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400 font-bold">Mudar Área Jurídica:</span>
                    <select
                      value={selectedArea}
                      onChange={(e) => handleSelectP2AreaInRevision(e.target.value)}
                      className="text-xs border border-slate-200 rounded p-2 bg-slate-50 focus:outline-none"
                    >
                      {PHASE2_LEGAL_AREAS.map(ar => (
                        <option key={ar} value={ar}>{ar}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Sub-Blocks of Phase 2 */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
                  
                  {/* Left Block: Pieces Library */}
                  <div className="lg:col-span-6 space-y-4">
                    <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1 border-b border-slate-100 pb-1">
                      <FileCode className="h-4 w-4 text-oab-accent" /> Peças para Revisar
                    </h4>

                    {p2Pieces.length === 0 ? (
                      <div className="text-center py-8 text-slate-400 text-xs">
                        Nenhuma peça mapeada para esta área jurídica no momento.
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {p2Pieces.map(piece => (
                          <div key={piece.id} className="p-3.5 rounded border border-slate-200 bg-slate-50/50 flex justify-between items-center text-xs">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-extrabold text-slate-800">{piece.title}</span>
                                <span className={`text-[9px] font-black uppercase px-2 py-0.2 rounded
                                  ${piece.importance === 'Extrema' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}
                                `}>
                                  {piece.importance}
                                </span>
                              </div>
                              <p className="text-[10px] text-slate-450 line-clamp-1">{piece.cabimento}</p>
                            </div>
                            <button
                              onClick={() => setViewingPiece(piece)}
                              className="bg-oab-primary hover:bg-slate-850 text-white font-bold text-[10px] px-3 py-1.5 rounded cursor-pointer transition-colors ml-3"
                            >
                              Estudar Estrutura
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Right Block: Discursivas draft pad */}
                  <div className="lg:col-span-6 space-y-4">
                    <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1 border-b border-slate-100 pb-1">
                      <HelpCircle className="h-4 w-4 text-indigo-500" /> Questões Discursivas da Área
                    </h4>

                    {p2Discursivas.length === 0 ? (
                      <div className="text-center py-8 text-slate-400 text-xs">
                        Nenhuma questão discursiva mapeada para esta área jurídica no momento.
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {p2Discursivas.map(disc => {
                          const isRevised = p2DiscursivasRevisadas.includes(disc.id);
                          const answerText = discursiveAnswers[disc.id] || '';
                          return (
                            <div key={disc.id} className="p-4 rounded-lg border border-slate-200 bg-white shadow-2xs space-y-3">
                              <div className="flex justify-between items-center">
                                <span className="text-[9.5px] uppercase font-black bg-slate-100 text-slate-500 px-2 py-0.5 rounded">
                                  {disc.theme}
                                </span>
                                <div className="flex items-center gap-2">
                                  <input 
                                    type="checkbox"
                                    checked={isRevised}
                                    onChange={() => handleToggleP2DiscursiveRevised(disc.id)}
                                    className="h-3.5 w-3.5 text-oab-accent focus:ring-amber-500"
                                  />
                                  <span className="text-[11px] text-slate-450 font-bold">Revisada</span>
                                </div>
                              </div>
                              <h5 className="font-extrabold text-xs text-slate-800 leading-snug">{disc.title}</h5>
                              <p className="text-[11px] text-slate-600 leading-relaxed bg-slate-50 p-2.5 rounded border border-slate-100">
                                {disc.statement}
                              </p>

                              {/* Input draft field */}
                              <div className="space-y-1 pt-1">
                                <label className="block text-[10px] text-slate-450 font-bold">Esboce sua Resposta (Treino):</label>
                                <textarea
                                  placeholder="Digite sua resposta estruturada aqui..."
                                  value={answerText}
                                  onChange={(e) => handleSaveDiscursiveDraft(disc.id, e.target.value)}
                                  className="w-full text-xs border border-slate-200 p-2 rounded focus:outline-none"
                                  rows={3}
                                />
                              </div>

                              <div className="flex gap-2">
                                <button
                                  onClick={() => setShowEspelhoId(showEspelhoId === disc.id ? null : disc.id)}
                                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[10px] px-3 py-1.5 rounded transition-all cursor-pointer flex items-center gap-1"
                                >
                                  <Info className="h-3 w-3" /> 
                                  {showEspelhoId === disc.id ? 'Ocultar Espelho' : 'Ver Espelho de Correção'}
                                </button>
                              </div>

                              {showEspelhoId === disc.id && (
                                <div className="p-3.5 bg-indigo-50/35 border border-indigo-100 rounded text-[11px] text-slate-650 space-y-2 animate-fadeIn leading-relaxed">
                                  <span className="font-extrabold text-indigo-900 block uppercase tracking-wide">Espelho de Nota FGV:</span>
                                  <p>{disc.espelhoCorrecao}</p>
                                  <div className="pt-2 border-t border-indigo-100/50">
                                    <span className="font-bold text-slate-750 block">Dica do Professor:</span>
                                    <p className="italic text-[10.5px]">{disc.professorObservations}</p>
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                </div>
              </div>
            </div>
          )}

          {/* =========================================
              SEÇÃO 8 - TRILHAS DE RECUPERAÇÃO POR DESEMPENHO
              ========================================= */}
          {activeSubtab === 'recuperacao' && (
            <div className="space-y-6" id="secao-trilhas-recuperacao">
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div>
                  <h3 className="text-base font-extrabold text-slate-800">Trilhas Inteligentes de Recuperação Acadêmica</h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    O algoritmo detecta as matérias em que seu rendimento em simulados ou testes ficou abaixo do ideal (&lt; 60%) e monta planos de ação cirúrgicos.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                  {RECOVERY_TRACKS.map(track => {
                    const isActive = activeRecoveryTrack === track.id;
                    return (
                      <div 
                        key={track.id} 
                        className={`p-4 rounded-lg border text-xs flex flex-col justify-between space-y-4 transition-all
                          ${track.severity === 'critical' ? 'border-red-150 bg-red-50/5' : 'border-amber-150 bg-amber-50/5'}
                        `}
                      >
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                              {track.discipline}
                            </span>
                            <span className={`text-[10px] font-black px-2 py-0.5 rounded
                              ${track.severity === 'critical' ? 'bg-red-100 text-red-700' : 'bg-amber-150 text-amber-800'}
                            `}>
                              Abaixo da Meta: {track.performance}
                            </span>
                          </div>

                          <h4 className="font-extrabold text-slate-800 leading-snug">{track.title}</h4>
                          <p className="text-[10.5px] text-slate-400 leading-relaxed">
                            Sequência de tarefas recomendadas para blindar o conhecimento e sanar falhas recorrentes identificadas nos dados de uso.
                          </p>
                        </div>

                        {isActive ? (
                          <div className="space-y-3 bg-white p-3 rounded border border-slate-150 animate-fadeIn text-[11px]">
                            <span className="font-bold text-slate-800 block mb-1">Tarefas de Recuperação:</span>
                            <div className="space-y-2">
                              {track.suggestedActions.map(act => {
                                const isDone = recoveryProgress[`${track.id}-${act.id}`];
                                return (
                                  <div key={act.id} className="flex items-start gap-2">
                                    <input
                                      type="checkbox"
                                      checked={isDone}
                                      onChange={() => handleToggleRecoveryAction(track.id, act.id)}
                                      className="h-3.5 w-3.5 text-oab-accent focus:ring-amber-500 rounded mt-0.5"
                                    />
                                    <span className={`${isDone ? 'line-through text-slate-400' : 'text-slate-700'}`}>
                                      <strong className="text-[9.5px] uppercase text-amber-700 mr-1">[{act.type}]</strong> {act.text}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                            <button
                              onClick={() => setActiveRecoveryTrack(null)}
                              className="w-full text-center py-1.5 text-[10px] font-black text-slate-500 uppercase tracking-wide border-t border-slate-100 mt-2 hover:text-slate-800 transition-colors cursor-pointer"
                            >
                              Minimizar Trilha
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              setActiveRecoveryTrack(track.id);
                              onSaveActivity('Revisão', `Iniciou trilha de recuperação para ${track.discipline}`);
                            }}
                            className="w-full py-2 bg-oab-primary hover:bg-slate-850 text-white font-bold text-xs rounded transition-colors cursor-pointer"
                          >
                            Iniciar Trilha de Recuperação
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* =========================================
              SEÇÃO 9 - HISTÓRICO DE REVISÃO E CONSTÂNCIA
              ========================================= */}
          {activeSubtab === 'historico' && (
            <div className="space-y-6" id="secao-historico-revisao">
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div>
                  <h3 className="text-base font-extrabold text-slate-800">Seu Histórico de Retenção & Metas</h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    A constância de revisão diária é a chave para a aprovação. Monitore sua rotina de retorno ao conteúdo.
                  </p>
                </div>

                {/* Simulated charts & cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                    <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Metas da Semana</span>
                    <h4 className="text-xl font-bold font-display text-slate-800">18 / 20 Revisões</h4>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div className="bg-oab-accent h-2 rounded-full" style={{ width: '90%' }}></div>
                    </div>
                    <span className="text-[10px] text-slate-400 block mt-1">90% da meta semanal concluída. Excelente aproveitamento!</span>
                  </div>

                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                    <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Artigos Esquematizados</span>
                    <h4 className="text-xl font-bold font-display text-slate-800">{readArticles.length} lidos</h4>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div className="bg-indigo-500 h-2 rounded-full" style={{ width: `${(readArticles.length / TOP_OAB_ARTICLES.length) * 100}%` }}></div>
                    </div>
                    <span className="text-[10px] text-slate-400 block mt-1">Dos artigos direcionados com dicas exclusivas de mentoria.</span>
                  </div>

                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                    <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Erros Sanados</span>
                    <h4 className="text-xl font-bold font-display text-slate-800">14 Registros</h4>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '75%' }}></div>
                    </div>
                    <span className="text-[10px] text-slate-400 block mt-1">Itens de erros resolvidos e superados em novas simulações.</span>
                  </div>
                </div>

                {/* Calendar Grid of study consistency */}
                <div className="space-y-2 pt-2">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                    <Calendar className="h-4 w-4 text-oab-accent" /> Calendário de Constância (Últimas 4 Semanas)
                  </h4>
                  <p className="text-[11px] text-slate-450">Quadrantes coloridos representam dias com revisões concluídas com sucesso.</p>
                  
                  {/* Visual Board simulating study contributions */}
                  <div className="p-4.5 bg-slate-50 border border-slate-150 rounded-xl flex flex-wrap gap-1.5 justify-start items-center">
                    {Array.from({ length: 28 }).map((_, idx) => {
                      // Simulating active study days
                      const activeDays = [1, 2, 3, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 17, 18, 19, 20, 22, 23, 24, 25, 26, 27];
                      const isActive = activeDays.includes(idx);
                      const isToday = idx === 27;
                      return (
                        <div
                          key={idx}
                          className={`w-7 h-7 rounded text-[9px] font-extrabold flex items-center justify-center border transition-all
                            ${isToday 
                              ? 'bg-oab-accent border-amber-400 text-slate-900 shadow-sm animate-pulse' 
                              : isActive 
                                ? 'bg-emerald-600 border-emerald-700 text-white' 
                                : 'bg-slate-200 border-slate-250 text-slate-400'}
                          `}
                          title={`Dia ${idx + 1}`}
                        >
                          {idx + 1}
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>
            </div>
          )}

        </motion.div>
      </AnimatePresence>

      {/* MODAL 1: SCHEDULED REVISION DETAIL SESSION */}
      {selectedReviewSession && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="review-session-modal">
          <div className="bg-white rounded-xl max-w-lg w-full border border-slate-250 p-6 space-y-4 shadow-xl">
            <div className="flex justify-between items-start border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] uppercase font-black text-oab-accent tracking-widest">
                  {selectedReviewSession.timeline} • {selectedReviewSession.type}
                </span>
                <h4 className="text-base font-extrabold text-slate-800">{selectedReviewSession.discipline}</h4>
              </div>
              <button 
                onClick={() => setSelectedReviewSession(null)} 
                className="text-slate-400 hover:text-slate-650 cursor-pointer"
              >
                <XCircle className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-2">
              <h5 className="text-xs font-black text-slate-400 uppercase tracking-wider">Conteúdo/Tema para Revisão:</h5>
              <p className="text-sm font-extrabold text-slate-800 bg-slate-50 p-3 rounded border border-slate-100">
                {selectedReviewSession.theme}
              </p>
            </div>

            <div className="space-y-2 leading-relaxed text-xs text-slate-600">
              <h5 className="text-xs font-black text-slate-400 uppercase tracking-wider">Resumo do Aluno e Principais Fundamentos:</h5>
              <p className="bg-amber-50/15 border border-amber-100 rounded-lg p-3.5 italic text-slate-700">
                &ldquo;{selectedReviewSession.details}&rdquo;
              </p>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => handleMarkReviewCompleted(selectedReviewSession.id)}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 rounded shadow cursor-pointer transition-colors"
              >
                Marcar como Concluída
              </button>
              <button
                onClick={() => setSelectedReviewSession(null)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs px-4 rounded cursor-pointer transition-colors"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: INTERACTIVE DRAFT REDO QUESTIONS */}
      {redoingQuestionId && (() => {
        const q = questions.find(x => x.id === redoingQuestionId);
        if (!q) return null;
        return (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="redo-question-modal">
            <div className="bg-white rounded-xl max-w-xl w-full border border-slate-250 p-6 space-y-4 shadow-xl overflow-y-auto max-h-[90vh]">
              <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                <div>
                  <span className="text-[10px] uppercase font-black text-oab-accent tracking-widest">
                    REFAZER QUESTÃO DA 1ª FASE
                  </span>
                  <h4 className="text-base font-extrabold text-slate-800">{q.discipline}</h4>
                </div>
                <button 
                  onClick={() => setRedoingQuestionId(null)} 
                  className="text-slate-400 hover:text-slate-650 cursor-pointer"
                >
                  <XCircle className="h-5 w-5" />
                </button>
              </div>

              <div className="space-y-3">
                <p className="text-xs text-slate-800 font-semibold leading-relaxed">
                  {q.statement}
                </p>

                <div className="space-y-2 pt-2">
                  {q.options.map((opt, i) => (
                    <div 
                      key={i}
                      onClick={() => {
                        if (redoResult === null) setSelectedRedoOption(i);
                      }}
                      className={`p-3 rounded border text-xs cursor-pointer transition-all flex items-start gap-2.5
                        ${selectedRedoOption === i ? 'border-oab-accent bg-amber-50/20 font-bold' : 'border-slate-200 bg-slate-50/30 hover:bg-slate-50'}
                      `}
                    >
                      <span className="font-extrabold text-oab-accent">{String.fromCharCode(65 + i)})</span>
                      <span className="text-slate-700">{opt}</span>
                    </div>
                  ))}
                </div>
              </div>

              {redoResult !== null && (
                <div className={`p-4 rounded text-xs space-y-1.5 animate-fadeIn
                  ${redoResult === 'correto' ? 'bg-emerald-50 border border-emerald-100 text-emerald-800' : 'bg-rose-50 border border-rose-100 text-rose-800'}
                `}>
                  <div className="font-extrabold flex items-center gap-1.5">
                    {redoResult === 'correto' ? (
                      <>
                        <CheckCircle2 className="h-4.5 w-4.5 text-emerald-600" />
                        <span>Excelente! Resposta Correta.</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="h-4.5 w-4.5 text-rose-600" />
                        <span>Incorreto. Tente de novo!</span>
                      </>
                    )}
                  </div>
                  <p className="text-slate-600 leading-relaxed mt-1 text-[11px]">
                    <strong>Comentário Acadêmico:</strong> {q.explanation}
                  </p>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                {redoResult === null ? (
                  <button
                    onClick={() => handleRedoQuestionSubmit(q)}
                    disabled={selectedRedoOption === null}
                    className="flex-1 bg-oab-primary hover:bg-slate-850 disabled:opacity-50 text-white font-bold text-xs py-2.5 rounded shadow cursor-pointer transition-colors"
                  >
                    Confirmar Resposta
                  </button>
                ) : (
                  <button
                    onClick={() => setRedoingQuestionId(null)}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 rounded shadow cursor-pointer transition-colors"
                  >
                    {redoResult === 'correto' ? 'Remover Fila de Erros' : 'Tentar Mais Tarde'}
                  </button>
                )}
                <button
                  onClick={() => setRedoingQuestionId(null)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs px-4 rounded cursor-pointer transition-colors"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* MODAL 3: STRUCTURAL GUIDELINE FOR PHASE 2 PIECES */}
      {viewingPiece && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="piece-structure-modal">
          <div className="bg-white rounded-xl max-w-2xl w-full border border-slate-250 p-6 space-y-4 shadow-xl overflow-y-auto max-h-[90vh]">
            <div className="flex justify-between items-start border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] uppercase font-black text-oab-accent tracking-widest">
                  ESTRUTURA DE PEÇA PRÁTICO-PROFISSIONAL
                </span>
                <h4 className="text-base font-extrabold text-slate-800">{viewingPiece.title}</h4>
              </div>
              <button 
                onClick={() => setViewingPiece(null)} 
                className="text-slate-400 hover:text-slate-650 cursor-pointer"
              >
                <XCircle className="h-5 w-5" />
              </button>
            </div>

            {/* Scrolling contents split inside tabs */}
            <div className="space-y-4 text-xs text-slate-600">
              
              <div className="space-y-1">
                <span className="text-xs font-black uppercase text-slate-400 tracking-wider">Quando Cabe (Cabimento):</span>
                <p className="bg-slate-50 p-3 rounded border border-slate-100 leading-relaxed text-slate-700">
                  {viewingPiece.cabimento}
                </p>
              </div>

              <div className="space-y-1">
                <span className="text-xs font-black uppercase text-slate-400 tracking-wider">Estrutura Geral:</span>
                <p className="bg-indigo-50/15 p-3.5 border border-indigo-100 rounded leading-relaxed text-slate-700 font-serif">
                  {viewingPiece.estrutura}
                </p>
              </div>

              <div className="space-y-1">
                <span className="text-xs font-black uppercase text-slate-400 tracking-wider">Passo a Passo de Montagem:</span>
                <div className="space-y-1.5 pl-2 mt-1">
                  {viewingPiece.passoAPasso.map((pStep, index) => (
                    <div key={index} className="flex gap-2 leading-relaxed">
                      <span className="text-oab-accent font-black">{index + 1}.</span>
                      <span>{pStep}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-xs font-black uppercase text-slate-400 tracking-wider">Fundamentos Principais:</span>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {viewingPiece.fundamentos.map((fund, index) => (
                    <span key={index} className="bg-slate-100 text-slate-700 border border-slate-200 px-2 py-1 rounded text-[10.5px]">
                      {fund}
                    </span>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-xs font-black uppercase text-slate-400 tracking-wider">Erros Fatais (Banca FGV):</span>
                <div className="space-y-1.5 bg-rose-50/30 p-3 rounded border border-rose-150 mt-1">
                  {viewingPiece.errosFatais.map((errFatal, index) => (
                    <div key={index} className="flex gap-2 text-rose-800 text-[11px] leading-relaxed">
                      <XCircle className="h-4 w-4 text-rose-500 shrink-0 mt-0.5" />
                      <span>{errFatal}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Checklist Mastery */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <span className="text-xs font-black uppercase text-slate-400 tracking-wider">Checklist de Domínio da Peça:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-1">
                  {viewingPiece.checklist.map((chk, idx) => {
                    const key = `${viewingPiece.id}-${idx}`;
                    const isChecked = pieceMastery[key];
                    return (
                      <div 
                        key={idx}
                        onClick={() => setPieceMastery(prev => ({ ...prev, [key]: !prev[key] }))}
                        className={`p-2.5 rounded border text-[11px] cursor-pointer flex items-center gap-2 transition-all
                          ${isChecked ? 'bg-emerald-50 border-emerald-200 text-emerald-800 font-bold' : 'bg-slate-50 border-slate-150 text-slate-655'}
                        `}
                      >
                        <Check className={`h-4 w-4 shrink-0 ${isChecked ? 'text-emerald-600' : 'text-slate-300'}`} />
                        <span>{chk}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setViewingPiece(null)}
                className="bg-oab-primary hover:bg-slate-850 text-white font-bold text-xs px-5 py-2.5 rounded shadow cursor-pointer transition-colors"
              >
                Concluir Estudo de Estrutura
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
