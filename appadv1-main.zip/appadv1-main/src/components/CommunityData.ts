/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ForumAnswer {
  id: string;
  author: string;
  role: 'aluno' | 'tutor' | 'professor';
  text: string;
  timestamp: string;
  likes: number;
}

export interface ForumQuestion {
  id: string;
  title: string;
  text: string;
  author: string;
  discipline: string;
  reference: string; // e.g. "Aula: Prerrogativas do Advogado", "Simulado Geral #1"
  timestamp: string;
  status: 'aberta' | 'respondida' | 'resolvida';
  likes: number;
  isLikedByUser?: boolean;
  answers: ForumAnswer[];
}

export interface SupportTicket {
  id: string;
  protocol: string;
  category: string;
  description: string;
  urgency: 'Normal' | 'Alta' | 'Urgente';
  status: 'aberto' | 'em_analise' | 'respondido' | 'resolvido' | 'encerrado';
  timestamp: string;
  replies: {
    author: string;
    role: 'aluno' | 'suporte';
    text: string;
    timestamp: string;
  }[];
}

export interface MentorshipMeeting {
  id: string;
  title: string;
  date: string;
  time: string;
  type: 'live' | 'gravado';
  description: string;
  zoomUrl?: string;
}

export interface MentorshipTask {
  id: string;
  title: string;
  description: string;
  completed: boolean;
}

export interface Testimonial {
  id: string;
  name: string;
  phase: '1a Fase' | '2a Fase' | 'Superação' | 'Destaque';
  area2ndPhase?: string;
  story: string;
  grade?: string;
  approvedYear: string;
}

export interface Announcement {
  id: string;
  title: string;
  text: string;
  category: 'Geral' | 'Eventos' | 'Materiais' | 'Mentoria';
  timestamp: string;
  isUrgent: boolean;
  isRead: boolean;
}

// DEFAULT MOCK DATA
export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: '🔥 Super Aulão de Véspera - Reta Final OAB XL',
    text: 'Preparem-se! No próximo sábado, às 08:30, teremos nosso tradicional Aulão de Revisão com todo o corpo docente revisando as 8 matérias mais importantes para a 1ª Fase. O link de acesso será liberado na aba Mentoria.',
    category: 'Eventos',
    timestamp: '25/06/2026',
    isUrgent: true,
    isRead: false
  },
  {
    id: 'ann-2',
    title: '📚 Atualização: Guia de Súmulas Vinculantes 2026',
    text: 'Atenção alunos de 2ª Fase, já está disponível para download na biblioteca de materiais o compilado de Súmulas Vinculantes do STF comentadas e filtradas por área. Não deixe de revisar!',
    category: 'Materiais',
    timestamp: '24/06/2026',
    isUrgent: false,
    isRead: false
  },
  {
    id: 'ann-3',
    title: '🧠 Cronograma Semanal de Mentoria Disponível',
    text: 'As metas individuais para esta semana foram atualizadas de acordo com o plano de ação de 60 dias. Verifique suas tarefas e acompanhe sua consistência.',
    category: 'Mentoria',
    timestamp: '22/06/2026',
    isUrgent: false,
    isRead: true
  }
];

export const INITIAL_TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Mariana Costa',
    phase: '2a Fase',
    area2ndPhase: 'Direito do Trabalho',
    story: 'O método de repetições espaçadas e a elaboração exaustiva das peças práticas me deram a segurança que eu precisava. Gabaritei a peça de Reclamação Trabalhista e fui aprovada com nota 9.2!',
    grade: '9.2',
    approvedYear: 'Exame XXXIX'
  },
  {
    id: 'test-2',
    name: 'Carlos Eduardo Ramos',
    phase: '1a Fase',
    story: 'Fiz 48 pontos na 1ª fase estudando apenas o cronograma de 30 dias na reta final. Os flashcards de Ética Profissional garantiram que eu acertasse 7 das 8 questões da disciplina!',
    grade: '48 pontos',
    approvedYear: 'Exame XXXIX'
  },
  {
    id: 'test-3',
    name: 'Ana Júlia Albuquerque',
    phase: 'Superação',
    story: 'Mãe de dois filhos pequenos, trabalhando em período integral. Achei que seria impossível, mas o cronograma de mentoria e o plano de ação personalizado me trouxeram a clareza e o suporte emocional necessários para a aprovação.',
    grade: '42 pontos',
    approvedYear: 'Exame XXXVIII'
  },
  {
    id: 'test-4',
    name: 'Dr. Lucas Ribeiro',
    phase: 'Destaque',
    area2ndPhase: 'Direito Penal',
    story: 'Não sabia estruturar uma peça sequer. No simulado de 5 horas do app, treinei o tempo exato e no dia oficial parecia que eu estava fazendo apenas mais um teste em casa. Aprovado com louvor!',
    grade: '8.5',
    approvedYear: 'Exame XXXVIII'
  }
];

export const INITIAL_FORUM_QUESTIONS: ForumQuestion[] = [
  {
    id: 'fq-1',
    title: 'Cabe Recurso Ordinário Constitucional (ROC) neste caso?',
    text: 'Professores, fiquei com dúvida no caso em que o Mandado de Segurança é impetrado perante o Tribunal de Justiça e denegada a segurança. Cabe ROC para o STJ ou cabe Recurso Especial?',
    author: 'Gabriel Sousa',
    discipline: 'Direito Constitucional',
    reference: 'Aula: Remédios e Recursos',
    timestamp: '25/06/2026, 09:12',
    status: 'respondida',
    likes: 12,
    answers: [
      {
        id: 'fa-1',
        author: 'Prof. Lucas (Equipe OAB 3F)',
        role: 'professor',
        text: 'Excelente pergunta, Gabriel! Conforme o art. 105, II, "b" da CF, cabe Recurso Ordinário para o STJ contra decisão denegatória de Mandado de Segurança decidido em única ou última instância pelos Tribunais de Justiça ou Tribunais Regionais Federais. Ou seja: se o MS começou originalmente no TJ e foi denegada a segurança, o recurso cabível é o ROC, e não o REsp.',
        timestamp: '25/06/2026, 10:45',
        likes: 8
      }
    ]
  },
  {
    id: 'fq-2',
    title: 'Pena restritiva de direitos e dosimetria',
    text: 'Se a pena fixada for inferior a 1 ano, o juiz pode substituir por duas penas restritivas de direitos, ou é obrigatório que seja apenas uma restritiva ou multa?',
    author: 'Beatriz Martins',
    discipline: 'Direito Penal',
    reference: 'Aula: Teoria da Pena',
    timestamp: '24/06/2026, 18:30',
    status: 'aberta',
    likes: 4,
    answers: []
  },
  {
    id: 'fq-3',
    title: 'Inviolabilidade do escritório de advocacia',
    text: 'A inviolabilidade do escritório abrange também os equipamentos eletrônicos de uso pessoal do advogado, como o celular dele, quando este estiver fora do escritório?',
    author: 'Thiago Mendes',
    discipline: 'Ética Profissional',
    reference: 'PDF: Direitos do Advogado',
    timestamp: '23/06/2026, 14:15',
    status: 'resolvida',
    likes: 9,
    answers: [
      {
        id: 'fa-2',
        author: 'Laura Vieira (Tutor)',
        role: 'tutor',
        text: 'Olá Thiago! A inviolabilidade prevista no Estatuto (art. 7º, II) protege o local de trabalho, arquivos e dados relativos aos clientes. Em relação ao celular de uso pessoal fora do escritório, a jurisprudência protege o sigilo das comunicações telefônicas e de dados, necessitando de autorização judicial específica e fundamentada para apreensão ou quebra de sigilo.',
        timestamp: '23/06/2026, 16:20',
        likes: 5
      }
    ]
  }
];

export const MENTORSHIP_MEETINGS: MentorshipMeeting[] = [
  {
    id: 'meet-1',
    title: '🔴 Análise de Edital & Planejamento de Estudos 1ª Fase',
    date: 'Hoje',
    time: '19:30',
    type: 'live',
    description: 'Encontro interativo de mentoria com orientações sobre quais temas priorizar nestes últimos 30 dias de reta final para o XL Exame de Ordem.',
    zoomUrl: 'https://zoom.us/j/mock-oab3f'
  },
  {
    id: 'meet-2',
    title: '🧠 Como Manusear o Vade Mecum na 2ª Fase',
    date: '28/06/2026',
    time: '14:00',
    type: 'gravado',
    description: 'Aula prática ensinando a fazer marcações permitidas pela banca e a encontrar artigos de fundamentação em menos de 2 minutos usando o índice remissivo.'
  }
];

export const MENTORSHIP_TASKS: MentorshipTask[] = [
  { id: 'mt-1', title: 'Resolver 30 questões de Ética', description: 'Meta essencial para garantir consistência no bloco mais fácil do exame.', completed: false },
  { id: 'mt-2', title: 'Fazer o Simulado de 40 questões no Sábado', description: 'Treino prático de gerenciamento de tempo.', completed: false },
  { id: 'mt-3', title: 'Estudar 3 mapas mentais de Controle de Constitucionalidade', description: 'Revisão ativa das teorias de controle difuso e concentrado.', completed: false }
];
