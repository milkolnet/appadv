/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Mail, 
  Send, 
  Check, 
  Clock, 
  AlertCircle, 
  ArrowLeft, 
  MessageSquare,
  Sparkles,
  CheckCircle,
  HelpCircle
} from 'lucide-react';
import { SupportTicket } from './CommunityData';

interface CommunitySupportProps {
  tickets: SupportTicket[];
  setTickets: React.Dispatch<React.SetStateAction<SupportTicket[]>>;
  onNavigateToFAQ: () => void;
}

export default function CommunitySupport({ tickets, setTickets, onNavigateToFAQ }: CommunitySupportProps) {
  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  const [showOpenForm, setShowOpenForm] = useState(false);

  // New Ticket Form States
  const [category, setCategory] = useState('Dúvida sobre o Aplicativo');
  const [urgency, setUrgency] = useState<'Normal' | 'Alta' | 'Urgente'>('Normal');
  const [description, setDescription] = useState('');
  const [ticketSuccess, setTicketSuccess] = useState(false);

  // New Reply State
  const [replyText, setReplyText] = useState('');

  const handleOpenTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    const protocolNum = `#OAB-3F-${Math.floor(1000 + Math.random() * 9000)}`;
    const newTicket: SupportTicket = {
      id: `tkt-${Date.now()}`,
      protocol: protocolNum,
      category,
      urgency,
      description,
      status: 'aberto',
      timestamp: new Date().toLocaleString('pt-BR', { hour12: false }).slice(0, 16),
      replies: [
        {
          author: 'poprotaspires@gmail.com',
          role: 'aluno',
          text: description,
          timestamp: new Date().toLocaleString('pt-BR', { hour12: false }).slice(0, 16)
        }
      ]
    };

    setTickets(prev => [newTicket, ...prev]);
    setDescription('');
    setTicketSuccess(true);
    setTimeout(() => {
      setTicketSuccess(false);
      setShowOpenForm(false);
    }, 3000);
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !activeTicketId) return;

    setTickets(prev => prev.map(t => {
      if (t.id === activeTicketId) {
        return {
          ...t,
          status: t.status === 'respondido' ? 'aberto' : t.status, // Reopen if they reply to a response
          replies: [
            ...t.replies,
            {
              author: 'poprotaspires@gmail.com',
              role: 'aluno',
              text: replyText,
              timestamp: new Date().toLocaleString('pt-BR', { hour12: false }).slice(0, 16)
            }
          ]
        };
      }
      return t;
    }));

    setReplyText('');
  };

  const activeTicket = tickets.find(t => t.id === activeTicketId);

  return (
    <div className="space-y-6" id="community-support-workspace">
      {activeTicket ? (
        /* TICKET DETAIL VIEW */
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm animate-fade-in">
          <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
            <button 
              onClick={() => setActiveTicketId(null)}
              className="flex items-center text-xs font-bold text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <ArrowLeft className="h-4 w-4 mr-1" /> Voltar ao Histórico de Chamados
            </button>
            <div className="flex items-center gap-2">
              <span className={`text-[9.5px] uppercase font-mono font-bold px-2 py-0.5 rounded ${
                activeTicket.urgency === 'Urgente' ? 'bg-red-500/20 text-red-400' :
                activeTicket.urgency === 'Alta' ? 'bg-amber-500/20 text-amber-400' :
                'bg-slate-700 text-slate-300'
              }`}>
                Prioridade: {activeTicket.urgency}
              </span>
              <span className="text-[10px] bg-slate-800 text-[#D4AF37] px-2 py-0.5 rounded font-mono font-bold">
                Protocolo: {activeTicket.protocol}
              </span>
            </div>
          </div>

          <div className="p-6 space-y-6">
            <div className="bg-slate-50 border border-slate-150 p-4 rounded-xl flex justify-between items-center text-xs text-slate-600">
              <div>
                <span className="block font-bold">Assunto / Categoria:</span>
                <span className="text-slate-500 font-medium">{activeTicket.category}</span>
              </div>
              <div className="text-right">
                <span className="block font-bold">Status do Atendimento:</span>
                <span className={`inline-block font-black uppercase text-[9px] tracking-wider px-2 py-0.5 rounded ${
                  activeTicket.status === 'resolvido' || activeTicket.status === 'encerrado' ? 'bg-emerald-500/10 text-emerald-600' :
                  activeTicket.status === 'respondido' ? 'bg-blue-500/10 text-blue-600' :
                  'bg-rose-500/10 text-rose-600 animate-pulse'
                }`}>
                  {activeTicket.status.replace('_', ' ')}
                </span>
              </div>
            </div>

            {/* Conversation Log */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">Histórico de Mensagens</h4>
              <div className="space-y-3">
                {activeTicket.replies.map((rep, idx) => {
                  const isStaff = rep.role === 'suporte';
                  return (
                    <div 
                      key={idx}
                      className={`p-4 rounded-xl border max-w-[85%] leading-relaxed ${
                        isStaff 
                          ? 'bg-amber-500/5 border-amber-500/25 ml-auto' 
                          : 'bg-slate-50 border-slate-200 mr-auto'
                      }`}
                    >
                      <div className="flex justify-between items-center gap-6 mb-1 text-[10.5px]">
                        <span className={`font-bold ${isStaff ? 'text-amber-700' : 'text-slate-700'}`}>
                          {isStaff ? 'Suporte Pedagógico OAB 3F' : rep.author}
                        </span>
                        <span className="text-slate-400 font-mono text-[9.5px]">{rep.timestamp}</span>
                      </div>
                      <p className="text-xs text-slate-600 whitespace-pre-line font-medium">{rep.text}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Reply Input */}
            {activeTicket.status !== 'encerrado' && activeTicket.status !== 'resolvido' ? (
              <form onSubmit={handleSendReply} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <label className="block text-xs font-bold text-slate-700">Responder ao Suporte</label>
                <textarea
                  placeholder="Escreva sua resposta ou envie informações adicionais..."
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  className="w-full text-xs bg-white border border-slate-200 rounded-lg p-2.5 h-20 focus:outline-none focus:ring-1 focus:ring-slate-400"
                  required
                />
                <button 
                  type="submit"
                  className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2 px-4 rounded-lg flex items-center gap-1.5 ml-auto cursor-pointer transition-colors"
                >
                  <Send className="h-3.5 w-3.5" /> Enviar Resposta
                </button>
              </form>
            ) : (
              <div className="text-center p-4 bg-emerald-500/5 border border-emerald-500/20 text-emerald-800 text-xs rounded-xl font-bold">
                ✔ Este atendimento foi marcado como resolvido e encerrado. Se precisar de mais ajuda, abra um novo chamado.
              </div>
            )}
          </div>
        </div>
      ) : (
        /* LIST OF ACTIVE/PAST TICKETS */
        <div className="space-y-4">
          {/* Header Action card */}
          {!showOpenForm && (
            <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="space-y-1 text-center sm:text-left">
                <h3 className="font-serif font-black text-slate-900 text-base">Atendimento Organizado</h3>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">
                  Abra um ticket para tirar dúvidas administrativas, sugerir melhorias ou relatar qualquer dificuldade técnica.
                </p>
              </div>
              <div className="flex gap-2 w-full sm:w-auto">
                <button 
                  onClick={onNavigateToFAQ}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold py-2.5 px-4 rounded-lg cursor-pointer flex-1 sm:flex-none flex items-center justify-center gap-1"
                >
                  <HelpCircle className="h-4 w-4" /> Buscar no FAQ
                </button>
                <button 
                  onClick={() => setShowOpenForm(true)}
                  className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2.5 px-4 rounded-lg cursor-pointer flex-1 sm:flex-none flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Mail className="h-4 w-4" /> Abrir Atendimento
                </button>
              </div>
            </div>
          )}

          {/* OPEN FORM VIEW */}
          {showOpenForm && (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm animate-fade-in">
              <div className="bg-slate-900 text-white p-4 flex justify-between items-center">
                <span className="font-serif font-bold text-sm flex items-center gap-1.5">
                  <Mail className="h-4.5 w-4.5 text-[#D4AF37]" /> Formulário de Novo Chamado
                </span>
                <button 
                  onClick={() => setShowOpenForm(false)}
                  className="text-slate-400 hover:text-white cursor-pointer font-bold text-lg"
                >
                  ×
                </button>
              </div>

              {ticketSuccess ? (
                <div className="p-12 text-center space-y-3 animate-fade-in">
                  <div className="h-12 w-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                    <Check className="h-6 w-6" />
                  </div>
                  <h3 className="font-serif font-bold text-slate-800">Chamado Registrado!</h3>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                    Sua solicitação foi enviada para a fila de atendimento. Em breve nossa equipe responderá. Você pode acompanhar o status logo abaixo.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleOpenTicket} className="p-6 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1">Categoria do Chamado</label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
                      >
                        <option value="Dúvida sobre o Aplicativo">Dúvida sobre o Aplicativo</option>
                        <option value="Dúvida sobre Conteúdo (1a ou 2a fase)">Dúvida sobre Conteúdo (1a ou 2a fase)</option>
                        <option value="Problema Técnico (Login/Erro em Aula)">Problema Técnico (Login/Erro em Aula)</option>
                        <option value="Financeiro e Planos de Assinatura">Financeiro e Planos de Assinatura</option>
                        <option value="Sugestão de Melhoria">Sugestão de Melhoria</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1">Prioridade</label>
                      <select
                        value={urgency}
                        onChange={(e) => setUrgency(e.target.value as any)}
                        className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
                      >
                        <option value="Normal">Normal (Até 12 horas úteis)</option>
                        <option value="Alta">Alta (Até 4 horas úteis)</option>
                        <option value="Urgente">Urgente (Até 2 horas úteis - Erros graves)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Descreva seu problema com detalhes</label>
                    <textarea
                      placeholder="Forneça o máximo de informações possível. Se for um erro em aula, indique o nome da aula. Se for pagamento, informe se foi via Pix ou Cartão..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full text-xs border border-slate-200 rounded-lg p-2.5 h-32 focus:outline-none focus:ring-1 focus:ring-slate-400"
                      required
                    />
                  </div>

                  <div className="pt-2 flex gap-3">
                    <button
                      type="button"
                      onClick={() => setShowOpenForm(false)}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex-1 cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex-1 cursor-pointer transition-colors"
                    >
                      Registrar Ticket
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* HISTORY TABLE */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            <div className="p-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-xs font-bold uppercase text-slate-500 tracking-wider">Histórico de Atendimentos</h3>
              <span className="text-[10px] font-mono text-slate-400">Total: {tickets.length}</span>
            </div>

            {tickets.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                Nenhum chamado de suporte aberto.
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {tickets.map(tkt => (
                  <div 
                    key={tkt.id}
                    onClick={() => setActiveTicketId(tkt.id)}
                    className="p-4 hover:bg-slate-50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 transition-colors cursor-pointer"
                  >
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-slate-900">{tkt.protocol}</span>
                        <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${
                          tkt.urgency === 'Urgente' ? 'bg-red-50 text-red-600' :
                          tkt.urgency === 'Alta' ? 'bg-amber-50 text-amber-600' :
                          'bg-slate-100 text-slate-500'
                        }`}>
                          {tkt.urgency}
                        </span>
                        <span className="text-[10px] text-slate-400">• {tkt.timestamp}</span>
                      </div>
                      <p className="text-xs font-bold text-slate-700 line-clamp-1">{tkt.category}</p>
                      <p className="text-[11px] text-slate-400 line-clamp-1">{tkt.description}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        tkt.status === 'resolvido' || tkt.status === 'encerrado' ? 'bg-emerald-50 text-emerald-700' :
                        tkt.status === 'respondido' ? 'bg-blue-50 text-blue-700' :
                        'bg-rose-50 text-rose-700 animate-pulse'
                      }`}>
                        {tkt.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
