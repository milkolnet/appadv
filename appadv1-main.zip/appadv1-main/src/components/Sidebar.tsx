/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Home,
  CheckSquare,
  BookOpen,
  Award,
  BookOpenCheck,
  RotateCcw,
  FileSpreadsheet,
  FileText,
  Calendar,
  TrendingUp,
  HelpCircle,
  Menu,
  X,
  Scale,
  Flame,
  Crown,
  Database,
  Sparkles,
  Megaphone,
  Milestone
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  streakDays: number;
}

export default function Sidebar({ activeTab, setActiveTab, streakDays }: SidebarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const menuItems = [
    { id: 'inicio', label: 'Início', icon: Home },
    { id: 'plano', label: 'Meu Plano', icon: CheckSquare },
    { id: 'fase1', label: '1ª Fase', icon: BookOpen },
    { id: 'fase2', label: '2ª Fase', icon: Award },
    { id: 'questoes', label: 'Questões', icon: BookOpenCheck },
    { id: 'simulados', label: 'Simulados', icon: FileSpreadsheet },
    { id: 'revisao', label: 'Revisão', icon: RotateCcw },
    { id: 'pecas', label: 'Peças', icon: Scale },
    { id: 'materiais', label: 'Materiais', icon: FileText },
    { id: 'calendario', label: 'Calendário OAB', icon: Calendar },
    { id: 'desempenho', label: 'Meu Desempenho', icon: TrendingUp },
    { id: 'monetizacao', label: 'Planos & Assinatura', icon: Crown },
    { id: 'suporte', label: 'Comunidade OAB 3F', icon: HelpCircle },
    { id: 'identidade', label: 'Identidade & Copy', icon: Sparkles },
    { id: 'growth', label: 'Growth & Comercial', icon: Megaphone },
    { id: 'arquitetura', label: 'Arquitetura OAB 3F', icon: Database },
    { id: 'roadmap', label: 'Roadmap de Execução', icon: Milestone },
    { id: 'documentacao', label: 'Documentação Mestra', icon: FileText },
  ];

  const toggleSidebar = () => setIsOpen(!isOpen);

  return (
    <>
      {/* Mobile Top Navigation */}
      <header className="lg:hidden flex items-center justify-between bg-oab-primary text-white px-4 py-3 sticky top-0 z-50 shadow-md">
        <div className="flex items-center space-x-2">
          <div className="bg-oab-accent p-1.5 rounded text-oab-primary font-bold shadow">
            <Scale className="h-5 w-5" />
          </div>
          <div>
            <span className="font-display font-extrabold text-lg tracking-tight">OAB 3F</span>
            <span className="block text-[9px] text-gray-300 -mt-1 font-sans">Da 1ª fase à aprovação</span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {streakDays > 0 && (
            <div className="flex items-center space-x-1 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded text-amber-400 text-xs font-semibold">
              <Flame className="h-3.5 w-3.5 fill-current text-amber-500 animate-pulse" />
              <span>{streakDays} dias</span>
            </div>
          )}
          <button
            onClick={toggleSidebar}
            className="p-1 rounded hover:bg-oab-secondary focus:outline-none transition-colors"
            aria-label="Toggle menu"
            id="mobile-menu-btn"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </header>

      {/* Sidebar - Desktop Layout & Mobile Drawer */}
      <aside
        id="app-sidebar"
        className={`
          fixed top-0 bottom-0 left-0 z-40 bg-oab-primary text-slate-300 w-64 border-r border-slate-800 flex flex-col justify-between transition-transform duration-300 ease-in-out
          lg:translate-x-0 lg:sticky lg:h-screen lg:z-10
          ${isOpen ? 'translate-x-0 pt-0' : '-translate-x-full lg:translate-x-0'}
          ${isOpen ? 'top-[52px]' : 'top-0'}
        `}
      >
        {/* Brand Header */}
        <div className="p-8 pb-5 border-b border-slate-800 hidden lg:block">
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight text-oab-accent">OAB 3F</h1>
            <p className="text-[10px] uppercase tracking-widest opacity-60 mt-1 italic text-slate-300">Da 1ª fase à aprovação final</p>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 overflow-y-auto px-4 py-6 space-y-1">
          {menuItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`sidebar-tab-${item.id}`}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsOpen(false);
                }}
                className={`
                  w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150
                  ${isActive
                    ? 'bg-oab-accent text-oab-primary font-semibold shadow-md shadow-oab-accent/15'
                    : 'hover:bg-slate-800/60 hover:text-white text-slate-400'
                  }
                `}
              >
                <IconComponent className={`h-4.5 w-4.5 ${isActive ? 'text-oab-primary' : 'text-slate-400 group-hover:text-white'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* User Card footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/45">
          <div className="flex items-center space-x-3">
            <div className="h-9 w-9 rounded-full bg-oab-accent/10 border border-oab-accent/30 flex items-center justify-center text-oab-accent font-bold">
              PP
            </div>
            <div className="overflow-hidden">
              <span className="block text-xs font-semibold text-white truncate">poprotaspires@gmail.com</span>
              <div className="flex items-center space-x-1 mt-0.5">
                <span className="inline-block h-2 w-2 rounded-full bg-oab-success"></span>
                <span className="text-[10px] text-slate-400 font-medium">Foco Ativo</span>
              </div>
            </div>
          </div>
          {streakDays > 0 && (
            <div className="mt-3 bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-lg text-amber-400 text-xs flex items-center justify-between hidden lg:flex">
              <div className="flex items-center space-x-1.5">
                <Flame className="h-4 w-4 text-amber-500 fill-current" />
                <span className="font-semibold">Ofensiva de Estudos</span>
              </div>
              <span className="font-bold text-white bg-amber-500/20 px-1.5 py-0.5 rounded text-[10px]">{streakDays} dias</span>
            </div>
          )}
        </div>
      </aside>

      {/* Overlay for mobile drawer */}
      {isOpen && (
        <div
          id="sidebar-overlay"
          onClick={toggleSidebar}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-30 lg:hidden top-[52px]"
        />
      )}
    </>
  );
}
