/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BookOpen,
  Play,
  FileText,
  CheckCircle,
  Clock,
  ArrowLeft,
  ChevronRight,
  ShieldAlert,
  Users,
  Briefcase,
  Scale,
  Award,
  Video,
  FileDown,
  BookOpenCheck,
  Building,
  FolderClosed,
  Gavel,
  Coins,
  Receipt,
  Heart,
  Baby,
  ShoppingBag,
  Leaf,
  Globe,
  Brain,
  HeartHandshake,
  PiggyBank,
  Check,
  AlertCircle,
  Sparkles,
  Calendar,
  Bookmark,
  ChevronDown,
  Info,
  Layers,
  CheckSquare,
  HelpCircle,
  Timer
} from 'lucide-react';
import { Discipline, StudentProgress, Lecture, PDFMaterial, Question } from '../types';
import { FULL_DISCIPLINES, PHASE1_QUESTIONS, EnrichedDiscipline, Phase1DisciplineModule } from '../data/phase1Data';

interface Phase1Props {
  disciplines: Discipline[]; // From App.tsx
  progress: StudentProgress;
  onToggleLecture: (lectureId: string) => void;
  onTogglePDF: (pdfId: string) => void;
  onSaveActivity: (tab: string, title: string, sectionId?: string, itemId?: string) => void;
}

export default function Phase1({
  disciplines: initialDisciplines,
  progress,
  onToggleLecture,
  onTogglePDF,
  onSaveActivity
}: Phase1Props) {
  // Navigation states
  const [selectedDiscipline, setSelectedDiscipline] = useState<EnrichedDiscipline | null>(null);
  const [selectedModule, setSelectedModule] = useState<string>("all"); // "all" or specific module ID
  const [activeSubTab, setActiveSubTab] = useState<'aulas' | 'pdfs' | 'questoes' | 'revisoes' | 'simulados'>('aulas');
  
  // Interactive lecture viewer state
  const [activeLecture, setActiveLecture] = useState<Lecture | null>(null);
  // Interactive PDF viewer state
  const [activePDF, setActivePDF] = useState<PDFMaterial | null>(null);
  
  // Interactive quiz & review states
  const [quizAnswers, setQuizAnswers] = useState<{ [qId: string]: number }>({});
  const [showExplanation, setShowExplanation] = useState<{ [qId: string]: boolean }>({});
  
  // Interactive Review Modal/Panel state
  const [activeReviewItem, setActiveReviewItem] = useState<{
    id: string;
    title: string;
    questions: Question[];
    currentIndex: number;
    answers: { [qId: string]: number };
    completed: boolean;
  } | null>(null);

  // Mini simulated exam state
  const [activeSimulado, setActiveSimulado] = useState<{
    id: string;
    title: string;
    questions: Question[];
    currentIndex: number;
    answers: { [qId: string]: number };
    timeRemaining: number;
    completed: boolean;
  } | null>(null);

  // Simulado timer hook
  useEffect(() => {
    if (!activeSimulado || activeSimulado.completed) return;
    if (activeSimulado.timeRemaining <= 0) {
      handleCompleteSimulado();
      return;
    }
    const timer = setTimeout(() => {
      setActiveSimulado(prev => prev ? { ...prev, timeRemaining: prev.timeRemaining - 1 } : null);
    }, 1000);
    return () => clearTimeout(timer);
  }, [activeSimulado]);

  // Handle active activity logging when entering a discipline
  const handleDisciplineSelect = (disc: EnrichedDiscipline) => {
    setSelectedDiscipline(disc);
    setSelectedModule("all");
    setActiveSubTab('aulas');
    
    // Default to first lecture and PDF
    setActiveLecture(disc.lectures[0] || null);
    setActivePDF(disc.pdfs[0] || null);
    
    // Clear interactive overlays
    setActiveReviewItem(null);
    setActiveSimulado(null);
    
    onSaveActivity('1ª Fase', `Estudando ${disc.name}`, 'disc-' + disc.id);
    
    // Scroll to top of classroom smoothly
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLectureSelect = (lecture: Lecture) => {
    setActiveLecture(lecture);
    onSaveActivity('1ª Fase', `Assistindo: ${lecture.title}`, 'disc-' + selectedDiscipline?.id, lecture.id);
  };

  const handlePDFSelect = (pdf: PDFMaterial) => {
    setActivePDF(pdf);
    onSaveActivity('1ª Fase', `Lendo: ${pdf.title}`, 'disc-' + selectedDiscipline?.id, pdf.id);
  };

  const handleQuizAnswer = (qId: string, optionIdx: number) => {
    if (quizAnswers[qId] !== undefined) return; // already answered
    setQuizAnswers(prev => ({ ...prev, [qId]: optionIdx }));
    setShowExplanation(prev => ({ ...prev, [qId]: true }));
  };

  // Get icons for disciplines
  const getDiscIcon = (iconName: string) => {
    const props = { className: "h-5 w-5 shrink-0" };
    switch (iconName) {
      case 'ShieldAlert': return <ShieldAlert {...props} className="h-5 w-5 text-amber-600 shrink-0" />;
      case 'BookOpen': return <BookOpen {...props} className="h-5 w-5 text-blue-600 shrink-0" />;
      case 'Building': return <Building {...props} className="h-5 w-5 text-indigo-600 shrink-0" />;
      case 'Users': return <Users {...props} className="h-5 w-5 text-teal-600 shrink-0" />;
      case 'Scale': return <Scale {...props} className="h-5 w-5 text-violet-600 shrink-0" />;
      case 'FolderClosed': return <FolderClosed {...props} className="h-5 w-5 text-orange-600 shrink-0" />;
      case 'Briefcase': return <Briefcase {...props} className="h-5 w-5 text-emerald-600 shrink-0" />;
      case 'Gavel': return <Gavel {...props} className="h-5 w-5 text-sky-600 shrink-0" />;
      case 'Coins': return <Coins {...props} className="h-5 w-5 text-yellow-600 shrink-0" />;
      case 'Receipt': return <Receipt {...props} className="h-5 w-5 text-pink-600 shrink-0" />;
      case 'Heart': return <Heart {...props} className="h-5 w-5 text-rose-600 shrink-0" />;
      case 'Baby': return <Baby {...props} className="h-5 w-5 text-amber-500 shrink-0" />;
      case 'ShoppingBag': return <ShoppingBag {...props} className="h-5 w-5 text-cyan-600 shrink-0" />;
      case 'Leaf': return <Leaf {...props} className="h-5 w-5 text-green-600 shrink-0" />;
      case 'Globe': return <Globe {...props} className="h-5 w-5 text-blue-500 shrink-0" />;
      case 'Brain': return <Brain {...props} className="h-5 w-5 text-purple-600 shrink-0" />;
      case 'HeartHandshake': return <HeartHandshake {...props} className="h-5 w-5 text-red-500 shrink-0" />;
      case 'PiggyBank': return <PiggyBank {...props} className="h-5 w-5 text-lime-600 shrink-0" />;
      default: return <BookOpen {...props} className="h-5 w-5 text-slate-500 shrink-0" />;
    }
  };

  // Stats Calculations
  const calculateDisciplineStats = (disc: EnrichedDiscipline) => {
    const totalLectures = disc.lectures.length;
    const totalPDFs = disc.pdfs.length;
    const totalItems = totalLectures + totalPDFs;
    
    const compLectures = disc.lectures.filter(l => progress.completedLectures.includes(l.id)).length;
    const compPDFs = disc.pdfs.filter(p => progress.completedPDFs.includes(p.id)).length;
    const completedItems = compLectures + compPDFs;
    
    const percentage = totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;
    
    // Performance in questions for this discipline
    const solvedQuestions = Object.entries(progress.answeredQuestions).filter(([qId, q]) => {
      // Find if question belongs to this discipline name
      const foundQ = Object.values(PHASE1_QUESTIONS).flat().find(item => item.id === qId);
      return foundQ && foundQ.discipline === disc.name;
    });
    const correctQuestions = solvedQuestions.filter(([_, q]) => q.isCorrect).length;
    const performanceRate = solvedQuestions.length > 0 ? Math.round((correctQuestions / solvedQuestions.length) * 100) : 0;

    return {
      percentage,
      totalLectures,
      totalPDFs,
      compLectures,
      compPDFs,
      solvedQuestionsCount: solvedQuestions.length,
      performanceRate
    };
  };

  // General Phase 1 progress (aggregated across all 19 disciplines)
  const totalLecturesAll = FULL_DISCIPLINES.reduce((acc, d) => acc + d.lectures.length, 0);
  const totalPDFsAll = FULL_DISCIPLINES.reduce((acc, d) => acc + d.pdfs.length, 0);
  const totalCompletedLecturesAll = progress.completedLectures.length;
  const totalCompletedPDFsAll = progress.completedPDFs.length;
  
  const overallProgressPercent = Math.min(
    100,
    totalLecturesAll + totalPDFsAll > 0
      ? Math.round(((totalCompletedLecturesAll + totalCompletedPDFsAll) / (totalLecturesAll + totalPDFsAll)) * 100)
      : 0
  );

  const totalAnsweredQuestions = Object.keys(progress.answeredQuestions).length;
  const totalCorrectQuestions = Object.values(progress.answeredQuestions).filter(q => q.isCorrect).length;
  const averageAccuracyPercent = totalAnsweredQuestions > 0 ? Math.round((totalCorrectQuestions / totalAnsweredQuestions) * 100) : 0;

  // Study continuity: find the first incomplete lecture in strategic order
  const getNextRecommendedClass = () => {
    // Sort disciplines by strategic order
    const sortedDiscs = [...FULL_DISCIPLINES].sort((a, b) => a.recommendedOrder - b.recommendedOrder);
    for (const disc of sortedDiscs) {
      for (const lec of disc.lectures) {
        if (!progress.completedLectures.includes(lec.id)) {
          return { discipline: disc, lecture: lec };
        }
      }
    }
    return { discipline: FULL_DISCIPLINES[0], lecture: FULL_DISCIPLINES[0].lectures[0] };
  };

  const recommendation = getNextRecommendedClass();

  // Find all pending reviews in disciplines
  const getAllPendingReviews = () => {
    const list: { discipline: EnrichedDiscipline; review: any }[] = [];
    FULL_DISCIPLINES.forEach(d => {
      d.reviews.forEach(r => {
        if (r.status === 'pendente' || r.status === 'atrasado') {
          list.push({ discipline: d, review: r });
        }
      });
    });
    return list;
  };

  const pendingReviews = getAllPendingReviews();

  // Categorize disciplines by Strategic Value (Strategic: Weight >= 5 questions, Complementary: Weight = 2 questions)
  const strategicDisciplines = FULL_DISCIPLINES.filter(d => d.importance === 'Muito Alta' || d.importance === 'Alta');
  const complementaryDisciplines = FULL_DISCIPLINES.filter(d => d.importance === 'Média');

  // Interactive Review Session
  const handleStartReview = (title: string, discId: string) => {
    const discQuestions = PHASE1_QUESTIONS[discId] || PHASE1_QUESTIONS["disc-etica"];
    if (!discQuestions || discQuestions.length === 0) {
      alert("Questões de revisão rápida sendo preparadas para esta matéria. Pratique nas videoaulas!");
      return;
    }
    setActiveReviewItem({
      id: `rev-${discId}-${Date.now()}`,
      title: `Revisão Ativa: ${title}`,
      questions: discQuestions,
      currentIndex: 0,
      answers: {},
      completed: false
    });
    setActiveSimulado(null);
  };

  const handleReviewAnswer = (optionIdx: number) => {
    if (!activeReviewItem) return;
    const currentQ = activeReviewItem.questions[activeReviewItem.currentIndex];
    
    // Save locally in active view
    setActiveReviewItem(prev => {
      if (!prev) return null;
      return {
        ...prev,
        answers: { ...prev.answers, [currentQ.id]: optionIdx }
      };
    });
  };

  const handleNextReviewQuestion = () => {
    if (!activeReviewItem) return;
    if (activeReviewItem.currentIndex < activeReviewItem.questions.length - 1) {
      setActiveReviewItem(prev => {
        if (!prev) return null;
        return { ...prev, currentIndex: prev.currentIndex + 1 };
      });
    } else {
      setActiveReviewItem(prev => {
        if (!prev) return null;
        return { ...prev, completed: true };
      });
    }
  };

  // Interactive Mini Simulado
  const handleStartSimulado = (sim: any, discId: string) => {
    const discQuestions = PHASE1_QUESTIONS[discId] || PHASE1_QUESTIONS["disc-etica"];
    if (!discQuestions || discQuestions.length === 0) {
      alert("Este simulado está sendo configurado. Tente o simulado geral de Ética ou Constitucional!");
      return;
    }
    setActiveSimulado({
      id: sim.id,
      title: sim.title,
      questions: discQuestions,
      currentIndex: 0,
      answers: {},
      timeRemaining: sim.timeLimitMinutes * 60,
      completed: false
    });
    setActiveReviewItem(null);
  };

  const handleSimuladoAnswer = (optionIdx: number) => {
    if (!activeSimulado || activeSimulado.completed) return;
    const currentQ = activeSimulado.questions[activeSimulado.currentIndex];
    setActiveSimulado(prev => {
      if (!prev) return null;
      return {
        ...prev,
        answers: { ...prev.answers, [currentQ.id]: optionIdx }
      };
    });
  };

  const handleNextSimuladoQuestion = () => {
    if (!activeSimulado) return;
    if (activeSimulado.currentIndex < activeSimulado.questions.length - 1) {
      setActiveSimulado(prev => {
        if (!prev) return null;
        return { ...prev, currentIndex: prev.currentIndex + 1 };
      });
    } else {
      handleCompleteSimulado();
    }
  };

  const handleCompleteSimulado = () => {
    setActiveSimulado(prev => {
      if (!prev) return null;
      return { ...prev, completed: true };
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div id="phase1-container" className="space-y-8 font-sans pb-12">
      
      {/* 1. Header / Navigation Back Trigger */}
      {selectedDiscipline ? (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center justify-between bg-white p-5 rounded-2xl border border-slate-100 shadow-sm gap-4"
        >
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setSelectedDiscipline(null)}
              className="p-2 hover:bg-slate-50 border border-slate-200 rounded-xl transition-all cursor-pointer shadow-sm hover:scale-105 active:scale-95"
              id="btn-back-to-disciplines"
            >
              <ArrowLeft className="h-5 w-5 text-slate-600" />
            </button>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] uppercase font-black text-amber-600 tracking-wider bg-amber-50 px-2 py-0.5 rounded-md">
                  Ambiente de Preparação (1ª Fase)
                </span>
                <span className={`
                  text-[9px] font-bold px-2 py-0.5 rounded-full uppercase
                  ${selectedDiscipline.importance === 'Muito Alta' ? 'bg-red-50 text-red-600 border border-red-100' : selectedDiscipline.importance === 'Alta' ? 'bg-amber-50 text-amber-700 border border-amber-100' : 'bg-slate-100 text-slate-600'}
                `}>
                  Relevância: {selectedDiscipline.importance}
                </span>
              </div>
              <h2 className="text-xl font-extrabold text-slate-800 flex items-center gap-2 mt-1">
                {getDiscIcon(selectedDiscipline.icon)}
                {selectedDiscipline.name}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-4 text-right bg-slate-50/50 px-4 py-2.5 rounded-xl border border-slate-100">
            <div className="border-r border-slate-200 pr-4">
              <span className="block text-[9px] uppercase font-bold text-slate-400">Questões na Prova</span>
              <span className="text-sm font-black text-slate-800">{selectedDiscipline.totalQuestions} questões</span>
            </div>
            <div>
              <span className="block text-[9px] uppercase font-bold text-slate-400">Aproveitamento</span>
              <span className="text-sm font-black text-slate-800">{calculateDisciplineStats(selectedDiscipline).performanceRate}% acertos</span>
            </div>
          </div>
        </motion.div>
      ) : (
        /* Intro Title and Banner */
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 space-y-2">
          <div className="flex items-center space-x-2">
            <span className="p-2 bg-amber-50 rounded-xl text-amber-600">
              <Award className="h-6 w-6" />
            </span>
            <div>
              <h1 className="text-2xl font-black text-slate-800 tracking-tight">OAB 3F — Área da 1ª Fase</h1>
              <p className="text-xs text-slate-400 mt-0.5 font-medium uppercase tracking-wider">Método científico focado na aprovação objetiva</p>
            </div>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed max-w-3xl pt-1">
            Plataforma pedagógica completa para a Prova Objetiva. Estude as 19 disciplinas divididas por grau de incidência na prova da FGV. Assista às videoaulas direcionadas, leia a lei seca mapeada nos PDFs de apoio, treine com questões reais justificadas e realize mini simulados cronometrados.
          </p>
        </div>
      )}

      {/* NO DISCIPLINE SELECTED: SHOW DASHBOARD OVERVIEW & SYLLABUS LIST */}
      {!selectedDiscipline ? (
        <div className="space-y-8">
          
          {/* SEÇÃO 1 — Visão geral da 1ª fase (Student Dashboard) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="dashboard-overview-container">
            
            {/* Box 1: Overall Progress & Performance Metrics */}
            <div className="lg:col-span-4 bg-white rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center justify-between">
                  <span>Progresso Geral da Fase</span>
                  <Layers className="h-4 w-4 text-slate-400" />
                </h3>
                
                <div className="space-y-2 pt-1">
                  <div className="flex justify-between items-baseline">
                    <span className="text-3xl font-black text-slate-800 tracking-tight">{overallProgressPercent}%</span>
                    <span className="text-xs text-slate-400 font-bold">{totalCompletedLecturesAll + totalCompletedPDFsAll} de {totalLecturesAll + totalPDFsAll} metas</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-amber-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${overallProgressPercent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Grid of micro numbers */}
              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-100">
                <div className="bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Aulas Concluídas</span>
                  <span className="text-lg font-black text-slate-800">{totalCompletedLecturesAll}</span>
                </div>
                <div className="bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Média Acertos</span>
                  <span className="text-lg font-black text-slate-800 text-emerald-600">{averageAccuracyPercent}%</span>
                </div>
                <div className="bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Questões Feitas</span>
                  <span className="text-lg font-black text-slate-800">{totalAnsweredQuestions}</span>
                </div>
                <div className="bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Disciplinas Totais</span>
                  <span className="text-lg font-black text-slate-800">19</span>
                </div>
              </div>
            </div>

            {/* Box 2: Study Continuity - Continue where I left off */}
            <div className="lg:col-span-5 bg-white rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                    <Play className="h-3.5 w-3.5 text-amber-500" />
                    <span>Continuar de Onde Parei</span>
                  </h3>
                  <span className="text-[9px] font-extrabold uppercase tracking-widest text-amber-600 bg-amber-50 px-2 py-0.5 rounded">Recomendado</span>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2 mt-2">
                  <div className="flex items-center space-x-2">
                    {getDiscIcon(recommendation.discipline.icon)}
                    <span className="text-xs font-bold text-slate-500">{recommendation.discipline.name}</span>
                  </div>
                  <h4 className="text-sm font-extrabold text-slate-800 leading-snug">{recommendation.lecture.title}</h4>
                  <p className="text-[11px] text-slate-400 font-medium line-clamp-2 leading-relaxed">{recommendation.lecture.summary}</p>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-between border-t border-slate-100">
                <div className="flex items-center text-xs text-slate-400 font-semibold gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  <span>Duração: {recommendation.lecture.duration} min</span>
                </div>
                <button
                  onClick={() => handleDisciplineSelect(recommendation.discipline)}
                  className="bg-slate-800 hover:bg-slate-950 text-white font-extrabold text-xs px-4 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <span>Estudar Agora</span>
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Box 3: Reviews & Simulated Exams Pending */}
            <div className="lg:col-span-3 bg-white rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col justify-between">
              <div className="space-y-4">
                <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center justify-between">
                  <span>Simulado & Revisões</span>
                  <Calendar className="h-4 w-4 text-slate-400" />
                </h3>

                <div className="space-y-3 pt-1">
                  {/* Countdown OAB */}
                  <div className="bg-red-50/50 p-3 rounded-xl border border-red-100 flex items-center justify-between">
                    <div>
                      <span className="text-[9px] uppercase font-extrabold text-red-600 block tracking-wider">Contagem Regressiva</span>
                      <span className="text-xs font-extrabold text-red-800">Próxima Prova OAB</span>
                    </div>
                    <span className="text-xl font-black text-red-700">52 dias</span>
                  </div>

                  {/* Reviews Pending Counter */}
                  <div className="bg-amber-50/50 p-3 rounded-xl border border-amber-100 flex items-center justify-between">
                    <div>
                      <span className="text-[9px] uppercase font-extrabold text-amber-700 block tracking-wider">Revisões Programadas</span>
                      <span className="text-xs font-extrabold text-amber-800">Estudo Espaçado</span>
                    </div>
                    <span className="text-xl font-black text-amber-700">
                      {pendingReviews.length} pendentes
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end">
                <button
                  onClick={() => {
                    // Quick jump to first pending review discipline if available
                    if (pendingReviews.length > 0) {
                      handleDisciplineSelect(pendingReviews[0].discipline);
                      setTimeout(() => setActiveSubTab('revisoes'), 100);
                    } else {
                      handleDisciplineSelect(FULL_DISCIPLINES[0]);
                    }
                  }}
                  className="text-amber-700 hover:text-amber-900 font-extrabold text-xs flex items-center gap-1 cursor-pointer"
                >
                  <span>Acessar revisões</span>
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>

          </div>

          {/* SEÇÃO 2 — Lista de disciplinas da 1ª fase (Syllabus List) */}
          <div className="space-y-6">
            
            {/* Dynamic layout message for strategic priority */}
            <div className="bg-amber-50/50 border border-amber-100 p-4 rounded-2xl flex items-start space-x-3 text-xs text-amber-800 leading-relaxed">
              <Info className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <strong>Recomendação Pedagógica OAB 3F:</strong> Priorize as <strong>Disciplinas Estratégicas</strong>. Elas correspondem a mais de 73% das questões cobradas na primeira fase (Ethics, Constitutional, Administrative, Civil, Civil Procedure, Penal, Penal Procedure, Labor, Labor Procedure). Garantir um bom aproveitamento nelas é o segredo para ultrapassar os 40 pontos necessários.
              </div>
            </div>

            {/* STRATEGIC DISCIPLINES (HIGH WEIGHT) */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-red-500" />
                  Disciplinas Estratégicas (Alta Incidência — Peso Importante)
                </h3>
                <span className="text-[10px] text-red-600 font-bold bg-red-50 px-2.5 py-0.5 rounded-full border border-red-100">Foco Principal</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {strategicDisciplines.map((disc) => {
                  const stats = calculateDisciplineStats(disc);
                  
                  return (
                    <motion.div
                      key={disc.id}
                      onClick={() => handleDisciplineSelect(disc)}
                      className="bg-white rounded-2xl p-5 border border-slate-100 hover:border-slate-200 shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer flex flex-col justify-between group"
                      whileHover={{ y: -3 }}
                    >
                      <div className="space-y-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="p-3 bg-slate-50 rounded-xl group-hover:bg-amber-50 group-hover:text-amber-700 transition-colors">
                              {getDiscIcon(disc.icon)}
                            </div>
                            <div>
                              <h4 className="font-extrabold text-slate-800 text-sm group-hover:text-amber-700 transition-colors">
                                {disc.name}
                              </h4>
                              <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                                {disc.totalQuestions} questões no exame
                              </p>
                            </div>
                          </div>
                          
                          {/* Metas count */}
                          <span className="text-[10px] text-slate-400 font-bold bg-slate-50 px-2 py-0.5 rounded-md">
                            {stats.compLectures}/{stats.totalLectures} aulas
                          </span>
                        </div>

                        {/* Progress Bar */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[10px] text-slate-400 font-bold">
                            <span>Conclusão da matéria</span>
                            <span>{stats.percentage}%</span>
                          </div>
                          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                            <div 
                              className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                              style={{ width: `${stats.percentage}%` }}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-50 text-[11px] text-slate-400 font-bold">
                        <div className="flex gap-2">
                          <span className="text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">{stats.solvedQuestionsCount} resolvidas</span>
                          {stats.performanceRate > 0 && (
                            <span className="text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">{stats.performanceRate}% acertos</span>
                          )}
                        </div>
                        <span className="text-amber-600 flex items-center group-hover:translate-x-1 transition-transform">
                          Estudar <ChevronRight className="h-3.5 w-3.5 ml-0.5" />
                        </span>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* COMPLEMENTARY DISCIPLINES (LOWER WEIGHT) */}
            <div className="space-y-4 pt-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-slate-400" />
                  Disciplinas Complementares (Peso Regular)
                </h3>
                <span className="text-[10px] text-slate-500 font-bold bg-slate-100 px-2.5 py-0.5 rounded-full">Consolidação</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {complementaryDisciplines.map((disc) => {
                  const stats = calculateDisciplineStats(disc);
                  
                  return (
                    <motion.div
                      key={disc.id}
                      onClick={() => handleDisciplineSelect(disc)}
                      className="bg-white rounded-2xl p-4 border border-slate-100 hover:border-slate-200 shadow-sm hover:shadow duration-300 cursor-pointer flex flex-col justify-between group"
                      whileHover={{ y: -2 }}
                    >
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2.5">
                            <div className="p-2 bg-slate-50 rounded-lg group-hover:bg-amber-50 transition-colors">
                              {getDiscIcon(disc.icon)}
                            </div>
                            <div>
                              <h4 className="font-extrabold text-slate-800 text-xs group-hover:text-amber-700 transition-colors">
                                {disc.name}
                              </h4>
                              <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">
                                {disc.totalQuestions} questões no exame
                              </p>
                            </div>
                          </div>

                          <span className="text-[9px] text-slate-400 font-semibold">
                            {stats.compLectures}/{stats.totalLectures} aulas
                          </span>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                          <div 
                            className="bg-slate-400 h-full rounded-full transition-all duration-300"
                            style={{ width: `${stats.percentage}%` }}
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-50 text-[10px] text-slate-400 font-semibold">
                        <span>{stats.percentage}% concluído</span>
                        <span className="text-slate-500 group-hover:translate-x-0.5 transition-transform flex items-center">
                          Acessar <ChevronRight className="h-3 w-3 ml-0.5" />
                        </span>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

          </div>

        </div>
      ) : (
        /* DISCIPLINE SELECTED: IMMERSIVE MODULE-BASED CLASSROOM SYLLABUS */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="classroom-layout-container">
          
          {/* Left Column (Academic navigation: modules, classes, quizzes, materials, reviews) */}
          <div className="lg:col-span-4 bg-white rounded-2xl p-5 border border-slate-100 shadow-sm h-fit space-y-6">
            
            {/* Bloco A & B — Header Module selector */}
            <div className="space-y-3">
              <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                <Layers className="h-4 w-4 text-slate-400" />
                <span>Trilhas / Módulos</span>
              </h3>
              
              {/* Module Dropdown or list */}
              <div className="space-y-1.5 max-h-[180px] overflow-y-auto pr-1">
                <button
                  onClick={() => setSelectedModule("all")}
                  className={`
                    w-full text-left px-3 py-2 rounded-xl text-xs font-extrabold transition-all flex items-center justify-between cursor-pointer
                    ${selectedModule === "all" ? "bg-amber-600 text-white" : "bg-slate-50 hover:bg-slate-100 text-slate-600"}
                  `}
                >
                  <span>Todos os Módulos</span>
                  <span className="text-[10px] opacity-80">{selectedDiscipline.lectures.length} aulas</span>
                </button>
                {selectedDiscipline.modules.map((mod) => {
                  return (
                    <button
                      key={mod.id}
                      onClick={() => setSelectedModule(mod.id)}
                      className={`
                        w-full text-left px-3 py-2 rounded-xl text-xs font-bold transition-all flex flex-col cursor-pointer
                        ${selectedModule === mod.id ? "bg-slate-800 text-white" : "bg-slate-50 hover:bg-slate-100 text-slate-600"}
                      `}
                    >
                      <span className="font-extrabold">{mod.title}</span>
                      <span className={`text-[9px] mt-0.5 ${selectedModule === mod.id ? "text-slate-300" : "text-slate-400"}`}>{mod.description}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Vertical Sub-tab workspaces */}
            <div className="space-y-3 pt-4 border-t border-slate-100">
              <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                Áreas de Trabalho
              </h3>
              
              <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-1 gap-2" id="classroom-subtabs">
                <button
                  onClick={() => { setActiveSubTab('aulas'); setActiveReviewItem(null); setActiveSimulado(null); }}
                  className={`
                    py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2
                    ${activeSubTab === 'aulas' ? 'bg-amber-50 text-amber-800 border border-amber-200' : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-transparent'}
                  `}
                >
                  <Video className="h-4 w-4 text-amber-600" />
                  <span>Videoaulas</span>
                </button>
                <button
                  onClick={() => { setActiveSubTab('pdfs'); setActiveReviewItem(null); setActiveSimulado(null); }}
                  className={`
                    py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2
                    ${activeSubTab === 'pdfs' ? 'bg-blue-50 text-blue-800 border border-blue-200' : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-transparent'}
                  `}
                >
                  <FileText className="h-4 w-4 text-blue-600" />
                  <span>Materiais</span>
                </button>
                <button
                  onClick={() => { setActiveSubTab('questoes'); setActiveReviewItem(null); setActiveSimulado(null); }}
                  className={`
                    py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2
                    ${activeSubTab === 'questoes' ? 'bg-indigo-50 text-indigo-800 border border-indigo-200' : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-transparent'}
                  `}
                >
                  <BookOpenCheck className="h-4 w-4 text-indigo-600" />
                  <span>Quizzes</span>
                </button>
                <button
                  onClick={() => { setActiveSubTab('revisoes'); setActiveReviewItem(null); setActiveSimulado(null); }}
                  className={`
                    py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2
                    ${activeSubTab === 'revisoes' ? 'bg-rose-50 text-rose-800 border border-rose-200' : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-transparent'}
                  `}
                >
                  <CheckSquare className="h-4 w-4 text-rose-600" />
                  <span>Revisões</span>
                </button>
                <button
                  onClick={() => { setActiveSubTab('simulados'); setActiveReviewItem(null); setActiveSimulado(null); }}
                  className={`
                    py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2
                    ${activeSubTab === 'simulados' ? 'bg-purple-50 text-purple-800 border border-purple-200' : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-transparent'}
                  `}
                >
                  <Timer className="h-4 w-4 text-purple-600" />
                  <span>Simulados</span>
                </button>
              </div>
            </div>

            {/* List items depending on selected tab */}
            <div className="space-y-3 pt-4 border-t border-slate-100 max-h-[300px] overflow-y-auto pr-1">
              
              {/* Classes list */}
              {activeSubTab === 'aulas' && (
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-black text-slate-400">Aulas Disponíveis</span>
                  {selectedDiscipline.lectures.map((lecture) => {
                    const isCompleted = progress.completedLectures.includes(lecture.id);
                    const isActive = activeLecture?.id === lecture.id;
                    return (
                      <div
                        key={lecture.id}
                        onClick={() => handleLectureSelect(lecture)}
                        className={`
                          p-2.5 rounded-xl border transition-all cursor-pointer flex items-start gap-2.5
                          ${isActive 
                            ? 'bg-slate-800 border-slate-900 text-white' 
                            : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                          }
                        `}
                      >
                        <div className="mt-0.5">
                          {isCompleted ? (
                            <CheckCircle className="h-4 w-4 text-emerald-500 fill-white shrink-0" />
                          ) : (
                            <Play className={`h-4 w-4 shrink-0 ${isActive ? 'text-amber-500' : 'text-slate-400'}`} />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xs font-extrabold truncate">{lecture.title}</h4>
                          <span className={`text-[9px] block mt-0.5 ${isActive ? 'text-slate-300' : 'text-slate-400'}`}>
                            Duração: {lecture.duration} min
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Material PDFs list */}
              {activeSubTab === 'pdfs' && (
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-black text-slate-400">PDFs Acadêmicos</span>
                  {selectedDiscipline.pdfs.map((pdf) => {
                    const isCompleted = progress.completedPDFs.includes(pdf.id);
                    const isActive = activePDF?.id === pdf.id;
                    return (
                      <div
                        key={pdf.id}
                        onClick={() => handlePDFSelect(pdf)}
                        className={`
                          p-2.5 rounded-xl border transition-all cursor-pointer flex items-start gap-2.5
                          ${isActive 
                            ? 'bg-slate-800 border-slate-900 text-white' 
                            : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                          }
                        `}
                      >
                        <div className="mt-0.5">
                          {isCompleted ? (
                            <CheckCircle className="h-4 w-4 text-emerald-500 fill-white shrink-0" />
                          ) : (
                            <FileText className={`h-4 w-4 shrink-0 ${isActive ? 'text-blue-400' : 'text-slate-400'}`} />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xs font-extrabold truncate">{pdf.title}</h4>
                          <span className={`text-[9px] block mt-0.5 ${isActive ? 'text-slate-300' : 'text-slate-400'}`}>
                            Apoio • {pdf.pageCount} pág.
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Quizzes overview in sidebar */}
              {activeSubTab === 'questoes' && (
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-150 text-center space-y-2">
                  <BookOpenCheck className="h-8 w-8 text-indigo-600 mx-auto" />
                  <h4 className="text-xs font-bold text-slate-700">Quiz da Disciplina</h4>
                  <p className="text-[10px] text-slate-400">
                    Bateria de questões históricas justificadas focadas em {selectedDiscipline.name}.
                  </p>
                </div>
              )}

              {/* Reviews count in sidebar */}
              {activeSubTab === 'revisoes' && (
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-black text-slate-400">Agenda de Revisões</span>
                  {selectedDiscipline.reviews.map((rev) => {
                    return (
                      <div
                        key={rev.id}
                        className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                      >
                        <div className="space-y-0.5">
                          <span className="font-extrabold block text-slate-700">{rev.title}</span>
                          <span className="text-[9px] uppercase font-bold text-slate-400">Tipo: {rev.type}</span>
                        </div>
                        <span className={`
                          text-[8px] font-black uppercase px-2 py-0.5 rounded-full
                          ${rev.status === 'em_dia' ? 'bg-emerald-100 text-emerald-800' : rev.status === 'pendente' ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800'}
                        `}>
                          {rev.status === 'em_dia' ? 'Em dia' : rev.status === 'pendente' ? 'Pendente' : 'Atrasado'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Mini-Simulados in sidebar */}
              {activeSubTab === 'simulados' && (
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-black text-slate-400">Simulados Cadastrados</span>
                  {selectedDiscipline.miniSimulados.map((sim) => {
                    return (
                      <div
                        key={sim.id}
                        className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                      >
                        <div className="space-y-0.5">
                          <span className="font-extrabold block text-slate-700 truncate max-w-[150px]">{sim.title}</span>
                          <span className="text-[9px] text-slate-400 font-semibold">{sim.totalQuestions} questões • {sim.timeLimitMinutes} min</span>
                        </div>
                        <span className={`text-[8.5px] font-bold ${sim.completed ? 'text-emerald-600' : 'text-slate-400'}`}>
                          {sim.completed ? 'Feito' : 'Disponível'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}

            </div>

          </div>

          {/* Right Column (Primary Classroom workspace display) */}
          <div className="lg:col-span-8 bg-white rounded-2xl p-6 border border-slate-100 shadow-sm" id="classroom-player-panel">
            
            {/* SUBTAB: LECTURES (VIDEOAULAS) */}
            {activeSubTab === 'aulas' && activeLecture && (
              <div className="space-y-6">
                
                {/* VIDEO PLAYER COMPONENT */}
                <div className="w-full bg-slate-900 aspect-video rounded-2xl relative overflow-hidden flex flex-col justify-between border border-slate-950 shadow-lg">
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />
                  
                  {/* Watermark/Static backdrop info */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center select-none">
                    <div className="bg-amber-600/25 border border-amber-500/40 text-amber-500 rounded-full p-4 hover:scale-105 active:scale-95 transition-all cursor-pointer">
                      <Play className="h-8 w-8 fill-current text-amber-500" />
                    </div>
                    <span className="text-white text-xs font-extrabold mt-3 bg-black/60 px-4 py-1 rounded-full border border-white/10 shadow-sm">
                      Clique para iniciar a videoaula do OAB 3F
                    </span>
                    <span className="text-[10px] text-slate-400 mt-1 uppercase font-bold tracking-wider">
                      {selectedDiscipline.name} • {activeLecture.duration} Minutos
                    </span>
                  </div>

                  {/* Player controls */}
                  <div className="relative z-10 flex items-center justify-between text-slate-300 text-xs mt-auto pt-4 bg-gradient-to-t from-slate-950 to-transparent p-4">
                    <span className="font-mono text-[10px]">0:00 / {activeLecture.duration}</span>
                    <div className="flex-1 mx-4 bg-slate-800 h-1 rounded-full overflow-hidden">
                      <div className="bg-amber-600 h-full w-[25%]" />
                    </div>
                    <span className="text-[9px] bg-slate-800 px-2 py-0.5 rounded font-bold">FULL HD</span>
                  </div>
                </div>

                {/* Class Info and Toggle metagoal */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                  <div className="space-y-1">
                    <span className="text-[9px] uppercase font-black text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">Próxima Aula</span>
                    <h3 className="text-lg font-black text-slate-800 leading-tight">{activeLecture.title}</h3>
                    <p className="text-xs text-slate-400 font-medium">Recomendado para gabaritar o Exame de Ordem</p>
                  </div>

                  <button
                    onClick={() => {
                      onToggleLecture(activeLecture.id);
                    }}
                    className={`
                      px-5 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-sm
                      ${progress.completedLectures.includes(activeLecture.id)
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-amber-600 hover:bg-amber-700 text-white'
                      }
                    `}
                  >
                    <CheckCircle className="h-4.5 w-4.5" />
                    <span>
                      {progress.completedLectures.includes(activeLecture.id) ? 'Aula Concluída' : 'Marcar como Assistida'}
                    </span>
                  </button>
                </div>

                {/* Bloco D: Materiais de Apoio under video */}
                <div className="space-y-3">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Resumo Pedagógico da Aula</h4>
                  <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 text-xs text-slate-600 leading-relaxed space-y-2">
                    <p>{activeLecture.summary}</p>
                    <p className="font-bold text-slate-700 pt-1">O que a banca FGV costuma cobrar sobre este assunto:</p>
                    <ul className="list-disc pl-5 space-y-1 text-slate-500 font-medium">
                      <li>A contextualização de casos práticos e resolução hipotética de litígios.</li>
                      <li>Incisos específicos da legislação seca mapeados no seu material em PDF.</li>
                      <li>Pontos de divergência jurisprudencial sumulada do STF e STJ.</li>
                    </ul>
                  </div>
                </div>

              </div>
            )}

            {/* SUBTAB: MATERIALS (PDFS) */}
            {activeSubTab === 'pdfs' && activePDF && (
              <div className="space-y-6">
                
                {/* PDF Reader Container Frame */}
                <div className="border border-slate-200 rounded-2xl overflow-hidden bg-slate-50 flex flex-col min-h-[400px] shadow-sm">
                  
                  {/* Action Bar */}
                  <div className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between text-xs text-slate-600">
                    <span className="font-extrabold flex items-center gap-1.5">
                      <FileText className="h-4.5 w-4.5 text-red-500" />
                      {activePDF.title} ({activePDF.pageCount} págs.)
                    </span>

                    <button
                      onClick={() => alert(`Material '${activePDF.title}' baixado simuladamente com sucesso.`)}
                      className="text-slate-500 hover:text-amber-600 flex items-center gap-1.5 font-bold cursor-pointer transition-colors"
                    >
                      <FileDown className="h-4 w-4" />
                      <span>Baixar PDF</span>
                    </button>
                  </div>

                  {/* Text Container area */}
                  <div className="p-6 bg-white flex-1 overflow-y-auto max-h-[300px] text-slate-700 text-xs leading-relaxed space-y-4">
                    <div className="border-b border-dashed border-slate-200 pb-4">
                      <span className="text-[10px] uppercase font-black text-amber-600 tracking-wider">OAB 3F Resumo Mapeado</span>
                      <h4 className="text-base font-black text-slate-800 uppercase mt-0.5">{selectedDiscipline.name}</h4>
                    </div>

                    <div className="space-y-3 font-sans">
                      <p className="font-extrabold text-slate-800 flex items-center gap-1">
                        <Check className="h-4 w-4 text-emerald-500" />
                        Anotações Críticas do Candidato:
                      </p>
                      <p className="bg-amber-50/50 p-4 rounded-xl border border-amber-100 text-slate-700 italic">
                        "{activePDF.summary}"
                      </p>
                      
                      <p className="font-bold text-slate-800 pt-2">Estrutura de Revisão Rápida (Lei Seca):</p>
                      <p>
                        Esta apostila foi elaborada por especialistas no exame de ordem. Use-a para complementar o estudo assistido. A leitura cuidadosa dos artigos correlatos e das súmulas vinculantes anexadas é imprescindível.
                      </p>
                      
                      <div className="grid grid-cols-2 gap-3 pt-2">
                        <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                          <span className="font-bold text-slate-800 block">Esquema 1: Mapa Mental</span>
                          <span className="text-[10px] text-slate-400">Verifique as competências na pág 3</span>
                        </div>
                        <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                          <span className="font-bold text-slate-800 block">Esquema 2: Tabela de Prazos</span>
                          <span className="text-[10px] text-slate-400">Regras de preclusão e decadência</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Read indicator toggle button */}
                  <div className="bg-slate-50 border-t border-slate-200 p-4 flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 font-bold">Caderno de Estudos OAB 3F</span>
                    <button
                      onClick={() => onTogglePDF(activePDF.id)}
                      className={`
                        px-4 py-2 rounded-xl text-xs font-extrabold transition-all cursor-pointer shadow-sm
                        ${progress.completedPDFs.includes(activePDF.id)
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-slate-800 text-white hover:bg-slate-900'
                        }
                      `}
                    >
                      {progress.completedPDFs.includes(activePDF.id) ? 'Marcar como Não Lido' : 'Confirmar Leitura'}
                    </button>
                  </div>

                </div>

              </div>
            )}

            {/* SUBTAB: QUIZZES (QUESTÕES) */}
            {activeSubTab === 'questoes' && (
              <div className="space-y-6">
                
                {/* Bloco E Header */}
                <div className="border-b border-slate-100 pb-4">
                  <h3 className="text-sm font-black uppercase text-slate-400 tracking-wider">Quizzes e Questões de Fixação</h3>
                  <p className="text-xs text-slate-500 mt-0.5 font-medium">Bateria de questões oficiais de exames de ordem passados, comentadas por especialistas.</p>
                </div>

                {/* Filter questions specifically for this discipline */}
                {(() => {
                  const disciplineQuestions = PHASE1_QUESTIONS[selectedDiscipline.id] || [];
                  
                  if (disciplineQuestions.length === 0) {
                    return (
                      <div className="text-center py-12 text-slate-400 text-xs border border-dashed border-slate-200 rounded-2xl p-6">
                        <HelpCircle className="h-10 w-10 text-slate-300 mx-auto mb-3" />
                        <p className="font-bold">Bateria de questões sendo processada para esta matéria!</p>
                        <p className="mt-1">Pratique utilizando os Quizzes em outras matérias como Ética e Constitucional para testar o sistema.</p>
                      </div>
                    );
                  }

                  return (
                    <div className="space-y-6">
                      {disciplineQuestions.map((q) => {
                        const isAnswered = quizAnswers[q.id] !== undefined;
                        const selectedOption = quizAnswers[q.id];
                        return (
                          <div key={q.id} className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-black text-amber-700 bg-amber-50 border border-amber-100 px-3 py-0.5 rounded-md">
                                {q.exam}
                              </span>
                              <span className={`
                                font-bold px-2 py-0.5 rounded-full uppercase text-[9px]
                                ${q.difficulty === 'Fácil' ? 'bg-emerald-50 text-emerald-700' : q.difficulty === 'Média' ? 'bg-amber-50 text-amber-700' : 'bg-red-50 text-red-700'}
                              `}>
                                Dificuldade: {q.difficulty}
                              </span>
                            </div>

                            <p className="text-xs text-slate-800 leading-relaxed font-semibold">
                              {q.statement}
                            </p>

                            <div className="space-y-2.5">
                              {q.options.map((opt, idx) => {
                                const isSelected = selectedOption === idx;
                                const isCorrect = q.correctIndex === idx;
                                let btnStyle = "bg-white border-slate-200 hover:border-slate-300 text-slate-700";

                                if (isAnswered) {
                                  if (isCorrect) {
                                    btnStyle = "bg-emerald-50 border-emerald-300 text-emerald-800 font-bold";
                                  } else if (isSelected) {
                                    btnStyle = "bg-red-50 border-red-300 text-red-800 font-medium";
                                  } else {
                                    btnStyle = "bg-white border-slate-100 text-slate-400 opacity-60";
                                  }
                                }

                                return (
                                  <button
                                    key={idx}
                                    onClick={() => handleQuizAnswer(q.id, idx)}
                                    disabled={isAnswered}
                                    className={`
                                      w-full text-left p-3 rounded-xl border text-xs transition-all duration-200 flex items-start gap-2.5
                                      ${btnStyle}
                                      ${!isAnswered ? 'cursor-pointer hover:scale-[1.01]' : 'cursor-default'}
                                    `}
                                  >
                                    <span className="font-mono font-black uppercase bg-slate-100 text-slate-600 rounded px-2 py-0.5 text-[9px] shrink-0 mt-0.5">
                                      {String.fromCharCode(65 + idx)}
                                    </span>
                                    <span>{opt}</span>
                                  </button>
                                );
                              })}
                            </div>

                            {showExplanation[q.id] && (
                              <motion.div 
                                initial={{ opacity: 0, y: 5 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="bg-white p-4 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-2 mt-4"
                              >
                                <p className="font-black text-slate-800 flex items-center gap-1">
                                  <CheckCircle className="h-4.5 w-4.5 text-emerald-500" />
                                  Gabarito Comentado (Justificativa):
                                </p>
                                <p className="leading-relaxed font-medium">
                                  {q.explanation}
                                </p>
                              </motion.div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}

              </div>
            )}

            {/* SUBTAB: REVIEWS (REVISÕES) */}
            {activeSubTab === 'revisoes' && (
              <div className="space-y-6">
                
                {/* Bloco F Header */}
                <div className="border-b border-slate-100 pb-4">
                  <h3 className="text-sm font-black uppercase text-slate-400 tracking-wider">Revisão Inteligente da Matéria</h3>
                  <p className="text-xs text-slate-500 mt-0.5 font-medium">Use a repetição espaçada (24h, 7d, 30d e erros) para nunca esquecer o que estudou.</p>
                </div>

                {!activeReviewItem ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {selectedDiscipline.reviews.map((rev) => {
                      return (
                        <div 
                          key={rev.id} 
                          className="bg-slate-50 border border-slate-200 rounded-2xl p-5 flex flex-col justify-between space-y-4"
                        >
                          <div className="space-y-1.5">
                            <span className="text-[9px] uppercase font-black text-slate-400 tracking-widest block">Revisão Programada</span>
                            <h4 className="text-sm font-black text-slate-800">{rev.title}</h4>
                            <div className="flex gap-2 pt-1">
                              <span className="text-[9px] font-bold bg-amber-50 text-amber-700 px-2 py-0.5 rounded uppercase border border-amber-100">Roteiro: {rev.type}</span>
                              <span className="text-[9px] font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded">{rev.dueDate}</span>
                            </div>
                          </div>

                          <button
                            onClick={() => handleStartReview(rev.title, selectedDiscipline.id)}
                            className="w-full bg-slate-800 hover:bg-slate-900 text-white font-extrabold text-xs py-2 rounded-xl transition-all cursor-pointer shadow-sm text-center"
                          >
                            Revisar Agora
                          </button>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  /* Interactive review recall session active */
                  <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 space-y-6">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                      <div>
                        <span className="text-[9px] uppercase font-black text-amber-600 tracking-wider">Sessão Ativa de Recordação</span>
                        <h4 className="text-sm font-black text-slate-800">{activeReviewItem.title}</h4>
                      </div>
                      <button
                        onClick={() => setActiveReviewItem(null)}
                        className="text-xs text-slate-500 hover:text-slate-800 font-bold"
                      >
                        Encerrar
                      </button>
                    </div>

                    {!activeReviewItem.completed ? (
                      <div className="space-y-4">
                        <div className="flex justify-between items-center text-xs text-slate-400 font-bold">
                          <span>Questão {activeReviewItem.currentIndex + 1} de {activeReviewItem.questions.length}</span>
                          <span className="text-amber-600 font-extrabold bg-amber-50 px-2 py-0.5 rounded-md">Ativa</span>
                        </div>

                        {/* Current active review question */}
                        {(() => {
                          const q = activeReviewItem.questions[activeReviewItem.currentIndex];
                          const selectedOption = activeReviewItem.answers[q.id];
                          const answered = selectedOption !== undefined;

                          return (
                            <div className="bg-white p-5 rounded-2xl border border-slate-100 space-y-4">
                              <p className="text-xs font-bold text-slate-700 leading-relaxed">{q.statement}</p>
                              
                              <div className="space-y-2">
                                {q.options.map((opt, idx) => {
                                  const isSelected = selectedOption === idx;
                                  const isCorrect = q.correctIndex === idx;
                                  let btnStyle = "bg-white border-slate-200 hover:border-slate-300 text-slate-700";

                                  if (answered) {
                                    if (isCorrect) {
                                      btnStyle = "bg-emerald-50 border-emerald-300 text-emerald-800 font-bold";
                                    } else if (isSelected) {
                                      btnStyle = "bg-red-50 border-red-300 text-red-800";
                                    } else {
                                      btnStyle = "bg-white border-slate-100 text-slate-400 opacity-60";
                                    }
                                  }

                                  return (
                                    <button
                                      key={idx}
                                      onClick={() => handleReviewAnswer(idx)}
                                      disabled={answered}
                                      className={`
                                        w-full text-left p-3 rounded-xl border text-xs transition-all flex items-start gap-2
                                        ${btnStyle}
                                        ${!answered ? 'cursor-pointer hover:scale-[1.01]' : 'cursor-default'}
                                      `}
                                    >
                                      <span className="font-mono font-black uppercase bg-slate-100 rounded px-1.5 py-0.5 text-[9px] text-slate-600 mt-0.5">
                                        {String.fromCharCode(65 + idx)}
                                      </span>
                                      <span>{opt}</span>
                                    </button>
                                  );
                                })}
                              </div>

                              {answered && (
                                <div className="space-y-3 pt-2">
                                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-150 text-xs text-slate-600 leading-relaxed">
                                    <strong>Comentário Jurídico:</strong> {q.explanation}
                                  </div>
                                  <button
                                    onClick={handleNextReviewQuestion}
                                    className="w-full bg-slate-800 hover:bg-slate-900 text-white font-extrabold text-xs py-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1"
                                  >
                                    <span>Próxima Questão</span>
                                    <ChevronRight className="h-4 w-4" />
                                  </button>
                                </div>
                              )}
                            </div>
                          );
                        })()}
                      </div>
                    ) : (
                      /* Review completed */
                      <div className="bg-white p-6 rounded-2xl text-center space-y-4 border border-slate-150">
                        <CheckCircle className="h-12 w-12 text-emerald-500 mx-auto" />
                        <div>
                          <h4 className="text-base font-black text-slate-800">Parabéns! Revisão Concluída</h4>
                          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto leading-relaxed">
                            Você praticou a repetição ativa programada de {selectedDiscipline.name}. Suas respostas reforçam as trilhas neurais para o dia do exame.
                          </p>
                        </div>
                        <button
                          onClick={() => setActiveReviewItem(null)}
                          className="bg-slate-800 hover:bg-slate-900 text-white font-extrabold text-xs px-6 py-2.5 rounded-xl transition-all cursor-pointer"
                        >
                          Concluir Sessão
                        </button>
                      </div>
                    )}
                  </div>
                )}

              </div>
            )}

            {/* SUBTAB: SIMULADOS (SIMULADOS) */}
            {activeSubTab === 'simulados' && (
              <div className="space-y-6">
                
                {/* Bloco G Header */}
                <div className="border-b border-slate-100 pb-4">
                  <h3 className="text-sm font-black uppercase text-slate-400 tracking-wider">Simulados Temáticos OAB</h3>
                  <p className="text-xs text-slate-500 mt-0.5 font-medium">Resolva questões em ambiente cronometrado. Simule a pressão e o tempo de prova.</p>
                </div>

                {!activeSimulado ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {selectedDiscipline.miniSimulados.map((sim) => {
                      return (
                        <div 
                          key={sim.id} 
                          className="bg-slate-50 border border-slate-200 rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-sm"
                        >
                          <div className="space-y-1.5">
                            <span className="text-[9px] uppercase font-black text-purple-600 bg-purple-50 px-2 py-0.5 rounded border border-purple-100 tracking-wider inline-block">Cronometrado</span>
                            <h4 className="text-sm font-black text-slate-800">{sim.title}</h4>
                            <p className="text-xs text-slate-400 font-semibold">{sim.totalQuestions} questões • Tempo: {sim.timeLimitMinutes} minutos</p>
                          </div>

                          <button
                            onClick={() => handleStartSimulado(sim, selectedDiscipline.id)}
                            className="w-full bg-slate-800 hover:bg-slate-950 text-white font-extrabold text-xs py-2 rounded-xl transition-all cursor-pointer text-center"
                          >
                            Iniciar Simulado
                          </button>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  /* Simulado active session view */
                  <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 space-y-6">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                      <div>
                        <span className="text-[9px] uppercase font-black text-purple-600 tracking-wider">Simulado Oficial em Progresso</span>
                        <h4 className="text-sm font-black text-slate-800 truncate max-w-[200px] sm:max-w-none">{activeSimulado.title}</h4>
                      </div>
                      
                      <div className="bg-purple-50 text-purple-800 border border-purple-200 font-mono text-xs font-black px-3 py-1.5 rounded-xl flex items-center gap-1.5">
                        <Timer className="h-4 w-4 text-purple-600" />
                        <span>{formatTime(activeSimulado.timeRemaining)}</span>
                      </div>
                    </div>

                    {!activeSimulado.completed ? (
                      <div className="space-y-4">
                        <div className="flex justify-between items-center text-xs text-slate-400 font-bold">
                          <span>Questão {activeSimulado.currentIndex + 1} de {activeSimulado.questions.length}</span>
                          <span>Não feche esta página</span>
                        </div>

                        {/* Current active question in simulated exam */}
                        {(() => {
                          const q = activeSimulado.questions[activeSimulado.currentIndex];
                          const selectedOption = activeSimulado.answers[q.id];
                          const isAnswered = selectedOption !== undefined;

                          return (
                            <div className="bg-white p-5 rounded-2xl border border-slate-100 space-y-4">
                              <p className="text-xs font-bold text-slate-700 leading-relaxed">{q.statement}</p>
                              
                              <div className="space-y-2.5">
                                {q.options.map((opt, idx) => {
                                  const isSelected = selectedOption === idx;
                                  let btnStyle = "bg-white border-slate-200 hover:border-slate-300 text-slate-700";

                                  if (isAnswered) {
                                    if (isSelected) {
                                      btnStyle = "bg-purple-50 border-purple-300 text-purple-800 font-bold";
                                    } else {
                                      btnStyle = "bg-white border-slate-100 text-slate-400 opacity-60";
                                    }
                                  }

                                  return (
                                    <button
                                      key={idx}
                                      onClick={() => handleSimuladoAnswer(idx)}
                                      disabled={isAnswered}
                                      className={`
                                        w-full text-left p-3 rounded-xl border text-xs transition-all flex items-start gap-2.5
                                        ${btnStyle}
                                        ${!isAnswered ? 'cursor-pointer hover:scale-[1.01]' : 'cursor-default'}
                                      `}
                                    >
                                      <span className="font-mono font-black uppercase bg-slate-100 rounded px-1.5 py-0.5 text-[9px] text-slate-600 mt-0.5">
                                        {String.fromCharCode(65 + idx)}
                                      </span>
                                      <span>{opt}</span>
                                    </button>
                                  );
                                })}
                              </div>

                              {isAnswered && (
                                <button
                                  onClick={handleNextSimuladoQuestion}
                                  className="w-full bg-slate-800 hover:bg-slate-900 text-white font-extrabold text-xs py-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1"
                                >
                                  <span>{activeSimulado.currentIndex < activeSimulado.questions.length - 1 ? 'Próxima Questão' : 'Finalizar Simulado'}</span>
                                  <ChevronRight className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          );
                        })()}
                      </div>
                    ) : (
                      /* Simulado score calculation and feedback */
                      (() => {
                        const totalQs = activeSimulado.questions.length;
                        let correctAnswers = 0;
                        activeSimulado.questions.forEach(q => {
                          if (activeSimulado.answers[q.id] === q.correctIndex) {
                            correctAnswers++;
                          }
                        });
                        const percentage = Math.round((correctAnswers / totalQs) * 100);

                        return (
                          <div className="bg-white p-6 rounded-2xl text-center space-y-4 border border-slate-150">
                            <CheckCircle className="h-12 w-12 text-emerald-500 mx-auto" />
                            <div>
                              <h4 className="text-base font-black text-slate-800">Resultado do Simulado</h4>
                              <p className="text-xs text-slate-400 mt-0.5">Simulado finalizado com sucesso.</p>
                            </div>

                            <div className="grid grid-cols-3 gap-3 max-w-sm mx-auto pt-2">
                              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                                <span className="text-[9px] uppercase font-bold text-slate-400 block">Acertos</span>
                                <span className="text-lg font-black text-slate-800">{correctAnswers}/{totalQs}</span>
                              </div>
                              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                                <span className="text-[9px] uppercase font-bold text-slate-400 block">Aproveitamento</span>
                                <span className={`text-lg font-black ${percentage >= 60 ? 'text-emerald-600' : 'text-amber-600'}`}>{percentage}%</span>
                              </div>
                              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                                <span className="text-[9px] uppercase font-bold text-slate-400 block">Status</span>
                                <span className={`text-xs font-black block mt-1.5 ${percentage >= 60 ? 'text-emerald-700' : 'text-amber-700'}`}>
                                  {percentage >= 60 ? 'Aprovado' : 'Reforçar'}
                                </span>
                              </div>
                            </div>

                            <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed pt-2">
                              {percentage >= 60 
                                ? "Excelente desempenho! Continue assim para garantir uma ótima pontuação na primeira fase." 
                                : "Ainda há espaço para evoluir. Revise as videoaulas e leia os PDFs para fixar melhor os temas com mais erros."
                              }
                            </p>

                            <button
                              onClick={() => setActiveSimulado(null)}
                              className="bg-slate-800 hover:bg-slate-900 text-white font-extrabold text-xs px-6 py-2.5 rounded-xl transition-all cursor-pointer"
                            >
                              Voltar para Simulados
                            </button>
                          </div>
                        );
                      })()
                    )}
                  </div>
                )}

              </div>
            )}

          </div>

        </div>
      )}

    </div>
  );
}
