/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Award, 
  Sparkles, 
  Crown, 
  MessageSquare, 
  Plus, 
  Check, 
  ThumbsUp,
  User,
  Quote
} from 'lucide-react';
import { Testimonial } from './CommunityData';

interface CommunityTestimonialsProps {
  testimonials: Testimonial[];
  setTestimonials: React.Dispatch<React.SetStateAction<Testimonial[]>>;
}

export default function CommunityTestimonials({ testimonials, setTestimonials }: CommunityTestimonialsProps) {
  const [activeCategory, setActiveCategory] = useState<'Todas' | '1a Fase' | '2a Fase' | 'Superação' | 'Destaque'>('Todas');
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Form states
  const [newName, setNewName] = useState('');
  const [newPhase, setNewPhase] = useState<'1a Fase' | '2a Fase' | 'Superação' | 'Destaque'>('1a Fase');
  const [newArea, setNewArea] = useState('');
  const [newStory, setNewStory] = useState('');
  const [newGrade, setNewGrade] = useState('');

  const filterTabs: { id: typeof activeCategory; label: string }[] = [
    { id: 'Todas', label: 'Todos os Relatos' },
    { id: '1a Fase', label: '1ª Fase OAB' },
    { id: '2a Fase', label: '2ª Fase OAB' },
    { id: 'Superação', label: 'Histórias de Superação' },
    { id: 'Destaque', label: 'Destaques do Método' }
  ];

  const handleAddTestimonial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newStory.trim()) return;

    const newTest: Testimonial = {
      id: `test-${Date.now()}`,
      name: newName,
      phase: newPhase,
      area2ndPhase: newPhase === '2a Fase' ? newArea || 'Geral' : undefined,
      story: newStory,
      grade: newGrade ? (newPhase === '1a Fase' ? `${newGrade} pontos` : `Nota ${newGrade}`) : undefined,
      approvedYear: 'Exame XL (Novo)'
    };

    setTestimonials(prev => [newTest, ...prev]);
    setSubmitSuccess(true);
    setNewName('');
    setNewStory('');
    setNewGrade('');
    setNewArea('');
    setTimeout(() => {
      setSubmitSuccess(false);
      setShowSubmitModal(false);
    }, 3000);
  };

  const filteredList = testimonials.filter(t => activeCategory === 'Todas' || t.phase === activeCategory);

  return (
    <div className="space-y-6 animate-fade-in" id="community-testimonials-workspace">
      
      {/* Motivational Header */}
      <div className="bg-gradient-to-r from-[#D4AF37]/10 via-[#D4AF37]/5 to-transparent border border-[#D4AF37]/30 rounded-xl p-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-1">
          <span className="bg-[#D4AF37] text-slate-900 text-[9px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full font-mono">
            ★ INSPIRAÇÃO E CREDIBILIDADE ★
          </span>
          <h2 className="font-serif font-black text-xl text-slate-950 flex items-center gap-1.5">
            Mural de Aprovados OAB 3F
          </h2>
          <p className="text-xs text-slate-600 max-w-xl leading-relaxed">
            Eles estiveram onde você está hoje, seguiram o método das 3 fases e conquistaram a tão sonhada carteira vermelha da OAB. Seu nome será o próximo neste mural!
          </p>
        </div>
        <button
          onClick={() => setShowSubmitModal(true)}
          className="bg-slate-900 hover:bg-slate-800 text-[#D4AF37] hover:text-white font-bold text-xs px-4 py-2.5 rounded-lg uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 shrink-0"
        >
          <Plus className="h-4 w-4" /> Enviar Meu Depoimento
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-1.5 border-b border-slate-100 pb-2">
        {filterTabs.map(tab => {
          const isSelected = activeCategory === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveCategory(tab.id)}
              className={`text-xs font-semibold px-4 py-2 rounded-lg transition-all border cursor-pointer ${
                isSelected 
                  ? 'bg-slate-900 text-white border-slate-900 shadow-sm' 
                  : 'bg-white hover:bg-slate-50 text-slate-600 border-slate-250'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Testimonials Grid Layout */}
      {filteredList.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-200">
          <Quote className="h-8 w-8 text-slate-300 mx-auto" />
          <p className="text-xs text-slate-500 font-bold mt-2">Nenhum depoimento nesta categoria ainda</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredList.map(t => (
            <div 
              key={t.id} 
              className="bg-white border border-slate-150 hover:border-slate-300 rounded-xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-4"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-start gap-4">
                  <div className="flex items-center space-x-2.5">
                    <div className="h-8 w-8 rounded-full bg-slate-900 flex items-center justify-center text-[#D4AF37] font-black text-xs font-serif shadow-inner">
                      {t.name[0]}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-800 leading-tight">{t.name}</h4>
                      <span className="text-[10px] text-slate-400 font-mono font-medium block mt-0.5">{t.approvedYear}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="bg-amber-100 text-[#D4AF37] border border-amber-500/20 text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full font-mono block">
                      {t.phase === '1a Fase' ? '1ª Fase' : t.phase === '2a Fase' ? '2ª Fase' : t.phase}
                    </span>
                    {t.area2ndPhase && (
                      <span className="text-[9px] font-medium text-slate-500 block mt-1">{t.area2ndPhase}</span>
                    )}
                  </div>
                </div>

                <div className="relative">
                  <Quote className="absolute -top-1 -left-1.5 h-6 w-6 text-slate-100 rotate-180 -z-0" />
                  <p className="text-xs text-slate-600 leading-relaxed italic relative z-10 font-medium pl-3">
                    "{t.story}"
                  </p>
                </div>
              </div>

              {t.grade && (
                <div className="border-t border-slate-50 pt-2.5 flex justify-between items-center text-[10.5px]">
                  <span className="text-slate-400 font-medium flex items-center gap-1">
                    <Check className="h-3.5 w-3.5 text-emerald-500" /> Aprovado Oficial
                  </span>
                  <span className="font-mono text-amber-600 bg-amber-500/10 px-2.5 py-0.5 rounded-md font-extrabold">
                    Resultado: {t.grade}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* SUBMIT TESTIMONIAL MODAL */}
      {showSubmitModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 animate-scale-in">
            <div className="bg-slate-900 text-white p-4 flex justify-between items-center">
              <span className="font-serif font-bold text-sm tracking-tight flex items-center gap-1.5">
                <Crown className="h-4.5 w-4.5 text-[#D4AF37]" /> Compartilhe Sua Vitória!
              </span>
              <button 
                onClick={() => setShowSubmitModal(false)}
                className="text-slate-400 hover:text-white cursor-pointer font-bold"
              >
                ×
              </button>
            </div>

            {submitSuccess ? (
              <div className="p-10 text-center space-y-3 animate-fade-in">
                <div className="h-10 w-10 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                  <Check className="h-5 w-5" />
                </div>
                <h3 className="font-serif font-bold text-slate-800">Depoimento Enviado!</h3>
                <p className="text-xs text-slate-500 max-w-xs mx-auto leading-relaxed">
                  Muito obrigado por inspirar outros alunos! Sua história foi publicada de forma instantânea e já está brilhando em nosso mural de aprovações.
                </p>
              </div>
            ) : (
              <form onSubmit={handleAddTestimonial} className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Seu Nome</label>
                    <input
                      type="text"
                      placeholder="Ex: Lucas Ribeiro"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Qual fase passou?</label>
                    <select
                      value={newPhase}
                      onChange={(e) => setNewPhase(e.target.value as any)}
                      className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
                    >
                      <option value="1a Fase">1ª Fase OAB</option>
                      <option value="2a Fase">2ª Fase OAB</option>
                      <option value="Superação">Superação</option>
                      <option value="Destaque">Destaque do Método</option>
                    </select>
                  </div>
                </div>

                {newPhase === '2a Fase' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Área da 2ª Fase</label>
                    <input
                      type="text"
                      placeholder="Ex: Direito Penal, Direito Civil..."
                      value={newArea}
                      onChange={(e) => setNewArea(e.target.value)}
                      className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
                    />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Sua Nota / Pontos (Opcional)</label>
                    <input
                      type="text"
                      placeholder="Ex: 48 pontos ou 8.5"
                      value={newGrade}
                      onChange={(e) => setNewGrade(e.target.value)}
                      className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Edição do Exame</label>
                    <input
                      type="text"
                      value="Exame XL"
                      disabled
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-400 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Conte um pouco da sua jornada com o OAB 3F</label>
                  <textarea
                    placeholder="Quais ferramentas do app você mais usou? Qual foi sua maior dificuldade e como o método te ajudou a vencer?"
                    value={newStory}
                    onChange={(e) => setNewStory(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg p-2.5 h-28 focus:outline-none focus:ring-1 focus:ring-slate-400"
                    required
                  />
                </div>

                <div className="pt-2 flex gap-3">
                  <button
                    type="button"
                    onClick={() => setShowSubmitModal(false)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex-1 cursor-pointer"
                  >
                    Voltar
                  </button>
                  <button
                    type="submit"
                    className="bg-slate-900 hover:bg-slate-800 text-[#D4AF37] px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex-1 cursor-pointer transition-colors"
                  >
                    Publicar Depoimento
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
