/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  Settings,
  Flame,
  CheckSquare,
  BookOpen,
  Plus,
  Play,
  Pause,
  RefreshCw,
  Sparkles,
  ChevronRight,
  ChevronDown,
  Award,
  HelpCircle,
  FileText,
  Layers,
  ShieldAlert,
  ArrowUpRight,
  Check,
  History,
  Compass,
  UserCheck,
  AlertTriangle,
  CalendarRange,
  Trash,
  Hourglass,
  CalendarDays,
  Target
} from 'lucide-react';
import { WeeklyTask, StudentProgress } from '../types';

interface StudyPlanProps {
  weeklyTasks: WeeklyTask[];
  studyHoursGoal: number;
  weeklyStudyHours: number;
  onToggleTask: (taskId: string) => void;
  onUpdateTaskStatus: (taskId: string, newStatus: 'pending' | 'in_progress' | 'completed') => void;
  onAddTask: (task: Omit<WeeklyTask, 'id' | 'status'>) => void;
  onUpdateHoursGoal: (hours: number) => void;
  onDeleteTask: (taskId: string) => void;
  progress: StudentProgress;
  onNavigateToTab: (tab: string) => void;
  onAddStudyHours: (hours: number) => void;
  onSelectArea: (area: string) => void;
  setProgress: React.Dispatch<React.SetStateAction<StudentProgress>>;
  onUpdateTasks: React.Dispatch<React.SetStateAction<WeeklyTask[]>>;
  onStartStudyTask?: (taskId: string) => void;
}

const DAYS_OF_WEEK = [
  'Segunda-feira',
  'Terça-feira',
  'Quarta-feira',
  'Quinta-feira',
  'Sexta-feira',
  'Sábado',
  'Domingo'
];

export default function StudyPlan({
  weeklyTasks,
  studyHoursGoal,
  weeklyStudyHours,
  onToggleTask,
  onUpdateTaskStatus,
  onAddTask,
  onUpdateHoursGoal,
  onDeleteTask,
  progress,
  onNavigateToTab,
  onAddStudyHours,
  onSelectArea,
  setProgress,
  onUpdateTasks,
  onStartStudyTask
}: StudyPlanProps) {
  // Navigation for internal sections of "Meu Plano"
  const [internalTab, setInternalTab] = useState<'hoje' | 'semanal' | 'metas' | 'trilhas' | 'replanejamento'>('hoje');
  
  // Active study profile state (persisted locally)
  const [studyProfile, setStudyProfile] = useState<'zero' | 'reta-final' | 'repetente' | 'fase2'>(() => {
    const saved = localStorage.getItem('oab3f_study_profile');
    return (saved as any) || 'reta-final';
  });

  // Today is simulated as Thursday (Quinta-feira) based on local date (June 25, 2026)
  const todayDayName = 'Quinta-feira';
  const [selectedDay, setSelectedDay] = useState<string>(todayDayName);

  // Active study session simulation state
  const [activeSessionTask, setActiveSessionTask] = useState<WeeklyTask | null>(null);
  const [sessionTime, setSessionTime] = useState<number>(0);
  const [sessionIsPlaying, setSessionIsPlaying] = useState<boolean>(false);
  const [sessionNotes, setSessionNotes] = useState<string>('');

  // Custom task form states
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newDay, setNewDay] = useState('Quinta-feira');
  const [newDuration, setNewDuration] = useState('60');
  const [newDiscipline, setNewDiscipline] = useState('Ética Profissional');
  const [newPriority, setNewPriority] = useState<'Baixa' | 'Média' | 'Alta'>('Média');
  const [newActivityType, setNewActivityType] = useState<'aula' | 'questao' | 'revisao' | 'simulado' | 'peca' | 'discursiva'>('questao');

  // Task Filter state for BLOCO C
  const [taskFilter, setTaskFilter] = useState<'hoje' | 'semana' | 'pendentes' | 'concluidas' | 'em_andamento'>('hoje');

  // Success celebration notification state for BLOCO D/F
  const [completionNotification, setCompletionNotification] = useState<{
    show: boolean;
    title: string;
    discipline: string;
    duration: number;
    hoursEarned: number;
  } | null>(null);

  // Custom confirmation dialog for pedagogical warning (Ajuste 5)
  const [rescheduleConfirm, setRescheduleConfirm] = useState<{
    show: boolean;
    onConfirm: () => void;
    message: string;
  } | null>(null);

  // Keep study profile synchronized
  useEffect(() => {
    localStorage.setItem('oab3f_study_profile', studyProfile);
  }, [studyProfile]);

  const getTaskStatus = (task: WeeklyTask): 'pendente' | 'em_andamento' | 'concluida' => {
    if (task.status === 'completed') return 'concluida';
    if (task.status === 'in_progress') return 'em_andamento';
    return 'pendente';
  };

  // Timer simulation for active study session
  useEffect(() => {
    let interval: any = null;
    if (sessionIsPlaying && activeSessionTask) {
      interval = setInterval(() => {
        setSessionTime((prev) => prev + 1);
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [sessionIsPlaying, activeSessionTask]);

  // Format stopwatch time
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // --- COMPUTE TODAY AND WEEKLY STATS ---
  const todayTasks = useMemo(() => {
    return weeklyTasks.filter(t => t.day === todayDayName);
  }, [weeklyTasks]);

  const todayCompletedCount = useMemo(() => {
    return todayTasks.filter(t => t.status === 'completed').length;
  }, [todayTasks]);

  const todayPendingCount = useMemo(() => {
    return todayTasks.filter(t => t.status !== 'completed').length;
  }, [todayTasks]);

  const totalWeeklyCompleted = useMemo(() => {
    return weeklyTasks.filter(t => t.status === 'completed').length;
  }, [weeklyTasks]);

  const progressPlanPercentage = useMemo(() => {
    if (weeklyTasks.length === 0) return 0;
    return Math.round((totalWeeklyCompleted / weeklyTasks.length) * 100);
  }, [weeklyTasks, totalWeeklyCompleted]);

  // Detect delayed tasks (all tasks before Thursday that are NOT completed)
  const delayedTasks = useMemo(() => {
    const thursdayIndex = DAYS_OF_WEEK.indexOf('Quinta-feira');
    return weeklyTasks.filter(t => {
      const taskDayIndex = DAYS_OF_WEEK.indexOf(t.day);
      return t.status !== 'completed' && taskDayIndex < thursdayIndex && taskDayIndex >= 0;
    });
  }, [weeklyTasks]);

  // Dynamic feedback messages based on study habits
  const dynamicAlertMessage = useMemo(() => {
    if (delayedTasks.length > 0) {
      return {
        text: `Você tem ${delayedTasks.length} tarefas atrasadas nesta semana. Use a aba "Perfil & Replanejamento" para reagendá-las com 1 clique!`,
        type: 'danger',
        desc: 'Replanejamento automático sugerido'
      };
    }
    if (todayCompletedCount === todayTasks.length && todayTasks.length > 0) {
      return {
        text: 'Excelente! Você concluiu 100% do roteiro programado para hoje. Mantenha a constância!',
        type: 'success',
        desc: 'Meta diária cumprida'
      };
    }
    return {
      text: 'Hoje o foco estratégico é Ética Profissional (Direitos) + Processo Penal (Nulidades). Revise a Lei Seca.',
      type: 'info',
      desc: 'Foco do dia'
    };
  }, [delayedTasks, todayCompletedCount, todayTasks]);

  // --- SPATIAL COGNITIVE INTELLIGENCE & AUTO-PRIORITIES ---
  const autoPriorities = useMemo(() => {
    const alerts = [];
    
    // Check Ética performance
    const eticaAnswers = Object.values(progress.answeredQuestions).filter(q => q.isCorrect); // simplified
    const totalEticaSolved = Object.keys(progress.answeredQuestions).length; // estimate
    
    // 1. Ética is highest importance (8 questions)
    alerts.push({
      id: 'prio-1',
      title: 'Prioridade Máxima: Blindar Ética Profissional',
      desc: 'Ética distribui 8 pontos (10% da prova). Garanta a leitura do Estatuto da OAB (Art. 6º e 7º).',
      level: 'Alta',
      actionText: 'Estudar Ética',
      targetTab: 'fase1'
    });

    // 2. Delayed tasks alert
    if (delayedTasks.length > 0) {
      alerts.push({
        id: 'prio-2',
        title: `Atraso Crítico: ${delayedTasks.length} metas pendentes`,
        desc: 'Sua trilha semanal está acumulando pendências de dias anteriores. Limpe o gargalo.',
        level: 'Alta',
        actionText: 'Reorganizar Hoje',
        targetTab: 'plano'
      });
    } else {
      alerts.push({
        id: 'prio-clean',
        title: 'Cronograma em Dia!',
        desc: 'Nenhuma tarefa atrasada de segunda a quarta. Fantástico ritmo de estudos!',
        level: 'Baixa',
        actionText: 'Ver Semana',
        targetTab: 'plano'
      });
    }

    // 3. Spaced revisions pending
    alerts.push({
      id: 'prio-3',
      title: 'Revisão Espaçada: Direito Civil e Processo Civil',
      desc: 'Você possui flashcards e conceitos de Direito das Obrigações prontos para revisão de 7 dias.',
      level: 'Média',
      actionText: 'Fazer Revisão',
      targetTab: 'revisao'
    });

    // 4. 2nd Phase choice check
    const secondPhaseArea = progress.selectedSecondPhaseArea || 'Direito Penal';
    alerts.push({
      id: 'prio-4',
      title: `Peça de 2ª Fase Pendente em ${secondPhaseArea}`,
      desc: 'Treine a estruturação do esqueleto e tese prática para Recurso ou Contestação.',
      level: 'Média',
      actionText: 'Treinar Peça',
      targetTab: 'fase2'
    });

    return alerts;
  }, [delayedTasks, progress.answeredQuestions, progress.selectedSecondPhaseArea]);

  // --- CALENDAR INTEGRATION COUNTDOWNS ---
  // Today: June 25, 2026
  // 1ª Fase Exam: September 13, 2026
  // 2ª Fase Exam: November 15, 2026
  const calendarCountdowns = useMemo(() => {
    const dateToday = new Date('2026-06-25');
    const date1st = new Date('2026-09-13');
    const date2nd = new Date('2026-11-15');

    const diff1st = Math.ceil((date1st.getTime() - dateToday.getTime()) / (1000 * 60 * 60 * 24));
    const diff2nd = Math.ceil((date2nd.getTime() - dateToday.getTime()) / (1000 * 60 * 60 * 24));

    let intensityNote = 'Intensidade Regular (20h-25h semanais)';
    if (diff1st <= 30) {
      intensityNote = '🚨 RETA FINAL! Maximize simulados, flashcards e revisão de erros (30h+ semanais).';
    } else if (diff1st <= 60) {
      intensityNote = '🔥 Foco em Questões OAB e preenchimento de lacunas teóricas.';
    } else {
      intensityNote = '📅 Planejamento estruturado. Foco em base teórica consolidada.';
    }

    return {
      daysTo1st: diff1st,
      daysTo2nd: diff2nd,
      intensityNote,
      exam1stDateStr: '13/09/2026',
      exam2ndDateStr: '15/11/2026'
    };
  }, []);

  // --- METRICAS COMPREHENSIVE DATA GRID (Section 4 & 9) ---
  const goalsData = useMemo(() => {
    // Calculated dynamic totals
    const solvedTodayCount = Object.values(progress.answeredQuestions).length; // Simulated/actual questions
    const solvedCorrectCount = Object.values(progress.answeredQuestions).filter(q => q.isCorrect).length;
    
    return {
      daily: [
        { name: 'Horas de Estudo Diário', target: '3h', current: `${weeklyStudyHours > 0 ? (weeklyStudyHours / 4).toFixed(1) : 0}h`, pct: weeklyStudyHours > 0 ? Math.min(100, Math.round(((weeklyStudyHours / 4) / 3) * 100)) : 0, status: weeklyStudyHours > 10 ? 'Concluído' : 'Atrasado' },
        { name: 'Tarefas Executadas', target: '3 metas', current: `${todayCompletedCount} metas`, pct: todayTasks.length > 0 ? Math.round((todayCompletedCount / todayTasks.length) * 100) : 0, status: todayCompletedCount >= 3 ? 'Concluído' : 'Atrasado' },
        { name: 'Questões Respondidas', target: '15 questões', current: `${solvedTodayCount + 8} questões`, pct: Math.min(100, Math.round(((solvedTodayCount + 8) / 15) * 100)), status: (solvedTodayCount + 8) >= 15 ? 'Concluído' : 'Dentro da Meta' },
        { name: 'Revisões Realizadas', target: '1 ciclo', current: `${progress.completedFlashcards.length > 0 ? 1 : 0} ciclo`, pct: progress.completedFlashcards.length > 0 ? 100 : 0, status: progress.completedFlashcards.length > 0 ? 'Concluído' : 'Atrasado' }
      ],
      weekly: [
        { name: 'Carga Horária Semanal', target: `${studyHoursGoal}h`, current: `${weeklyStudyHours}h`, pct: Math.min(100, Math.round((weeklyStudyHours / studyHoursGoal) * 100)), status: weeklyStudyHours >= studyHoursGoal ? 'Concluído' : 'Dentro da Meta' },
        { name: 'Disciplinas Estudadas', target: '6 matérias', current: '5 matérias', pct: 83, status: 'Dentro da Meta' },
        { name: 'Simulados Concluídos', target: '1 simulado', current: `${progress.simulatedExamsHistory.length} feito`, pct: progress.simulatedExamsHistory.length > 0 ? 100 : 0, status: progress.simulatedExamsHistory.length > 0 ? 'Concluído' : 'Atrasado' },
        { name: 'Progresso da Trilha', target: '100%', current: `${progressPlanPercentage}%`, pct: progressPlanPercentage, status: progressPlanPercentage >= 80 ? 'Concluído' : 'Dentro da Meta' }
      ],
      monthly: [
        { name: 'Matérias Fechadas', target: '12 matérias', current: '8 matérias', pct: 66, status: 'Dentro da Meta' },
        { name: 'Acúmulo de Questões', target: '300 questões', current: `${140 + solvedTodayCount} q.`, pct: Math.min(100, Math.round(((140 + solvedTodayCount) / 300) * 100)), status: 'Dentro da Meta' },
        { name: 'Esqueletos de Peças', target: '8 peças', current: `${4 + progress.favoritePieces.length} peças`, pct: Math.min(100, Math.round(((4 + progress.favoritePieces.length) / 8) * 100)), status: 'Dentro da Meta' },
        { name: 'Simulados Globais', target: '3 simulados', current: `${1 + progress.simulatedExamsHistory.length} feito`, pct: Math.min(100, Math.round(((1 + progress.simulatedExamsHistory.length) / 3) * 100)), status: 'Atrasado' }
      ]
    };
  }, [progress, weeklyStudyHours, studyHoursGoal, todayCompletedCount, todayTasks, progressPlanPercentage]);

  // --- TRILHA 1ª FASE STRATEGIC DATA (Section 5) ---
  const phase1StrategicPlan = useMemo(() => {
    return [
      { name: 'Ética Profissional', questions: 8, priority: 'Crítica / Muito Alta', advice: 'Garante 10% da nota total. Foque em prerrogativas, incompatibilidades e honorários.', progress: 85 },
      { name: 'Direito Constitucional', questions: 6, priority: 'Muito Alta', advice: 'Controle de constitucionalidade, remédios e organização do Estado.', progress: 70 },
      { name: 'Direito Administrativo', questions: 6, priority: 'Alta', advice: 'Agentes públicos, licitações e atos administrativos.', progress: 60 },
      { name: 'Direito Penal', questions: 6, priority: 'Alta', advice: 'Teoria do crime, penas e crimes contra a administração pública.', progress: 75 },
      { name: 'Processo Penal', questions: 6, priority: 'Alta', advice: 'Inquérito policial, ação penal e nulidades recorrentes.', progress: 50 },
      { name: 'Processo Civil', questions: 6, priority: 'Muito Alta', advice: 'Procedimento comum, recursos e execução.', progress: 45 },
      { name: 'Direito Civil', questions: 6, priority: 'Alta', advice: 'Contratos, família, obrigações e bens.', progress: 40 },
      { name: 'Direito do Trabalho', questions: 5, priority: 'Média', advice: 'Relação de emprego, jornada, rescisão e verbas.', progress: 80 }
    ];
  }, []);

  // --- TRILHA 2ª FASE TEMPLATES (Section 6) ---
  const phase2StrategicPlan = useMemo(() => {
    const area = progress.selectedSecondPhaseArea || 'Direito Penal';
    
    // Customized schedules for 2nd phase based on selected area
    const schedules: { [key: string]: { day: string; task: string; type: 'peca' | 'discursiva' | 'simulado' | 'revisao' }[] } = {
      'Direito Penal': [
        { day: 'Segunda-feira', task: 'Estudo de Peça: Memoriais de Alegações Finais (Art. 403, §3º CPP)', type: 'peca' },
        { day: 'Terça-feira', task: 'Prática de Discursivas: 2 questões sobre Dosimetria de Pena e Sursis', type: 'discursiva' },
        { day: 'Quarta-feira', task: 'Revisão: Esqueleto de Apelação Criminal e Prazos Recursais', type: 'revisao' },
        { day: 'Quinta-feira', task: 'Estudo de Peça: Resposta à Acusação (Art. 396 e 396-A CPP)', type: 'peca' },
        { day: 'Sexta-feira', task: 'Prática de Discursivas: Crimes contra o Patrimônio e Legítima Defesa', type: 'discursiva' },
        { day: 'Sábado', task: 'Simulado Prático Completo: 1 Peça + 4 Discursivas (5 horas corridas)', type: 'simulado' }
      ],
      'Direito Constitucional': [
        { day: 'Segunda-feira', task: 'Estudo de Peça: Ação Direta de Inconstitucionalidade (ADI)', type: 'peca' },
        { day: 'Terça-feira', task: 'Prática de Discursivas: Repartição de Competências e CPI', type: 'discursiva' },
        { day: 'Quarta-feira', task: 'Revisão: Esqueleto de Mandado de Segurança e Remédios', type: 'revisao' },
        { day: 'Quinta-feira', task: 'Estudo de Peça: Recurso Ordinário Constitucional (ROC)', type: 'peca' },
        { day: 'Sexta-feira', task: 'Prática de Discursivas: Controle de Constitucionalidade e Direitos Fundamentais', type: 'discursiva' },
        { day: 'Sábado', task: 'Simulado Realista de 2ª Fase Constitucional', type: 'simulado' }
      ],
      'Direito Administrativo': [
        { day: 'Segunda-feira', task: 'Estudo de Peça: Ação Anulatória de Ato Administrativo', type: 'peca' },
        { day: 'Terça-feira', task: 'Prática de Discursivas: Processo Administrativo Disciplinar (PAD)', type: 'discursiva' },
        { day: 'Quarta-feira', task: 'Revisão: Esqueleto de Mandado de Segurança e Liminares', type: 'revisao' },
        { day: 'Quinta-feira', task: 'Estudo de Peça: Ação de Improbidade Administrativa', type: 'peca' },
        { day: 'Sexta-feira', task: 'Prática de Discursivas: Concessões, Parcerias e Licitações', type: 'discursiva' },
        { day: 'Sábado', task: 'Simulado Prático Geral: 1 Peça + 4 Discursivas', type: 'simulado' }
      ],
      'Direito do Trabalho': [
        { day: 'Segunda-feira', task: 'Estudo de Peça: Reclamação Trabalhista Completa', type: 'peca' },
        { day: 'Terça-feira', task: 'Prática de Discursivas: Equiparação Salarial e Terceirização', type: 'discursiva' },
        { day: 'Quarta-feira', task: 'Revisão: Esqueleto de Recurso Ordinário (RO)', type: 'revisao' },
        { day: 'Quinta-feira', task: 'Estudo de Peça: Contestação Trabalhista e Preliminares', type: 'peca' },
        { day: 'Sexta-feira', task: 'Prática de Discursivas: Horas Extras, Dano Moral e Estabilidade', type: 'discursiva' },
        { day: 'Sábado', task: 'Simulado Prático 2ª Fase OAB Trabalho', type: 'simulado' }
      ]
    };

    return schedules[area] || schedules['Direito Penal'];
  }, [progress.selectedSecondPhaseArea]);

  // --- REPLANEJAMENTO AUTOMÁTICO ACTIONS (Section 8) ---
  // 1. Shift uncompleted previous tasks to today/future (Ajuste 5)
  const handleShiftDelayedTasks = () => {
    if (delayedTasks.length === 0) return;
    
    setRescheduleConfirm({
      show: true,
      message: `Atenção Estudante: Você está prestes a mover ${delayedTasks.length} metas atrasadas para hoje. O reagendamento frequente de metas pode acumular matérias nas semanas seguintes, aumentando o risco de sobrecarga de conteúdo. Deseja prosseguir com o reagendamento pedagógico de segurança?`,
      onConfirm: () => {
        onUpdateTasks(prev => {
          return prev.map(t => {
            const thursdayIndex = DAYS_OF_WEEK.indexOf('Quinta-feira');
            const taskDayIndex = DAYS_OF_WEEK.indexOf(t.day);
            if (t.status !== 'completed' && taskDayIndex < thursdayIndex && taskDayIndex >= 0) {
              return {
                ...t,
                day: todayDayName, // Shift to Thursday!
                description: `[REAGENDADA] ${t.description}`
              };
            }
            return t;
          });
        });
      }
    });
  };

  // 2. Redistribute weekly study load (Ajuste 5)
  const handleRedistributeWeeklyLoad = () => {
    setRescheduleConfirm({
      show: true,
      message: "Atenção Estudante: Você está prestes a redistribuir todas as suas tarefas pendentes desta semana de forma igualitária até domingo. O reagendamento frequente de metas pode acumular matérias nas semanas seguintes, aumentando o risco de sobrecarga. Deseja prosseguir com o reagendamento pedagógico?",
      onConfirm: () => {
        onUpdateTasks(prev => {
          // Split remaining incomplete tasks equally between Thursday, Friday, Saturday, Sunday
          const futureDays = ['Quinta-feira', 'Sexta-feira', 'Sábado', 'Domingo'];
          let dayPointer = 0;
          return prev.map(t => {
            if (t.status !== 'completed') {
              const targetDay = futureDays[dayPointer % futureDays.length];
              dayPointer++;
              return {
                ...t,
                day: targetDay,
                description: `[REDISTRIBUÍDA] ${t.description}`
              };
            }
            return t;
          });
        });
      }
    });
  };

  // 3. Inject reinforcement tasks for weak subjects
  const handleInjectReinforcementTasks = () => {
    // Inject custom tasks for Civil and Criminal Law (areas OAB designates with lower student accuracy)
    const newTasksToInject = [
      {
        id: `injected-civil-${Date.now()}`,
        day: todayDayName,
        title: 'Reforço Inteligente: Teoria Geral das Obrigações',
        description: 'Sugerido pela plataforma devido ao desempenho abaixo de 50% em Direito Civil. Leia resumos e resolva 5 questões.',
        durationMinutes: 45,
        discipline: 'Direito Civil',
        completed: false,
        priority: 'Alta' as const
      },
      {
        id: `injected-proc-penal-${Date.now()}`,
        day: 'Sexta-feira',
        title: 'Reforço Inteligente: Teoria das Nulidades (CPP)',
        description: 'Sugerido automaticamente. Faça um mapa mental sobre as nulidades absolutas e relativas mais cobradas na OAB.',
        durationMinutes: 50,
        discipline: 'Processo Penal',
        completed: false,
        priority: 'Alta' as const
      }
    ];

    onUpdateTasks(prev => [...newTasksToInject, ...prev]);
    alert('Reforço inteligente ativado! Foram inseridas 2 metas direcionadas em Direito Civil e Processo Penal para turbinar seus pontos fracos.');
  };

  // --- HANDLERS FOR STUDENT ACTIONS ---
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onAddTask({
      day: newDay,
      title: `${newActivityType === 'aula' ? '📺 Aula: ' : newActivityType === 'questao' ? '✍️ Questões: ' : newActivityType === 'revisao' ? '🔁 Revisão: ' : newActivityType === 'simulado' ? '📈 Simulado: ' : newActivityType === 'peca' ? '📂 Peça Prática: ' : '📝 Discursiva: '}${newTitle}`,
      description: newDesc,
      durationMinutes: parseInt(newDuration, 10) || 60,
      discipline: newDiscipline,
      priority: newPriority
    });

    // Reset Form
    setNewTitle('');
    setNewDesc('');
    setShowAddForm(false);
  };

  // Toggle custom task inside active session
  const handleToggleActiveTask = (task: WeeklyTask) => {
    onToggleTask(task.id);
    if (activeSessionTask && activeSessionTask.id === task.id) {
      setActiveSessionTask(prev => prev ? { ...prev, status: prev.status === 'completed' ? 'pending' : 'completed' } : null);
    }
  };

  // Handle study profile change
  const handleProfileChange = (profile: 'zero' | 'reta-final' | 'repetente' | 'fase2') => {
    setStudyProfile(profile);
    
    // Adapt current tasks or inject standard templates depending on selected profile
    if (profile === 'reta-final') {
      onUpdateHoursGoal(28);
    } else if (profile === 'zero') {
      onUpdateHoursGoal(18);
    } else if (profile === 'repetente') {
      onUpdateHoursGoal(24);
    } else if (profile === 'fase2') {
      onUpdateHoursGoal(30);
    }
  };

  // Trigger main CTA "Iniciar estudo de hoje"
  const handleStartTodayStudy = () => {
    // Find first uncompleted task of today
    const firstPending = todayTasks.find(t => t.status !== 'completed');
    if (firstPending) {
      setActiveSessionTask(firstPending);
      setSessionTime(0);
      setSessionIsPlaying(true);
      setInternalTab('hoje');
      // Scroll to active study session container
      setTimeout(() => {
        const el = document.getElementById('active-session-cockpit');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      alert('Todas as metas programadas para hoje já foram concluídas! Parabéns! Que tal fazer um Simulado de 1ª Fase ou treinar uma peça?');
    }
  };

  // Complete study session (Ajustes 1, 4)
  const handleCompleteStudySession = () => {
    if (!activeSessionTask) return;
    const taskId = activeSessionTask.id;
    const studiedHrs = parseFloat((sessionTime / 3600).toFixed(2));
    
    // Update task in parent state with real metrics
    onUpdateTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        return {
          ...t,
          status: 'completed',
          realStudyTimeSeconds: sessionTime,
          completedAt: new Date().toISOString()
        };
      }
      return t;
    }));

    // Synchronize task status in parent controller
    onUpdateTaskStatus(taskId, 'completed');

    // Add studied hours dynamically to the counter
    onAddStudyHours(studiedHrs);

    // Record note if present
    if (sessionNotes.trim()) {
      setProgress(prev => ({
        ...prev,
        notes: {
          ...prev.notes,
          [`task-note-${taskId}`]: sessionNotes
        }
      }));
    }

    // Trigger celebration notification
    setCompletionNotification({
      show: true,
      title: activeSessionTask.title,
      discipline: activeSessionTask.discipline,
      duration: Math.max(1, Math.round(sessionTime / 60)), // minutes or estimated if stopwatch was quick
      hoursEarned: studiedHrs
    });

    // Reset active session
    setActiveSessionTask(null);
    setSessionIsPlaying(false);
    setSessionTime(0);
    setSessionNotes('');
  };

  // Filtered tasks for BLOCO B / C
  const filteredTasks = useMemo(() => {
    switch (taskFilter) {
      case 'hoje':
        return weeklyTasks.filter(t => t.day === todayDayName);
      case 'semana':
        return weeklyTasks;
      case 'pendentes':
        return weeklyTasks.filter(t => t.status !== 'completed');
      case 'concluidas':
        return weeklyTasks.filter(t => t.status === 'completed');
      case 'em_andamento':
        return weeklyTasks.filter(t => t.status === 'in_progress');
      default:
        return weeklyTasks.filter(t => t.day === todayDayName);
    }
  }, [weeklyTasks, taskFilter, todayDayName]);

  // Short history / recent activity tasks for BLOCO E
  const recentActivityTasks = useMemo(() => {
    // Collect all tasks that are marked completed
    return weeklyTasks
      .filter(t => t.status === 'completed')
      .slice(-3) // last 3 completed
      .reverse();
  }, [weeklyTasks]);

  const focusDisciplines = useMemo(() => {
    const incomplete = weeklyTasks.filter(t => t.status !== 'completed');
    const unique = Array.from(new Set(incomplete.map(t => t.discipline)));
    return unique.slice(0, 3);
  }, [weeklyTasks]);

  return (
    <div id="study-plan-container" className="space-y-6">
      
      {/* 1. Header Banner & Profile Selector */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <span className="text-[10px] uppercase font-black tracking-widest text-oab-accent flex items-center gap-1.5">
            <Sparkles className="h-4 w-4 text-oab-accent fill-oab-accent animate-pulse" /> PLANO INTELIGENTE OAB
          </span>
          <h2 className="text-2xl font-black font-display text-oab-primary">
            Meu Plano de Estudos
          </h2>
          <p className="text-xs text-slate-500 max-w-xl">
            Sua central adaptativa de estudos. Veja o cronograma diário, semanal, treine peças da 2ª Fase e organize sua jornada rumo à carteira vermelha.
          </p>
        </div>

        {/* PROFILE SELECTOR: Adaptability of the study plans */}
        <div className="flex flex-col gap-1 w-full md:w-auto">
          <label className="text-[10px] uppercase font-black text-slate-400">Perfil de Plano Recomendado</label>
          <select
            value={studyProfile}
            onChange={(e) => handleProfileChange(e.target.value as any)}
            className="text-xs font-bold border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-oab-accent text-slate-700 min-w-[200px]"
            id="study-profile-select"
          >
            <option value="zero">🌱 Aluno Iniciando do Zero</option>
            <option value="reta-final">🔥 Aluno de Reta Final</option>
            <option value="repetente">🔄 Aluno Repetente (Foco em erros)</option>
            <option value="fase2">🎓 Aluno da 2ª Fase Prática</option>
          </select>
        </div>
      </div>

      {/* 2. Sub-Tabs Navigation for Meu Plano */}
      <div className="overflow-x-auto pb-1" id="meuplano-subnavigation">
        <div className="flex border-b border-slate-200 whitespace-nowrap min-w-max gap-1">
          {[
            { id: 'hoje', label: '📋 Hoje & Painel Geral' },
            { id: 'semanal', label: '🗓️ Cronograma Semanal' },
            { id: 'metas', label: '🎯 Minhas Metas & Histórico' },
            { id: 'trilhas', label: '🛡️ Trilha OAB (1ª e 2ª Fase)' },
            { id: 'replanejamento', label: '⚙️ Replanejamento & Ajustes' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setInternalTab(tab.id as any)}
              className={`
                py-3 px-4 text-xs font-bold transition-all border-b-2 cursor-pointer
                ${internalTab === tab.id 
                  ? 'border-oab-accent text-oab-primary font-extrabold bg-white/40' 
                  : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-100/50'}
              `}
              id={`meuplano-tab-${tab.id}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* --- RENDER ACTIVE SUBTAB CONTENT --- */}
      {internalTab === 'hoje' && (
        <div className="space-y-6">

          {/* ========================================================
              BLOCO A — Resumo do plano da semana (Weekly Overview Card Grid)
              ======================================================== */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Compass className="h-5 w-5 text-oab-primary" />
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">Resumo da sua Carga de Estudo Semanal</h3>
              </div>
              <span className="text-[9px] bg-slate-100 px-2.5 py-1 rounded font-black font-mono text-slate-500 uppercase tracking-wide">
                Foco do Aluno
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              {/* Card 1: Phase and recommendation based on profile */}
              <div className="p-4 bg-[#FAF9F6] border border-[#E5E1D8] rounded-xl flex flex-col justify-between space-y-1">
                <span className="text-[9px] uppercase font-black text-slate-400 tracking-wider">Metodologia e Foco</span>
                <span className="text-xs font-black text-slate-800">
                  {studyProfile === 'zero' ? '🌱 Base Geral (Fase 1)' :
                   studyProfile === 'reta-final' ? '🔥 Reta Final (Fase 3)' :
                   studyProfile === 'repetente' ? '🔄 Reforço (Fase 2)' :
                   '🎓 Prática OAB (Fase 2)'}
                </span>
                <span className="text-[10px] text-slate-500 font-medium">Perfil: {
                  studyProfile === 'zero' ? 'Iniciando do zero' :
                  studyProfile === 'reta-final' ? 'Foco em Simulados' :
                  studyProfile === 'repetente' ? 'Gargalos & Erros' :
                  'Peças Profissionais'
                }</span>
              </div>

              {/* Card 2: Horas Estudadas / Meta de Horas */}
              <div className="p-4 bg-[#FAF9F6] border border-[#E5E1D8] rounded-xl flex flex-col justify-between space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-[9px] uppercase font-black text-slate-400 tracking-wider">Carga Horária</span>
                  <span className="text-[10px] font-mono font-black text-indigo-600">{weeklyStudyHours}h / {studyHoursGoal}h</span>
                </div>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mt-1">
                  <div className="h-full bg-indigo-500 rounded-full transition-all" style={{ width: `${Math.min(100, (weeklyStudyHours / studyHoursGoal) * 100)}%` }} />
                </div>
                <span className="text-[10px] text-slate-500 font-medium">{Math.max(0, studyHoursGoal - weeklyStudyHours)}h restantes para a meta</span>
              </div>

              {/* Card 3: Metas Concluídas / Total */}
              <div className="p-4 bg-[#FAF9F6] border border-[#E5E1D8] rounded-xl flex flex-col justify-between space-y-1">
                <span className="text-[9px] uppercase font-black text-slate-400 tracking-wider">Metas da Semana</span>
                <div className="flex justify-between items-baseline">
                  <span className="text-xs font-bold text-slate-850">{totalWeeklyCompleted} / {weeklyTasks.length} metas</span>
                  <span className="text-[10px] font-mono font-black text-emerald-600">({progressPlanPercentage}%)</span>
                </div>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mt-1">
                  <div className="h-full bg-emerald-500 rounded-full transition-all" style={{ width: `${progressPlanPercentage}%` }} />
                </div>
              </div>

              {/* Card 4: Disciplinas de maior foco da semana */}
              <div className="p-4 bg-[#FAF9F6] border border-[#E5E1D8] rounded-xl flex flex-col justify-between space-y-1">
                <span className="text-[9px] uppercase font-black text-slate-400 tracking-wider">Matérias de Maior Foco</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {focusDisciplines.length > 0 ? (
                    focusDisciplines.map((disc, idx) => (
                      <span key={idx} className="text-[8.5px] bg-slate-100 border border-slate-200 font-extrabold text-slate-600 px-1.5 py-0.5 rounded">
                        {disc}
                      </span>
                    ))
                  ) : (
                    <span className="text-[10px] text-slate-450 italic">Tudo em dia!</span>
                  )}
                </div>
              </div>

            </div>
          </div>

          {/* ========================================================
              BLOCO D — Active Study Session Cockpit (stopwatch)
              ======================================================== */}
          {activeSessionTask && (
            <div id="active-session-cockpit" className="bg-amber-50/60 border border-amber-300 rounded-xl p-6 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="space-y-1.5">
                  <span className="bg-amber-600 text-white px-2.5 py-0.5 rounded text-[9.5px] font-black uppercase tracking-wider flex items-center gap-1.5 w-fit">
                    <Hourglass className="h-3 w-3 animate-spin" /> SESSÃO DE ESTUDO ATIVA
                  </span>
                  <h4 className="text-sm font-black text-slate-800">{activeSessionTask.title}</h4>
                  <p className="text-xs text-slate-600 max-w-xl">{activeSessionTask.description}</p>
                </div>

                {/* Clock Stopwatch */}
                <div className="bg-white px-4 py-2 rounded-xl border border-amber-200 text-center shrink-0 min-w-[130px] shadow-2xs">
                  <span className="text-2xl font-mono font-black text-slate-850 tracking-tight block">
                    {formatTime(sessionTime)}
                  </span>
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-wider mt-0.5 block">Tempo de Foco</span>
                </div>
              </div>

              {/* Note taker box inside active study session */}
              <div className="space-y-1.5">
                <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1">
                  <FileText className="h-4 w-4 text-amber-600" /> Caderno de Anotações Rápido (Salvo no Histórico)
                </label>
                <textarea
                  placeholder="Escreva pontos cruciais estudados, erros percebidos, artigos lidos ou súmulas para não esquecer..."
                  value={sessionNotes}
                  onChange={(e) => setSessionNotes(e.target.value)}
                  className="w-full text-xs border border-slate-200 rounded-lg p-2.5 bg-white h-16 focus:outline-none focus:ring-1 focus:ring-oab-accent shadow-3xs"
                />
              </div>

              {/* Controls bar */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={() => setSessionIsPlaying(!sessionIsPlaying)}
                  className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-all ${sessionIsPlaying ? 'bg-amber-100 hover:bg-amber-200 text-amber-800 border border-amber-300' : 'bg-oab-primary hover:bg-slate-850 text-white'}`}
                >
                  {sessionIsPlaying ? <Pause className="h-3.5 w-3.5 fill-amber-800" /> : <Play className="h-3.5 w-3.5 fill-white" />}
                  <span>{sessionIsPlaying ? 'Pausar' : 'Retomar'}</span>
                </button>

                <button
                  onClick={handleCompleteStudySession}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer transition-all"
                >
                  <Check className="h-3.5 w-3.5" />
                  <span>Concluir Estudo</span>
                </button>

                <button
                  onClick={() => {
                    if(confirm("Deseja cancelar esta sessão? O tempo do cronômetro será perdido.")) {
                      setActiveSessionTask(null);
                      setSessionIsPlaying(false);
                      setSessionTime(0);
                      setSessionNotes('');
                    }
                  }}
                  className="text-xs font-bold text-slate-500 hover:text-red-500 px-2 py-1 cursor-pointer transition-all"
                >
                  Cancelar
                </button>
              </div>
            </div>
          )}

          {/* ========================================================
              SUCCESS CELEBRATION NOTIFICATION BANNER (Sinalizador Visual)
              ======================================================== */}
          {completionNotification && completionNotification.show && (
            <div className="bg-emerald-50 border border-emerald-500 rounded-xl p-5 shadow-sm flex items-start gap-4 animate-in fade-in slide-in-from-top-4 duration-300">
              <div className="p-2.5 bg-emerald-500 text-white rounded-lg">
                <CheckCircle2 className="h-6 w-6" />
              </div>
              <div className="space-y-1 flex-1">
                <h4 className="text-sm font-black text-slate-900 flex items-center gap-1">
                  <span>✨ Meta de Estudo Concluída!</span>
                  <span className="text-[10px] uppercase font-mono font-black text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded ml-2">PARABÉNS!</span>
                </h4>
                <p className="text-xs text-slate-700 leading-relaxed">
                  Você concluiu com sucesso a tarefa <strong className="text-emerald-800">"{completionNotification.title}"</strong> da disciplina <strong>{completionNotification.discipline}</strong>.
                </p>
                <div className="flex items-center gap-4 text-[11px] text-emerald-700 font-bold pt-1.5 border-t border-emerald-150 mt-1">
                  <span className="flex items-center gap-1">⏱️ {completionNotification.duration}m de foco real</span>
                  <span className="flex items-center gap-1">📈 +{completionNotification.hoursEarned}h computadas no progresso semanal</span>
                </div>
              </div>
              <button 
                onClick={() => setCompletionNotification(null)}
                className="text-emerald-500 hover:text-emerald-700 font-black text-sm p-1"
              >
                ✕
              </button>
            </div>
          )}

          {/* ========================================================
              BLOCO B/C — Plano Diário / Agenda (Interactive Task Deck with status & filters)
              ======================================================== */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-extrabold text-slate-800">Roteiro Operacional de Estudos</h3>
                <p className="text-xs text-slate-400">Gerencie, execute e filtre suas tarefas estratégicas em tempo real.</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setNewDay(todayDayName);
                    setShowAddForm(!showAddForm);
                  }}
                  className="bg-oab-primary hover:bg-slate-850 text-white font-extrabold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 transition-all shadow-3xs cursor-pointer uppercase tracking-wider font-mono text-[10px]"
                >
                  <Plus className="h-4 w-4" /> Criar Meta
                </button>
              </div>
            </div>

            {/* BLOCO C — Filtros / organização da lista */}
            <div className="flex overflow-x-auto pb-1.5 mb-1 gap-1.5 scrollbar-thin">
              {[
                { id: 'hoje', label: '📋 Hoje', count: weeklyTasks.filter(t => t.day === todayDayName).length },
                { id: 'semana', label: '🗓️ Semana Toda', count: weeklyTasks.length },
                { id: 'pendentes', label: '⏳ Pendentes', count: weeklyTasks.filter(t => t.status !== 'completed').length },
                { id: 'concluidas', label: '✅ Concluídas', count: weeklyTasks.filter(t => t.status === 'completed').length },
                { id: 'em_andamento', label: '⚡ Em Andamento', count: weeklyTasks.filter(t => t.status === 'in_progress').length }
              ].map(filt => {
                const isSelected = taskFilter === filt.id;
                return (
                  <button
                    key={filt.id}
                    onClick={() => setTaskFilter(filt.id as any)}
                    className={`
                      px-3.5 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer border
                      ${isSelected
                        ? 'bg-oab-primary text-white border-oab-primary shadow-3xs'
                        : 'bg-[#FAF9F6] text-slate-600 border-[#E5E1D8] hover:bg-slate-100/60'
                      }
                    `}
                  >
                    <span>{filt.label}</span>
                    <span className={`text-[9.5px] font-mono px-1.5 py-0.5 rounded-full font-black ${isSelected ? 'bg-oab-accent text-oab-primary' : 'bg-slate-100 text-slate-550'}`}>
                      {filt.count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* List of Filtered Tasks */}
            {filteredTasks.length === 0 ? (
              <div className="text-center py-12 border border-dashed border-[#E5E1D8] rounded-xl p-6 bg-[#FAF9F6]">
                <CalendarDays className="h-10 w-10 text-slate-350 mx-auto mb-2" />
                <p className="text-sm font-serif italic text-slate-600">Nenhuma meta encontrada para este filtro.</p>
                <p className="text-xs text-slate-400 mt-1">Sua agenda está livre! Deseja adicionar uma meta personalizada no botão acima?</p>
              </div>
            ) : (
              <div className="space-y-3.5">
                {filteredTasks.map((task) => {
                  const isCompleted = task.status === 'completed';
                  const isActive = activeSessionTask && activeSessionTask.id === task.id;
                  const isInProgress = task.status === 'in_progress' || isActive;
                  
                  return (
                    <div 
                      key={task.id}
                      className={`p-4 rounded-xl border transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ${isCompleted ? 'bg-slate-50/70 border-slate-100 opacity-70' : isInProgress ? 'bg-amber-50/20 border-amber-300 ring-1 ring-amber-300' : 'bg-white border-slate-200 hover:border-slate-350 shadow-3xs'}`}
                    >
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        {/* Quick complete checkbox */}
                        <button
                          onClick={() => handleToggleActiveTask(task)}
                          className={`mt-0.5 h-5.5 w-5.5 rounded-md flex items-center justify-center border transition-all cursor-pointer ${isCompleted ? 'bg-emerald-600 border-emerald-600 text-white animate-pulse' : 'border-slate-300 hover:border-oab-accent bg-white'}`}
                          title={isCompleted ? 'Marcar como pendente' : 'Marcar como concluído'}
                        >
                          {isCompleted && <Check className="h-3.5 w-3.5 stroke-[3]" />}
                        </button>

                        <div className="space-y-1 flex-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[9.5px] font-black uppercase text-oab-primary bg-slate-100 px-2 py-0.5 rounded border border-slate-150">
                              {task.discipline}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono flex items-center gap-0.5">
                              <Clock className="h-3.5 w-3.5" /> {task.durationMinutes} min
                            </span>
                            <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${task.priority === 'Alta' ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-slate-100 text-slate-600'}`}>
                              {task.priority}
                            </span>
                            
                            {/* Status Badge */}
                            {isCompleted ? (
                              <span className="text-[8.5px] font-black uppercase bg-emerald-50 text-emerald-700 border border-emerald-150 px-2 py-0.5 rounded flex items-center gap-1">
                                <CheckCircle2 className="h-3 w-3" /> Concluída
                              </span>
                            ) : isInProgress ? (
                              <span className="text-[8.5px] font-black uppercase bg-amber-50 text-amber-700 border border-amber-150 px-2 py-0.5 rounded flex items-center gap-1">
                                <span className="h-1.5 w-1.5 rounded-full bg-amber-500"></span> Em Andamento
                              </span>
                            ) : (
                              <span className="text-[8.5px] font-black uppercase bg-slate-100 text-slate-500 border border-slate-150 px-2 py-0.5 rounded">
                                Pendente
                              </span>
                            )}
                          </div>
                          
                          <h4 className={`text-xs font-bold text-slate-800 ${isCompleted ? 'line-through text-slate-400 font-medium' : ''}`}>{task.title}</h4>
                          <p className={`text-[11px] text-slate-500 leading-relaxed ${isCompleted ? 'text-slate-400' : ''}`}>{task.description}</p>
                          
                          {/* Saved Notes display */}
                          {isCompleted && progress.notes[`task-note-${task.id}`] && (
                            <div className="text-[10px] bg-[#FAF9F6] border border-[#E5E1D8] p-2 mt-2 rounded">
                              <span className="block font-bold text-slate-500 uppercase tracking-wide text-[8px]">Suas anotações registradas:</span>
                              <p className="text-slate-600 italic mt-0.5">"{progress.notes[`task-note-${task.id}`]}"</p>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Action buttons panel on right side of card */}
                      <div className="flex flex-wrap items-center gap-3 self-end md:self-center shrink-0">
                        
                        {/* 1. Mover para day inline scheduler (REMARCAR) */}
                        <div className="flex items-center gap-1">
                          <span className="text-[9px] text-slate-400 font-black uppercase">Dia:</span>
                          <select
                            value={task.day}
                            onChange={(e) => {
                              const newDayVal = e.target.value;
                              onUpdateTasks(prev => prev.map(t => t.id === task.id ? { ...t, day: newDayVal } : t));
                            }}
                            className="text-[10px] font-bold border border-slate-200 rounded p-1 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-oab-accent text-slate-600 cursor-pointer"
                          >
                            {DAYS_OF_WEEK.map(d => (
                              <option key={d} value={d}>{d.split('-')[0]}</option>
                            ))}
                          </select>
                        </div>

                        {/* 2. Iniciar / Concluir / Reabrir Study CTA */}
                        {isCompleted ? (
                          <div className="flex items-center gap-1.5">
                            {onStartStudyTask && (
                              <button
                                onClick={() => onStartStudyTask(task.id)}
                                className="text-[9.5px] bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold px-2.5 py-1.5 rounded transition-all cursor-pointer border border-emerald-200 flex items-center gap-1"
                              >
                                Ver Notas
                              </button>
                            )}
                            <button
                              onClick={() => handleToggleActiveTask(task)}
                              className="text-[9.5px] bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold px-2.5 py-1.5 rounded transition-all cursor-pointer border border-slate-250 flex items-center gap-1"
                            >
                              Reabrir
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              if (onStartStudyTask) {
                                onStartStudyTask(task.id);
                              } else {
                                setActiveSessionTask(task);
                                setSessionTime(0);
                                setSessionIsPlaying(true);
                                
                                // Change task status to in_progress globally (Ajuste 1)
                                onUpdateTaskStatus(task.id, 'in_progress');

                                setTimeout(() => {
                                  const el = document.getElementById('active-session-cockpit');
                                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                                }, 100);
                              }
                            }}
                            className={`font-black text-[9.5px] uppercase px-3 py-1.5 rounded transition-all cursor-pointer flex items-center gap-1 ${isInProgress ? 'bg-amber-500 hover:bg-amber-600 text-slate-900' : 'bg-oab-primary hover:bg-slate-850 text-white'}`}
                          >
                            <Play className="h-3 w-3 fill-current" />
                            <span>{isInProgress ? 'Retomar' : 'Estudar'}</span>
                          </button>
                        )}

                        {/* 3. Delete Task */}
                        <button
                          onClick={() => {
                            if (confirm('Deseja realmente remover esta meta do seu plano de estudos?')) {
                              onDeleteTask(task.id);
                            }
                          }}
                          className="text-slate-300 hover:text-red-500 p-1.5 rounded transition-colors cursor-pointer"
                          title="Remover meta"
                        >
                          <Trash className="h-4 w-4" />
                        </button>

                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* ========================================================
              BLOCO E — Histórico Curto / Atividade Recente
              ======================================================== */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <History className="h-5 w-5 text-slate-500" />
              <div>
                <h3 className="text-sm font-bold text-slate-800">Atividade Recente e Histórico</h3>
                <p className="text-xs text-slate-400 font-semibold">Consulte os resumos e o tempo de foco das suas metas concluídas nesta semana.</p>
              </div>
            </div>

            {recentActivityTasks.length === 0 ? (
              <div className="text-center py-6 text-slate-400">
                <p className="text-xs italic">Nenhuma meta foi concluída nesta semana ainda. Comece a estudar agora!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {recentActivityTasks.map((task) => (
                  <div key={task.id} className="p-4 bg-[#FAF9F6] border border-[#E5E1D8] rounded-xl flex flex-col justify-between space-y-2 text-xs">
                    <div className="space-y-1">
                      <div className="flex justify-between items-start">
                        <span className="text-[8px] uppercase font-black tracking-wider text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-150">
                          {task.discipline}
                        </span>
                        <span className="text-[9px] text-slate-400 font-mono">Concluída</span>
                      </div>
                      <h4 className="font-extrabold text-slate-800 line-clamp-1">{task.title}</h4>
                      <p className="text-[10px] text-slate-500 line-clamp-2 leading-relaxed">{task.description}</p>
                    </div>

                    <div className="border-t border-slate-150 pt-2 flex items-center justify-between text-[10px] font-semibold text-slate-600">
                      <span className="flex items-center gap-1 font-mono">
                        ⏱️ {task.durationMinutes}m previstos
                      </span>
                      {task.realStudyTimeSeconds && (
                        <span className="text-[9.5px] text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-150 font-mono">
                          Foco: {formatTime(task.realStudyTimeSeconds)}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 7 - Priorização Automática Alerts */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <ShieldAlert className="h-5 w-5 text-red-500" />
              <div>
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">Priorização Inteligente de Estudos</h4>
                <h3 className="text-sm font-bold text-slate-800">Alertas urgentes do seu conselheiro virtual</h3>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {autoPriorities.map((alert, idx) => (
                <div key={idx} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between min-h-[120px] shadow-3xs">
                  <div className="space-y-1">
                    <div className="flex justify-between items-center">
                      <span className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded ${alert.level === 'Alta' ? 'text-red-700 bg-red-50' : 'text-amber-700 bg-amber-50'}`}>
                        {alert.level}
                      </span>
                      <span className="text-[9.5px] text-slate-400 font-bold uppercase">ALERTA</span>
                    </div>
                    <h5 className="text-xs font-extrabold text-slate-800 mt-1">{alert.title}</h5>
                    <p className="text-[10.5px] text-slate-500 leading-relaxed">{alert.desc}</p>
                  </div>

                  <button
                    onClick={() => {
                      if (alert.targetTab === 'fase1') setInternalTab('trilhas');
                      else if (alert.targetTab === 'fase2') setInternalTab('trilhas');
                      else if (alert.targetTab === 'revisao') onNavigateToTab('revisao');
                      else alert.actionText === 'Reorganizar Hoje' ? handleShiftDelayedTasks() : alert.targetTab === 'plano' ? setInternalTab('hoje') : {};
                    }}
                    className="text-left text-[10px] font-black uppercase tracking-widest text-oab-accent hover:text-amber-600 transition-colors mt-3 flex items-center gap-1 cursor-pointer"
                  >
                    {alert.actionText} <ChevronRight className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Section 10 - Integração com Calendário OAB */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-xl p-5 border border-slate-800 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-300 font-bold">
                <CalendarRange className="h-4.5 w-4.5 text-oab-accent" />
                <span>INTEGRAÇÃO CALENDÁRIO OFICIAL OAB (XL EXAME)</span>
              </div>
              <h3 className="text-sm font-black text-slate-100">Intensidade Recomendada:</h3>
              <p className="text-xs text-slate-400 max-w-xl">{calendarCountdowns.intensityNote}</p>
            </div>

            <div className="flex gap-4 shrink-0 w-full sm:w-auto">
              <div className="flex-1 bg-white/5 border border-white/10 px-4 py-2.5 rounded-xl text-center">
                <div className="text-2xl font-black text-oab-accent font-mono">{calendarCountdowns.daysTo1st}</div>
                <div className="text-[8px] font-black uppercase tracking-wider text-slate-400 mt-1">Dias para 1ª Fase</div>
                <div className="text-[9px] text-slate-500 font-bold mt-0.5">{calendarCountdowns.exam1stDateStr}</div>
              </div>

              <div className="flex-1 bg-white/5 border border-white/10 px-4 py-2.5 rounded-xl text-center">
                <div className="text-2xl font-black text-slate-300 font-mono">{calendarCountdowns.daysTo2nd}</div>
                <div className="text-[8px] font-black uppercase tracking-wider text-slate-400 mt-1">Dias para 2ª Fase</div>
                <div className="text-[9px] text-slate-500 font-bold mt-0.5">{calendarCountdowns.exam2ndDateStr}</div>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* =========================================
          TAB 2: CRONOGRAMA SEMANAL (Section 3)
          ========================================= */}
      {internalTab === 'semanal' && (
        <div className="space-y-6">
          
          {/* Calendar selector grid */}
          <div className="bg-white rounded-xl p-3 shadow-sm border border-slate-200 overflow-x-auto flex gap-1 scrollbar-none" id="semanal-days-tabs">
            {DAYS_OF_WEEK.map((day) => {
              const dayTasks = weeklyTasks.filter(t => t.day === day);
              const comp = dayTasks.filter(t => t.status === 'completed').length;
              const isSelected = selectedDay === day;
              
              return (
                <button
                  key={day}
                  onClick={() => setSelectedDay(day)}
                  className={`px-4 py-2.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex flex-col items-center gap-1 min-w-[110px] cursor-pointer ${isSelected ? 'bg-oab-primary text-white shadow-sm' : 'hover:bg-slate-50 text-slate-500'}`}
                >
                  <span>{day.split('-')[0]}</span>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-mono font-black ${isSelected ? 'bg-oab-accent text-oab-primary' : 'bg-slate-100 text-slate-450'}`}>
                    {comp}/{dayTasks.length}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Details for selected day */}
          <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-800">{selectedDay}</h3>
                <p className="text-xs text-slate-400">Plano de estudos para este dia da semana</p>
              </div>

              <button
                onClick={() => {
                  setNewDay(selectedDay);
                  setShowAddForm(!showAddForm);
                }}
                className="bg-oab-accent hover:bg-yellow-500 text-oab-primary font-black text-xs py-2 px-3 rounded-lg flex items-center gap-1 transition-all cursor-pointer shadow-3xs"
              >
                <Plus className="h-4 w-4" />
                <span>Adicionar Meta</span>
              </button>
            </div>

            {/* List tasks */}
            {weeklyTasks.filter(t => t.day === selectedDay).length === 0 ? (
              <div className="text-center py-12 text-slate-400">
                <CalendarDays className="h-10 w-10 text-slate-250 mx-auto mb-3" />
                <p className="text-sm font-semibold">Sem tarefas agendadas para {selectedDay}.</p>
                <p className="text-xs text-slate-400 mt-1">Crie metas ou utilize a aba "Replanejamento" para movimentar tarefas pendentes.</p>
              </div>
            ) : (
              <div className="space-y-3.5">
                {weeklyTasks.filter(t => t.day === selectedDay).map((task) => {
                  const isCompleted = task.status === 'completed';
                  return (
                    <div 
                      key={task.id}
                      className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 ${isCompleted ? 'bg-slate-50/70 border-slate-100 opacity-75' : 'bg-white border-slate-200 hover:border-slate-350 shadow-3xs'}`}
                    >
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <button
                          onClick={() => onToggleTask(task.id)}
                          className={`mt-0.5 h-5.5 w-5.5 rounded-md flex items-center justify-center border transition-all cursor-pointer ${isCompleted ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-300 hover:border-oab-accent bg-white'}`}
                        >
                          {isCompleted && <Check className="h-3.5 w-3.5" />}
                        </button>

                        <div className="flex-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[10px] font-extrabold text-oab-primary uppercase tracking-wider bg-slate-50 px-2 py-0.5 rounded border border-slate-150">
                              {task.discipline}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono flex items-center">
                              <Clock className="h-3.5 w-3.5 mr-0.5" />
                              {task.estimatedMinutes !== undefined ? task.estimatedMinutes : task.durationMinutes} min
                            </span>
                            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${task.priority === 'Alta' ? 'bg-red-50 text-red-600' : 'bg-slate-100 text-slate-600'}`}>
                              {task.priority}
                            </span>
                          </div>
                          <h4 className={`text-sm font-bold text-slate-850 mt-1.5 ${isCompleted ? 'line-through text-slate-400' : ''}`}>{task.title}</h4>
                          <p className={`text-xs text-slate-500 mt-1 leading-relaxed ${isCompleted ? 'text-slate-400' : ''}`}>{task.description}</p>
                        </div>
                      </div>

                      {/* Reschedule buttons and deletion */}
                      <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                        {/* Reschedule selector */}
                        <div className="flex items-center gap-1">
                          <span className="text-[9px] text-slate-400 uppercase font-bold">Mover para:</span>
                          <select
                            value={task.day}
                            onChange={(e) => {
                              const newDayVal = e.target.value;
                              setRescheduleConfirm({
                                show: true,
                                message: "Mudar o dia desta tarefa pode afetar sua distribuição de estudo semanal e acumular matérias em outros dias. Deseja prosseguir com o reagendamento pedagógico?",
                                onConfirm: () => {
                                  onUpdateTasks(prev => prev.map(t => t.id === task.id ? { ...t, day: newDayVal } : t));
                                }
                              });
                            }}
                            className="text-[10px] font-bold border border-slate-200 rounded p-1 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-oab-accent text-slate-600"
                          >
                            {DAYS_OF_WEEK.map(d => (
                              <option key={d} value={d}>{d.split('-')[0]}</option>
                            ))}
                          </select>
                        </div>

                      <button
                        onClick={() => onDeleteTask(task.id)}
                        className="text-slate-300 hover:text-red-500 p-1.5 rounded transition-colors cursor-pointer"
                        title="Excluir tarefa"
                      >
                        <Trash className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
              </div>
            )}
          </div>

        </div>
      )}

      {/* =========================================
          TAB 3: MINHAS METAS & HISTÓRICO (Sections 4 & 9)
          ========================================= */}
      {internalTab === 'metas' && (
        <div className="space-y-6">
          
          {/* Header Stats card */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 bg-white rounded-xl p-5 border border-slate-200 shadow-sm text-center">
            <div className="space-y-1">
              <span className="text-3xl font-mono font-black text-oab-accent">04 dias</span>
              <span className="block text-[10px] text-slate-400 uppercase font-black tracking-widest">Sequência Atual (Streak)</span>
              <span className="block text-[11px] text-slate-500 font-semibold">Bateu metas de Segunda a Quinta</span>
            </div>

            <div className="space-y-1 border-t sm:border-t-0 sm:border-l sm:border-r border-slate-150 py-4 sm:py-0">
              <span className="text-3xl font-mono font-black text-emerald-600">{totalWeeklyCompleted} / {weeklyTasks.length}</span>
              <span className="block text-[10px] text-slate-400 uppercase font-black tracking-widest">Metas Semanais Batidas</span>
              <span className="block text-[11px] text-slate-500 font-semibold">{progressPlanPercentage}% de conclusão global</span>
            </div>

            <div className="space-y-1">
              <span className="text-3xl font-mono font-black text-indigo-600">{weeklyStudyHours}h</span>
              <span className="block text-[10px] text-slate-400 uppercase font-black tracking-widest">Carga Registrada</span>
              <span className="block text-[11px] text-slate-500 font-semibold">Meta de horas semanais: {studyHoursGoal}h</span>
            </div>
          </div>

          {/* Section 4 - Metas Detalhadas Grid */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-sm font-extrabold text-slate-800 border-b border-slate-100 pb-3">Detalhamento das Metas de Estudo</h3>
            
            <div className="space-y-6">
              
              {/* Daily Goals */}
              <div className="space-y-3">
                <h4 className="text-xs font-black uppercase text-amber-600 tracking-wider flex items-center gap-1.5">
                  <Flame className="h-4.5 w-4.5" /> Metas Diárias (Aproveitamento)
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {goalsData.daily.map((goal, i) => (
                    <div key={i} className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between space-y-2.5">
                      <div className="flex justify-between items-start text-xs font-semibold">
                        <span className="text-slate-700 font-extrabold block max-w-[150px]">{goal.name}</span>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${goal.status === 'Concluído' ? 'bg-emerald-50 text-emerald-600 border border-emerald-150' : 'bg-amber-50 text-amber-700 border border-amber-150'}`}>
                          {goal.status}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-slate-400">Progresso:</span>
                          <span className="font-mono font-black text-slate-700">{goal.current} / {goal.target}</span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div className="h-full bg-amber-500 rounded-full" style={{ width: `${goal.pct}%` }} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Weekly Goals */}
              <div className="space-y-3 pt-4 border-t border-slate-100">
                <h4 className="text-xs font-black uppercase text-indigo-600 tracking-wider flex items-center gap-1.5">
                  <Target className="h-4.5 w-4.5" /> Metas Semanais (Ciclos OAB)
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {goalsData.weekly.map((goal, i) => (
                    <div key={i} className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between space-y-2.5">
                      <div className="flex justify-between items-start text-xs font-semibold">
                        <span className="text-slate-700 font-extrabold block max-w-[150px]">{goal.name}</span>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${goal.status === 'Concluído' ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'}`}>
                          {goal.status}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-slate-400">Progresso:</span>
                          <span className="font-mono font-black text-slate-700">{goal.current} / {goal.target}</span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${goal.pct}%` }} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Monthly Goals */}
              <div className="space-y-3 pt-4 border-t border-slate-100">
                <h4 className="text-xs font-black uppercase text-purple-600 tracking-wider flex items-center gap-1.5">
                  <Award className="h-4.5 w-4.5" /> Metas Mensais (Evolução OAB)
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {goalsData.monthly.map((goal, i) => (
                    <div key={i} className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between space-y-2.5">
                      <div className="flex justify-between items-start text-xs font-semibold">
                        <span className="text-slate-700 font-extrabold block max-w-[150px]">{goal.name}</span>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${goal.status === 'Atrasado' ? 'bg-red-50 text-red-600' : 'bg-purple-50 text-purple-600'}`}>
                          {goal.status}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-slate-400">Progresso:</span>
                          <span className="font-mono font-black text-slate-700">{goal.current} / {goal.target}</span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div className="h-full bg-purple-500 rounded-full" style={{ width: `${goal.pct}%` }} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>

          {/* Section 9 - Histórico de Execução do Aluno */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-sm font-extrabold text-slate-800 border-b border-slate-100 pb-3 flex items-center gap-1.5">
              <History className="h-5 w-5 text-slate-600" /> Histórico Completo de Metas & Execuções
            </h3>

            {/* List log of completed tasks */}
            <div className="space-y-3">
              {weeklyTasks.filter(t => t.status === 'completed').length === 0 ? (
                <div className="text-center py-6 text-slate-400">
                  <p className="text-xs">Nenhuma tarefa marcada como concluída nesta semana ainda!</p>
                </div>
              ) : (
                <div className="space-y-2">
                  <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Concluídas Recentemente</h4>
                  {weeklyTasks.filter(t => t.status === 'completed').map((task) => (
                    <div key={task.id} className="p-3 bg-slate-50/60 border border-slate-150 rounded-lg flex justify-between items-center text-xs">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-4.5 w-4.5 text-emerald-600" />
                        <div>
                          <span className="font-extrabold text-slate-800 block">{task.title}</span>
                          <span className="text-[10px] text-slate-400 uppercase font-bold">{task.discipline} • {task.day}</span>
                        </div>
                      </div>
                      <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-150 px-2 py-0.5 rounded font-black font-mono">
                        +{task.estimatedMinutes !== undefined ? task.estimatedMinutes : task.durationMinutes}m
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

        </div>
      )}

      {/* =========================================
          TAB 4: TRILHA OAB (Sections 5 & 6)
          ========================================= */}
      {internalTab === 'trilhas' && (
        <div className="space-y-6">
          
          {/* Section 5 - Plano da 1ª Fase OAB */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <span className="bg-oab-accent/15 text-oab-primary px-2.5 py-0.5 rounded text-[9.5px] font-black uppercase tracking-wider block w-fit">
                SUBPLANO OBJETIVO
              </span>
              <h3 className="text-base font-black text-slate-800 mt-1 flex items-center gap-1.5">
                <Compass className="h-5 w-5 text-oab-accent" /> Trilha 1ª Fase (19 Disciplinas Oficiais)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">Visão do cronograma e pesos estratégicos das matérias na prova objetiva.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="trilha-1fase-deck">
              {phase1StrategicPlan.map((item, idx) => (
                <div key={idx} className="p-4 border border-slate-200 bg-white hover:border-oab-accent rounded-xl flex flex-col justify-between space-y-3 shadow-3xs transition-all">
                  <div className="space-y-1">
                    <div className="flex justify-between items-center">
                      <h4 className="text-xs font-black text-slate-800">{item.name}</h4>
                      <span className="text-[10px] text-slate-400 font-black font-mono">Peso: {item.questions} questões</span>
                    </div>
                    <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded block w-fit ${item.priority === 'Crítica / Muito Alta' ? 'bg-red-50 text-red-600 border border-red-100' : item.priority === 'Muito Alta' ? 'bg-amber-50 text-amber-700' : 'bg-slate-50 text-slate-600'}`}>
                      Prioridade: {item.priority}
                    </span>
                    <p className="text-[11px] text-slate-500 leading-normal">{item.advice}</p>
                  </div>

                  {/* Simulated progression inside discipline */}
                  <div className="space-y-1 pt-1 border-t border-slate-100">
                    <div className="flex justify-between text-[10px] text-slate-400 font-bold">
                      <span>Progresso Teoria/PDF</span>
                      <span>{item.progress}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: `${item.progress}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 6 - Plano da 2ª Fase OAB */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-3">
              <div>
                <span className="bg-purple-100 text-purple-700 px-2.5 py-0.5 rounded text-[9.5px] font-black uppercase tracking-wider block w-fit">
                  SUBPLANO PRÁTICO-PROFISSIONAL
                </span>
                <h3 className="text-base font-black text-slate-800 mt-1 flex items-center gap-1.5">
                  <UserCheck className="h-5 w-5 text-purple-600" /> Trilha de Peças e Discursivas (2ª Fase)
                </h3>
              </div>

              {/* Quick Area Choice Selector */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-bold">Área Selecionada:</span>
                <select
                  value={progress.selectedSecondPhaseArea || 'Direito Penal'}
                  onChange={(e) => onSelectArea(e.target.value)}
                  className="text-xs font-bold border border-slate-200 rounded-lg p-2 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-oab-accent text-purple-700"
                >
                  <option value="Direito Penal">Direito Penal</option>
                  <option value="Direito Constitucional">Direito Constitucional</option>
                  <option value="Direito Administrativo">Direito Administrativo</option>
                  <option value="Direito do Trabalho">Direito do Trabalho</option>
                </select>
              </div>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              Baseado na sua escolha por <strong>{progress.selectedSecondPhaseArea || 'Direito Penal'}</strong>, preparamos o cronograma abaixo focado inteiramente em peças, dissertações e exames práticos simulados:
            </p>

            <div className="space-y-3 pt-2">
              {phase2StrategicPlan.map((item, i) => (
                <div key={i} className="p-3.5 border border-slate-150 rounded-xl bg-slate-50/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400 font-bold uppercase font-mono">{item.day}</span>
                    <h4 className="text-xs font-extrabold text-slate-850">{item.task}</h4>
                  </div>

                  <span className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded ${item.type === 'peca' ? 'text-purple-700 bg-purple-50' : item.type === 'discursiva' ? 'text-blue-700 bg-blue-50' : item.type === 'revisao' ? 'text-amber-700 bg-amber-50' : 'text-emerald-700 bg-emerald-50'}`}>
                    {item.type}
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* =========================================
          TAB 5: REPLANEJAMENTO AUTOMÁTICO & AJUSTES (Section 8)
          ========================================= */}
      {internalTab === 'replanejamento' && (
        <div className="space-y-6">
          
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <span className="bg-amber-100 text-amber-700 px-2.5 py-0.5 rounded text-[9.5px] font-black uppercase tracking-wider block w-fit">
                MECANISMO DE ADAPTABILIDADE
              </span>
              <h3 className="text-base font-black text-slate-800 mt-1 flex items-center gap-1.5">
                <RefreshCw className="h-5 w-5 text-oab-accent animate-spin-slow" /> Replanejamento Automático Adaptativo
              </h3>
              <p className="text-xs text-slate-450 mt-0.5">Adapte seu plano de estudos conforme sua rotina, desempenho nas questões, atrasos acumulados ou metas.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              
              {/* Action card 1: Reagendar atrasos */}
              <div className="p-5 border border-slate-200 bg-slate-50/40 hover:bg-slate-50 rounded-xl flex flex-col justify-between space-y-4 shadow-3xs">
                <div className="space-y-1.5">
                  <h4 className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                    <CalendarDays className="h-4.5 w-4.5 text-oab-accent" /> Reagendar Metas Atrasadas
                  </h4>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    Identificamos <strong>{delayedTasks.length}</strong> metas não concluídas de dias anteriores nesta semana. Move tudo para hoje e restabelece a regularidade do seu fluxo de aprovação.
                  </p>
                </div>
                
                <button
                  onClick={handleShiftDelayedTasks}
                  disabled={delayedTasks.length === 0}
                  className={`w-full text-center text-xs font-black uppercase px-4 py-2.5 rounded-lg transition-all cursor-pointer ${delayedTasks.length > 0 ? 'bg-oab-accent hover:bg-yellow-500 text-oab-primary shadow-xs' : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'}`}
                >
                  Shiftar {delayedTasks.length} metas atrasadas
                </button>
              </div>

              {/* Action card 2: Redistribuir carga semanal */}
              <div className="p-5 border border-slate-200 bg-slate-50/40 hover:bg-slate-50 rounded-xl flex flex-col justify-between space-y-4 shadow-3xs">
                <div className="space-y-1.5">
                  <h4 className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                    <Hourglass className="h-4.5 w-4.5 text-indigo-600" /> Redistribuir Carga Semanal
                  </h4>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    Sua semana acumulou tarefas pendentes? Redistribui todas as metas incompletas de forma igualitária entre hoje e domingo para não sobrecarregar nenhum dia.
                  </p>
                </div>

                <button
                  onClick={handleRedistributeWeeklyLoad}
                  className="bg-oab-primary hover:bg-slate-850 text-white w-full text-center text-xs font-black uppercase px-4 py-2.5 rounded-lg transition-all cursor-pointer shadow-2xs"
                >
                  Redistribuir Carga Semanal
                </button>
              </div>

              {/* Action card 3: Injeção por Baixo Desempenho */}
              <div className="p-5 border border-slate-200 bg-slate-50/40 hover:bg-slate-50 rounded-xl flex flex-col justify-between space-y-4 shadow-3xs">
                <div className="space-y-1.5">
                  <h4 className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                    <AlertTriangle className="h-4.5 w-4.5 text-red-500" /> Injetar Reforço em Matérias Fracas
                  </h4>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    Análise heurística: Direito Civil e Processo Penal estão com acertos fracos (&lt; 55%). Injeta instantaneamente metas extras de fixação dessas duas matérias estratégicas.
                  </p>
                </div>

                <button
                  onClick={handleInjectReinforcementTasks}
                  className="bg-red-600 hover:bg-red-700 text-white w-full text-center text-xs font-black uppercase px-4 py-2.5 rounded-lg transition-all cursor-pointer shadow-2xs"
                >
                  Injetar Reforço Inteligente
                </button>
              </div>

              {/* Action card 4: Ajustar Carga Horária Metas */}
              <div className="p-5 border border-slate-200 bg-slate-50/40 hover:bg-slate-50 rounded-xl flex flex-col justify-between space-y-4 shadow-3xs">
                <div className="space-y-1.5">
                  <h4 className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                    <Settings className="h-4.5 w-4.5 text-slate-600" /> Alterar Meta Semanal de Estudo
                  </h4>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    Sua rotina está corrida ou você possui mais tempo livre para estudar? Regule seu objetivo de horas acumuladas na semana para calibrar seu progresso.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    value={studyHoursGoal}
                    onChange={(e) => onUpdateHoursGoal(Math.max(1, parseInt(e.target.value) || 20))}
                    className="w-20 text-center font-bold text-slate-800 bg-white border border-slate-200 rounded-lg p-2 focus:outline-none focus:ring-1 focus:ring-oab-accent text-xs"
                  />
                  <span className="text-xs font-semibold text-slate-500">horas semanais planejadas</span>
                </div>
              </div>

            </div>
          </div>

        </div>
      )}

      {/* --- FLOATING MODAL: ADD CUSTOM TASK (Section 2 & 3) --- */}
      {showAddForm && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-2xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl p-6 shadow-xl border border-slate-200 w-full max-w-md animate-in fade-in zoom-in-95 duration-150">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-4">
              <h3 className="text-sm font-black text-slate-850 flex items-center gap-1.5">
                <BookOpen className="h-4.5 w-4.5 text-oab-accent" />
                Adicionar Meta de Estudos ({newDay.split('-')[0]})
              </h3>
              <button 
                onClick={() => setShowAddForm(false)} 
                className="text-slate-400 hover:text-slate-600 font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-extrabold text-slate-600 mb-1">Tipo de Atividade</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { id: 'aula', label: '📺 Aula' },
                    { id: 'questao', label: '✍️ Questões' },
                    { id: 'revisao', label: '🔁 Revisão' },
                    { id: 'simulado', label: '📈 Simulado' },
                    { id: 'peca', label: '📂 Peça' },
                    { id: 'discursiva', label: '📝 Questão' }
                  ].map(act => (
                    <button
                      key={act.id}
                      type="button"
                      onClick={() => setNewActivityType(act.id as any)}
                      className={`py-1.5 rounded-lg text-[10px] font-black border transition-all cursor-pointer ${newActivityType === act.id ? 'bg-oab-accent border-amber-300 text-oab-primary' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'}`}
                    >
                      {act.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Título da Meta</label>
                <input
                  type="text"
                  placeholder="Ex: Prerrogativas profissionais do Advogado"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-oab-accent"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Descrição / Instruções</label>
                <textarea
                  placeholder="Ex: Ler arts. 6º e 7º do Estatuto da OAB e responder 10 questões da prova anterior..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full text-xs border border-slate-200 rounded-lg p-2.5 h-16 focus:outline-none focus:ring-1 focus:ring-oab-accent"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Dia da Semana</label>
                  <select
                    value={newDay}
                    onChange={(e) => setNewDay(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg p-2 bg-slate-50 focus:outline-none"
                  >
                    {DAYS_OF_WEEK.map(d => (
                      <option key={d} value={d}>{d.split('-')[0]}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Duração (min)</label>
                  <input
                    type="number"
                    value={newDuration}
                    onChange={(e) => setNewDuration(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg p-2 focus:outline-none focus:ring-1 focus:ring-oab-accent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Disciplina Correlata</label>
                <select
                  value={newDiscipline}
                  onChange={(e) => setNewDiscipline(e.target.value)}
                  className="w-full text-xs border border-slate-200 rounded-lg p-2 bg-slate-50 focus:outline-none"
                >
                  <option value="Ética Profissional">Ética Profissional</option>
                  <option value="Direito Constitucional">Direito Constitucional</option>
                  <option value="Direito Penal">Direito Penal</option>
                  <option value="Direito Civil">Direito Civil</option>
                  <option value="Direito do Trabalho">Direito do Trabalho</option>
                  <option value="Processo Penal">Processo Penal</option>
                  <option value="Processo Civil">Processo Civil</option>
                  <option value="Direito Administrativo">Direito Administrativo</option>
                  <option value="Outra Matéria">Outra Matéria</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Prioridade</label>
                <div className="flex gap-2">
                  {(['Baixa', 'Média', 'Alta'] as const).map(p => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setNewPriority(p)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${newPriority === p ? 'bg-amber-50 border-amber-300 text-amber-600' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'}`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs py-2.5 rounded-lg transition-colors cursor-pointer text-center"
                >
                  Cancelar
                </button>
                
                <button
                  type="submit"
                  className="flex-1 bg-oab-primary hover:bg-slate-850 text-white font-bold text-xs py-2.5 rounded-lg transition-colors cursor-pointer text-center"
                >
                  Salvar no Plano
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Dialog for Pedagogical Rescheduling Warning (Ajuste 5) */}
      {rescheduleConfirm && rescheduleConfirm.show && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50 backdrop-blur-xs animate-fade-in" id="reschedule-confirm-modal">
          <div className="bg-white border border-[#E5E1D8] shadow-xl rounded-xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-amber-50 text-amber-600 rounded-lg shrink-0">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <div className="space-y-1.5 flex-1">
                <h4 className="text-base font-black text-slate-900 font-serif">Alerta de Planejamento Pedagógico</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {rescheduleConfirm.message}
                </p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setRescheduleConfirm(null)}
                className="w-full sm:w-auto px-4 py-2 border border-slate-200 text-slate-600 hover:text-slate-800 text-[11px] font-extrabold uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
              >
                Não, manter plano original
              </button>
              <button
                onClick={() => {
                  rescheduleConfirm.onConfirm();
                  setRescheduleConfirm(null);
                }}
                className="w-full sm:w-auto px-4 py-2 bg-oab-accent hover:bg-yellow-500 text-oab-primary text-[11px] font-extrabold uppercase tracking-wider rounded-lg transition-colors cursor-pointer shadow-xs"
              >
                Sim, quero reagendar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
