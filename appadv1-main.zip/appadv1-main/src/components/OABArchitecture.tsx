/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Settings, 
  Workflow, 
  ShieldCheck, 
  ChevronRight, 
  ChevronDown, 
  Play, 
  RefreshCw, 
  User, 
  Key, 
  Activity, 
  Sliders, 
  FileText, 
  CheckCircle, 
  Lock, 
  Sparkles, 
  Crown, 
  AlertTriangle, 
  Layers, 
  ArrowRight, 
  Cpu, 
  Search, 
  Check, 
  Clock, 
  Calendar, 
  BookOpen, 
  Plus,
  Shield,
  Briefcase
} from 'lucide-react';

// ==========================================
// ARCHITECTURE TYPES & MODELS DECLARATIONS
// ==========================================

interface DatabaseField {
  name: string;
  type: string;
  nullable: boolean;
  isKey?: 'PK' | 'FK' | boolean;
  description: string;
}

interface DatabaseEntity {
  id: string;
  name: string;
  group: 'usuario' | 'academica' | 'questoes' | 'fase2' | 'plano' | 'desempenho' | 'monetizacao' | 'calendario' | 'comunidade';
  groupLabel: string;
  description: string;
  fields: DatabaseField[];
  relations: string[];
  importance: string;
}

interface SimulatedAuditLog {
  id: string;
  timestamp: string;
  actor: string;
  role: string;
  action: string;
  target: string;
  status: 'sucesso' | 'info' | 'alerta';
}

export default function OABArchitecture() {
  // Navigation tabs of the architecture system
  const [activeLayer, setActiveLayer] = useState<'database' | 'rules' | 'integrations' | 'governance'>('database');

  // Schema state
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<string>('all');
  const [expandedEntityId, setExpandedEntityId] = useState<string | null>('usuario');

  // Business Rules Simulator inputs
  const [simFase, setSimFase] = useState<'1a' | '2a'>('1a');
  const [simArea2nd, setSimArea2nd] = useState<string>('Direito Penal');
  const [simHoursPerDay, setSimHoursPerDay] = useState<number>(3);
  const [simDaysPerWeek, setSimDaysPerWeek] = useState<number>(6);
  const [simPlan, setSimPlan] = useState<'gratuito' | 'fase1' | 'fase2' | 'completo' | 'vip'>('gratuito');
  const [simAccuracy, setSimAccuracy] = useState<number>(60);
  const [simDaysActive, setSimDaysActive] = useState<number>(4);
  const [examDistance, setExamDistance] = useState<number>(45); // Days left for the exam

  // Computed rules state
  const [computedProfile, setComputedProfile] = useState<string>('Iniciante 1ª Fase');
  const [computedRisk, setComputedRisk] = useState<'Baixo' | 'Médio' | 'Alto'>('Baixo');
  const [simulationLogs, setSimulationLogs] = useState<string[]>([]);
  const [simActiveFeatures, setSimActiveFeatures] = useState<Record<string, boolean>>({});

  // Governance state
  const [selectedRole, setSelectedRole] = useState<string>('super_admin');
  const [auditLogs, setAuditLogs] = useState<SimulatedAuditLog[]>([
    { id: '1', timestamp: '2026-06-25 10:15:23', actor: 'Prof. Lucas Santos', role: 'Super Admin', action: 'Criou nova Trilha Teórica', target: 'Trilha 1ª Fase - Direito Constitucional', status: 'sucesso' },
    { id: '2', timestamp: '2026-06-25 10:18:41', actor: 'Amanda Lima (Suporte)', role: 'Suporte', action: 'Respondeu chamado #OAB-3F-1025', target: 'poprotaspires@gmail.com', status: 'sucesso' },
    { id: '3', timestamp: '2026-06-25 10:32:10', actor: 'poprotaspires@gmail.com', role: 'Aluno', action: 'Concluiu Onboarding OAB 3F', target: 'Geração de Plano Inteligente', status: 'info' },
    { id: '4', timestamp: '2026-06-25 10:35:00', actor: 'Sistema OAB 3F', role: 'Motor de Regras', action: 'Regra de Transição: Reta Final Ativada', target: 'Perfil do Aluno ID: 8854', status: 'alerta' }
  ]);

  // Integration Event simulator state
  const [activeIntegrationId, setActiveIntegrationId] = useState<string | null>(null);
  const [integrationSteps, setIntegrationSteps] = useState<string[]>([]);
  const [isSimulatingIntegration, setIsSimulatingIntegration] = useState(false);

  // Run dynamic business rules logic check on input change
  useEffect(() => {
    let profile = 'Iniciante 1ª Fase';
    let risk: 'Baixo' | 'Médio' | 'Alto' = 'Baixo';
    const logs: string[] = [];

    logs.push("🚦 Reiniciando Motor de Regras OAB 3F...");

    // Rule 1: Determine Student Profile
    if (simFase === '2a') {
      profile = `Focado na 2ª Fase (${simArea2nd})`;
      if (simPlan === 'fase1') {
        logs.push("⚠️ ALERTA DE PERMISSÃO: Aluno na 2ª Fase mas assina apenas 1ª Fase.");
      }
    } else {
      if (examDistance <= 15) {
        profile = 'Reta Final 1ª Fase (Intensivo)';
      } else if (simAccuracy < 50) {
        profile = 'Aluno em Recuperação (Abaixo da Meta)';
      } else if (simPlan === 'vip' || simPlan === 'completo') {
        profile = 'Aluno VIP OAB 3F';
      } else {
        profile = 'Iniciante / Intermediário 1ª Fase';
      }
    }
    logs.push(`👤 Perfil computado: ${profile}`);

    // Rule 2: Determine Risco de Abandono / Desempenho
    if (simDaysActive <= 2) {
      risk = 'Alto';
      logs.push("🚨 RISCO DE ABANDONO: Aluno ativo menos de 3 dias na semana.");
    } else if (simAccuracy < 50 || simDaysActive === 3) {
      risk = 'Médio';
      logs.push("⚖️ ALERTA DE RISCO MÉDIO: Desempenho acadêmico ou frequência requer atenção.");
    } else {
      risk = 'Baixo';
      logs.push("✅ RISCO BAIXO: Estudante consistente com ótima constância!");
    }

    // Rule 3: Validate Subscription & Active Features
    const features = {
      teoriaBasica: true,
      simuladosComuns: simPlan !== 'gratuito',
      simuladosIlimitados: simPlan === 'vip' || simPlan === 'completo',
      cronogramaPersonalizado: true,
      pecasPraticas: simPlan === 'vip' || simPlan === 'completo' || simPlan === 'fase2',
      correcaoIndividual: simPlan === 'vip',
      mentoriaAoVivo: simPlan === 'vip',
      suportePrioritario: simPlan === 'vip' || simPlan === 'completo',
    };
    
    setComputedProfile(profile);
    setComputedRisk(risk);
    setSimActiveFeatures(features);
    setSimulationLogs(logs);

  }, [simFase, simArea2nd, simHoursPerDay, simDaysPerWeek, simPlan, simAccuracy, simDaysActive, examDistance]);

  // Handle live integration simulation trigger
  const triggerIntegrationSimulation = (id: string, name: string) => {
    setIsSimulatingIntegration(true);
    setActiveIntegrationId(id);
    setIntegrationSteps([]);

    let steps: string[] = [];
    if (id === 'int1') {
      steps = [
        "1. Onboarding finalizado com sucesso pelo usuário.",
        "2. Criada entidade PerfilDoAluno com as respostas estruturadas.",
        "3. Chamado o Motor de Geração de Planos com dados de Horas Diárias e Área Escolhida.",
        "4. Gerado PlanoDeEstudo id: 'pln-generated' e populado com 42 tarefas prioritárias.",
        "5. Salvo HistóricoDeAtividade: 'onboarding_concluido'.",
        "6. Dashboard principal atualizado instantaneamente com o foco semanal!"
      ];
    } else if (id === 'int2') {
      steps = [
        "1. Carregada entidade PlanoDeEstudo ativa para o usuário logado.",
        "2. Filtradas tarefas recomendadas para a data sugerida = hoje.",
        "3. Buscados conteúdos e materiais correlacionados a cada tarefa.",
        "4. Calculada a contagem regressiva para a prova com base em PerfilDoAluno.data_prova.",
        "5. Atualizado o progresso diário na barra de tarefas do Dashboard."
      ];
    } else if (id === 'int3') {
      steps = [
        "1. Aluno respondeu uma questão de Direito Penal OAB.",
        "2. Criada a entidade TentativaDeQuestao (Acertou: TRUE, Tempo: 45s).",
        "3. Sistema detecta disciplina vinculada (ID: 'dp-penal').",
        "4. Atualizado o cache de MetricaDeDesempenhoDoAluno para Direito Penal.",
        "5. Regra de Revisão Inteligente é disparada: Criado agendamento de RevisaoProgramada de 24h para o assunto estudado."
      ];
    } else if (id === 'int4') {
      steps = [
        "1. Verificada AssinaturaDoAluno ativa vinculada ao usuário.",
        "2. Motor de ControleDeAcesso intercepta a rota de Peças OAB.",
        "3. Validação: Plano 'Apenas 1ª Fase' ou 'Gratuito' não possuem acesso à 2ª Fase.",
        "4. Disparada Regra de Paywall contextual com oferta personalizada de Upgrade.",
        "5. Registro em HistóricoDeAtividade: 'visualizou_paywall_pecas'."
      ];
    } else {
      steps = [
        "1. Iniciando sincronização entre módulos.",
        "2. Dados do banco de dados atualizados nas tabelas acadêmicas.",
        "3. Notificação do aluno gerada e despachada para o painel."
      ];
    }

    // Simulate animated step-by-step display
    let currentStepIndex = 0;
    const interval = setInterval(() => {
      if (currentStepIndex < steps.length) {
        setIntegrationSteps(prev => [...prev, steps[currentStepIndex]]);
        currentStepIndex++;
      } else {
        clearInterval(interval);
        setIsSimulatingIntegration(false);
      }
    }, 450);
  };

  // 35 Entities of OAB 3F Database Schema
  const entities: DatabaseEntity[] = [
    // GROUP A: USUARIO E PERFIL
    {
      id: 'usuario',
      name: 'Usuário',
      group: 'usuario',
      groupLabel: 'Grupo A — Usuário e Perfil',
      description: 'Entidade principal que representa o candidato ou equipe operacional no sistema.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'Chave primária exclusiva do usuário' },
        { name: 'nome', type: 'VARCHAR(150)', nullable: false, description: 'Nome completo do usuário' },
        { name: 'email', type: 'VARCHAR(100)', nullable: false, description: 'Email de login único' },
        { name: 'telefone', type: 'VARCHAR(20)', nullable: true, description: 'Contato telefônico (usado para envio de avisos VIP de mentoria)' },
        { name: 'senha_hash', type: 'VARCHAR(255)', nullable: false, description: 'Senha criptografada' },
        { name: 'foto_url', type: 'VARCHAR(255)', nullable: true, description: 'Foto de perfil do estudante' },
        { name: 'data_cadastro', type: 'TIMESTAMP', nullable: false, description: 'Data/hora da criação do cadastro' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Status da conta (ativo, bloqueado, suspenso)' },
        { name: 'tipo', type: 'VARCHAR(20)', nullable: false, description: 'Perfil (aluno, admin, mentor, suporte, professor)' },
        { name: 'ultimo_acesso', type: 'TIMESTAMP', nullable: true, description: 'Registro de data/hora da última atividade no app' }
      ],
      relations: [
        'Perfil do Aluno (1:1)',
        'Assinatura do Aluno (1:N)',
        'Tentativa de Questão (1:N)',
        'Dúvida / Comentário (1:N)',
        'Chamado de Suporte (1:N)'
      ],
      importance: 'É a espinha dorsal de identificação do ecossistema. Todo progresso e acesso estão atrelados a ela.'
    },
    {
      id: 'perfil_aluno',
      name: 'Perfil do Aluno',
      group: 'usuario',
      groupLabel: 'Grupo A — Usuário e Perfil',
      description: 'Dados pedagógicos e características acadêmicas complementares do estudante.',
      fields: [
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Chave estrangeira apontando para Usuário' },
        { name: 'fase_atual', type: 'VARCHAR(10)', nullable: false, description: 'Fase de preparação (1ª fase, 2ª fase)' },
        { name: 'area_2ª_fase', type: 'VARCHAR(50)', nullable: true, description: 'Área da 2ª fase OAB escolhida (Penal, Trabalho, Civil etc.)' },
        { name: 'nivel_estudante', type: 'VARCHAR(30)', nullable: false, description: 'Iniciante, intermediário, avançado, repetente' },
        { name: 'horas_diarias', type: 'DECIMAL(3,1)', nullable: false, description: 'Horas disponíveis por dia para estudar' },
        { name: 'dias_semana', type: 'INT', nullable: false, description: 'Dias livres na semana' },
        { name: 'turno_estudo', type: 'VARCHAR(20)', nullable: true, description: 'Manhã, Tarde, Noite, Integral' },
        { name: 'data_prova_estimada', type: 'DATE', nullable: false, description: 'Data da prova oficial OAB de destino' },
        { name: 'perfil_onboarding', type: 'VARCHAR(50)', nullable: true, description: 'Classificação gerada pelo questionário de entrada' }
      ],
      relations: [
        'Usuário (1:1)',
        'Plano de Estudo (1:1)'
      ],
      importance: 'Usado para personalizar a carga horária de tarefas e aplicar regras de recomendação adaptativas.'
    },
    {
      id: 'historico_onboarding',
      name: 'Histórico de Onboarding',
      group: 'usuario',
      groupLabel: 'Grupo A — Usuário e Perfil',
      description: 'Armazena as respostas brutas fornecidas pelo estudante durante a configuração inicial do aplicativo.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'Chave primária do onboarding' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Chave estrangeira apontando para Usuário' },
        { name: 'data_conclusao', type: 'TIMESTAMP', nullable: false, description: 'Data e hora que finalizou o onboarding' },
        { name: 'respostas_json', type: 'JSON', nullable: false, description: 'JSON contendo as perguntas e respostas brutas das etapas' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Status (iniciado, em_progresso, concluido, abandonado)' }
      ],
      relations: [
        'Usuário (1:N)'
      ],
      importance: 'Guarda o histórico do comportamento inicial para fins de auditoria acadêmica e calibração de modelos de recomendação.'
    },

    // GROUP B: ACADEMICA
    {
      id: 'curso',
      name: 'Curso',
      group: 'academica',
      groupLabel: 'Grupo B — Estrutura Acadêmica',
      description: 'Representação de um produto educacional completo comercializado ou disponibilizado gratuitamente.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do Curso' },
        { name: 'nome', type: 'VARCHAR(100)', nullable: false, description: 'Nome do curso (ex: OAB 3F Completo)' },
        { name: 'descricao', type: 'TEXT', nullable: true, description: 'Descrição das disciplinas inclusas' },
        { name: 'tipo', type: 'VARCHAR(20)', nullable: false, description: 'Tipo (1ª fase, 2ª fase, Reta Final, Combo)' },
        { name: 'premium_somente', type: 'BOOLEAN', nullable: false, description: 'Se requer assinatura comercial paga' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Status do curso (publicado, rascunho, arquivado)' }
      ],
      relations: [
        'Trilha (1:N)'
      ],
      importance: 'Mapeia os principais módulos pedagógicos que serão liberados com base no plano contratado pelo aluno.'
    },
    {
      id: 'trilha',
      name: 'Trilha',
      group: 'academica',
      groupLabel: 'Grupo B — Estrutura Acadêmica',
      description: 'Trilha sequencial proposta pelo método 3 fases para ordenar o avanço do aluno.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da Trilha' },
        { name: 'curso_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Curso associado' },
        { name: 'nome', type: 'VARCHAR(100)', nullable: false, description: 'Nome da trilha (ex: Trilha Reta Final Ética)' },
        { name: 'fase_oab', type: 'VARCHAR(10)', nullable: false, description: 'Fase associada (1ª ou 2ª)' },
        { name: 'ordem', type: 'INT', nullable: false, description: 'Ordem de exibição na trilha de estudos' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Rascunho ou Publicado' }
      ],
      relations: [
        'Curso (N:1)',
        'Disciplina (1:N)'
      ],
      importance: 'Permite agrupar disciplinas de forma sequencial coerente com as 3 fases de estudo do cronograma.'
    },
    {
      id: 'disciplina',
      name: 'Disciplina',
      group: 'academica',
      groupLabel: 'Grupo B — Estrutura Acadêmica',
      description: 'Mapeamento de ramos do Direito cobrados pela FGV na prova OAB.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da disciplina' },
        { name: 'nome', type: 'VARCHAR(80)', nullable: false, description: 'Nome do ramo (Direito Administrativo, Ética Profissional etc.)' },
        { name: 'professor_responsavel', type: 'VARCHAR(100)', nullable: true, description: 'Nome do docente titular' },
        { name: 'fase', type: 'VARCHAR(10)', nullable: false, description: 'Fase de atuação (1 ou 2)' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Ativa ou Inativa' }
      ],
      relations: [
        'Trilha (N:1)',
        'Módulo (1:N)',
        'Questão (1:N)',
        'Métrica de Desempenho (1:N)'
      ],
      importance: 'Concentra as estatísticas de acerto e erro do aluno para calcular as disciplinas críticas que requerem reforço.'
    },
    {
      id: 'modulo',
      name: 'Módulo',
      group: 'academica',
      groupLabel: 'Grupo B — Estrutura Acadêmica',
      description: 'Subdivisão pedagógica dentro de cada disciplina para organizar tópicos de forma compreensível.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do Módulo' },
        { name: 'disciplina_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Disciplina vinculada' },
        { name: 'nome', type: 'VARCHAR(100)', nullable: false, description: 'Nome (ex: Recursos em Processo Civil)' },
        { name: 'descricao', type: 'TEXT', nullable: true, description: 'Resumo das aulas do módulo' },
        { name: 'ordem', type: 'INT', nullable: false, description: 'Ordenação' }
      ],
      relations: [
        'Disciplina (N:1)',
        'Aula (1:N)'
      ],
      importance: 'Fornece aos coordenadores o controle granular para ordenar e liberar matérias de forma sequencial no cronograma.'
    },
    {
      id: 'aula',
      name: 'Aula',
      group: 'academica',
      groupLabel: 'Grupo B — Estrutura Acadêmica',
      description: 'Entidade de conteúdo que armazena as videoaulas gravadas para transmissão no reprodutor.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da Aula' },
        { name: 'modulo_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Módulo acadêmico' },
        { name: 'titulo', type: 'VARCHAR(150)', nullable: false, description: 'Título da aula' },
        { name: 'duracao_segundos', type: 'INT', nullable: false, description: 'Tempo total do vídeo para controle de visualização' },
        { name: 'video_provider_id', type: 'VARCHAR(100)', nullable: false, description: 'Identificador do player de vídeo (Vimeo/Wistia)' },
        { name: 'ordem', type: 'INT', nullable: false, description: 'Ordem dentro do módulo' },
        { name: 'premium_somente', type: 'BOOLEAN', nullable: false, description: 'Se exige assinatura para reproduzir' }
      ],
      relations: [
        'Módulo (N:1)',
        'Progresso em Conteúdo (1:N)',
        'Dúvida / Comentário (1:N)'
      ],
      importance: 'Registra se foi concluída acima de 85% para liberar a próxima tarefa do plano do estudante.'
    },
    {
      id: 'material',
      name: 'Material',
      group: 'academica',
      groupLabel: 'Grupo B — Estrutura Acadêmica',
      description: 'Arquivos de apoio, PDFs, resumos, checklists, modelos de peças e resumos esquemáticos.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do Material' },
        { name: 'titulo', type: 'VARCHAR(150)', nullable: false, description: 'Nome do arquivo de estudo' },
        { name: 'tipo', type: 'VARCHAR(30)', nullable: false, description: 'Tipo (pdf, mapa_mental, resumo, lei_seca, modelo_peca)' },
        { name: 'arquivo_url', type: 'VARCHAR(255)', nullable: false, description: 'Link de download do arquivo' },
        { name: 'disciplina_id', type: 'UUID', nullable: true, isKey: 'FK', description: 'Disciplina vinculada se aplicável' },
        { name: 'aula_id', type: 'UUID', nullable: true, isKey: 'FK', description: 'Aula de apoio vinculada se aplicável' },
        { name: 'premium_somente', type: 'BOOLEAN', nullable: false, description: 'Se exige plano pago' }
      ],
      relations: [
        'Disciplina (N:1)',
        'Aula (N:1)',
        'Progresso em Conteúdo (1:N)'
      ],
      importance: 'Permite baixar materiais diretamente em cada módulo do cronograma.'
    },

    // GROUP C: QUESTÕES E AVALIAÇÃO
    {
      id: 'questao',
      name: 'Questão',
      group: 'questoes',
      groupLabel: 'Grupo C — Banco de Questões',
      description: 'Questão teórica múltipla escolha aplicada em exames anteriores OAB ou elaborada por professores.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID único da questão' },
        { name: 'enunciado', type: 'TEXT', nullable: false, description: 'Texto norteador da questão' },
        { name: 'alternativas', type: 'JSON', nullable: false, description: 'Vetor contendo letras, textos das alternativas e marcadores' },
        { name: 'resposta_correta', type: 'CHAR(1)', nullable: false, description: 'Letra correta da alternativa (A, B, C ou D)' },
        { name: 'comentario_professor', type: 'TEXT', nullable: true, description: 'Fundamentação didática detalhada escrita pelo professor' },
        { name: 'disciplina_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Disciplina principal' },
        { name: 'assunto', type: 'VARCHAR(100)', nullable: false, description: 'Assunto do edital (ex: Habeas Corpus)' },
        { name: 'dificuldade', type: 'VARCHAR(15)', nullable: false, description: 'Nível (facil, medio, dificil)' },
        { name: 'exame_edicao', type: 'VARCHAR(20)', nullable: true, description: 'Exame FGV original (ex: Exame XXXIX)' }
      ],
      relations: [
        'Disciplina (N:1)',
        'Item de Simulado (1:N)',
        'Tentativa de Questão (1:N)'
      ],
      importance: 'Essencial para o motor de treino ativo, simulados e estatísticas de proficiência do aluno.'
    },
    {
      id: 'simulado',
      name: 'Simulado',
      group: 'questoes',
      groupLabel: 'Grupo C — Banco de Questões',
      description: 'Prova simulada contendo conjuntos de questões cronometradas.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do simulado' },
        { name: 'nome', type: 'VARCHAR(100)', nullable: false, description: 'Título (ex: 1º Simulado Oficial Exame XL)' },
        { name: 'fase', type: 'VARCHAR(10)', nullable: false, description: 'Fase associada (1 ou 2)' },
        { name: 'tipo', type: 'VARCHAR(30)', nullable: false, description: 'Tipo (geral, tematico, diagnostico)' },
        { name: 'tempo_limite_segundos', type: 'INT', nullable: false, description: 'Tempo total regulamentar (geralmente 18000s para 5h)' },
        { name: 'premium_somente', type: 'BOOLEAN', nullable: false, description: 'Disponível apenas para pagantes' }
      ],
      relations: [
        'Item de Simulado (1:N)',
        'Tentativa de Simulado (1:N)'
      ],
      importance: 'Simula o ambiente real de prova para calibrar o nível de ansiedade e o gerenciamento de tempo.'
    },
    {
      id: 'item_simulado',
      name: 'Item de Simulado',
      group: 'questoes',
      groupLabel: 'Grupo C — Banco de Questões',
      description: 'Tabela intermediária que estabelece quais questões compõem um simulado e sua ordem específica.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do Item' },
        { name: 'simulado_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Simulado pai' },
        { name: 'questao_id', type: 'UUID', nullable: true, isKey: 'FK', description: 'Questão vinculada (1ª Fase)' },
        { name: 'discursiva_id', type: 'UUID', nullable: true, isKey: 'FK', description: 'Discursiva vinculada (2ª Fase)' },
        { name: 'ordem', type: 'INT', nullable: false, description: 'Número da questão dentro da prova simulada' }
      ],
      relations: [
        'Simulado (N:1)',
        'Questão (N:1)'
      ],
      importance: 'Permite reutilizar questões do banco para estruturar simulados personalizados dinamicamente.'
    },
    {
      id: 'tentativa_questao',
      name: 'Tentativa de Questão',
      group: 'questoes',
      groupLabel: 'Grupo C — Banco de Questões',
      description: 'Registro de cada resposta submetida por um aluno a uma determinada questão.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da tentativa' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Aluno que respondeu' },
        { name: 'questao_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Questão respondida' },
        { name: 'data_hora', type: 'TIMESTAMP', nullable: false, description: 'Instante da submissão' },
        { name: 'resposta_marcada', type: 'CHAR(1)', nullable: false, description: 'Alternativa escolhida pelo aluno' },
        { name: 'acertou', type: 'BOOLEAN', nullable: false, description: 'Se o aluno acertou a resposta' },
        { name: 'tempo_gasto_segundos', type: 'INT', nullable: false, description: 'Tempo que o aluno levou para responder' },
        { name: 'origem', type: 'VARCHAR(30)', nullable: false, description: 'Origem (modulo_aula, simulado, treino_avulso, revisao)' }
      ],
      relations: [
        'Usuário (N:1)',
        'Questão (N:1)'
      ],
      importance: 'Base primária para o cálculo da taxa de acertos e alimentação das revisões baseadas em erros.'
    },
    {
      id: 'tentativa_simulado',
      name: 'Tentativa de Simulado',
      group: 'questoes',
      groupLabel: 'Grupo C — Banco de Questões',
      description: 'Registro de desempenho consolidado do aluno ao finalizar um simulado completo.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da tentativa de simulado' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Aluno' },
        { name: 'simulado_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Simulado realizado' },
        { name: 'data_inicio', type: 'TIMESTAMP', nullable: false, description: 'Data/Hora de início do simulado' },
        { name: 'data_fim', type: 'TIMESTAMP', nullable: true, description: 'Data/Hora de submissão do simulado' },
        { name: 'pontuacao_final', type: 'DECIMAL(4,2)', nullable: true, description: 'Quantidade total de acertos (ex: 45.00 na 1ª fase ou 7.50 na 2ª)' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Status (em_andamento, concluido, abandonado)' }
      ],
      relations: [
        'Usuário (N:1)',
        'Simulado (N:1)'
      ],
      importance: 'Mapeia a evolução acadêmica e fornece dados concretos sobre a prontidão do candidato para o dia real do exame.'
    },

    // GROUP D: SEGUNDA FASE
    {
      id: 'area_2ª_fase',
      name: 'Área da 2ª Fase',
      group: 'fase2',
      groupLabel: 'Grupo D — Estrutura 2ª Fase OAB',
      description: 'Opções de ramos jurídicos elegíveis pelo candidato para prestar a prova prática profissional de 2ª fase.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da área' },
        { name: 'nome', type: 'VARCHAR(50)', nullable: false, description: 'Nome da área (Direito Penal, Constitucional, Civil etc.)' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Disponível ou Indisponível' }
      ],
      relations: [
        'Perfil do Aluno (1:N)',
        'Peça Prático-Profissional (1:N)',
        'Discursiva (1:N)'
      ],
      importance: 'Filtra todo o aplicativo, garantindo que o cronograma e os treinos práticos mostrem apenas conteúdos da especialidade escolhida.'
    },
    {
      id: 'peca_profissional',
      name: 'Peça Prático-Profissional',
      group: 'fase2',
      groupLabel: 'Grupo D — Estrutura 2ª Fase OAB',
      description: 'Modelos, estruturas de teses, cabimento, checklist estruturado e erros fatais de peças profissionais.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID único da peça' },
        { name: 'area_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Área de 2ª fase relacionada' },
        { name: 'nome', type: 'VARCHAR(150)', nullable: false, description: 'Nome da peça (ex: Recurso em Sentido Estrito - RESE)' },
        { name: 'cabimento', type: 'TEXT', nullable: false, description: 'Regras processuais de cabimento da petição' },
        { name: 'estrutura_json', type: 'JSON', nullable: false, description: 'Passo a passo estruturado (Endereçamento, Qualificação, Fatos, Direito, Pedidos)' },
        { name: 'erros_fatais_checklist', type: 'JSON', nullable: false, description: 'Gatilhos de pontuação zero (zerar a peça)' }
      ],
      relations: [
        'Área da 2ª Fase (N:1)',
        'Treino de 2ª Fase (1:N)'
      ],
      importance: 'Subsidia os estudos práticos e treinos com o espelho de pontuação oficial da FGV.'
    },
    {
      id: 'discursiva',
      name: 'Discursiva 2ª Fase',
      group: 'fase2',
      groupLabel: 'Grupo D — Estrutura 2ª Fase OAB',
      description: 'Questões práticas discursivas que constituem a metade da pontuação do exame de 2ª fase.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da discursiva' },
        { name: 'area_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Área de 2ª fase' },
        { name: 'enunciado', type: 'TEXT', nullable: false, description: 'Situação-problema proposta' },
        { name: 'espelho_correcao', type: 'TEXT', nullable: false, description: 'Gabarito oficial de teses e fundamentação legal necessária' }
      ],
      relations: [
        'Área da 2ª Fase (N:1)',
        'Treino de 2ª Fase (1:N)'
      ],
      importance: 'Permite praticar a escrita jurídica focando na pontuação exata por menção a artigos de lei.'
    },
    {
      id: 'treino_2ª_fase',
      name: 'Treino de 2ª Fase',
      group: 'fase2',
      groupLabel: 'Grupo D — Estrutura 2ª Fase OAB',
      description: 'Registra a submissão de arquivos ou textos pelo aluno para exercitar escrita de peças ou discursivas.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do treino' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Estudante' },
        { name: 'tipo', type: 'VARCHAR(20)', nullable: false, description: 'Tipo (peca, discursiva, simulado_pratico)' },
        { name: 'peca_id', type: 'UUID', nullable: true, isKey: 'FK', description: 'Peça estudada' },
        { name: 'discursiva_id', type: 'UUID', nullable: true, isKey: 'FK', description: 'Discursiva estudada' },
        { name: 'data_envio', type: 'TIMESTAMP', nullable: false, description: 'Data do envio' },
        { name: 'nota_atribuida', type: 'DECIMAL(3,2)', nullable: true, description: 'Nota atribuída pelo professor (0.0 a 6.0 ou 0.0 a 10.0)' },
        { name: 'feedback_pdf_url', type: 'VARCHAR(255)', nullable: true, description: 'Caminho do PDF com correções personalizadas da mentoria' }
      ],
      relations: [
        'Usuário (N:1)',
        'Peça Prática (N:1)',
        'Discursiva (N:1)'
      ],
      importance: 'Viabiliza o serviço de mentoria e correção individualizada de peças do plano VIP.'
    },

    // GROUP E: PROGRESSO E CRONOGRAMA
    {
      id: 'plano_estudo',
      name: 'Plano de Estudo',
      group: 'plano',
      groupLabel: 'Grupo E — Planejamento e Progresso',
      description: 'Entidade organizacional central que agrupa e distribui as tarefas diárias de forma sequencial.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do Plano' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Estudante associado' },
        { name: 'fase', type: 'VARCHAR(10)', nullable: false, description: 'Fase atual de vigência (1 ou 2)' },
        { name: 'intensidade', type: 'VARCHAR(20)', nullable: false, description: 'Nível de ritmo (suave, moderado, acelerado)' },
        { name: 'data_geracao', type: 'TIMESTAMP', nullable: false, description: 'Data de criação do plano' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Status (ativo, pausado, recalculando)' }
      ],
      relations: [
        'Perfil do Aluno (1:1)',
        'Tarefa do Plano (1:N)'
      ],
      importance: 'Representa a espinha dorsal de execução do cronograma de estudos diário do aluno.'
    },
    {
      id: 'tarefa_plano',
      name: 'Tarefa do Plano',
      group: 'plano',
      groupLabel: 'Grupo E — Planejamento e Progresso',
      description: 'Atividade concreta recomendada ao estudante para ser executada em um dia específico.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da tarefa' },
        { name: 'plano_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Plano pai' },
        { name: 'tipo', type: 'VARCHAR(30)', nullable: false, description: 'Tipo (videoaula, leitura_material, resolver_questoes, treino_peca, revisao)' },
        { name: 'referencia_id', type: 'UUID', nullable: false, description: 'ID do conteúdo acadêmico correlacionado (aula, material ou simulado)' },
        { name: 'data_sugerida', type: 'DATE', nullable: false, description: 'Data para execução da tarefa' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Status (pendente, concluida, adiada, perdida)' },
        { name: 'prioridade', type: 'VARCHAR(15)', nullable: false, description: 'Prioridade (alta, media, baixa)' }
      ],
      relations: [
        'Plano de Estudo (N:1)'
      ],
      importance: 'Alimenta o cronograma do aluno e a aba "Meu Plano" com checklist interativo.'
    },
    {
      id: 'progresso_conteudo',
      name: 'Progresso em Conteúdo',
      group: 'plano',
      groupLabel: 'Grupo E — Planejamento e Progresso',
      description: 'Tabela de rastreamento de conclusão individualizada de todos os ativos acadêmicos por aluno.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do registro' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Aluno' },
        { name: 'tipo_conteudo', type: 'VARCHAR(20)', nullable: false, description: 'Tipo (aula, material_leitura)' },
        { name: 'conteudo_id', type: 'UUID', nullable: false, description: 'ID da aula ou material' },
        { name: 'concluido', type: 'BOOLEAN', nullable: false, description: 'Se a aula foi assistida ou material lido' },
        { name: 'percentual_conclusao', type: 'INT', nullable: false, description: 'Percentual de avanço (0 a 100)' },
        { name: 'data_ultima_interacao', type: 'TIMESTAMP', nullable: false, description: 'Última data de reprodução do arquivo' }
      ],
      relations: [
        'Usuário (N:1)'
      ],
      importance: 'Permite que o aluno pause um vídeo e continue de onde parou, além de marcar tarefas como feitas.'
    },
    {
      id: 'revisao_programada',
      name: 'Revisão Programada',
      group: 'plano',
      groupLabel: 'Grupo E — Planejamento e Progresso',
      description: 'Gatilhos de repetição espaçada criados pelo motor de inteligência do OAB 3F com base em erros e progresso.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da revisão' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Estudante' },
        { name: 'disciplina_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Matéria de revisão' },
        { name: 'assunto', type: 'VARCHAR(100)', nullable: false, description: 'Tema específico' },
        { name: 'estagio', type: 'VARCHAR(20)', nullable: false, description: 'Estágio (24h, 7dias, 30dias, reta_final)' },
        { name: 'data_revisao_sugerida', type: 'DATE', nullable: false, description: 'Próxima data agendada para revisar' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Pendente ou Concluída' }
      ],
      relations: [
        'Usuário (N:1)',
        'Disciplina (N:1)'
      ],
      importance: 'Implementa de forma científica o método de fixação de longo prazo contra a curva do esquecimento.'
    },

    // GROUP F: DESEMPENHO
    {
      id: 'metrica_desempenho',
      name: 'Métrica de Desempenho do Aluno',
      group: 'desempenho',
      groupLabel: 'Grupo F — Métricas & Desempenho',
      description: 'Consolidação periódica de acertos, erros e dedicação temporal do aluno.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID de métrica' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Estudante' },
        { name: 'tempo_estudo_total_segundos', type: 'BIGINT', nullable: false, description: 'Segundos totais de estudo acumulados' },
        { name: 'questoes_respondidas', type: 'INT', nullable: false, description: 'Quantidade respondida' },
        { name: 'questoes_acertadas', type: 'INT', nullable: false, description: 'Quantidade acertada' },
        { name: 'taxa_acertos_geral', type: 'DECIMAL(5,2)', nullable: false, description: 'Porcentagem de acerto consolidada' },
        { name: 'simulados_concluidos', type: 'INT', nullable: false, description: 'Simulados completos realizados' },
        { name: 'data_ultima_consolidacao', type: 'TIMESTAMP', nullable: false, description: 'Data da última consolidação' }
      ],
      relations: [
        'Usuário (1:1)'
      ],
      importance: 'Permite exibir os gráficos de barras e progresso circular na tela "Meu Desempenho".'
    },
    {
      id: 'historico_atividade',
      name: 'Histórico de Atividade',
      group: 'desempenho',
      groupLabel: 'Grupo F — Métricas & Desempenho',
      description: 'Logs granulados de ações e cliques do usuário para fins de recomendação e suporte técnico.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da atividade' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Usuário' },
        { name: 'tipo_acao', type: 'VARCHAR(50)', nullable: false, description: 'Ação (login, iniciou_simulado, baixou_pdf, visualizou_paywall)' },
        { name: 'descricao', type: 'VARCHAR(255)', nullable: false, description: 'Resumo textual legível por humanos' },
        { name: 'timestamp', type: 'TIMESTAMP', nullable: false, description: 'Data e hora da ação' }
      ],
      relations: [
        'Usuário (N:1)'
      ],
      importance: 'Ajuda a equipe pedagógica e suporte técnico a mapear e auditar gargalos operacionais no uso do app.'
    },

    // GROUP G: MONETIZACAO
    {
      id: 'plano_comercial',
      name: 'Plano Comercial',
      group: 'monetizacao',
      groupLabel: 'Grupo G — Monetização e Acesso',
      description: 'Cadastro dos planos de assinatura disponíveis para aquisição.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do Plano Comercial' },
        { name: 'nome', type: 'VARCHAR(50)', nullable: false, description: 'Nome (1ª Fase, 2ª Fase, Completo, VIP)' },
        { name: 'preco_recorrente', type: 'DECIMAL(10,2)', nullable: false, description: 'Preço da assinatura em Reais' },
        { name: 'duracao_meses', type: 'INT', nullable: false, description: 'Tempo total de acesso em meses' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Ativo ou Desativado para venda' }
      ],
      relations: [
        'Assinatura do Aluno (1:N)'
      ],
      importance: 'Unifica e padroniza as ofertas financeiras mostradas na tela de Checkout.'
    },
    {
      id: 'assinatura_aluno',
      name: 'Assinatura do Aluno',
      group: 'monetizacao',
      groupLabel: 'Grupo G — Monetização e Acesso',
      description: 'Contratos vigentes de contratação de serviços do app por aluno.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID de contrato' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Comprador' },
        { name: 'plano_comercial_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Plano contratado' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Vigência (ativa, expirada, cancelada, atrasada, trial)' },
        { name: 'data_inicio', type: 'TIMESTAMP', nullable: false, description: 'Início da vigência' },
        { name: 'data_expiracao', type: 'TIMESTAMP', nullable: false, description: 'Término do contrato' },
        { name: 'gateway_payment_id', type: 'VARCHAR(100)', nullable: true, description: 'Código do pagamento no intermediador (Stripe/Asaas)' }
      ],
      relations: [
        'Usuário (N:1)',
        'Plano Comercial (N:1)',
        'Permissão de Acesso (1:N)'
      ],
      importance: 'Crucial para o Motor de Controle de Acesso validar se o usuário pode consumir conteúdos pagos.'
    },
    {
      id: 'permissao_acesso',
      name: 'Permissão de Acesso',
      group: 'monetizacao',
      groupLabel: 'Grupo G — Monetização e Acesso',
      description: 'Tabela lógica que detalha os privilégios exatos habilitados para o aluno.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da permissão' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Usuário' },
        { name: 'recurso_codigo', type: 'VARCHAR(50)', nullable: false, description: 'Código do privilégio (pecas_premium, simulados_ilimitados, mentoria_zoom)' },
        { name: 'habilitado', type: 'BOOLEAN', nullable: false, description: 'Se está ativo' }
      ],
      relations: [
        'Usuário (N:1)'
      ],
      importance: 'Isola e blinda as regras de negócios do código-fonte, tornando a liberação de novos recursos extremamente flexível.'
    },
    {
      id: 'cupom_promocao',
      name: 'Cupom / Promoção',
      group: 'monetizacao',
      groupLabel: 'Grupo G — Monetização e Acesso',
      description: 'Cadastro de campanhas de descontos para impulsionar conversões e campanhas de marketing.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do cupom' },
        { name: 'codigo', type: 'VARCHAR(30)', nullable: false, description: 'Código digitável (ex: OABFUTURO20)' },
        { name: 'porcentagem_desconto', type: 'INT', nullable: false, description: 'Porcentagem de desconto real (0 a 100)' },
        { name: 'validade', type: 'DATE', nullable: false, description: 'Data de expiração da promoção' },
        { name: 'limite_usos', type: 'INT', nullable: true, description: 'Quantidade máxima de utilizações permitidas' }
      ],
      relations: [],
      importance: 'Aplicado no formulário de pagamento para aplicar descontos instantâneos.'
    },

    // GROUP H: CALENDARIO
    {
      id: 'evento_calendario',
      name: 'Evento de Calendário',
      group: 'calendario',
      groupLabel: 'Grupo H — Cronograma OAB & Calendário',
      description: 'Datas institucionais oficiais da FGV/OAB ou compromissos pedagógicos internos da mentoria.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID de evento' },
        { name: 'titulo', type: 'VARCHAR(150)', nullable: false, description: 'Nome do evento (ex: Edital Exame XL)' },
        { name: 'categoria', type: 'VARCHAR(30)', nullable: false, description: 'Categoria (oficial_fgv, mentoria, prova, simulado_coletivo)' },
        { name: 'data_evento', type: 'DATE', nullable: false, description: 'Data de realização' },
        { name: 'fase', type: 'VARCHAR(10)', nullable: true, description: 'Fase associada se aplicável' }
      ],
      relations: [],
      importance: 'Abastece o calendário interativo do estudante com as contagens regressivas oficiais da prova.'
    },
    {
      id: 'notificacao',
      name: 'Notificação',
      group: 'calendario',
      groupLabel: 'Grupo H — Cronograma OAB & Calendário',
      description: 'Mensagens direcionadas ou alertas push disparados para o aluno.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da notificação' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Destinatário' },
        { name: 'titulo', type: 'VARCHAR(100)', nullable: false, description: 'Assunto do alerta' },
        { name: 'mensagem', type: 'VARCHAR(255)', nullable: false, description: 'Texto explicativo do alerta' },
        { name: 'lida', type: 'BOOLEAN', nullable: false, description: 'Se o aluno leu' },
        { name: 'data_envio', type: 'TIMESTAMP', nullable: false, description: 'Data do disparo' }
      ],
      relations: [
        'Usuário (N:1)'
      ],
      importance: 'Reengaja candidatos alertando sobre tarefas diárias atrasadas e respostas a dúvidas.'
    },

    // GROUP I: COMUNIDADE E SUPORTE
    {
      id: 'duvida_comentario',
      name: 'Dúvida / Comentário',
      group: 'comunidade',
      groupLabel: 'Grupo I — Comunidade, Suporte & Mentoria',
      description: 'Perguntas e debates acadêmicos criados pelos estudantes dentro de aulas ou no fórum livre.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da dúvida' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Autor' },
        { name: 'disciplina_id', type: 'UUID', nullable: true, isKey: 'FK', description: 'Disciplina se vinculada' },
        { name: 'titulo', type: 'VARCHAR(150)', nullable: false, description: 'Título resumo' },
        { name: 'mensagem', type: 'TEXT', nullable: false, description: 'Dúvida explicativa detalhada' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Status (aberta, respondida, resolvida, moderada)' },
        { name: 'curtidas', type: 'INT', nullable: false, description: 'Quantidade de votos de apoio de colegas' }
      ],
      relations: [
        'Usuário (N:1)',
        'Disciplina (N:1)'
      ],
      importance: 'Alimenta o Mural de Dúvidas integrando alunos e tutores pedagógicos.'
    },
    {
      id: 'chamado_suporte',
      name: 'Chamado de Suporte',
      group: 'comunidade',
      groupLabel: 'Grupo I — Comunidade, Suporte & Mentoria',
      description: 'Tickets de atendimento aberto pelos alunos para tratar de dúvidas financeiras, login ou suporte técnico.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do Ticket' },
        { name: 'user_id', type: 'UUID', nullable: false, isKey: 'FK', description: 'Solicitante' },
        { name: 'protocolo', type: 'VARCHAR(30)', nullable: false, description: 'Protocolo de rastreio (ex: #OAB-3F-1025)' },
        { name: 'categoria', type: 'VARCHAR(50)', nullable: false, description: 'Categoria (financeiro, login, tecnico, academico)' },
        { name: 'descricao', type: 'TEXT', nullable: false, description: 'Problema relatado pelo aluno' },
        { name: 'status', type: 'VARCHAR(20)', nullable: false, description: 'Vigência (aberto, em_analise, respondido, resolvido)' },
        { name: 'prioridade', type: 'VARCHAR(15)', nullable: false, description: 'Prioridade (alta, media, baixa)' }
      ],
      relations: [
        'Usuário (N:1)'
      ],
      importance: 'Garante que problemas técnicos sejam resolvidos sem poluir as áreas acadêmicas de estudo.'
    },
    {
      id: 'faq_artigo',
      name: 'FAQ / Artigo',
      group: 'comunidade',
      groupLabel: 'Grupo I — Comunidade, Suporte & Mentoria',
      description: 'Artigos explicativos da base de conhecimento e FAQ geral de autoatendimento.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID do FAQ' },
        { name: 'pergunta', type: 'VARCHAR(255)', nullable: false, description: 'Pergunta ou Título' },
        { name: 'resposta', type: 'TEXT', nullable: false, description: 'Resposta explicativa didática' },
        { name: 'categoria', type: 'VARCHAR(50)', nullable: false, description: 'Categoria do artigo' }
      ],
      relations: [],
      importance: 'Reduz a sobrecarga do suporte fornecendo soluções instantâneas para dúvidas operacionais frequentes.'
    },
    {
      id: 'depoimento_aprovado',
      name: 'Depoimento / Aprovado',
      group: 'comunidade',
      groupLabel: 'Grupo I — Comunidade, Suporte & Mentoria',
      description: 'Homenagens e relatos oficiais de alunos que utilizaram o método 3F e obtiveram a aprovação oficial OAB.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID de depoimento' },
        { name: 'nome', type: 'VARCHAR(100)', nullable: false, description: 'Nome do ex-aluno' },
        { name: 'fase_aprovada', type: 'VARCHAR(20)', nullable: false, description: 'Fase aprovado (1ª, 2ª ou Ambas)' },
        { name: 'texto_depoimento', type: 'TEXT', nullable: false, description: 'História inspiradora contada pelo aprovado' },
        { name: 'exame_aprovacao', type: 'VARCHAR(30)', nullable: false, description: 'Edição de conquista (ex: Exame XXXIX)' }
      ],
      relations: [],
      importance: 'Gera forte prova social no mural da comunidade para motivar candidatos que estão desanimados.'
    },
    {
      id: 'mentoria_sessao',
      name: 'Mentoria / Sessão / Conteúdo VIP',
      group: 'comunidade',
      groupLabel: 'Grupo I — Comunidade, Suporte & Mentoria',
      description: 'Registro de cronogramas de encontros semanais exclusivos por videoconferência com os mentores.',
      fields: [
        { name: 'id', type: 'UUID', nullable: false, isKey: 'PK', description: 'ID da sessão' },
        { name: 'titulo', type: 'VARCHAR(150)', nullable: false, description: 'Assunto da mentoria' },
        { name: 'data_hora', type: 'TIMESTAMP', nullable: false, description: 'Data e hora do encontro ao vivo' },
        { name: 'zoom_link', type: 'VARCHAR(255)', nullable: true, description: 'Link da sala de transmissão ao vivo' },
        { name: 'professor_mentor', type: 'VARCHAR(100)', nullable: false, description: 'Mentor titular responsável pelo encontro' }
      ],
      relations: [],
      importance: 'Atributo restrito de alto valor agregado oferecido apenas a alunos de planos VIP e Mentoria.'
    }
  ];

  // Filter entities by search term or group selection
  const filteredEntities = entities.filter(ent => {
    const matchesSearch = ent.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          ent.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          ent.fields.some(f => f.name.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesGroup = selectedGroup === 'all' || ent.group === selectedGroup;
    return matchesSearch && matchesGroup;
  });

  return (
    <div className="space-y-6" id="oab-architecture-root">
      
      {/* HEADER HERO AREA */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-1.5">
          <span className="bg-slate-900 text-[#D4AF37] text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full font-mono shadow-inner">
            ★ BACKEND & DATA ENGINE ★
          </span>
          <h1 className="text-2xl font-black text-slate-900 font-serif flex items-center">
            <Cpu className="h-6 w-6 mr-2 text-slate-900" />
            Arquitetura de Dados & Regras de Negócio OAB 3F
          </h1>
          <p className="text-xs text-slate-500 max-w-3xl leading-relaxed">
            Mapeamento lógico estruturado do ecossistema de educação jurídica. Explore as tabelas do banco de dados, teste regras de negócios interativas de forma emulada e audite a governança e segurança de dados do aplicativo.
          </p>
        </div>

        {/* Status indicator badges */}
        <div className="flex bg-slate-50 border border-slate-200 rounded-xl p-3 items-center space-x-3 shrink-0">
          <div className="h-2.5 w-2.5 bg-emerald-500 rounded-full animate-pulse" />
          <div className="text-xs">
            <span className="block font-bold text-slate-700">Mecanismo Ativo</span>
            <span className="text-[10px] text-slate-400 font-mono">SQLite / PostgreSQL Schema V1.2</span>
          </div>
        </div>
      </div>

      {/* CORE LAYER NAVIGATION TABS */}
      <div className="flex bg-slate-150 p-1.5 rounded-xl border border-slate-200">
        <button
          onClick={() => setActiveLayer('database')}
          className={`flex items-center gap-2 px-4 py-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex-1 justify-center ${
            activeLayer === 'database' 
              ? 'bg-slate-900 text-white shadow' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Database className="h-4.5 w-4.5" />
          Camada 1 — Entidades & Banco de Dados ({entities.length})
        </button>
        <button
          onClick={() => setActiveLayer('rules')}
          className={`flex items-center gap-2 px-4 py-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex-1 justify-center ${
            activeLayer === 'rules' 
              ? 'bg-slate-900 text-white shadow' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Settings className="h-4.5 w-4.5" />
          Camada 2 — Regras de Negócio (Simulador)
        </button>
        <button
          onClick={() => setActiveLayer('integrations')}
          className={`flex items-center gap-2 px-4 py-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex-1 justify-center ${
            activeLayer === 'integrations' 
              ? 'bg-slate-900 text-white shadow' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Workflow className="h-4.5 w-4.5" />
          Camada 3 — Integrações Internas
        </button>
        <button
          onClick={() => setActiveLayer('governance')}
          className={`flex items-center gap-2 px-4 py-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex-1 justify-center ${
            activeLayer === 'governance' 
              ? 'bg-slate-900 text-white shadow' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <ShieldCheck className="h-4.5 w-4.5" />
          Camada 4 — Governança & Controle
        </button>
      </div>

      {/* RENDER CONTENT BY ACTIVE LAYER */}
      <div id="architecture-rendered-layer">
        
        {/* =======================================================
            CAMADA 1: ENTIDADES E SCHEMAS DE BANCO DE DADOS
           ======================================================= */}
        {activeLayer === 'database' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
            
            {/* Filter & Left Sidebar */}
            <div className="lg:col-span-3 space-y-4">
              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm space-y-4">
                <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Filtros de Pesquisa</h4>
                
                {/* Search input */}
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Buscar tabela ou campo..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full text-xs pl-9 pr-3 py-2.5 border border-slate-250 bg-slate-50 rounded-lg focus:outline-none focus:bg-white"
                  />
                </div>

                {/* Category select buttons */}
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Grupos de Dados</span>
                  {[
                    { id: 'all', label: 'Tudo (35 Entidades)', count: entities.length },
                    { id: 'usuario', label: 'Usuário & Perfil', count: entities.filter(e => e.group === 'usuario').length },
                    { id: 'academica', label: 'Cursos & Trilhas', count: entities.filter(e => e.group === 'academica').length },
                    { id: 'questoes', label: 'Questões & Provas', count: entities.filter(e => e.group === 'questoes').length },
                    { id: 'fase2', label: 'Recursos da 2ª Fase', count: entities.filter(e => e.group === 'fase2').length },
                    { id: 'plano', label: 'Planos & Tarefas', count: entities.filter(e => e.group === 'plano').length },
                    { id: 'desempenho', label: 'Históricos & Analytics', count: entities.filter(e => e.group === 'desempenho').length },
                    { id: 'monetizacao', label: 'Monetização & Contratos', count: entities.filter(e => e.group === 'monetizacao').length },
                    { id: 'comunidade', label: 'Comunidade & Atendimento', count: entities.filter(e => e.group === 'comunidade').length }
                  ].map(grp => (
                    <button
                      key={grp.id}
                      onClick={() => setSelectedGroup(grp.id)}
                      className={`w-full text-left text-xs px-3 py-2 rounded-lg font-medium flex justify-between items-center transition-colors cursor-pointer ${
                        selectedGroup === grp.id 
                          ? 'bg-slate-900 text-white font-bold' 
                          : 'hover:bg-slate-50 text-slate-600'
                      }`}
                    >
                      <span>{grp.label}</span>
                      <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${selectedGroup === grp.id ? 'bg-[#D4AF37]/20 text-[#D4AF37]' : 'bg-slate-100 text-slate-400'}`}>
                        {grp.count}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Database Quick Stats */}
              <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-slate-300 p-5 rounded-xl border border-slate-800 space-y-3 shadow-md">
                <span className="text-[9.5px] uppercase font-black text-[#D4AF37] tracking-widest block font-mono">⚡ STATUS DE INFRAESTRUTURA</span>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                    <span>Mecanismo Primário:</span>
                    <span className="font-mono text-white font-bold">PostgreSQL Cloud Run</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                    <span>Tabelas Mapeadas:</span>
                    <span className="font-mono text-white font-bold">35</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                    <span>Integridade de Chaves:</span>
                    <span className="font-mono text-emerald-400 font-bold">Ativa (Cascateante)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Segurança de Dados:</span>
                    <span className="font-mono text-emerald-400 font-bold">ISO 27001 / LGPD</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Central Database Entities Drawer */}
            <div className="lg:col-span-9 space-y-3.5">
              
              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex items-center justify-between text-xs text-slate-500">
                <span>Mostrando <b>{filteredEntities.length}</b> entidades correspondentes aos filtros selecionados.</span>
                <span className="font-semibold text-slate-400 font-mono">DICA: Clique na tabela para expandir campos e relacionamentos</span>
              </div>

              {filteredEntities.map((ent) => {
                const isExpanded = expandedEntityId === ent.id;
                return (
                  <div 
                    key={ent.id} 
                    className={`bg-white border rounded-xl overflow-hidden shadow-sm transition-all ${
                      isExpanded ? 'border-slate-300 ring-1 ring-slate-150' : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {/* Entity Header summary */}
                    <div 
                      onClick={() => setExpandedEntityId(isExpanded ? null : ent.id)}
                      className="p-4 flex justify-between items-center cursor-pointer select-none bg-white hover:bg-slate-50/50"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-slate-900 text-white rounded-lg">
                          <Database className="h-4 w-4 text-[#D4AF37]" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-serif font-black text-slate-900 text-xs sm:text-sm">{ent.name}</h3>
                            <span className="bg-slate-100 text-slate-500 text-[9px] font-bold px-2 py-0.5 rounded font-mono">
                              {ent.groupLabel}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 font-medium leading-normal mt-0.5 max-w-2xl">{ent.description}</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3 shrink-0">
                        <span className="text-[10px] font-mono text-slate-400 font-bold hidden sm:inline">{ent.fields.length} campos</span>
                        {isExpanded ? <ChevronDown className="h-5 w-5 text-slate-400" /> : <ChevronRight className="h-5 w-5 text-slate-400" />}
                      </div>
                    </div>

                    {/* Entity Details (Visible when expanded) */}
                    {isExpanded && (
                      <div className="border-t border-slate-100 p-5 bg-slate-50/45 space-y-4 animate-fade-in text-xs">
                        
                        {/* Table Schema mapping */}
                        <div className="space-y-2">
                          <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 font-mono block">Dicionário de Atributos (Fields)</span>
                          <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white">
                            <table className="w-full text-left border-collapse">
                              <thead>
                                <tr className="bg-slate-50 text-[10px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-200">
                                  <th className="p-2.5">Nome do Atributo</th>
                                  <th className="p-2.5">Tipo de Dado</th>
                                  <th className="p-2.5 text-center">Nulidade</th>
                                  <th className="p-2.5 text-center">Chave</th>
                                  <th className="p-2.5">Descrição Acadêmica / Operacional</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-100">
                                {ent.fields.map((f, fIdx) => (
                                  <tr key={fIdx} className="hover:bg-slate-50/50">
                                    <td className="p-2.5 font-mono text-slate-800 font-black">{f.name}</td>
                                    <td className="p-2.5 font-mono text-slate-500 font-semibold">{f.type}</td>
                                    <td className="p-2.5 text-center text-slate-400">{f.nullable ? 'NULL' : 'NOT NULL'}</td>
                                    <td className="p-2.5 text-center">
                                      {f.isKey === 'PK' ? (
                                        <span className="bg-amber-100 text-amber-800 text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded font-mono">PK</span>
                                      ) : f.isKey === 'FK' ? (
                                        <span className="bg-blue-100 text-blue-800 text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded font-mono">FK</span>
                                      ) : (
                                        <span className="text-slate-300">-</span>
                                      )}
                                    </td>
                                    <td className="p-2.5 text-slate-500 font-medium">{f.description}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>

                        {/* Relations & Functional importance info */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                          <div className="bg-white border border-slate-200 rounded-lg p-3.5 space-y-1.5">
                            <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider block font-mono">🔗 Relações de Integridade Referencial</span>
                            {ent.relations.length > 0 ? (
                              <div className="flex flex-wrap gap-1.5">
                                {ent.relations.map((rel, rIdx) => (
                                  <span key={rIdx} className="bg-slate-100 text-slate-600 font-mono font-bold text-[10px] px-2 py-0.5 rounded border border-slate-200">
                                    {rel}
                                  </span>
                                ))}
                              </div>
                            ) : (
                              <span className="text-slate-400 italic text-[10px]">Tabela isolada sem chaves externas de integridade</span>
                            )}
                          </div>

                          <div className="bg-amber-500/5 border border-[#D4AF37]/20 rounded-lg p-3.5 space-y-1">
                            <span className="text-[9px] font-black uppercase text-amber-800 tracking-wider block font-mono">💡 Importância Prática na Preparação</span>
                            <p className="text-slate-600 font-medium leading-relaxed">{ent.importance}</p>
                          </div>
                        </div>

                      </div>
                    )}
                  </div>
                );
              })}

            </div>

          </div>
        )}

        {/* =======================================================
            CAMADA 2: REGRAS DE NEGÓCIO (INTERACTIVE SIMULATOR)
           ======================================================= */}
        {activeLayer === 'rules' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in text-xs">
            
            {/* Left Inputs Control Panel */}
            <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5">
              <div className="border-b border-slate-100 pb-3">
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5 font-display">
                  <Sliders className="h-4.5 w-4.5 text-slate-900" />
                  Calibração das Respostas do Aluno
                </h3>
                <p className="text-[10.5px] text-slate-400 leading-snug mt-0.5">
                  Ajuste as características do estudante de forma dinâmica para emular a execução lógica das regras pedagógicas e de marketing.
                </p>
              </div>

              {/* Form elements */}
              <div className="space-y-4">
                
                {/* 1. Fase da OAB */}
                <div>
                  <label className="block text-[10.5px] font-bold text-slate-500 mb-1.5">1. Fase Atual do Estudante</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setSimFase('1a')}
                      className={`py-2 px-3 border rounded-lg text-xs font-bold transition-all cursor-pointer text-center ${
                        simFase === '1a' ? 'bg-slate-900 text-white border-slate-900 shadow-sm' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      1ª Fase (80 Questões)
                    </button>
                    <button
                      onClick={() => setSimFase('2a')}
                      className={`py-2 px-3 border rounded-lg text-xs font-bold transition-all cursor-pointer text-center ${
                        simFase === '2a' ? 'bg-slate-900 text-white border-slate-900 shadow-sm' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      2ª Fase (Peça + Discursivas)
                    </button>
                  </div>
                </div>

                {/* 2. Área da Segunda Fase */}
                {simFase === '2a' && (
                  <div>
                    <label className="block text-[10.5px] font-bold text-slate-500 mb-1.5">Área Escolhida (2ª Fase)</label>
                    <select
                      value={simArea2nd}
                      onChange={(e) => setSimArea2nd(e.target.value)}
                      className="w-full text-xs border border-slate-250 bg-slate-50 p-2.5 rounded-lg focus:outline-none focus:bg-white focus:ring-1 focus:ring-slate-400"
                    >
                      <option value="Direito Penal">Direito Penal (Mais escolhida)</option>
                      <option value="Direito Civil">Direito Civil (Ramo Geral)</option>
                      <option value="Direito Constitucional">Direito Constitucional (OAB 3F Titular)</option>
                      <option value="Direito Administrativo">Direito Administrativo</option>
                      <option value="Direito do Trabalho">Direito do Trabalho</option>
                      <option value="Direito Tributário">Direito Tributário</option>
                    </select>
                  </div>
                )}

                {/* 3. Assinatura do Aluno */}
                <div>
                  <label className="block text-[10.5px] font-bold text-slate-500 mb-1.5">2. Assinatura do Aluno (Plano)</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'gratuito', label: 'Gratuito / Trial' },
                      { id: 'fase1', label: 'Apenas 1ª Fase' },
                      { id: 'fase2', label: 'Apenas 2ª Fase' },
                      { id: 'completo', label: 'OAB 3F Completo' },
                      { id: 'vip', label: 'VIP & Mentoria' }
                    ].map(p => (
                      <button
                        key={p.id}
                        onClick={() => setSimPlan(p.id as any)}
                        className={`py-2 px-2.5 border rounded-lg text-[10px] font-bold transition-all text-left cursor-pointer ${
                          simPlan === p.id 
                            ? 'bg-[#D4AF37]/15 text-[#D4AF37] border-[#D4AF37]' 
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <span className="block">{p.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Sliders Area */}
                <div className="space-y-3 pt-2">
                  
                  {/* Desempenho e Acertos */}
                  <div>
                    <div className="flex justify-between font-bold text-slate-500 mb-1">
                      <span>3. Taxa de Acerto nas Questões:</span>
                      <span className="font-mono text-slate-800">{simAccuracy}%</span>
                    </div>
                    <input
                      type="range"
                      min="20"
                      max="100"
                      value={simAccuracy}
                      onChange={(e) => setSimAccuracy(parseInt(e.target.value))}
                      className="w-full accent-slate-900"
                    />
                    <span className="text-[9px] text-slate-400 block -mt-1 font-medium">FGV exige no mínimo 50% de acertos na 1ª fase (40 pontos).</span>
                  </div>

                  {/* Frequência Ativa na semana */}
                  <div>
                    <div className="flex justify-between font-bold text-slate-500 mb-1">
                      <span>4. Dias Ativos por Semana:</span>
                      <span className="font-mono text-slate-800">{simDaysActive} dias</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="7"
                      value={simDaysActive}
                      onChange={(e) => setSimDaysActive(parseInt(e.target.value))}
                      className="w-full accent-slate-900"
                    />
                  </div>

                  {/* Dias Restantes para Prova */}
                  <div>
                    <div className="flex justify-between font-bold text-slate-500 mb-1">
                      <span>5. Dias Restantes para o Exame:</span>
                      <span className="font-mono text-slate-800">{examDistance} dias</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="120"
                      value={examDistance}
                      onChange={(e) => setExamDistance(parseInt(e.target.value))}
                      className="w-full accent-slate-900"
                    />
                    <span className="text-[9px] text-slate-400 block -mt-1 font-medium">Abaixo de 15 dias ativa o "Motor de Reta Final" com revisões cirúrgicas.</span>
                  </div>

                  {/* Horas de Estudo Diárias */}
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">Horas Diárias</label>
                      <select
                        value={simHoursPerDay}
                        onChange={(e) => setSimHoursPerDay(parseInt(e.target.value))}
                        className="text-xs border p-2 rounded-lg bg-slate-50 focus:outline-none w-full font-bold"
                      >
                        <option value="2">2 Horas (Foco Médio)</option>
                        <option value="3">3 Horas (Ideal)</option>
                        <option value="4">4 Horas (Intensivo)</option>
                        <option value="6">6 Horas (Reta Final Máxima)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">Dias por Semana</label>
                      <select
                        value={simDaysPerWeek}
                        onChange={(e) => setSimDaysPerWeek(parseInt(e.target.value))}
                        className="text-xs border p-2 rounded-lg bg-slate-50 focus:outline-none w-full font-bold"
                      >
                        <option value="5">5 Dias (Úteis)</option>
                        <option value="6">6 Dias (Com Sábado)</option>
                        <option value="7">7 Dias (Sem Descanso)</option>
                      </select>
                    </div>
                  </div>

                </div>

              </div>
            </div>

            {/* Right Computed Outcomes Dashboard */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Output Results summary */}
              <div className="bg-slate-900 text-white rounded-xl p-5 border border-slate-850 space-y-4 shadow-lg">
                <span className="text-[10px] font-black text-[#D4AF37] uppercase tracking-widest font-mono">🔮 MOTOR DE REGRAS OAB 3F — OUTPUTS GERADOS</span>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Computed Profile Box */}
                  <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 space-y-1">
                    <span className="text-[9px] uppercase font-bold text-slate-400">Classificação de Perfil</span>
                    <h4 className="text-sm font-black text-[#D4AF37]">{computedProfile}</h4>
                    <p className="text-[10.5px] text-slate-300 leading-snug">
                      Gerado a partir das preferências de fase, exames anteriores e taxa de acerto de {simAccuracy}%.
                    </p>
                  </div>

                  {/* Computed Risk Box */}
                  <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 space-y-1">
                    <span className="text-[9px] uppercase font-bold text-slate-400">Nível de Risco de Abandono</span>
                    <div className="flex items-center space-x-1.5">
                      <span className={`h-2.5 w-2.5 rounded-full ${
                        computedRisk === 'Alto' ? 'bg-red-500' : computedRisk === 'Médio' ? 'bg-amber-500' : 'bg-emerald-500'
                      }`} />
                      <h4 className={`text-sm font-black ${
                        computedRisk === 'Alto' ? 'text-red-400' : computedRisk === 'Médio' ? 'text-amber-400' : 'text-emerald-400'
                      }`}>{computedRisk}</h4>
                    </div>
                    <p className="text-[10.5px] text-slate-300 leading-snug">
                      {computedRisk === 'Alto' ? 'Lembretes automáticos e SMS prioritário serão disparados para reengajamento.' : 
                       computedRisk === 'Médio' ? 'O suporte acadêmico agendará uma ligação para tirar dúvidas.' : 
                       'Excelente consistência de estudo! O aluno está progredindo bem.'}
                    </p>
                  </div>

                </div>

                {/* Simulated Logs Terminal */}
                <div className="bg-slate-950 rounded-lg p-3 border border-slate-800 text-[10px] font-mono text-slate-300 space-y-1">
                  <span className="text-slate-500 font-bold block">// Logs de Interpretação das Regras:</span>
                  {simulationLogs.map((log, lIdx) => (
                    <div key={lIdx}>{log}</div>
                  ))}
                </div>
              </div>

              {/* Dynamic Feature Access Table */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                <div className="border-b border-slate-100 pb-2">
                  <h4 className="font-serif font-black text-slate-900 text-xs">Mapeamento de Controle de Acesso (Assinatura)</h4>
                  <p className="text-[10px] text-slate-400">Validação em tempo real dos recursos liberados para o plano de assinatura selecionado (<b>{simPlan.toUpperCase()}</b>).</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-medium">
                  {[
                    { id: 'teoriaBasica', label: 'Trilhas Teóricas de 1ª Fase', group: 'Comum' },
                    { id: 'cronogramaPersonalizado', label: 'Cronograma Diário Adaptativo', group: 'Comum' },
                    { id: 'simuladosComuns', label: 'Simulados Básicos de Diagnóstico', group: 'Pago' },
                    { id: 'suportePrioritario', label: 'Suporte Prioritário por Chamados', group: 'Pago' },
                    { id: 'simuladosIlimitados', label: 'Simulados Ilimitados OAB', group: 'VIP/Premium' },
                    { id: 'pecasPraticas', label: 'Doutrina de Peças (2ª Fase)', group: 'Pago/2Fase' },
                    { id: 'correcaoIndividual', label: 'Correção de Peças Individualizada', group: 'VIP Somente' },
                    { id: 'mentoriaAoVivo', label: 'Mentoria Semanal com Mentores', group: 'VIP Somente' }
                  ].map(f => {
                    const isAllowed = simActiveFeatures[f.id];
                    return (
                      <div key={f.id} className={`p-3 border rounded-xl flex items-center justify-between transition-colors ${
                        isAllowed ? 'bg-emerald-500/5 border-emerald-150' : 'bg-slate-50/50 border-slate-200/80 opacity-65'
                      }`}>
                        <div className="space-y-0.5">
                          <span className="font-bold text-slate-800 block">{f.label}</span>
                          <span className="text-[9px] text-slate-400 font-bold block">{f.group}</span>
                        </div>

                        {isAllowed ? (
                          <div className="h-5 w-5 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center shrink-0">
                            <Check className="h-3 w-3" />
                          </div>
                        ) : (
                          <div className="h-5 w-5 bg-rose-50 border border-rose-200 text-rose-500 rounded-full flex items-center justify-center shrink-0" title="Exige upgrade de plano comercial">
                            <Lock className="h-2.5 w-2.5" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Simulated paywall feedback when user clicks lock button */}
                {Object.values(simActiveFeatures).some(v => !v) && (
                  <div className="p-4 bg-[#D4AF37]/5 border border-[#D4AF37]/30 rounded-xl flex flex-col sm:flex-row justify-between items-center gap-3 animate-fade-in text-xs">
                    <div className="space-y-0.5">
                      <span className="font-black text-amber-900 flex items-center gap-1">
                        <Crown className="h-4 w-4 text-[#D4AF37]" /> Paywall Inteligente OAB 3F Ativado!
                      </span>
                      <p className="text-slate-500 font-medium">O sistema identificou recursos de alta performance travados para este aluno. Oferecendo plano <b>Completo ou VIP</b>.</p>
                    </div>
                    <button className="bg-slate-900 hover:bg-slate-800 text-[#D4AF37] font-bold py-2 px-3.5 rounded-lg text-[10.5px] uppercase tracking-wider cursor-pointer">
                      Simular Upgrade
                    </button>
                  </div>
                )}
              </div>

            </div>

          </div>
        )}

        {/* =======================================================
            CAMADA 3: INTEGRAÇÕES INTERNAS ENTRE MÓDULOS
           ======================================================= */}
        {activeLayer === 'integrations' && (
          <div className="space-y-6 animate-fade-in text-xs font-medium">
            
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-2">
              <h3 className="font-serif font-black text-slate-900 text-sm">Integração de Eventos e Fluxo de Dados (Data Flow)</h3>
              <p className="text-slate-500 leading-relaxed font-medium">
                No OAB 3F, os módulos não funcionam isolados. As ações do aluno na biblioteca, simulados ou fóruns disparam eventos que recalibram o perfil e cronograma em tempo real. Clique em "Disparar Fluxo" para rodar a simulação lógica em tempo real.
              </p>
            </div>

            {/* Integration modules list */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              <div className="space-y-3">
                {[
                  { id: 'int1', title: 'Integração 1: Onboarding → Perfil → Plano', desc: 'As respostas fornecidas na pesquisa inicial modelam o perfil pedagógico e criam automaticamente as tarefas do cronograma diário.', category: 'Geração de Plano' },
                  { id: 'int2', title: 'Integração 2: Plano → Dashboard Principal', desc: 'A tela inicial busca ativamente as tarefas pendentes sugeridas para hoje e renderiza o progresso, metas e contagem regressiva para a prova.', category: 'UX & Visualização' },
                  { id: 'int3', title: 'Integração 3: Atividade → Desempenho & Revisão', desc: 'Questões respondidas alimentam a taxa de acerto por matéria jurídica e agendam revisões automáticas baseadas nos erros do aluno.', category: 'Estudo Ativo' },
                  { id: 'int4', title: 'Integração 4: Monetização → Controle de Acesso', desc: 'Sincronização imediata entre gateways de pagamento (ex: Stripe) e liberação das permissões do aluno no ecossistema.', category: 'Comercial' },
                  { id: 'int5', title: 'Integração 5: Calendário → Plano → Notificações', desc: 'Prazos oficiais da FGV adicionados no calendário acionam lembretes push e adaptam o cronograma para modo reta final.', category: 'Cronograma' },
                  { id: 'int6', title: 'Integração 6: Comunidade / Suporte → Perfil Aluno', desc: 'Comentários acadêmicos em aulas dão visibilidade aos mentores sobre as dificuldades reais do candidato para refinar tarefas.', category: 'Acolhimento' },
                  { id: 'int7', title: 'Integração 7: Admin → Aplicativo do Aluno', desc: 'Videoaulas e simulados submetidos por professores no painel admin refletem imediatamente para alunos elegíveis.', category: 'Coordenação' },
                  { id: 'int8', title: 'Integração 8: Escolha da 2ª Fase → Customização', desc: 'A escolha da área pelo aluno altera todo o catálogo de materiais de apoio, peça prática e simulados para sua especialidade.', category: 'Especialização' }
                ].map(item => {
                  const isActive = activeIntegrationId === item.id;
                  return (
                    <div 
                      key={item.id}
                      className={`p-4 border rounded-xl flex flex-col justify-between gap-3 transition-all ${
                        isActive ? 'bg-slate-900 border-slate-950 text-white shadow-md' : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex justify-between items-center">
                          <span className={`text-[9px] font-black uppercase tracking-wider font-mono ${isActive ? 'text-[#D4AF37]' : 'text-slate-400'}`}>
                            {item.category}
                          </span>
                          <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded font-mono ${isActive ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-500'}`}>
                            {item.id.toUpperCase()}
                          </span>
                        </div>
                        <h4 className={`text-xs font-black font-serif ${isActive ? 'text-white' : 'text-slate-800'}`}>{item.title}</h4>
                        <p className={`text-[10.5px] leading-relaxed font-medium ${isActive ? 'text-slate-300' : 'text-slate-500'}`}>{item.desc}</p>
                      </div>

                      <div className="flex justify-end pt-1">
                        <button
                          onClick={() => triggerIntegrationSimulation(item.id, item.title)}
                          disabled={isSimulatingIntegration}
                          className={`text-[10px] font-bold uppercase tracking-wider py-1.5 px-3 rounded-md flex items-center gap-1.5 cursor-pointer transition-colors ${
                            isActive 
                              ? 'bg-[#D4AF37] text-slate-900 font-extrabold' 
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700 disabled:opacity-50'
                          }`}
                        >
                          {isActive && isSimulatingIntegration ? (
                            <>
                              <RefreshCw className="h-3 w-3 animate-spin" /> Processando...
                            </>
                          ) : (
                            <>
                              <Play className="h-3 w-3" /> Disparar Fluxo
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Integration Outputs logs terminal */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4 h-fit sticky top-6">
                <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h4 className="font-serif font-black text-slate-900 text-xs flex items-center gap-1.5">
                      <Activity className="h-4.5 w-4.5 text-slate-900" />
                      Visualizador de Eventos em Tempo Real (Data Flow)
                    </h4>
                    <p className="text-[10px] text-slate-400">Selecione uma integração ao lado para ver o mapeamento de requisições de backend.</p>
                  </div>
                  {activeIntegrationId && (
                    <button 
                      onClick={() => { setActiveIntegrationId(null); setIntegrationSteps([]); }}
                      className="text-xs font-bold text-slate-400 hover:text-slate-600"
                    >
                      Limpar
                    </button>
                  )}
                </div>

                {activeIntegrationId ? (
                  <div className="space-y-3.5">
                    <div className="bg-slate-900 text-white rounded-lg p-3.5 space-y-1.5 font-mono text-[10.5px]">
                      <span className="text-[#D4AF37] font-bold block">// EVENT_TRIGGER: {activeIntegrationId.toUpperCase()}</span>
                      <span className="text-slate-400 block">Timestamp: {new Date().toLocaleString()}</span>
                    </div>

                    <div className="space-y-3 border-l-2 border-slate-200 pl-4 py-1">
                      {integrationSteps.map((step, sIdx) => (
                        <div key={sIdx} className="space-y-1 text-xs animate-fade-in">
                          <p className="text-slate-700 font-bold leading-normal">{step}</p>
                        </div>
                      ))}
                    </div>

                    {isSimulatingIntegration ? (
                      <div className="flex items-center space-x-2 text-slate-400 text-xs font-semibold animate-pulse">
                        <RefreshCw className="h-3.5 w-3.5 animate-spin text-slate-900" />
                        <span>Escrevendo logs de transação no banco...</span>
                      </div>
                    ) : (
                      <div className="p-3 bg-emerald-50 border border-emerald-150 text-emerald-800 text-[10.5px] rounded-xl flex items-center gap-1.5 font-bold animate-scale-in">
                        <CheckCircle className="h-4.5 w-4.5 text-emerald-600 shrink-0" />
                        <span>Transação de Banco de Dados Concluída com Sucesso! Integridade de dados assegurada.</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-16 text-slate-400 border border-dashed border-slate-200 rounded-xl">
                    <Workflow className="h-10 w-10 text-slate-300 mx-auto" />
                    <p className="text-xs font-bold mt-3">Nenhum evento disparado ainda.</p>
                    <p className="text-[10px] text-slate-400 max-w-xs mx-auto mt-1 leading-normal">Escolha uma das 8 integrações sugeridas e clique em "Disparar Fluxo" para ver as requisições.</p>
                  </div>
                )}
              </div>

            </div>

          </div>
        )}

        {/* =======================================================
            CAMADA 4: GOVERNANÇA, ESCALABILIDADE E CONTROLE
           ======================================================= */}
        {activeLayer === 'governance' && (
          <div className="space-y-6 animate-fade-in text-xs font-medium">
            
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Side: Roles & Standard Status */}
              <div className="lg:col-span-6 space-y-6">
                
                {/* Roles & Permissions Matrix */}
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="font-serif font-black text-slate-900 text-xs flex items-center gap-1.5">
                      <Shield className="h-4.5 w-4.5 text-slate-900" /> Matriz de Perfis e Permissões Administrativas
                    </h3>
                    <p className="text-[10px] text-slate-400">Controles e privilégios específicos para equipe acadêmica, comercial e de mentoria.</p>
                  </div>

                  <div className="flex bg-slate-50 border p-1 rounded-lg">
                    {[
                      { id: 'super_admin', label: 'Super Admin' },
                      { id: 'gestor', label: 'Gestor' },
                      { id: 'professor', label: 'Professor/Mentor' },
                      { id: 'suporte', label: 'Suporte Técnico' }
                    ].map(role => (
                      <button
                        key={role.id}
                        onClick={() => setSelectedRole(role.id)}
                        className={`text-[10px] font-bold px-2.5 py-1.5 rounded-md flex-1 cursor-pointer transition-colors text-center ${
                          selectedRole === role.id ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-500 hover:text-slate-800'
                        }`}
                      >
                        {role.label}
                      </button>
                    ))}
                  </div>

                  {/* Permissions representation for selected role */}
                  <div className="bg-slate-50 p-4 rounded-xl space-y-2.5 border border-slate-150">
                    <span className="text-[9px] font-black uppercase tracking-wider text-slate-400 font-mono">Privilégios Habilitados:</span>
                    
                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      {[
                        { label: 'Excluir tabelas de dados', allowed: ['super_admin'] },
                        { label: 'Gerenciar planos comerciais', allowed: ['super_admin', 'gestor'] },
                        { label: 'Publicar cursos e trilhas', allowed: ['super_admin', 'gestor'] },
                        { label: 'Criar aulas e materiais', allowed: ['super_admin', 'gestor', 'professor'] },
                        { label: 'Cadastrar questões e simulados', allowed: ['super_admin', 'gestor', 'professor'] },
                        { label: 'Responder chamado de suporte', allowed: ['super_admin', 'suporte'] },
                        { label: 'Responder fórum acadêmico', allowed: ['super_admin', 'professor'] },
                        { label: 'Moderar comentários', allowed: ['super_admin', 'gestor', 'professor'] }
                      ].map((perm, pIdx) => {
                        const isAllowed = perm.allowed.includes(selectedRole);
                        return (
                          <div key={pIdx} className="flex items-center space-x-2">
                            <span className={`h-4 w-4 rounded-full flex items-center justify-center shrink-0 text-white ${isAllowed ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                              {isAllowed ? '✓' : '×'}
                            </span>
                            <span className={isAllowed ? 'text-slate-800 font-semibold' : 'text-slate-400'}>{perm.label}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Standard States */}
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="font-serif font-black text-slate-900 text-xs">Padrões de Status de Entidades</h3>
                    <p className="text-[10px] text-slate-400">Padronização de status lógico para as principais entidades do sistema.</p>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <span className="font-bold text-slate-700 block">A. Conteúdo Acadêmico (Aulas, Questões, Simulados)</span>
                      <div className="flex gap-2 mt-1">
                        {['rascunho', 'publicado', 'oculto', 'arquivado'].map(s => (
                          <span key={s} className="bg-slate-100 text-slate-600 font-mono font-bold text-[9px] px-2 py-0.5 rounded border border-slate-200 uppercase">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <span className="font-bold text-slate-700 block">B. Tarefa do Cronograma</span>
                      <div className="flex gap-2 mt-1">
                        {['pendente', 'concluida', 'adiada', 'perdida'].map(s => (
                          <span key={s} className="bg-slate-100 text-slate-600 font-mono font-bold text-[9px] px-2 py-0.5 rounded border border-slate-200 uppercase">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <span className="font-bold text-slate-700 block">C. Assinatura do Estudante</span>
                      <div className="flex gap-2 mt-1">
                        {['ativa', 'expirada', 'cancelada', 'trial', 'atrasada'].map(s => (
                          <span key={s} className="bg-slate-100 text-slate-600 font-mono font-bold text-[9px] px-2 py-0.5 rounded border border-slate-200 uppercase">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              {/* Right Side: Logs & Scalability */}
              <div className="lg:col-span-6 space-y-6">
                
                {/* Simulated Audit Logs */}
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="font-serif font-black text-slate-900 text-xs flex items-center gap-1.5">
                      <FileText className="h-4.5 w-4.5 text-slate-900" /> Histórico de Logs & Auditoria do Sistema
                    </h3>
                    <p className="text-[10px] text-slate-400">Rastreabilidade integral das alterações de permissões, finanças e dados acadêmicos.</p>
                  </div>

                  <div className="space-y-3">
                    {auditLogs.map(log => (
                      <div key={log.id} className="border border-slate-150 p-3 rounded-lg text-xs leading-normal font-medium bg-slate-50 flex items-start gap-3">
                        <div className={`h-4.5 w-4.5 rounded-md flex items-center justify-center text-white font-mono font-bold text-[9px] shrink-0 mt-0.5 ${
                          log.status === 'sucesso' ? 'bg-emerald-500' : log.status === 'alerta' ? 'bg-amber-500' : 'bg-blue-500'
                        }`}>
                          {log.status[0].toUpperCase()}
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-slate-800">{log.actor} <span className="text-[9px] font-mono text-slate-400 font-medium">({log.role})</span></span>
                            <span className="text-[9.5px] font-mono text-slate-400">{log.timestamp}</span>
                          </div>
                          <p className="text-slate-600 mt-0.5">{log.action}: <span className="font-bold">{log.target}</span></p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Scalability Future Roadmap */}
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="font-serif font-black text-slate-900 text-xs flex items-center gap-1.5">
                      <Crown className="h-4.5 w-4.5 text-amber-500" /> Prontidão de Escalabilidade
                    </h3>
                    <p className="text-[10px] text-slate-400">Preparação técnica de arquitetura para acomodar o crescimento sem perda de performance.</p>
                  </div>

                  <div className="space-y-3 text-xs leading-relaxed font-medium">
                    <div className="flex items-start gap-2">
                      <div className="h-4.5 w-4.5 bg-slate-100 rounded-full flex items-center justify-center shrink-0 font-bold text-slate-700 text-[9px] mt-0.5">1</div>
                      <div>
                        <span className="font-bold text-slate-800">Correção Individualizada Assistida por IA:</span>
                        <p className="text-slate-500">Mapeamento pronto nas tabelas `treino_2a_fase` para plugar IA no pré-diagnóstico de teses e artigos, acelerando em 75% o tempo de entrega do mentor.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <div className="h-4.5 w-4.5 bg-slate-100 rounded-full flex items-center justify-center shrink-0 font-bold text-slate-700 text-[9px] mt-0.5">2</div>
                      <div>
                        <span className="font-bold text-slate-800">Sistemas de Gamificação Avançados:</span>
                        <p className="text-slate-500">Entidade de Usuário estruturada para suportar tabelas de Ranking Acadêmico, Conquistas de Ofensivas e Moedas Virtuais (Tokens OAB) para trocar por simulados bônus.</p>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}

      </div>

    </div>
  );
}
