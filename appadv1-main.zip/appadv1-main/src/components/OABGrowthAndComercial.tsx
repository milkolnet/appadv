/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  Users, 
  Target, 
  Crown, 
  Megaphone, 
  Sliders, 
  MessageSquare, 
  Mail, 
  Smartphone, 
  Send, 
  DollarSign, 
  Briefcase, 
  AlertTriangle, 
  ChevronRight, 
  Search, 
  Filter, 
  Settings, 
  CheckCircle2, 
  Percent, 
  Calendar, 
  ShoppingBag, 
  FileText, 
  UserCheck, 
  HelpCircle, 
  Sparkles, 
  Copy, 
  Check, 
  Clock, 
  FileCheck, 
  Play, 
  Activity, 
  BookOpen, 
  Compass, 
  RefreshCw,
  Plus
} from 'lucide-react';

// Contact / Lead Interface
interface Contact {
  id: string;
  name: string;
  email: string;
  phone: string;
  origin: string;
  dateJoined: string;
  funnelStage: 'lead_novo' | 'lead_engajado' | 'gratuito_ativo' | 'gratuito_travado' | 'checkout_abandonado' | 'premium_ativo' | 'elegivel_upgrade' | 'em_risco' | 'cancelado_recente' | 'reativado';
  oabPhase: '1_fase' | '2_fase' | 'ambas' | 'indefinida';
  interest: '1ª Fase' | '2ª Fase' | 'Reta Final' | 'Mentoria' | 'Geral';
  secondPhaseArea?: string;
  currentPlan: 'Gratuito' | 'Plano 1ª Fase' | 'Plano 2ª Fase' | 'Plano Completo' | 'Reta Final VIP' | 'Nenhum';
  score: number; // 0 to 100 commercial engagement score
  tags: string[];
  lastTouch: string;
}

// Initial CRM Contacts Data
const INITIAL_CONTACTS: Contact[] = [
  {
    id: '1',
    name: 'Ana Carolina Meireles',
    email: 'carol.meireles@gmail.com',
    phone: '(11) 98234-1102',
    origin: 'LP Cronograma Gratuito',
    dateJoined: '2026-06-20',
    funnelStage: 'gratuito_ativo',
    oabPhase: '1_fase',
    interest: '1ª Fase',
    currentPlan: 'Gratuito',
    score: 82,
    tags: ['isca:cronograma', 'engajamento:alto', 'metas:dia_3'],
    lastTouch: 'Hoje às 09:12'
  },
  {
    id: '2',
    name: 'Matheus Albuquerque Castro',
    email: 'matheus.castro@adv.com.br',
    phone: '(21) 97120-4039',
    origin: 'Anúncio Instagram Reta Final',
    dateJoined: '2026-06-22',
    funnelStage: 'checkout_abandonado',
    oabPhase: '1_fase',
    interest: 'Reta Final',
    currentPlan: 'Nenhum',
    score: 95,
    tags: ['checkout:abandonado', 'origem:ads_insta', 'plano:reta_final'],
    lastTouch: 'Ontem às 18:45'
  },
  {
    id: '3',
    name: 'Larissa Fontes',
    email: 'larissa.fontes@outlook.com',
    phone: '(31) 99341-2287',
    origin: 'Cadastro Direto App',
    dateJoined: '2026-06-15',
    funnelStage: 'gratuito_travado',
    oabPhase: '1_fase',
    interest: '1ª Fase',
    currentPlan: 'Gratuito',
    score: 35,
    tags: ['status:inativo_5dias', 'onboarding:completo', 'revisao:acumulada'],
    lastTouch: 'Há 5 dias'
  },
  {
    id: '4',
    name: 'Dr. Thiago Vasconcelos',
    email: 'thiago.vasconcelos.oab@hotmail.com',
    phone: '(85) 98877-3341',
    origin: 'E-book Estratégia OAB',
    dateJoined: '2026-05-10',
    funnelStage: 'premium_ativo',
    oabPhase: '1_fase',
    interest: '1ª Fase',
    currentPlan: 'Plano 1ª Fase',
    score: 90,
    tags: ['plano:fase1_anual', 'simulados:concluidos', 'score:alto_acerto'],
    lastTouch: 'Hoje às 07:30'
  },
  {
    id: '5',
    name: 'Juliana Portela Costa',
    email: 'juliana.portela@yahoo.com.br',
    phone: '(19) 99182-4521',
    origin: 'Resultado 1ª Fase LP',
    dateJoined: '2026-06-18',
    funnelStage: 'elegivel_upgrade',
    oabPhase: '2_fase',
    interest: '2ª Fase',
    secondPhaseArea: 'Direito Tributário',
    currentPlan: 'Plano 1ª Fase', // Approved, ready for upgrade to 2nd phase
    score: 88,
    tags: ['aprovado:fase1', 'interesse:tributario', 'origem:resultado_lp'],
    lastTouch: 'Há 2 dias'
  },
  {
    id: '6',
    name: 'Felipe Siqueira Pinto',
    email: 'felipe.siqueira.adv@gmail.com',
    phone: '(41) 98455-1122',
    origin: 'Lista de Espera VIP',
    dateJoined: '2026-06-24',
    funnelStage: 'lead_novo',
    oabPhase: 'ambas',
    interest: 'Mentoria',
    currentPlan: 'Nenhum',
    score: 65,
    tags: ['lista:espera_vip', 'contato:whats'],
    lastTouch: 'Hoje às 11:00'
  },
  {
    id: '7',
    name: 'Beatriz Rezende Rocha',
    email: 'beatriz.rezende@gmail.com',
    phone: '(81) 99612-4578',
    origin: 'Mini Simulado Gratuito',
    dateJoined: '2026-06-05',
    funnelStage: 'em_risco',
    oabPhase: '1_fase',
    interest: '1ª Fase',
    currentPlan: 'Plano Completo',
    score: 48,
    tags: ['alerta:baixo_uso', 'simulado:reprovado', 'risco:cancelamento'],
    lastTouch: 'Há 3 dias'
  },
  {
    id: '8',
    name: 'Eduardo Guedes Mendes',
    email: 'edu.guedesm@outlook.com',
    phone: '(71) 99112-8822',
    origin: 'Aula Aberta YouTube',
    dateJoined: '2026-04-12',
    funnelStage: 'reativado',
    oabPhase: '2_fase',
    interest: '2ª Fase',
    secondPhaseArea: 'Direito Penal',
    currentPlan: 'Plano 2ª Fase',
    score: 78,
    tags: ['reativado:whats', 'campanha:desconto_retomada', 'pecas:treinando'],
    lastTouch: 'Hoje às 08:15'
  },
  {
    id: '9',
    name: 'Mariana Sales',
    email: 'mariana.sales.direto@gmail.com',
    phone: '(11) 98111-2233',
    origin: 'LP Cronograma Gratuito',
    dateJoined: '2026-06-12',
    funnelStage: 'lead_engajado',
    oabPhase: '1_fase',
    interest: '1ª Fase',
    currentPlan: 'Gratuito',
    score: 75,
    tags: ['isca:cronograma', 'simulado:feito', 'abertura:email_alta'],
    lastTouch: 'Hoje às 10:44'
  },
  {
    id: '10',
    name: 'Roberto Arruda',
    email: 'roberto.arruda@gmail.com',
    phone: '(31) 98777-6655',
    origin: 'Checklist 2ª Fase LP',
    dateJoined: '2026-06-01',
    funnelStage: 'cancelado_recente',
    oabPhase: '2_fase',
    interest: '2ª Fase',
    secondPhaseArea: 'Direito Civil',
    currentPlan: 'Nenhum',
    score: 20,
    tags: ['plano:expirado', 'motivo:financeiro'],
    lastTouch: 'Há 7 dias'
  }
];

// Lead Magnets list (BLOCO 12)
const LEAD_MAGNETS = [
  {
    id: 'cronograma_1f',
    title: 'Cronograma Gratuito de 90 Dias (1ª Fase)',
    type: 'PDF Dinâmico',
    target: 'Bacharel perdido ou sem rotina',
    offer: 'Conversão para Plano 1ª Fase com 10% OFF',
    leadsCount: 1450,
    conversion: '12.4%',
    cta: 'Baixar Plano 90 Dias Gratuitamente'
  },
  {
    id: 'checklist_2f',
    title: 'Checklist Estrutural da Peça Nota 10 (2ª Fase)',
    type: 'Guia Interativo',
    target: 'Estudante aprovado na 1ª fase',
    offer: 'Upgrade para Plano 2ª Fase + Correção Premium',
    leadsCount: 890,
    conversion: '18.2%',
    cta: 'Acessar Checklist de Cabimento'
  },
  {
    id: 'planner_reta',
    title: 'Planner de Sobrevivência Reta Final (Últimos 15 Dias)',
    type: 'Template Organizador',
    target: 'Candidato ansioso de reta final',
    offer: 'Plano Reta Final VIP com Simulados Comentados',
    leadsCount: 1820,
    conversion: '22.5%',
    cta: 'Garantir Plano de Sobrevivência'
  },
  {
    id: 'mini_simulado',
    title: 'Mini Simulado Diagnóstico FGV (20 Questões Comentadas)',
    type: 'Atividade no App',
    target: 'Lead curioso avaliando nível',
    offer: 'Assinatura Plano Completo com Mentoria Coletiva',
    leadsCount: 2100,
    conversion: '15.8%',
    cta: 'Iniciar Simulado Diagnóstico'
  },
  {
    id: 'aula_aberta',
    title: 'Masterclass: Como Gabaritar Ética sem Decorar Doutrina',
    type: 'Vídeo Gravado',
    target: 'Qualquer candidato em busca de pontos rápidos',
    offer: 'Inscrição Direta no App Premium',
    leadsCount: 1250,
    conversion: '9.6%',
    cta: 'Assistir Aula Gratuita Agora'
  }
];

export default function OABGrowthAndComercial() {
  const [activeTab, setActiveTab] = useState<'overview' | 'crm' | 'automation' | 'campaigns' | 'retention' | 'governance'>('overview');
  
  // Growth and Revenue States (Dynamic Simulator)
  const [activeLeadsCount, setActiveLeadsCount] = useState<number>(7512);
  const [conversionRate, setConversionRate] = useState<number>(4.2); // as percentage
  const [isLauchMode, setIsLaunchMode] = useState<boolean>(false); // Launch vs Perpetual Mode Toggle
  
  // Launch checklist states
  const [launchCountdown, setLaunchCountdown] = useState<string>('02d 14h 35m');
  const [launchRegistered, setLaunchRegistered] = useState<number>(3104);
  const [preLaunchChecklist, setPreLaunchChecklist] = useState([
    { task: 'Criar Landing Page de Pré-Cadastro', done: true },
    { task: 'Disparar Régua de Aquecimento (E-mails 1 a 3)', done: true },
    { task: 'Configurar Carrinho de Checkout com Link Único', done: true },
    { task: 'Gravar Vídeo de Revelação do Método 3F', done: true },
    { task: 'Liberar Bônus por Tempo Limitado no Painel', done: false },
    { task: 'Disparar Push de Contagem Regressiva Final', done: false }
  ]);

  // CRM Search & Filters
  const [crmSearch, setCrmSearch] = useState<string>('');
  const [crmStageFilter, setCrmStageFilter] = useState<string>('todos');
  const [crmPhaseFilter, setCrmPhaseFilter] = useState<string>('todos');
  const [crmContacts, setCrmContacts] = useState<Contact[]>(INITIAL_CONTACTS);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  
  // Custom segment state (BLOCO 5)
  const [customSegments, setCustomSegments] = useState([
    { name: 'Interessados 1ª Fase - Reta Final', query: '1_fase + score > 70', estCount: 840, status: 'Ativo' },
    { name: 'Gratuitos Travados (Resgate)', query: 'gratuito_travado', estCount: 1205, status: 'Ativo' },
    { name: 'Aprovados 1ª Fase (Alvo 2ª Fase)', query: 'elegivel_upgrade', estCount: 215, status: 'Ativo' },
    { name: 'Risco de Churn (Inatividade)', query: 'em_risco', estCount: 114, status: 'Ativo' }
  ]);
  const [newSegmentName, setNewSegmentName] = useState<string>('');
  const [newSegmentQuery, setNewSegmentQuery] = useState<string>('');

  // Active automations triggers count (simulated)
  const [automationStats, setAutomationStats] = useState({
    sentToday: 1245,
    openRate: '68.4%',
    clickRate: '24.2%',
    upgradesTriggered: 14
  });

  // Communication régua view states
  const [expandedRegua, setExpandedRegua] = useState<string | null>('regua1');

  // Logs of commercial operations (BLOCO 19)
  const [operationLogs, setOperationLogs] = useState<Array<{time: string, action: string, type: string, target: string}>>([
    { time: '09:45', action: 'Disparo de Push de Abandono de Checkout', type: 'Automação', target: 'Matheus Albuquerque Castro' },
    { time: '08:30', action: 'Reajuste do Cronograma no CRM', type: 'Manual', target: 'Eduardo Guedes Mendes' },
    { time: 'Ontem', action: 'Ativação da Régua de Boas-Vindas', type: 'Automação', target: 'Ana Carolina Meireles' },
    { time: 'Ontem', action: 'Fase de Lançamento de 2ª Fase Ativada', type: 'Campanha', target: 'Todos os Alunos Elegíveis' }
  ]);

  // Pricing streams variables (BLOCO 1)
  const PRICING_PLANS = {
    fase1: { name: 'Plano 1ª Fase', price: 297, details: 'Teoria, banco de questões e cronograma focado na 1ª fase.' },
    fase2: { name: 'Plano 2ª Fase', price: 497, details: 'Roteiros de peças práticas, discursivas e análise estrutural.' },
    completo: { name: 'Plano Completo OAB 3F', price: 697, details: 'Acesso total de 1ª e 2ª fase com cronograma adaptativo completo.' },
    retaFinal: { name: 'Plano Reta Final', price: 147, details: 'Revisões ultra-focadas + simulados comentados de véspera.' },
    mentoria: { name: 'Mentoria / VIP', price: 1297, details: 'Acompanhamento pessoal com correção individual de peças.' }
  };

  // Dynamic Revenue Calculation
  const estimatedRevenue = useMemo(() => {
    const conversions = Math.round(activeLeadsCount * (conversionRate / 100));
    // Average order value simulated as R$ 420 based on mix of plans
    const totalRev = conversions * 420;
    const mrr = Math.round(totalRev * 0.4); // 40% as recurring subscription
    return {
      conversions,
      totalRev,
      mrr
    };
  }, [activeLeadsCount, conversionRate]);

  // Filter contacts list based on search and selected options
  const filteredContacts = useMemo(() => {
    return crmContacts.filter(c => {
      const matchSearch = c.name.toLowerCase().includes(crmSearch.toLowerCase()) || 
                          c.email.toLowerCase().includes(crmSearch.toLowerCase()) ||
                          c.tags.some(t => t.toLowerCase().includes(crmSearch.toLowerCase()));
      const matchStage = crmStageFilter === 'todos' || c.funnelStage === crmStageFilter;
      const matchPhase = crmPhaseFilter === 'todos' || c.oabPhase === crmPhaseFilter;
      return matchSearch && matchStage && matchPhase;
    });
  }, [crmContacts, crmSearch, crmStageFilter, crmPhaseFilter]);

  // Copy indicator state
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const triggerCopyNotification = (id: string) => {
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Add a segment manual
  const handleAddSegment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSegmentName) return;
    setCustomSegments([
      ...customSegments,
      {
        name: newSegmentName,
        query: newSegmentQuery || 'custom_rule',
        estCount: Math.floor(Math.random() * 300) + 12,
        status: 'Ativo'
      }
    ]);
    setNewSegmentName('');
    setNewSegmentQuery('');
    
    // Add log
    const now = new Date();
    setOperationLogs([
      { 
        time: `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
        action: `Segmento criado: ${newSegmentName}`,
        type: 'Segmento',
        target: 'Base de leads'
      },
      ...operationLogs
    ]);
  };

  // Toggle checklist tasks
  const toggleChecklistTask = (index: number) => {
    const updated = [...preLaunchChecklist];
    updated[index].done = !updated[index].done;
    setPreLaunchChecklist(updated);
  };

  // Execute direct CRM actions
  const executeCRMAction = (actionName: string, contact: Contact) => {
    const now = new Date();
    setOperationLogs([
      {
        time: `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
        action: `${actionName} disparado`,
        type: 'Ação CRM',
        target: contact.name
      },
      ...operationLogs
    ]);
    alert(`Sucesso: Ação [${actionName}] executada para o contato ${contact.name}.`);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8 font-sans text-left" id="oab-growth-container">
      {/* Editorial Header */}
      <div className="border-b border-oab-accent/30 pb-6 mb-8">
        <div className="flex items-center space-x-2 text-oab-accent font-mono text-xs uppercase tracking-widest mb-1.5 font-bold">
          <Megaphone className="h-4 w-4 text-oab-accent" />
          <span>Máquina de Vendas & Relacionamento</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-display font-bold tracking-tight text-slate-900 leading-tight">
          Growth & Comercial OAB 3F
        </h1>
        <p className="text-slate-600 mt-2 max-w-4xl text-sm sm:text-base leading-relaxed">
          Gerencie o funil comercial integrado, execute campanhas por momento de prova (1ª e 2ª Fase), acompanhe o CRM de leads/alunos, 
          ajuste réguas automatizadas de retenção/upgrades e audite a governança do ecossistema.
        </p>
      </div>

      {/* Mode Switcher Banner: Lançamento vs Perpétuo (BLOCO 16 & 17) */}
      <div className={`p-4 border shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all ${
        isLauchMode 
          ? 'bg-amber-500/5 border-amber-500/20 text-amber-900' 
          : 'bg-emerald-500/5 border-emerald-500/10 text-emerald-900'
      }`}>
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <Activity className={`h-5 w-5 ${isLauchMode ? 'text-amber-500 animate-pulse' : 'text-emerald-500'}`} />
            <span className="font-bold text-sm uppercase font-mono">
              Operação Ativa: {isLauchMode ? 'Modo Lançamento Promocional' : 'Modo Venda Contínua (Perpétuo)'}
            </span>
          </div>
          <p className="text-xs text-slate-600 max-w-2xl">
            {isLauchMode 
              ? 'Foco total em captação de leads para listas quentes, contagem regressiva, bônus de escassez e aberturas de carrinhos coordenadas com o cronograma da OAB.'
              : 'Fluxo contínuo de entrada orgânica/ads. O plano de degustação gratuito e as réguas contextuais baseadas no uso do app guiam as conversões diárias.'
            }
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setIsLaunchMode(!isLauchMode)}
            className={`px-4 py-2 text-xs font-bold transition-all flex items-center space-x-2 border rounded ${
              isLauchMode 
                ? 'bg-amber-600 hover:bg-amber-700 text-white border-amber-600' 
                : 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-600'
            }`}
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Alternar para {isLauchMode ? 'Modo Perpétuo' : 'Modo Lançamento'}</span>
          </button>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-px" id="growth-main-tabs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'overview' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <TrendingUp className="h-4 w-4" />
          <span>Visão Geral & Métricas</span>
        </button>
        <button
          onClick={() => setActiveTab('crm')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'crm' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Users className="h-4 w-4" />
          <span>CRM & Segmentos</span>
        </button>
        <button
          onClick={() => setActiveTab('automation')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'automation' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Sliders className="h-4 w-4" />
          <span>Réguas & Automações</span>
        </button>
        <button
          onClick={() => setActiveTab('campaigns')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'campaigns' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Calendar className="h-4 w-4" />
          <span>Campanhas OAB</span>
        </button>
        <button
          onClick={() => setActiveTab('retention')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'retention' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Target className="h-4 w-4" />
          <span>Checkout & Retenção</span>
        </button>
        <button
          onClick={() => setActiveTab('governance')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'governance' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Settings className="h-4 w-4" />
          <span>Integração & Regras</span>
        </button>
      </div>

      {/* ==========================================
          TAB 1: VISÃO GERAL & METRICAS
          ========================================== */}
      {activeTab === 'overview' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Métricas Key Performance Indicators (BLOCO 15) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-5 border border-slate-200 shadow-sm space-y-2">
              <span className="text-xs uppercase font-mono tracking-wider text-slate-500 block">Leads Ativos na Base</span>
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl sm:text-3xl font-display font-extrabold text-slate-900">{activeLeadsCount}</span>
                <span className="text-xs text-emerald-600 font-bold font-mono">+12%</span>
              </div>
              <p className="text-[10px] text-slate-400">Captados de Landing Pages e materiais de entrada.</p>
            </div>

            <div className="bg-white p-5 border border-slate-200 shadow-sm space-y-2">
              <span className="text-xs uppercase font-mono tracking-wider text-slate-500 block">Conversão de Assinaturas</span>
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl sm:text-3xl font-display font-extrabold text-slate-900">{conversionRate}%</span>
                <span className="text-xs text-amber-600 font-bold font-mono">Meta: 5%</span>
              </div>
              <p className="text-[10px] text-slate-400">Percentual de leads que convertem em planos pagos.</p>
            </div>

            <div className="bg-white p-5 border border-slate-200 shadow-sm space-y-2">
              <span className="text-xs uppercase font-mono tracking-wider text-slate-500 block">Conversões Estimadas</span>
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl sm:text-3xl font-display font-extrabold text-slate-900">{estimatedRevenue.conversions}</span>
                <span className="text-xs text-slate-500 font-mono">novos alunos</span>
              </div>
              <p className="text-[10px] text-slate-400">Total de novos assinantes no ciclo comercial atual.</p>
            </div>

            <div className="bg-white p-5 border border-slate-200 shadow-sm space-y-2">
              <span className="text-xs uppercase font-mono tracking-wider text-slate-500 block">MRR Projetado (Mensal)</span>
              <div className="flex items-baseline space-x-2 text-oab-accent">
                <span className="text-2xl sm:text-3xl font-display font-extrabold text-slate-900">R$ {estimatedRevenue.mrr.toLocaleString('pt-BR')}</span>
              </div>
              <p className="text-[10px] text-slate-400">Estimativa baseada no ticket médio de R$ 420 dos planos.</p>
            </div>
          </div>

          {/* Interactive Metric Tweak & Lines of Revenue (BLOCO 1 & 15) */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Interactive Simulator sliders */}
            <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6 lg:col-span-2">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-lg font-display font-bold text-slate-900">Calculadora e Simulador de Receita OAB 3F</h3>
                <span className="text-[11px] font-mono bg-oab-accent/10 text-oab-accent px-2 py-0.5 rounded uppercase font-bold">Simulação Dinâmica</span>
              </div>
              
              <p className="text-xs text-slate-600">
                Ajuste os parâmetros abaixo para simular o comportamento da sua máquina de growth. Entenda o impacto do tráfego e da otimização de conversão no faturamento total do negócio.
              </p>

              <div className="space-y-4 font-sans text-xs">
                <div className="space-y-2">
                  <div className="flex justify-between text-slate-700 font-bold">
                    <span>Volume de Leads (LP/Iscas):</span>
                    <span className="text-oab-accent text-sm font-mono">{activeLeadsCount.toLocaleString()} leads</span>
                  </div>
                  <input 
                    type="range" 
                    min="1000" 
                    max="20000" 
                    step="500"
                    value={activeLeadsCount} 
                    onChange={(e) => setActiveLeadsCount(Number(e.target.value))}
                    className="w-full accent-[#D4AF37]"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>Min: 1.000</span>
                    <span>Max: 20.000</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-slate-700 font-bold">
                    <span>Taxa de Conversão (Lead → Pago):</span>
                    <span className="text-oab-accent text-sm font-mono">{conversionRate}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="1" 
                    max="15" 
                    step="0.1"
                    value={conversionRate} 
                    onChange={(e) => setConversionRate(Number(e.target.value))}
                    className="w-full accent-[#D4AF37]"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>Média da Indústria: 2% a 4%</span>
                    <span>Alta Conversão: 8%+</span>
                  </div>
                </div>
              </div>

              {/* Simulation Result summary Card */}
              <div className="p-4 bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4 text-center rounded">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-mono text-slate-400 block">Leads Necessários</span>
                  <p className="text-base font-bold text-slate-900">{activeLeadsCount}</p>
                </div>
                <div className="space-y-1 border-t sm:border-t-0 sm:border-l sm:border-r border-slate-200">
                  <span className="text-[10px] uppercase font-mono text-slate-400 block">Vendas Esperadas</span>
                  <p className="text-base font-bold text-slate-900">{estimatedRevenue.conversions} assinaturas</p>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-mono text-slate-400 block">Faturamento Total do Ciclo</span>
                  <p className="text-lg font-extrabold text-[#D4AF37]">R$ {estimatedRevenue.totalRev.toLocaleString('pt-BR')}</p>
                </div>
              </div>
            </div>

            {/* Pricing list / revenue lines display (BLOCO 1) */}
            <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
              <h3 className="text-base font-display font-bold text-slate-900 border-b border-slate-100 pb-2">Linhas de Receita do Modelo Comercial</h3>
              <p className="text-xs text-slate-600">Nossos 5 principais produtos desenhados para capturar valor em cada estágio da jornada:</p>
              
              <div className="space-y-3 font-sans text-xs">
                {Object.entries(PRICING_PLANS).map(([key, plan]) => (
                  <div key={key} className="p-2.5 border border-slate-100 bg-slate-50 rounded flex justify-between items-start">
                    <div className="space-y-0.5 max-w-[70%]">
                      <span className="font-bold text-slate-900 block">{plan.name}</span>
                      <p className="text-[10px] text-slate-500 leading-tight">{plan.details}</p>
                    </div>
                    <div className="text-right">
                      <span className="font-mono text-xs font-bold text-slate-900 block">R$ {plan.price}</span>
                      <span className="text-[9px] uppercase font-mono text-slate-400 block">À Vista</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Interactive Funnel Stages Flow (BLOCO 2) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-lg font-display font-bold text-slate-900 border-b border-slate-100 pb-3">O Funil Comercial do OAB 3F (Captação à Expansão)</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Visualize como um estudante navega por nossa jornada comercial. Cada transição é monitorada no banco de dados e aciona réguas específicas de CRM.
            </p>

            <div className="relative space-y-3 font-sans text-xs">
              {/* Funnel Stage 1 */}
              <div className="p-3 border border-slate-200 bg-slate-50/50 flex justify-between items-center rounded-l-md border-l-4 border-slate-400">
                <div className="flex items-center space-x-3">
                  <span className="h-6 w-6 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs">1</span>
                  <div>
                    <span className="font-bold text-slate-950 block">Visitante / Desconhecido</span>
                    <span className="text-[10px] text-slate-500">Público frio assistindo aulas no YouTube ou clicando em anúncios de redes sociais.</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold block">100% de Entrada</span>
                  <span className="text-[10px] text-slate-400">Sem contato comercial</span>
                </div>
              </div>

              {/* Funnel Stage 2 */}
              <div className="p-3 border border-slate-200 bg-slate-50/50 flex justify-between items-center rounded-l-md border-l-4 border-slate-500">
                <div className="flex items-center space-x-3">
                  <span className="h-6 w-6 rounded-full bg-slate-300 text-slate-800 flex items-center justify-center font-bold text-xs">2</span>
                  <div>
                    <span className="font-bold text-slate-950 block">Lead</span>
                    <span className="text-[10px] text-slate-500">Bacharel que deixou dados (e-mail, nome) para baixar uma isca digital ou ver o checklist da prova.</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-slate-700 block">~45% conversão LP</span>
                  <span className="text-[10px] text-slate-400">Nutrição de Boas-Vindas</span>
                </div>
              </div>

              {/* Funnel Stage 3 */}
              <div className="p-3 border border-slate-200 bg-slate-50/50 flex justify-between items-center rounded-l-md border-l-4 border-blue-400">
                <div className="flex items-center space-x-3">
                  <span className="h-6 w-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-xs">3</span>
                  <div>
                    <span className="font-bold text-slate-950 block">Lead Qualificado</span>
                    <span className="text-[10px] text-slate-500">Lead que confirmou a fase da OAB, informou área da 2ª fase e demonstrou intenção imediata de prova.</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-blue-700 block">~60% preenche perfil</span>
                  <span className="text-[10px] text-slate-400">Incentivo ao Onboarding</span>
                </div>
              </div>

              {/* Funnel Stage 4 */}
              <div className="p-3 border border-slate-200 bg-slate-50/50 flex justify-between items-center rounded-l-md border-l-4 border-indigo-400">
                <div className="flex items-center space-x-3">
                  <span className="h-6 w-6 rounded-full bg-indigo-100 text-indigo-800 flex items-center justify-center font-bold text-xs">4</span>
                  <div>
                    <span className="font-bold text-slate-950 block">Usuário Gratuito / Degustação</span>
                    <span className="text-[10px] text-slate-500">Cria a conta no app, resolve meta do Dia 1 e testa a plataforma no modo de degustação com limites.</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-indigo-700 block">75% ativação conta</span>
                  <span className="text-[10px] text-slate-400">Gatilho de Limite do Gratuito</span>
                </div>
              </div>

              {/* Funnel Stage 5 */}
              <div className="p-3 border border-slate-200 bg-slate-50/50 flex justify-between items-center rounded-l-md border-l-4 border-[#D4AF37]">
                <div className="flex items-center space-x-3">
                  <span className="h-6 w-6 rounded-full bg-amber-100 text-[#D4AF37] flex items-center justify-center font-bold text-xs">5</span>
                  <div>
                    <span className="font-bold text-slate-950 block">Assinante Premium / Aluno Pago</span>
                    <span className="text-[10px] text-slate-500">Assina o Plano 1ª Fase, Plano 2ª Fase ou Completo. Acesso irrestrito ao ecossistema.</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-[#D4AF37] block">{conversionRate}% global</span>
                  <span className="text-[10px] text-slate-400">Régua de Boas-Vindas Premium</span>
                </div>
              </div>

              {/* Funnel Stage 6 */}
              <div className="p-3 border border-slate-200 bg-slate-50/50 flex justify-between items-center rounded-l-md border-l-4 border-emerald-400">
                <div className="flex items-center space-x-3">
                  <span className="h-6 w-6 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">6</span>
                  <div>
                    <span className="font-bold text-slate-950 block">Aluno em Expansão / Recompra</span>
                    <span className="text-[10px] text-slate-500">Aprovado na 1ª fase migrando para 2ª fase, ou aluno premium assinando pacote de Mentoria VIP.</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-emerald-700 block">35% taxa de upgrade</span>
                  <span className="text-[10px] text-slate-400">Upsell Automático Integrado</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 2: CRM & SEGMENTOS
          ========================================== */}
      {activeTab === 'crm' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Active Custom Segments Panel (BLOCO 5) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-lg font-display font-bold text-slate-900">Configuração de Segmentação Comercial</h3>
              <span className="text-[10px] font-mono bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-bold uppercase">Segmentos Ativos</span>
            </div>
            
            <p className="text-xs text-slate-600">
              Crie regras inteligentes para isolar perfis de alunos e leads. Estes grupos alimentam as automações e campanhas de retargeting de forma dinâmica.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Existing segments list */}
              <div className="space-y-3">
                <span className="text-xs uppercase font-mono text-slate-400 font-bold block">Filtros de Segmentação Registrados</span>
                <div className="space-y-2 font-sans text-xs">
                  {customSegments.map((segment, idx) => (
                    <div key={idx} className="p-3 border border-slate-100 bg-slate-50 rounded flex justify-between items-center">
                      <div className="space-y-0.5">
                        <span className="font-bold text-slate-900 block">{segment.name}</span>
                        <code className="text-[10px] text-oab-accent font-mono block">{segment.query}</code>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-slate-900 block">{segment.estCount}</span>
                        <span className="text-[9px] text-slate-400 uppercase font-mono">leads estimados</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Segment Creator Form */}
              <div className="p-4 border border-slate-100 bg-slate-50/50 rounded space-y-4">
                <span className="text-xs uppercase font-mono text-slate-900 font-bold block">Criar Novo Segmento de Growth</span>
                <form onSubmit={handleAddSegment} className="space-y-3 font-sans text-xs">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 block">Nome do Segmento:</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Ex: Alunos Inativos de 2ª Fase Penal" 
                      value={newSegmentName}
                      onChange={(e) => setNewSegmentName(e.target.value)}
                      className="w-full p-2 border border-slate-200 rounded text-xs focus:ring-1 focus:ring-oab-accent outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 block">Critérios / Regra Operacional:</label>
                    <select 
                      value={newSegmentQuery}
                      onChange={(e) => setNewSegmentQuery(e.target.value)}
                      className="w-full p-2 border border-slate-200 bg-white rounded text-xs focus:ring-1 focus:ring-oab-accent outline-none"
                    >
                      <option value="funnelStage == 'gratuito_travado'">Gratuito Inativo (Sem estudar há mais de 4 dias)</option>
                      <option value="oabPhase == '2_fase' && currentPlan == 'Nenhum'">Aprovados na 1ª fase sem plano de 2ª fase</option>
                      <option value="score < 40 && funnelStage == 'premium_ativo'">Alunos Premium com baixo score de engajamento</option>
                      <option value="funnelStage == 'checkout_abandonado'">Checkout abandonado nas últimas 24 horas</option>
                    </select>
                  </div>
                  <button 
                    type="submit" 
                    className="w-full bg-[#0F172A] hover:bg-[#1E293B] text-white font-bold py-2 rounded transition-colors flex items-center justify-center space-x-1.5"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>Salvar Segmento Inteligente</span>
                  </button>
                </form>
              </div>
            </div>
          </div>

          {/* Interactive CRM Contact Grid (BLOCO 3 & 4) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div className="space-y-1">
                <h3 className="text-lg font-display font-bold text-slate-900">CRM de Leads e Alunos OAB 3F</h3>
                <p className="text-xs text-slate-600">Base unificada de contatos. Clique em um perfil para visualizar histórico acadêmico-comercial e disparar gatilhos manuais.</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-mono text-slate-400 font-bold">Pesquisa Avançada:</span>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="Nome, e-mail ou tag..."
                    value={crmSearch}
                    onChange={(e) => setCrmSearch(e.target.value)}
                    className="pl-9 pr-4 py-1.5 border border-slate-200 rounded text-xs focus:ring-1 focus:ring-oab-accent outline-none w-48 sm:w-64"
                  />
                </div>
              </div>
            </div>

            {/* Quick Filters */}
            <div className="flex flex-wrap gap-2 text-xs font-sans">
              <div className="flex items-center space-x-1 border border-slate-200 p-1 bg-slate-50/50 rounded">
                <span className="text-[10px] uppercase font-mono text-slate-400 px-1 font-bold">Estágio Funil:</span>
                <select 
                  value={crmStageFilter} 
                  onChange={(e) => setCrmStageFilter(e.target.value)}
                  className="bg-transparent font-bold text-slate-800 py-0.5 px-1 outline-none"
                >
                  <option value="todos">Todos os Estágios</option>
                  <option value="lead_novo">Lead Novo</option>
                  <option value="lead_engajado">Lead Engajado</option>
                  <option value="gratuito_ativo">Gratuito Ativo</option>
                  <option value="gratuito_travado">Gratuito Travado</option>
                  <option value="checkout_abandonado">Checkout Abandonado</option>
                  <option value="premium_ativo">Premium Ativo</option>
                  <option value="elegivel_upgrade">Elegível para Upgrade</option>
                  <option value="em_risco">Em Risco de Churn</option>
                  <option value="cancelado_recente">Cancelado / Ex-Aluno</option>
                  <option value="reativado">Reativado</option>
                </select>
              </div>

              <div className="flex items-center space-x-1 border border-slate-200 p-1 bg-slate-50/50 rounded">
                <span className="text-[10px] uppercase font-mono text-slate-400 px-1 font-bold">Fase de Interesse:</span>
                <select 
                  value={crmPhaseFilter} 
                  onChange={(e) => setCrmPhaseFilter(e.target.value)}
                  className="bg-transparent font-bold text-slate-800 py-0.5 px-1 outline-none"
                >
                  <option value="todos">Todas as Fases</option>
                  <option value="1_fase">Apenas 1ª Fase</option>
                  <option value="2_fase">Apenas 2ª Fase</option>
                  <option value="ambas">Ambas as Fases</option>
                  <option value="indefinida">Não Definida</option>
                </select>
              </div>
            </div>

            {/* CRM Contact List Table */}
            <div className="overflow-x-auto border border-slate-100 rounded">
              <table className="w-full text-left border-collapse text-xs font-sans">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100 text-[10px] uppercase font-mono text-slate-500">
                    <th className="p-3">Nome / Lead</th>
                    <th className="p-3">Fase & Interesse</th>
                    <th className="p-3">Status do Funil</th>
                    <th className="p-3">Plano Atual</th>
                    <th className="p-3 text-center">Score</th>
                    <th className="p-3">Tags</th>
                    <th className="p-3 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredContacts.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-6 text-center text-slate-400">Nenhum contato encontrado com os filtros selecionados.</td>
                    </tr>
                  ) : (
                    filteredContacts.map(c => {
                      // Formatting funnel styles
                      let badgeStyle = 'bg-slate-100 text-slate-700';
                      if (c.funnelStage === 'premium_ativo') badgeStyle = 'bg-emerald-100 text-emerald-800 border-l-2 border-emerald-500';
                      if (c.funnelStage === 'checkout_abandonado') badgeStyle = 'bg-amber-100 text-amber-800 border-l-2 border-amber-500 animate-pulse';
                      if (c.funnelStage === 'em_risco') badgeStyle = 'bg-red-100 text-red-800 border-l-2 border-red-500';
                      if (c.funnelStage === 'gratuito_travado') badgeStyle = 'bg-blue-100 text-blue-800';
                      if (c.funnelStage === 'elegivel_upgrade') badgeStyle = 'bg-purple-100 text-purple-800';

                      return (
                        <tr key={c.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-3">
                            <span className="font-bold text-slate-950 block">{c.name}</span>
                            <span className="text-[10px] text-slate-500">{c.email}</span>
                          </td>
                          <td className="p-3">
                            <span className="font-semibold text-slate-800 block">
                              {c.oabPhase === '1_fase' ? '1ª Fase' : c.oabPhase === '2_fase' ? '2ª Fase' : 'Geral'}
                            </span>
                            <span className="text-[9px] text-slate-400 uppercase font-mono block">Origem: {c.origin}</span>
                          </td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold block w-fit ${badgeStyle}`}>
                              {c.funnelStage.replace('_', ' ').toUpperCase()}
                            </span>
                          </td>
                          <td className="p-3">
                            <span className="font-semibold block">{c.currentPlan}</span>
                            <span className="text-[9px] text-slate-400 block">Modificado: {c.lastTouch}</span>
                          </td>
                          <td className="p-3 text-center">
                            <span className={`font-mono font-bold text-sm ${c.score >= 75 ? 'text-emerald-600' : c.score >= 45 ? 'text-amber-600' : 'text-red-500'}`}>
                              {c.score}
                            </span>
                          </td>
                          <td className="p-3">
                            <div className="flex flex-wrap gap-1 max-w-[200px]">
                              {c.tags.map((t, i) => (
                                <span key={i} className="bg-slate-100 text-slate-600 rounded px-1.5 py-0.5 text-[9px] font-mono">
                                  {t}
                                </span>
                              ))}
                            </div>
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => setSelectedContact(c)}
                              className="px-2.5 py-1 text-[10px] font-bold bg-[#0F172A] hover:bg-slate-800 text-white rounded transition-colors"
                            >
                              Ver Histórico
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Contact History Detail Modal (BLOCO 4 & CRM Action) */}
      {selectedContact && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 font-sans animate-fade-in" id="contact-modal-overlay">
          <div className="bg-white border border-slate-200 rounded max-w-2xl w-full p-6 space-y-6 shadow-xl relative text-left">
            <button 
              onClick={() => setSelectedContact(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-900 font-bold text-lg"
            >
              ✕
            </button>
            
            <div className="border-b border-slate-100 pb-4">
              <span className="text-[9px] uppercase font-mono bg-oab-accent/20 text-oab-accent px-2 py-0.5 rounded font-bold">Ficha de CRM OAB 3F</span>
              <h3 className="text-xl font-display font-bold text-slate-900 mt-1">{selectedContact.name}</h3>
              <p className="text-xs text-slate-500">{selectedContact.email} • {selectedContact.phone} • Membro desde {selectedContact.dateJoined}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="space-y-3">
                <span className="text-[10px] uppercase font-mono text-slate-400 font-bold block">Dados de Diagnóstico Acadêmico</span>
                <div className="space-y-1.5 p-3 bg-slate-50 border border-slate-100 rounded">
                  <div><strong>Fase OAB de Foco:</strong> {selectedContact.oabPhase === '1_fase' ? '1ª Fase' : selectedContact.oabPhase === '2_fase' ? '2ª Fase' : 'Geral'}</div>
                  {selectedContact.secondPhaseArea && <div><strong>Área Escolhida 2ª Fase:</strong> {selectedContact.secondPhaseArea}</div>}
                  <div><strong>Estágio de Funil Comercial:</strong> {selectedContact.funnelStage.replace('_', ' ').toUpperCase()}</div>
                  <div><strong>Plano do Aluno:</strong> {selectedContact.currentPlan}</div>
                  <div><strong>Engajamento Comercial:</strong> <span className="font-bold text-oab-accent">{selectedContact.score}/100</span></div>
                </div>
              </div>

              <div className="space-y-3">
                <span className="text-[10px] uppercase font-mono text-slate-400 font-bold block">Tags de Rastreamento</span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedContact.tags.map((t, idx) => (
                    <span key={idx} className="bg-slate-100 border border-slate-200 text-slate-700 px-2.5 py-1 rounded font-mono text-[10px]">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Simulated History Logs */}
            <div className="space-y-2 text-xs">
              <span className="text-[10px] uppercase font-mono text-slate-400 font-bold block">Interações e Jornada de Mensagens</span>
              <div className="space-y-2 max-h-32 overflow-y-auto border border-slate-100 p-2 rounded">
                <div className="flex items-start space-x-2 border-b border-slate-50 pb-1.5 text-[11px]">
                  <Clock className="h-3.5 w-3.5 text-slate-400 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-800">Hoje às 09:12:</span>
                    <span className="text-slate-600"> Abriu o aplicativo e acessou o cronograma adaptativo.</span>
                  </div>
                </div>
                <div className="flex items-start space-x-2 border-b border-slate-50 pb-1.5 text-[11px]">
                  <Mail className="h-3.5 w-3.5 text-emerald-500 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-800">Ontem:</span>
                    <span className="text-slate-600"> Recebeu e-mail da Régua 1 (Boas-vindas ao Método OAB 3F). Status: ABRIU.</span>
                  </div>
                </div>
                <div className="flex items-start space-x-2 text-[11px]">
                  <Send className="h-3.5 w-3.5 text-blue-500 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-800">Há 2 dias:</span>
                    <span className="text-slate-600"> Criou a conta a partir da Landing Page de Cronograma de 90 Dias.</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Direct CRM Manual Actions (BLOCO 4 & 14) */}
            <div className="border-t border-slate-100 pt-4 space-y-3">
              <span className="text-[10px] uppercase font-mono text-slate-900 font-bold block">Ações Comerciais de CRM Diretas</span>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => executeCRMAction('WhatsApp Manual de Abandono', selectedContact)}
                  className="px-3 py-1.5 text-[11px] font-bold bg-[#25D366] hover:opacity-90 text-white rounded flex items-center space-x-1"
                >
                  <MessageSquare className="h-3.5 w-3.5" />
                  <span>Chamar no WhatsApp</span>
                </button>
                <button
                  onClick={() => executeCRMAction('E-mail Customizado de Oferta', selectedContact)}
                  className="px-3 py-1.5 text-[11px] font-bold bg-slate-900 hover:bg-slate-800 text-white rounded flex items-center space-x-1"
                >
                  <Mail className="h-3.5 w-3.5" />
                  <span>Enviar E-mail de Proposta</span>
                </button>
                <button
                  onClick={() => executeCRMAction('Push de Alerta de Churn', selectedContact)}
                  className="px-3 py-1.5 text-[11px] font-bold bg-[#D4AF37] hover:bg-opacity-95 text-slate-950 rounded flex items-center space-x-1"
                >
                  <Smartphone className="h-3.5 w-3.5" />
                  <span>Disparar Push de Incentivo</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 3: RÉGUAS & AUTOMAÇÕES (BLOCO 6)
          ========================================== */}
      {activeTab === 'automation' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Automation stats banner */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 bg-[#0F172A] text-white p-5 rounded border border-slate-800 font-mono text-xs">
            <div className="space-y-1">
              <span className="text-slate-400 uppercase tracking-widest block">Automações Ativas</span>
              <p className="text-base font-bold text-oab-accent">14 Réguas Configuradas</p>
            </div>
            <div className="space-y-1">
              <span className="text-slate-400 uppercase tracking-widest block">Disparos Hoje</span>
              <p className="text-base font-bold text-white">{automationStats.sentToday} triggers</p>
            </div>
            <div className="space-y-1">
              <span className="text-slate-400 uppercase tracking-widest block">Taxa de Abertura</span>
              <p className="text-base font-bold text-emerald-400">{automationStats.openRate}</p>
            </div>
            <div className="space-y-1">
              <span className="text-slate-400 uppercase tracking-widest block">Upgrades Gerados</span>
              <p className="text-base font-bold text-[#D4AF37]">{automationStats.upgradesTriggered} assinantes</p>
            </div>
          </div>

          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-lg font-display font-bold text-slate-900 border-b border-slate-100 pb-3">
              As 14 Réguas de Comunicação & Automação de Produto
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Expanda cada régua operacional abaixo para examinar o gatilho tecnológico, o canal de comunicação ideal e a cópia exata do texto (copywriting) enviado aos estudantes.
            </p>

            {/* Core 14 Reguas Interativas accordion */}
            <div className="space-y-3 font-sans text-xs">
              {/* Régua 1 */}
              <div className="border border-slate-200 rounded overflow-hidden">
                <button
                  onClick={() => setExpandedRegua(expandedRegua === 'regua1' ? null : 'regua1')}
                  className="w-full bg-slate-50/50 p-4 text-left flex justify-between items-center font-bold text-slate-900"
                >
                  <div className="flex items-center space-x-3">
                    <span className="h-5 w-5 rounded-full bg-oab-accent/20 text-oab-accent flex items-center justify-center font-mono text-xs">01</span>
                    <span>RÉGUA 1 — Boas-Vindas ao Lead (Aquecimento Inicial)</span>
                  </div>
                  <ChevronRight className={`h-4 w-4 transition-transform ${expandedRegua === 'regua1' ? 'rotate-90' : ''}`} />
                </button>
                {expandedRegua === 'regua1' && (
                  <div className="p-4 border-t border-slate-100 bg-white space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <strong>Gatilho Acadêmico:</strong> Lead deixa dados na Landing Page para baixar material gratuito.
                      </div>
                      <div>
                        <strong>Meta Comercial:</strong> Fazer o lead criar conta e entrar no aplicativo de estudos.
                      </div>
                    </div>
                    <div className="p-3 bg-slate-50 border-l-4 border-slate-900 space-y-2">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-1.5">
                        <span className="font-bold text-slate-950 uppercase text-[10px] tracking-wider font-mono flex items-center gap-1">
                          <Mail className="h-3 w-3 text-slate-700" /> E-mail de Entrega
                        </span>
                        <button onClick={() => triggerCopyNotification('r1_email')} className="text-oab-accent font-bold hover:text-slate-950 flex items-center gap-1 text-[10px]">
                          {copiedId === 'r1_email' ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                          <span>{copiedId === 'r1_email' ? 'Copiado!' : 'Copiar Copy'}</span>
                        </button>
                      </div>
                      <p className="italic text-slate-600">
                        <strong>Assunto:</strong> Seu Cronograma Estratégico OAB está liberado (Passo 1 de 3)<br /><br />
                        Olá [Nome], aqui é o Prof. Ricardo Abreu.<br /><br />
                        Seu cronograma gratuito de estudos já está disponível. Mas atenção: o plano no papel é estático. Nós criamos uma estrutura que se ajusta aos seus erros em tempo real dentro do nosso aplicativo. Toque abaixo para ativar sua meta gratuita do Dia 1 e testar de forma prática o método OAB 3F.
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Régua 2 */}
              <div className="border border-slate-200 rounded overflow-hidden">
                <button
                  onClick={() => setExpandedRegua(expandedRegua === 'regua2' ? null : 'regua2')}
                  className="w-full bg-slate-50/50 p-4 text-left flex justify-between items-center font-bold text-slate-900"
                >
                  <div className="flex items-center space-x-3">
                    <span className="h-5 w-5 rounded-full bg-oab-accent/20 text-oab-accent flex items-center justify-center font-mono text-xs">02</span>
                    <span>RÉGUA 2 — Lead Qualificado para 1ª Fase (Conteúdo Estratégico)</span>
                  </div>
                  <ChevronRight className={`h-4 w-4 transition-transform ${expandedRegua === 'regua2' ? 'rotate-90' : ''}`} />
                </button>
                {expandedRegua === 'regua2' && (
                  <div className="p-4 border-t border-slate-100 bg-white space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <strong>Gatilho Acadêmico:</strong> Lead marca "Foco na 1ª Fase" no seu diagnóstico ou preenche perfil de interesse.
                      </div>
                      <div>
                        <strong>Meta Comercial:</strong> Vender o Plano Completo ou Plano 1ª Fase com argumento de taxa de acerto.
                      </div>
                    </div>
                    <div className="p-3 bg-slate-50 border-l-4 border-slate-900 space-y-2">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-1.5">
                        <span className="font-bold text-slate-950 uppercase text-[10px] tracking-wider font-mono flex items-center gap-1">
                          <Smartphone className="h-3 w-3 text-slate-700" /> Notificação Push
                        </span>
                        <button onClick={() => triggerCopyNotification('r2_push')} className="text-oab-accent font-bold hover:text-slate-950 flex items-center gap-1 text-[10px]">
                          {copiedId === 'r2_push' ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                          <span>{copiedId === 'r2_push' ? 'Copiado!' : 'Copiar Copy'}</span>
                        </button>
                      </div>
                      <p className="italic text-slate-600">
                        <strong>Texto:</strong> 🎯 [Nome], estas 5 regras de Ética caem SEMPRE no Exame da Ordem. Toque para ver o resumo em vídeo e garantir 4 pontos fáceis!
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Régua 3 */}
              <div className="border border-slate-200 rounded overflow-hidden">
                <button
                  onClick={() => setExpandedRegua(expandedRegua === 'regua3' ? null : 'regua3')}
                  className="w-full bg-slate-50/50 p-4 text-left flex justify-between items-center font-bold text-slate-900"
                >
                  <div className="flex items-center space-x-3">
                    <span className="h-5 w-5 rounded-full bg-oab-accent/20 text-oab-accent flex items-center justify-center font-mono text-xs">03</span>
                    <span>RÉGUA 3 — Lead Qualificado para 2ª Fase (Peça e Discursivas)</span>
                  </div>
                  <ChevronRight className={`h-4 w-4 transition-transform ${expandedRegua === 'regua3' ? 'rotate-90' : ''}`} />
                </button>
                {expandedRegua === 'regua3' && (
                  <div className="p-4 border-t border-slate-100 bg-white space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <strong>Gatilho Acadêmico:</strong> Lead informa que está na 2ª fase e seleciona a matéria jurídica específica.
                      </div>
                      <div>
                        <strong>Meta Comercial:</strong> Venda do Plano Intensivo 2ª Fase com mentoria de peças individual.
                      </div>
                    </div>
                    <div className="p-3 bg-slate-50 border-l-4 border-slate-900 space-y-2">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-1.5">
                        <span className="font-bold text-slate-950 uppercase text-[10px] tracking-wider font-mono flex items-center gap-1">
                          <Mail className="h-3 w-3 text-slate-700" /> E-mail Estruturado
                        </span>
                        <button onClick={() => triggerCopyNotification('r3_email')} className="text-oab-accent font-bold hover:text-slate-950 flex items-center gap-1 text-[10px]">
                          {copiedId === 'r3_email' ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                          <span>{copiedId === 'r3_email' ? 'Copiado!' : 'Copiar Copy'}</span>
                        </button>
                      </div>
                      <p className="italic text-slate-600">
                        <strong>Assunto:</strong> Como estruturar sua peça de [Matéria] sem errar o cabimento (Gabarito OAB)<br /><br />
                        Na 2ª fase, você não assinalará letras, mas escreverá peças prático-profissionais reais. A maior causa de reprovação é a falta de correção profissional individualizada. O nosso método exclusivo traz modelos baseados no espelho exato da FGV.
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Régua 4 */}
              <div className="border border-slate-200 rounded overflow-hidden">
                <button
                  onClick={() => setExpandedRegua(expandedRegua === 'regua4' ? null : 'regua4')}
                  className="w-full bg-slate-50/50 p-4 text-left flex justify-between items-center font-bold text-slate-900"
                >
                  <div className="flex items-center space-x-3">
                    <span className="h-5 w-5 rounded-full bg-oab-accent/20 text-oab-accent flex items-center justify-center font-mono text-xs">04</span>
                    <span>RÉGUA 4 — Abandono de Cadastro / Onboarding</span>
                  </div>
                  <ChevronRight className={`h-4 w-4 transition-transform ${expandedRegua === 'regua4' ? 'rotate-90' : ''}`} />
                </button>
                {expandedRegua === 'regua4' && (
                  <div className="p-4 border-t border-slate-100 bg-white space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <strong>Gatilho Acadêmico:</strong> Lead inicia o onboarding no app mas para no meio do cadastro de metas.
                      </div>
                      <div>
                        <strong>Meta Comercial:</strong> Concluir onboarding para liberar a conta de degustação.
                      </div>
                    </div>
                    <div className="p-3 bg-slate-50 border-l-4 border-slate-900 space-y-2">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-1.5">
                        <span className="font-bold text-slate-950 uppercase text-[10px] tracking-wider font-mono flex items-center gap-1">
                          <MessageSquare className="h-3 w-3 text-slate-700" /> WhatsApp Direct
                        </span>
                        <button onClick={() => triggerCopyNotification('r4_wa')} className="text-oab-accent font-bold hover:text-slate-950 flex items-center gap-1 text-[10px]">
                          {copiedId === 'r4_wa' ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                          <span>{copiedId === 'r4_wa' ? 'Copiado!' : 'Copiar Copy'}</span>
                        </button>
                      </div>
                      <p className="italic text-slate-600">
                        Olá [Nome], vi que você começou a configurar suas metas no OAB 3F mas parou na metade. Nós guardamos o seu progresso acadêmico. Clique aqui para concluir seu onboarding em 1 minuto e receber seu cronograma ajustado sem estresse: [Link].
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Régua 5 */}
              <div className="border border-slate-200 rounded overflow-hidden">
                <button
                  onClick={() => setExpandedRegua(expandedRegua === 'regua5' ? null : 'regua5')}
                  className="w-full bg-slate-50/50 p-4 text-left flex justify-between items-center font-bold text-slate-900"
                >
                  <div className="flex items-center space-x-3">
                    <span className="h-5 w-5 rounded-full bg-oab-accent/20 text-oab-accent flex items-center justify-center font-mono text-xs">05</span>
                    <span>RÉGUA 5 — Usuário Gratuito → Conversão Premium</span>
                  </div>
                  <ChevronRight className={`h-4 w-4 transition-transform ${expandedRegua === 'regua5' ? 'rotate-90' : ''}`} />
                </button>
                {expandedRegua === 'regua5' && (
                  <div className="p-4 border-t border-slate-100 bg-white space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <strong>Gatilho Acadêmico:</strong> Aluno gratuito conclui 3 metas diárias e tenta resolver mais questões além do limite diário de 5.
                      </div>
                      <div>
                        <strong>Meta Comercial:</strong> Induzir o upgrade para o Plano Completo com gatilho de consistência.
                      </div>
                    </div>
                    <div className="p-3 bg-slate-50 border-l-4 border-slate-900 space-y-2">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-1.5">
                        <span className="font-bold text-slate-950 uppercase text-[10px] tracking-wider font-mono flex items-center gap-1">
                          <Sparkles className="h-3 w-3 text-slate-700" /> Mensagem In-App
                        </span>
                        <button onClick={() => triggerCopyNotification('r5_inapp')} className="text-oab-accent font-bold hover:text-slate-950 flex items-center gap-1 text-[10px]">
                          {copiedId === 'r5_inapp' ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                          <span>{copiedId === 'r5_inapp' ? 'Copiado!' : 'Copiar Copy'}</span>
                        </button>
                      </div>
                      <p className="italic text-slate-600">
                        <strong>Título:</strong> Você atingiu sua meta diária de degustação gratuita!<br />
                        <strong>Mensagem:</strong> Parabéns por manter o foco! No Plano Completo, seu motor de revisões espaçadas assume o controle científico dos seus erros para bloquear a curva do esquecimento de forma automática. Toque para liberar questões e revisões ilimitadas.
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Other Reguas listed compactly for structural completeness */}
              {['RÉGUA 6 — Abandono de Checkout (Recuperação de Carrinho)',
                'RÉGUA 7 — Pós-Compra / Onboarding Premium de Boas-Vindas',
                'RÉGUA 8 — Ativação de Aluno Premium (Incentivo a Estudos Práticos)',
                'RÉGUA 9 — Retenção de Assinante (Feedback de Desempenho Regular)',
                'RÉGUA 10 — Reativação de Aluno Inativo (Resgate de Abandono)',
                'RÉGUA 11 — Migração de 1ª Fase para 2ª Fase (Upgrade Acadêmico)',
                'RÉGUA 12 — Reta Final (Urgência Saudável com Metas Rápidas)',
                'RÉGUA 13 — Renovação / Recompra de Ciclo de Assinatura',
                'RÉGUA 14 — Assinatura Expirada / Campanha de Reengajamento por Desconto'].map((title, idx) => (
                <div key={idx + 6} className="border border-slate-200 rounded overflow-hidden opacity-95">
                  <button
                    onClick={() => setExpandedRegua(expandedRegua === `regua${idx + 6}` ? null : `regua${idx + 6}`)}
                    className="w-full bg-slate-50/50 p-4 text-left flex justify-between items-center font-bold text-slate-950"
                  >
                    <div className="flex items-center space-x-3">
                      <span className="h-5 w-5 rounded-full bg-slate-200 text-slate-800 flex items-center justify-center font-mono text-xs">{String(idx + 6).padStart(2, '0')}</span>
                      <span>{title}</span>
                    </div>
                    <ChevronRight className={`h-4 w-4 transition-transform ${expandedRegua === `regua${idx + 6}` ? 'rotate-90' : ''}`} />
                  </button>
                  {expandedRegua === `regua${idx + 6}` && (
                    <div className="p-4 border-t border-slate-100 bg-white space-y-3">
                      <p className="text-xs text-slate-700">
                        <strong>Momentos e Escopo da régua comercial automatizada:</strong>
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-3 bg-slate-50 border border-slate-100 rounded text-xs text-slate-600">
                        <div>
                          <strong>Gatilho de Produto:</strong> Ativado dinamicamente pelo motor de rastreamento do aplicativo OAB 3F com base no comportamento acadêmico ou faturamento.
                        </div>
                        <div>
                          <strong>Canais Integrados:</strong> Email transactional, SMS/WhatsApp webhook, Push Notification, banners em tempo real no Dashboard.
                        </div>
                      </div>
                      <div className="p-2.5 bg-slate-100/50 rounded font-mono text-[10px] text-slate-600">
                        💡 Copy customizável acionada automaticamente para o segmento correspondente.
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 4: CAMPANHAS OAB (BLOCO 7, 8, 9, 16)
          ========================================== */}
      {activeTab === 'campaigns' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Calendar Moments Checklist (BLOCO 8) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-lg font-display font-bold text-slate-900 border-b border-slate-100 pb-3">Campanhas Estratégicas por Calendário OAB</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              O ecossistema sincroniza o momento do funil de vendas com as datas oficiais da Ordem dos Advogados do Brasil. Gerencie as ofertas baseadas no calendário oficial:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs font-sans">
              <div className="p-4 border border-slate-100 bg-slate-50 rounded space-y-2">
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">MOMENTO 1 — Preparação Prévia</span>
                <span className="font-bold text-slate-900 block text-sm">Muito Antes da Prova (D-90 a D-60)</span>
                <p className="text-slate-600">
                  Foco na entrada pelo Plano Completo de longo prazo. Isca ideal: <strong>Cronograma 90 dias</strong>.
                </p>
                <div className="p-1.5 bg-white border border-slate-200 font-mono text-[9px] text-[#D4AF37] font-bold">
                  CAMPANHA: Rota Ideal de Longo Prazo
                </div>
              </div>

              <div className="p-4 border border-slate-100 bg-slate-50 rounded space-y-2">
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">MOMENTO 2 — Funil Estratégico</span>
                <span className="font-bold text-slate-900 block text-sm">Reta Final 1ª Fase (D-30 a Véspera)</span>
                <p className="text-slate-600">
                  Foco em conversões rápidas de baixo ticket. Ofereça o <strong>Combo Reta Final OAB</strong> focado em Ética.
                </p>
                <div className="p-1.5 bg-white border border-slate-200 font-mono text-[9px] text-[#D4AF37] font-bold">
                  CAMPANHA: Operação Reta Final Ética
                </div>
              </div>

              <div className="p-4 border border-slate-100 bg-slate-50 rounded space-y-2">
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">MOMENTO 3 — Upgrade Prático</span>
                <span className="font-bold text-slate-900 block text-sm">Pós-Resultado 1ª Fase (Transição 2ªF)</span>
                <p className="text-slate-600">
                  Foco em alunos aprovados. Oferecer migração rápida para o <strong>Plano 2ª Fase com Mentoria VIP</strong>.
                </p>
                <div className="p-1.5 bg-white border border-slate-200 font-mono text-[9px] text-[#D4AF37] font-bold">
                  CAMPANHA: Transição Rumo à Carteira
                </div>
              </div>
            </div>
          </div>

          {/* Active Campaigns list (BLOCO 7) */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white p-6 border border-slate-200 shadow-sm lg:col-span-2 space-y-6">
              <h3 className="text-lg font-display font-bold text-slate-900 border-b border-slate-100 pb-3">Central de Campanhas Comerciais Ativas</h3>
              
              <div className="space-y-4 text-xs font-sans">
                {/* Campaign Item 1 */}
                <div className="p-4 border border-slate-200 bg-slate-50 rounded relative">
                  <span className="absolute top-4 right-4 bg-emerald-100 text-emerald-800 font-mono text-[9px] font-bold px-2 py-0.5 rounded">STATUS: EXECUTANDO</span>
                  <div className="flex items-center space-x-2 text-slate-900 font-bold mb-1">
                    <Megaphone className="h-4 w-4 text-oab-accent" />
                    <span>Campanha de Transição de 2ª Fase</span>
                  </div>
                  <p className="text-slate-600 text-[11px] mb-2 leading-relaxed">
                    <strong>Público:</strong> Alunos que marcaram aprovação na 1ª fase. <strong>Oferta:</strong> Desconto de 15% na Trilha Teoria + Peças Práticas + 3 correções individuais pelo time de professores titulares da OAB 3F.
                  </p>
                  <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono">
                    <span>Duração: 7 dias pós-resultado</span>
                    <span>Conversão Alvo: 35%</span>
                  </div>
                </div>

                {/* Campaign Item 2 */}
                <div className="p-4 border border-slate-200 bg-slate-50 rounded relative">
                  <span className="absolute top-4 right-4 bg-amber-100 text-amber-800 font-mono text-[9px] font-bold px-2 py-0.5 rounded">STATUS: AGENDADA</span>
                  <div className="flex items-center space-x-2 text-slate-900 font-bold mb-1">
                    <Megaphone className="h-4 w-4 text-oab-accent" />
                    <span>Campanha Reta Final VIP (Ética Extrema)</span>
                  </div>
                  <p className="text-slate-600 text-[11px] mb-2 leading-relaxed">
                    <strong>Público:</strong> Alunos em ritmo gratuito faltavam 15 dias para o Exame. <strong>Oferta:</strong> Plano Reta Final com apostilas esquematizadas de véspera por apenas R$ 147.
                  </p>
                  <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono">
                    <span>Disparo em: 10 dias</span>
                    <span>Conversão Alvo: 20%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Launch Checklist Panel (BLOCO 16) */}
            <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
              <div className="border-b border-slate-100 pb-3">
                <span className="text-[10px] font-mono text-slate-400 block uppercase">Operações Promocionais</span>
                <h3 className="text-base font-display font-bold text-slate-900">Checklist de Lançamento</h3>
              </div>

              <div className="space-y-4 font-sans text-xs">
                <div className="p-3 bg-amber-500/10 text-amber-950 rounded flex justify-between items-center font-mono text-[11px]">
                  <span>Abertura do Carrinho em:</span>
                  <span className="font-bold animate-pulse">{launchCountdown}</span>
                </div>

                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-mono text-slate-400 font-bold block">Tarefas de Lançamento Ativas</span>
                  <div className="space-y-2">
                    {preLaunchChecklist.map((item, idx) => (
                      <div 
                        key={idx} 
                        onClick={() => toggleChecklistTask(idx)}
                        className="flex items-center space-x-2 p-2 bg-slate-50 border border-slate-100 rounded hover:bg-slate-100 cursor-pointer transition-colors"
                      >
                        <input 
                          type="checkbox" 
                          checked={item.done} 
                          onChange={() => {}} // handled by parent click
                          className="rounded accent-oab-accent" 
                        />
                        <span className={`text-[11px] ${item.done ? 'line-through text-slate-400' : 'text-slate-700 font-semibold'}`}>
                          {item.task}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 5: CHECKOUT & RETENÇÃO (BLOCO 10, 11, 12, 18)
          ========================================== */}
      {activeTab === 'retention' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Lead Magnets list (BLOCO 12) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-lg font-display font-bold text-slate-900 border-b border-slate-100 pb-3">Iscas Digitais & Entradas Gratuitas (Alimentação Funil)</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Estes materiais servem como imãs de captação de leads. Ao baixar o arquivo, o lead é inserido no CRM com a tag correspondente e inicia a régua automática de conversão.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 font-sans text-xs">
              {LEAD_MAGNETS.map(magnet => (
                <div key={magnet.id} className="p-4 bg-slate-50 border border-slate-100 rounded space-y-3 relative">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="bg-slate-200 text-slate-800 text-[9px] font-bold font-mono uppercase px-1.5 py-0.5 rounded">
                        {magnet.type}
                      </span>
                      <h4 className="font-bold text-slate-950 mt-1.5">{magnet.title}</h4>
                    </div>
                  </div>
                  <div className="space-y-1 text-slate-600 text-[11px] leading-relaxed">
                    <div><strong>Alvo de Captação:</strong> {magnet.target}</div>
                    <div><strong>Próxima Oferta de Fluxo:</strong> <span className="text-oab-accent font-semibold">{magnet.offer}</span></div>
                    <div className="flex justify-between border-t border-slate-100 pt-2 text-[10px] font-mono mt-2">
                      <span>Leads Gerados: <strong>{magnet.leadsCount}</strong></span>
                      <span>Conversão LP: <strong>{magnet.conversion}</strong></span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Checkout Recovery & Profiling (BLOCO 10 & 18) */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Checkout Recovery Rules */}
            <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
              <h3 className="text-base font-display font-bold text-slate-900 border-b border-slate-100 pb-2">Sistema de Recuperação de Checkout Abandonado</h3>
              <p className="text-xs text-slate-600">Lógica estruturada para identificar e converter pessoas que abandonaram o carrinho de compras:</p>

              <div className="space-y-3 font-sans text-xs">
                <div className="p-3 bg-slate-50 border-l-4 border-amber-500 rounded-r">
                  <span className="font-bold text-slate-900 block mb-0.5">Etapa 1: Notificação Push de Checkout Abandonado (15 minutos após)</span>
                  <p className="text-slate-600 text-[11px] italic">"Ficou alguma dúvida, [Nome]? Garanta seu plano de estudos OAB 3F com segurança e dê o primeiro passo hoje. Toque para restaurar seu carrinho."</p>
                </div>
                <div className="p-3 bg-slate-50 border-l-4 border-amber-500 rounded-r">
                  <span className="font-bold text-slate-900 block mb-0.5">Etapa 2: E-mail com Quebra de Objeções (2 horas após)</span>
                  <p className="text-slate-600 text-[11px] italic">"Assunto: Não arrisque outro Exame da OAB, [Nome]...<br />O OAB 3F se ajusta à sua rotina real. Se o problema é preço, dividimos em até 12x no cartão. Clique para recuperar."</p>
                </div>
                <div className="p-3 bg-slate-50 border-l-4 border-amber-500 rounded-r">
                  <span className="font-bold text-slate-900 block mb-0.5">Etapa 3: WhatsApp Comercial Manual / Cupom Especial (24 horas após)</span>
                  <p className="text-slate-600 text-[11px] italic">"Olá [Nome], sou a consultora acadêmica do OAB 3F. Liberamos um cupom de 10% válido apenas para hoje no plano completo. Posso ativar para você?"</p>
                </div>
              </div>
            </div>

            {/* Targeted Messaging Profiles (BLOCO 18) */}
            <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
              <h3 className="text-base font-display font-bold text-slate-900 border-b border-slate-100 pb-2">Linha de Mensagens Comerciais por Perfil</h3>
              <p className="text-xs text-slate-600">Personalize o tom de acordo com o status psicológico do estudante:</p>

              <div className="space-y-4 font-sans text-xs">
                <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                  <span className="font-bold text-slate-950 block">Bacharel Sem Tempo / Conciliando Trabalho:</span>
                  <p className="text-slate-600 text-[11px] mt-1 leading-relaxed">
                    <strong>Argumento Comercial:</strong> "Não estude por doutrinas longas. Nosso método prioriza 15 minutos de micro-aulas fáceis pareadas com o Vade Mecum prático."
                  </p>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                  <span className="font-bold text-slate-950 block">Estudante Traumatizado / Reprovado Anteriormente:</span>
                  <p className="text-slate-600 text-[11px] mt-1 leading-relaxed">
                    <strong>Argumento Comercial:</strong> "O erro no simulado reconstrói o aprovado. Nosso banco de dados rastreia o ponto cego para você não cometer a mesma falha na prova."
                  </p>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                  <span className="font-bold text-slate-950 block">Aprovado Reta Final (Foco em Ética):</span>
                  <p className="text-slate-600 text-[11px] mt-1 leading-relaxed">
                    <strong>Argumento Comercial:</strong> "Ética corresponde a 20% dos pontos necessários. Garanta sua aprovação focando nos artigos do Estatuto com maior recorrência histórica."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 6: INTEGRAÇÃO & GOVERNANÇA (BLOCO 13, 14, 19)
          ========================================== */}
      {activeTab === 'governance' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Data integrations flow chart (BLOCO 13) */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-lg font-display font-bold text-slate-900 border-b border-slate-100 pb-3">Arquitetura de Integração e Fluxo de Dados</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              O ecossistema comercial é totalmente integrado às áreas internas do app de forma serverless. Veja como as informações trafegam em tempo real:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 text-center font-mono text-[10px] text-slate-700">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded flex flex-col justify-between h-32">
                <span className="font-bold uppercase text-slate-400">1. Entrada</span>
                <span className="text-slate-800 text-xs font-sans font-bold">Landing Pages & Iscas</span>
                <p className="text-[9px] text-slate-500 font-sans leading-tight">Captura UTM, e-mail e telefone do lead.</p>
              </div>

              <div className="flex items-center justify-center font-bold text-oab-accent">➔</div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded flex flex-col justify-between h-32">
                <span className="font-bold uppercase text-slate-400">2. Qualificação</span>
                <span className="text-slate-800 text-xs font-sans font-bold">Onboarding & Diagnóstico</span>
                <p className="text-[9px] text-slate-500 font-sans leading-tight">Estudante seleciona Fase e matéria preferida.</p>
              </div>

              <div className="flex items-center justify-center font-bold text-oab-accent">➔</div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded flex flex-col justify-between h-32">
                <span className="font-bold uppercase text-slate-400">3. Rastreamento</span>
                <span className="text-slate-800 text-xs font-sans font-bold">Métrica & Performance</span>
                <p className="text-[9px] text-slate-500 font-sans leading-tight">Rastreia inatividade de estudo ou queda na média.</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Tag Standardization List (BLOCO 19) */}
            <div className="bg-white p-6 border border-slate-200 shadow-sm lg:col-span-2 space-y-6">
              <h3 className="text-base font-display font-bold text-slate-900 border-b border-slate-100 pb-2">Padronização de Tags & Governança de CRM</h3>
              <p className="text-xs text-slate-600">Regras oficiais de nomenclaturas para garantir relatórios confiáveis e evitar erros de sobreposição de emails:</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans text-xs">
                <div className="p-3 bg-slate-50 border border-slate-100 rounded space-y-1.5">
                  <span className="font-bold text-slate-900 block font-mono text-[11px]">Tags de Origem (LP / Campanhas)</span>
                  <ul className="space-y-1 list-disc list-inside text-slate-600 text-[11px]">
                    <li><code className="text-oab-accent bg-slate-100 px-1 font-mono text-[10px]">origem:ads_insta</code> — Cadastro por anúncio</li>
                    <li><code className="text-oab-accent bg-slate-100 px-1 font-mono text-[10px]">isca:cronograma</code> — Baixou o cronograma grátis</li>
                    <li><code className="text-oab-accent bg-slate-100 px-1 font-mono text-[10px]">origem:aula_yt</code> — Entrou por link do YouTube</li>
                  </ul>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-100 rounded space-y-1.5">
                  <span className="font-bold text-slate-900 block font-mono text-[11px]">Tags de Comportamento Acadêmico</span>
                  <ul className="space-y-1 list-disc list-inside text-slate-600 text-[11px]">
                    <li><code className="text-oab-accent bg-slate-100 px-1 font-mono text-[10px]">status:inativo_5dias</code> — Sem atividade</li>
                    <li><code className="text-oab-accent bg-slate-100 px-1 font-mono text-[10px]">alerta:baixo_acerto</code> — Taxa de acerto &lt; 45%</li>
                    <li><code className="text-oab-accent bg-slate-100 px-1 font-mono text-[10px]">revisao:acumulada</code> — Mais de 5 revisões pendentes</li>
                  </ul>
                </div>
              </div>

              {/* Frequency Caps */}
              <div className="p-4 bg-amber-500/5 border border-amber-500/10 text-amber-900 text-[11px] rounded leading-relaxed">
                <strong>Regra de Saturação de Comunicação (Frequência Máxima):</strong><br />
                Para proteger o aluno contra spam e ansiedade acadêmica, o sistema bloqueia disparos de marketing caso o lead tenha recebido mais de 1 e-mail promocional ou 1 mensagem de WhatsApp nas últimas 48 horas. Notificações transacionais pedagógicas de cronograma diário continuam ativas normalmente.
              </div>
            </div>

            {/* Live Operational Audit Logs (BLOCO 19) */}
            <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
              <h3 className="text-base font-display font-bold text-slate-900 border-b border-slate-100 pb-2">Log de Operações Comerciais</h3>
              <p className="text-xs text-slate-600">Registro histórico das últimas ações geradas automaticamente ou por administradores:</p>

              <div className="space-y-2.5 font-sans text-xs max-h-60 overflow-y-auto pr-1">
                {operationLogs.map((log, idx) => (
                  <div key={idx} className="p-2 border border-slate-100 bg-slate-50 rounded flex justify-between items-start text-[11px]">
                    <div className="space-y-0.5">
                      <span className="font-bold text-slate-800 block">{log.action}</span>
                      <span className="text-slate-500">Destino: {log.target}</span>
                    </div>
                    <div className="text-right">
                      <span className="bg-slate-200 text-slate-700 text-[9px] font-mono font-bold px-1 py-0.5 rounded uppercase block w-fit ml-auto mb-1">
                        {log.type}
                      </span>
                      <span className="text-slate-400 font-mono block">{log.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer Design Concept */}
      <div className="border-t border-slate-200 pt-6 mt-12 text-center text-xs text-slate-400 font-mono flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
        <span>© 2026 OAB 3F — Operação Comercial & Growth Engine</span>
        <span>Aprovação Jurídica Estruturada com Alta Performance</span>
      </div>
    </div>
  );
}
