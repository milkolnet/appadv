/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Award,
  Scale,
  CheckCircle,
  FileText,
  AlertTriangle,
  ChevronDown,
  ChevronRight,
  BookOpen,
  Eye,
  ArrowRight,
  Edit,
  Save,
  CheckSquare,
  Clock,
  Play,
  Pause,
  RotateCcw,
  TrendingUp,
  HelpCircle,
  History,
  User,
  Bookmark,
  BookmarkCheck,
  Settings,
  AlertCircle,
  Activity,
  CheckSquare2,
  Trash2,
  Lock
} from 'lucide-react';
import { StudentProgress, JuridicalPiece, SimulatedResult } from '../types';
import {
  PHASE2_LEGAL_AREAS,
  PHASE2_MODULES,
  PHASE2_PIECES_BY_AREA,
  PHASE2_DISCURSIVES_BY_AREA,
  PHASE2_SIMULADOS_BY_AREA,
  Phase2Piece,
  Phase2Discursive,
  Phase2Simulado
} from '../data/phase2Data';

interface Phase2Props {
  progress: StudentProgress;
  pieces: JuridicalPiece[];
  onSelectArea: (area: string) => void;
  onSavePieceNote: (pieceId: string, note: string) => void;
  onAddSimulatedResult: (result: SimulatedResult) => void;
  onSaveActivity: (tab: string, title: string, sectionId?: string, itemId?: string) => void;
  userPlan?: string;
  onNavigateToTab?: (tab: string) => void;
}

export default function Phase2({
  progress,
  pieces,
  onSelectArea,
  onSavePieceNote,
  onAddSimulatedResult,
  onSaveActivity,
  userPlan = 'gratuito',
  onNavigateToTab
}: Phase2Props) {
  // Current active legal area
  const [activeArea, setActiveArea] = useState<string>(() => {
    return progress.selectedSecondPhaseArea || "Direito do Trabalho";
  });

  // Section Tabs (Dashboard is now the default hub!)
  const [activeSection, setActiveSection] = useState<'dashboard' | 'trilha' | 'pecas' | 'discursivas' | 'simulador' | 'revisao' | 'desempenho'>('dashboard');

  // Persistence of study states
  const [pieceStatuses, setPieceStatuses] = useState<{ [key: string]: 'Pendente' | 'Estudando' | 'Revisado' }>(() => {
    const saved = localStorage.getItem('oab3f_fase2_piece_statuses');
    return saved ? JSON.parse(saved) : {};
  });

  const [discursiveStatuses, setDiscursiveStatuses] = useState<{ [key: string]: 'Pendente' | 'Respondida' }>(() => {
    const saved = localStorage.getItem('oab3f_fase2_discursive_statuses');
    return saved ? JSON.parse(saved) : {};
  });

  const [completedMilestones, setCompletedMilestones] = useState<string[]>(() => {
    const saved = localStorage.getItem('oab3f_fase2_milestones');
    return saved ? JSON.parse(saved) : [];
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('oab3f_fase2_favorites');
    return saved ? JSON.parse(saved) : [];
  });

  // Active pieces database for selected area
  const areaPieces = PHASE2_PIECES_BY_AREA[activeArea] || [];
  const [selectedPieceId, setSelectedPieceId] = useState<string>('');

  useEffect(() => {
    if (areaPieces.length > 0) {
      setSelectedPieceId(areaPieces[0].id);
    }
  }, [activeArea]);

  const selectedPiece = areaPieces.find(p => p.id === selectedPieceId) || areaPieces[0];

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('oab3f_fase2_piece_statuses', JSON.stringify(pieceStatuses));
  }, [pieceStatuses]);

  useEffect(() => {
    localStorage.setItem('oab3f_fase2_discursive_statuses', JSON.stringify(discursiveStatuses));
  }, [discursiveStatuses]);

  useEffect(() => {
    localStorage.setItem('oab3f_fase2_milestones', JSON.stringify(completedMilestones));
  }, [completedMilestones]);

  useEffect(() => {
    localStorage.setItem('oab3f_fase2_favorites', JSON.stringify(favorites));
  }, [favorites]);

  // Notes state
  const [userNote, setUserNote] = useState('');
  useEffect(() => {
    if (selectedPiece) {
      setUserNote(progress.notes[selectedPiece.id] || '');
    }
  }, [selectedPieceId, progress.notes]);

  // Discursive states
  const areaDiscursives = PHASE2_DISCURSIVES_BY_AREA[activeArea] || [];
  const [activeDiscursiveId, setActiveDiscursiveId] = useState<string>('');
  useEffect(() => {
    if (areaDiscursives.length > 0) {
      setActiveDiscursiveId(areaDiscursives[0].id);
    }
  }, [activeArea]);

  const activeDiscursive = areaDiscursives.find(q => q.id === activeDiscursiveId) || areaDiscursives[0];
  const [discursiveDraft, setDiscursiveDraft] = useState('');
  const [showDiscursiveKey, setShowDiscursiveKey] = useState(false);

  useEffect(() => {
    setDiscursiveDraft('');
    setShowDiscursiveKey(false);
  }, [activeDiscursiveId]);

  // Simulator states
  const areaSimulados = PHASE2_SIMULADOS_BY_AREA[activeArea] || [];
  const [activeSimuladoId, setActiveSimuladoId] = useState<string>('');
  useEffect(() => {
    if (areaSimulados.length > 0) {
      setActiveSimuladoId(areaSimulados[0].id);
    }
  }, [activeArea]);

  const activeSimulado = areaSimulados.find(s => s.id === activeSimuladoId) || areaSimulados[0];

  // Simulation timer
  const [isExamRunning, setIsExamRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(18000); // 5 hours in seconds
  const [simPieceDraft, setSimPieceDraft] = useState('');
  const [simQuestionsDrafts, setSimQuestionsDrafts] = useState<string[]>(['', '', '', '']);
  const [isSubmittingSim, setIsSubmittingSim] = useState(false);
  const [simResultFeedback, setSimResultFeedback] = useState<SimulatedResult | null>(null);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isExamRunning && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isExamRunning) {
      setIsExamRunning(false);
      handleAutoSubmitExam();
    }
    return () => clearInterval(timer);
  }, [isExamRunning, timeLeft]);

  // Format stopwatch time
  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Calculations for Progress metrics
  const totalPiecesCount = areaPieces.length;
  const piecesStudiedCount = areaPieces.filter(p => pieceStatuses[p.id] === 'Estudando' || pieceStatuses[p.id] === 'Revisado').length;
  const piecesRevisadasCount = areaPieces.filter(p => pieceStatuses[p.id] === 'Revisado').length;

  const totalDiscursivesCount = areaDiscursives.length;
  const discursivesAnsweredCount = areaDiscursives.filter(q => discursiveStatuses[q.id] === 'Respondida').length;

  const totalMilestonesCount = PHASE2_MODULES.reduce((sum, mod) => sum + mod.milestones.length, 0);
  const milestonesCompletedCount = completedMilestones.length;

  // General Phase 2 percentage
  const overallPercentage = Math.round(
    ((piecesStudiedCount * 2 + piecesRevisadasCount + discursivesAnsweredCount * 3 + milestonesCompletedCount) /
      (totalPiecesCount * 3 + totalDiscursivesCount * 3 + totalMilestonesCount)) * 100
  ) || 0;

  // Average performance
  const areaSimHistory = progress.simulatedExamsHistory.filter(h => h.type === '2a Fase');
  const averageSimScore = areaSimHistory.length > 0
    ? (areaSimHistory.reduce((sum, item) => sum + item.score, 0) / areaSimHistory.length).toFixed(1)
    : '7.5'; // Default starting benchmark

  // Handle area change
  const handleAreaChange = (area: string) => {
    setActiveArea(area);
    onSelectArea(area);
    onSaveActivity('2ª Fase', `Mudança de área jurídica: ${area}`);
  };

  // Toggle favorite
  const handleToggleFav = (id: string) => {
    setFavorites(prev =>
      prev.includes(id) ? prev.filter(fId => fId !== id) : [...prev, id]
    );
  };

  // Update piece status
  const updatePieceStatus = (pieceId: string, status: 'Pendente' | 'Estudando' | 'Revisado') => {
    setPieceStatuses(prev => ({ ...prev, [pieceId]: status }));
    onSaveActivity('2ª Fase', `Status da peça alterado para ${status}`, 'piece-' + pieceId);
  };

  // Milestone toggler
  const handleToggleMilestone = (milestoneId: string) => {
    setCompletedMilestones(prev =>
      prev.includes(milestoneId) ? prev.filter(m => m !== milestoneId) : [...prev, milestoneId]
    );
  };

  // Save notes handler
  const handleSaveNote = () => {
    if (selectedPiece) {
      onSavePieceNote(selectedPiece.id, userNote);
      onSaveActivity('2ª Fase', `Anotações atualizadas na peça: ${selectedPiece.title}`);
      alert('Anotações salvas com sucesso!');
    }
  };

  // Submit discursive draft
  const handleMarkDiscursiveAsSolved = () => {
    if (activeDiscursive) {
      setDiscursiveStatuses(prev => ({ ...prev, [activeDiscursive.id]: 'Respondida' }));
      onSaveActivity('2ª Fase', `Respondeu questão discursiva: ${activeDiscursive.title}`);
      alert('Questão marcada como Respondida! Seu progresso foi atualizado.');
    }
  };

  // Action: Continuing where left off
  const handleContinueStudy = () => {
    const pendingPiece = areaPieces.find(p => !pieceStatuses[p.id]);
    if (pendingPiece) {
      setSelectedPieceId(pendingPiece.id);
      setActiveSection('pecas');
    } else {
      setActiveSection('trilha');
    }
  };

  // Simulator Start
  const handleStartExam = () => {
    if (confirm('Deseja iniciar o simulado cronometrado de 5 horas? O cronômetro começará a rodar.')) {
      setTimeLeft(18000);
      setIsExamRunning(true);
      setSimPieceDraft('');
      setSimQuestionsDrafts(['', '', '', '']);
      setSimResultFeedback(null);
      setActiveSection('simulador');
    }
  };

  // Auto submit when time runs out
  const handleAutoSubmitExam = () => {
    setIsExamRunning(false);
    alert('O tempo esgotou! Seu simulado foi enviado automaticamente para correção estatística.');
    processExamGrading();
  };

  // Trigger manual submit
  const handleManualSubmitExam = () => {
    if (confirm('Tem certeza de que deseja finalizar o simulado e enviar para correção?')) {
      setIsExamRunning(false);
      processExamGrading();
    }
  };

  // Simulated grading logic
  const processExamGrading = () => {
    setIsSubmittingSim(true);
    setTimeout(() => {
      // Calculate grade out of 10
      let pieceScore = 2.0; // Starts with baseline
      let questionsScore = 1.0;

      // Analyze piece draft keyword coverage
      const pieceKeywords = ['excelentíssimo', 'reclamante', 'reclamada', 'fato', 'direito', 'pedido', 'art', 'artigo', 'oab', 'vossa excelência'];
      const pieceHits = pieceKeywords.filter(k => simPieceDraft.toLowerCase().includes(k)).length;
      pieceScore += (pieceHits / pieceKeywords.length) * 3.5; // Max 5.5 points

      // Analyze questions drafts keyword coverage
      let questionsHitsCount = 0;
      simQuestionsDrafts.forEach(draft => {
        const questionKeywords = ['art', 'artigo', 'lei', 'súmula', 'portanto', 'porque', 'direto'];
        questionsHitsCount += questionKeywords.filter(k => draft.toLowerCase().includes(k)).length;
      });
      questionsScore += (questionsHitsCount / 28) * 3.5; // Max 4.5 points

      const finalScore = parseFloat(Math.min(10, pieceScore + questionsScore).toFixed(2));
      const percentage = Math.round(finalScore * 10);

      const passed = finalScore >= 6.0;

      const newSimRes: SimulatedResult = {
        id: "sim-p2-" + Date.now(),
        title: activeSimulado ? activeSimulado.title : `Simulado Prático - ${activeArea}`,
        type: '2a Fase',
        date: new Date().toISOString().split('T')[0],
        score: finalScore,
        total: 10,
        percentage,
        timeSpentMinutes: Math.round((18000 - timeLeft) / 60),
        feedback: passed
          ? `PARABÉNS! Você foi aprovado no simulado da 2ª Fase com nota ${finalScore}/10.0 (Mínimo exigido: 6.0). Sua estrutura jurídica está muito bem desenvolvida. Continue revisando os detalhes formais para garantir nota máxima!`
          : `Rendimento de ${finalScore}/10.0. Você ficou abaixo do mínimo de 6.0 exigido na prova discursiva da OAB. Recomendamos praticar mais a fundamentação baseada em artigos e certificar-se de preencher todos os pedidos do checklist oficial.`
      };

      onAddSimulatedResult(newSimRes);
      setSimResultFeedback(newSimRes);
      setIsSubmittingSim(false);
      onSaveActivity('2ª Fase', `Fez simulado prático, nota: ${finalScore}`);
    }, 1500);
  };

  const isPremiumUnlocked = userPlan === 'fase2' || userPlan === 'completo' || userPlan === 'vip';

  return (
    <div className="relative" id="phase2-wrapper">
      {/* If not unlocked, render a crisp, premium card centered in the viewport */}
      {!isPremiumUnlocked && (
        <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-md z-30 flex items-center justify-center p-4 sm:p-6 lg:p-12">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-xl w-full overflow-hidden animate-scale-in text-center p-8 space-y-6">
            <div className="w-14 h-14 bg-amber-100 text-[#D4AF37] rounded-full flex items-center justify-center mx-auto shadow-inner">
              <Lock className="h-7 w-7" />
            </div>
            
            <div className="space-y-2">
              <span className="bg-[#D4AF37] text-slate-900 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full font-mono">
                RECURSO PREMIUM OAB 3F
              </span>
              <h3 className="font-serif font-black text-2xl text-slate-900">
                Desbloqueie a Trilha da 2ª Fase OAB
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed max-w-md mx-auto">
                A 2ª Fase do Exame de Ordem exige preparação cirúrgica. Domine a estruturação de peças jurídicas, redija discursivas de alta pontuação e treine simulados práticos oficiais na sua área escolhida ({activeArea}).
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-2.5 text-left text-xs max-w-md mx-auto">
              <span className="font-bold text-slate-700 block uppercase tracking-wider text-[10px]">O que você recebe ao assinar:</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-600">
                <span className="block font-medium">• Peças Práticas completas</span>
                <span className="block font-medium">• Cronograma de 2ª Fase</span>
                <span className="block font-medium">• Discursivas Comentadas</span>
                <span className="block font-medium">• Simulados de 5 Horas</span>
                <span className="block font-medium">• Checklists de autocorreção</span>
                <span className="block font-medium">• Suporte e Correções VIP</span>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row justify-center gap-3 max-w-md mx-auto">
              {onNavigateToTab && (
                <button
                  onClick={() => onNavigateToTab('monetizacao')}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-6 py-3 rounded-lg text-xs tracking-wider uppercase transition-all shadow-md cursor-pointer flex-1"
                >
                  Ver Planos de Assinatura
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Main content, blurred if not unlocked */}
      <div className={`space-y-8 animate-fadeIn ${!isPremiumUnlocked ? 'filter blur-xs pointer-events-none select-none h-screen overflow-hidden' : ''}`} id="phase2-workspace">
      
      {/* 1. Header & Dynamic Legal Area Select */}
      <div className="bg-white border border-slate-200 p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <div className="flex items-center space-x-2.5">
            <span className="h-2 w-2 rounded-full bg-oab-accent"></span>
            <span className="font-mono text-xs uppercase tracking-widest text-slate-400">Preparação de Elite</span>
          </div>
          <h1 className="font-serif text-3xl font-bold text-oab-primary tracking-tight mt-1">
            Estudos de 2ª Fase
          </h1>
          <p className="text-xs text-slate-500 mt-1.5 max-w-xl">
            Sua trilha especializada para a prova prática. Altere a área escolhida no menu ao lado para personalizar todo o conteúdo de peças e simulados.
          </p>
        </div>

        <div className="flex items-center space-x-3 bg-slate-50 border border-slate-200 p-3 self-stretch md:self-auto">
          <Scale className="h-5 w-5 text-oab-accent shrink-0" />
          <div className="flex-1">
            <span className="block text-[10px] font-mono text-slate-400 uppercase">Área Prática de Foco</span>
            <select
              value={activeArea}
              onChange={(e) => handleAreaChange(e.target.value)}
              className="text-xs font-serif font-semibold text-oab-primary bg-transparent focus:outline-none cursor-pointer pr-4"
              id="select-active-area-p2"
            >
              {PHASE2_LEGAL_AREAS.map(area => (
                <option key={area} value={area}>{area}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* 2. Horizontal navigation menu bar */}
      <div className="border-b border-slate-200 flex overflow-x-auto scrollbar-none gap-2" id="phase2-navigation-menu">
        <button
          onClick={() => setActiveSection('dashboard')}
          className={`py-3 px-5 text-xs font-mono tracking-wider uppercase border-b-2 cursor-pointer transition-all shrink-0 ${
            activeSection === 'dashboard' ? 'border-oab-accent text-oab-primary font-bold' : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
          id="btn-nav-p2-dashboard"
        >
          Início
        </button>
        <button
          onClick={() => setActiveSection('trilha')}
          className={`py-3 px-5 text-xs font-mono tracking-wider uppercase border-b-2 cursor-pointer transition-all shrink-0 ${
            activeSection === 'trilha' ? 'border-oab-accent text-oab-primary font-bold' : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
          id="btn-nav-p2-trilha"
        >
          Trilha de Aprendizado
        </button>
        <button
          onClick={() => setActiveSection('pecas')}
          className={`py-3 px-5 text-xs font-mono tracking-wider uppercase border-b-2 cursor-pointer transition-all shrink-0 ${
            activeSection === 'pecas' ? 'border-oab-accent text-oab-primary font-bold' : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
          id="btn-nav-p2-pecas"
        >
          Biblioteca de Peças ({totalPiecesCount})
        </button>
        <button
          onClick={() => setActiveSection('discursivas')}
          className={`py-3 px-5 text-xs font-mono tracking-wider uppercase border-b-2 cursor-pointer transition-all shrink-0 ${
            activeSection === 'discursivas' ? 'border-oab-accent text-oab-primary font-bold' : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
          id="btn-nav-p2-discursivas"
        >
          Questões Discursivas ({totalDiscursivesCount})
        </button>
        <button
          onClick={() => setActiveSection('simulador')}
          className={`py-3 px-5 text-xs font-mono tracking-wider uppercase border-b-2 cursor-pointer transition-all shrink-0 ${
            activeSection === 'simulador' ? 'border-oab-accent text-oab-primary font-bold' : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
          id="btn-nav-p2-simulador"
        >
          Simulador Oficial
        </button>
        <button
          onClick={() => setActiveSection('revisao')}
          className={`py-3 px-5 text-xs font-mono tracking-wider uppercase border-b-2 cursor-pointer transition-all shrink-0 ${
            activeSection === 'revisao' ? 'border-oab-accent text-oab-primary font-bold' : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
          id="btn-nav-p2-revisao"
        >
          Revisões
        </button>
        <button
          onClick={() => setActiveSection('desempenho')}
          className={`py-3 px-5 text-xs font-mono tracking-wider uppercase border-b-2 cursor-pointer transition-all shrink-0 ${
            activeSection === 'desempenho' ? 'border-oab-accent text-oab-primary font-bold' : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
          id="btn-nav-p2-desempenho"
        >
          Painel de Notas
        </button>
      </div>

      {/* 3. Section Router */}

      {/* SECTION A: DASHBOARD INÍCIO */}
      {activeSection === 'dashboard' && (
        <div className="space-y-6" id="p2-dashboard">
          
          {/* Main welcome banner with statistics */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Card Left: Welcome & Primary Call To Action */}
            <div className="lg:col-span-2 bg-oab-primary text-white p-6 flex flex-col justify-between border border-oab-primary relative overflow-hidden">
              <div className="space-y-4">
                <span className="font-mono text-[10px] text-oab-accent uppercase tracking-widest bg-slate-800 px-2.5 py-1 inline-block">
                  Área selecionada: {activeArea}
                </span>
                <h2 className="font-serif text-2xl font-bold leading-tight">
                  Bem-vindo à sua Oficina de Peças e Discursivas
                </h2>
                <p className="text-xs text-slate-300 leading-relaxed max-w-lg">
                  Estude as peças mais recorrentes de {activeArea}, aprenda a estruturar preliminares de defesa e prepare-se com simulados em tempo real de 5 horas.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center gap-4 mt-8">
                <button
                  onClick={handleContinueStudy}
                  className="bg-oab-accent hover:bg-yellow-500 text-oab-primary font-mono text-xs font-bold py-3 px-5 cursor-pointer transition-all flex items-center justify-center space-x-1"
                >
                  <span>Continuar Estudos</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
                <div className="text-xs text-slate-400 flex items-center justify-center sm:justify-start">
                  <Clock className="h-4 w-4 mr-1 text-oab-accent" />
                  <span>Sugerido hoje: Módulo 3 — Peças Práticas</span>
                </div>
              </div>
            </div>

            {/* Card Right: Overall Progress gauge */}
            <div className="bg-white border border-slate-200 p-6 flex flex-col justify-between">
              <div>
                <h3 className="font-mono text-xs uppercase text-slate-400 tracking-wider">Seu Progresso de 2ª Fase</h3>
                <div className="mt-4 flex items-baseline space-x-2">
                  <span className="font-serif text-4xl font-extrabold text-oab-primary">{overallPercentage}%</span>
                  <span className="text-xs text-slate-400">concluído</span>
                </div>
              </div>

              {/* Progress bar and small metrics */}
              <div className="space-y-3 mt-6">
                <div className="w-full bg-slate-100 h-1">
                  <div className="bg-oab-accent h-1" style={{ width: `${overallPercentage}%` }}></div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-100">
                  <div>
                    <span className="block text-[10px] font-mono text-slate-400 uppercase">Peças Estudadas</span>
                    <span className="text-sm font-serif font-bold text-oab-primary">{piecesStudiedCount} / {totalPiecesCount}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-mono text-slate-400 uppercase">Discursivas Feitas</span>
                    <span className="text-sm font-serif font-bold text-oab-primary">{discursivesAnsweredCount} / {totalDiscursivesCount}</span>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Next Recommended elements row */}
          <div className="space-y-4">
            <h3 className="font-serif text-lg font-bold text-oab-primary flex items-center">
              <Activity className="h-5 w-5 mr-2 text-oab-accent" />
              Próximos passos recomendados para hoje
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Step 1: Peça */}
              <div className="bg-white border border-slate-200 p-5 flex flex-col justify-between hover:border-oab-accent transition-all group">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-400 uppercase bg-slate-50 px-2 py-0.5 border border-slate-200">Recomendado</span>
                    <Scale className="h-4.5 w-4.5 text-slate-400 group-hover:text-oab-accent transition-colors" />
                  </div>
                  <h4 className="text-sm font-serif font-bold text-oab-primary">
                    {areaPieces[0] ? areaPieces[0].title : "Modelagem de Peças"}
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Aprenda a fundamentação jurídica de mérito e pedidos formais essenciais.
                  </p>
                </div>
                <button
                  onClick={() => {
                    if (areaPieces[0]) setSelectedPieceId(areaPieces[0].id);
                    setActiveSection('pecas');
                  }}
                  className="mt-4 text-xs font-mono font-bold text-oab-accent hover:text-oab-primary cursor-pointer transition-colors flex items-center self-start"
                >
                  <span>Estudar Peça</span>
                  <ChevronRight className="h-4 w-4 ml-0.5" />
                </button>
              </div>

              {/* Step 2: Discursiva */}
              <div className="bg-white border border-slate-200 p-5 flex flex-col justify-between hover:border-oab-accent transition-all group">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-400 uppercase bg-slate-50 px-2 py-0.5 border border-slate-200">Discursiva</span>
                    <FileText className="h-4.5 w-4.5 text-slate-400 group-hover:text-oab-accent transition-colors" />
                  </div>
                  <h4 className="text-sm font-serif font-bold text-oab-primary">
                    {areaDiscursives[0] ? areaDiscursives[0].theme : "Treino de Teses"}
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Escreva seu rascunho de fundamentação para treinar as palavras-chave do espelho.
                  </p>
                </div>
                <button
                  onClick={() => {
                    if (areaDiscursives[0]) setActiveDiscursiveId(areaDiscursives[0].id);
                    setActiveSection('discursivas');
                  }}
                  className="mt-4 text-xs font-mono font-bold text-oab-accent hover:text-oab-primary cursor-pointer transition-colors flex items-center self-start"
                >
                  <span>Praticar Questão</span>
                  <ChevronRight className="h-4 w-4 ml-0.5" />
                </button>
              </div>

              {/* Step 3: Simulado */}
              <div className="bg-white border border-slate-200 p-5 flex flex-col justify-between hover:border-oab-accent transition-all group">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-400 uppercase bg-slate-50 px-2 py-0.5 border border-slate-200">Simulado</span>
                    <Clock className="h-4.5 w-4.5 text-slate-400 group-hover:text-oab-accent transition-colors" />
                  </div>
                  <h4 className="text-sm font-serif font-bold text-oab-primary">
                    {areaSimulados[0] ? areaSimulados[0].title : "Simulado Geral"}
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Responda à peça e a 4 discursivas sob cronômetro de 5 horas.
                  </p>
                </div>
                <button
                  onClick={handleStartExam}
                  className="mt-4 text-xs font-mono font-bold text-oab-accent hover:text-oab-primary cursor-pointer transition-colors flex items-center self-start"
                >
                  <span>Iniciar Simulado</span>
                  <ChevronRight className="h-4 w-4 ml-0.5" />
                </button>
              </div>

            </div>
          </div>

          {/* Quick Metrics Dashboard Summary Grid */}
          <div className="bg-slate-50 border border-slate-200 p-6">
            <h3 className="font-mono text-xs uppercase text-slate-400 tracking-wider mb-4">Resumo Geral de Desempenho</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="space-y-1">
                <span className="block text-[10px] font-mono text-slate-400 uppercase">Peças Estudadas</span>
                <span className="font-serif text-2xl font-bold text-oab-primary">{piecesStudiedCount}</span>
                <p className="text-[10px] text-slate-400">{piecesRevisadasCount} marcadas como revisadas</p>
              </div>
              <div className="space-y-1">
                <span className="block text-[10px] font-mono text-slate-400 uppercase">Discursivas Feitas</span>
                <span className="font-serif text-2xl font-bold text-oab-primary">{discursivesAnsweredCount}</span>
                <p className="text-[10px] text-slate-400">De um total de {totalDiscursivesCount} disponíveis</p>
              </div>
              <div className="space-y-1">
                <span className="block text-[10px] font-mono text-slate-400 uppercase">Simulados Feitos</span>
                <span className="font-serif text-2xl font-bold text-oab-primary">{areaSimHistory.length}</span>
                <p className="text-[10px] text-slate-400">Na área de {activeArea}</p>
              </div>
              <div className="space-y-1">
                <span className="block text-[10px] font-mono text-slate-400 uppercase">Média Simulados</span>
                <span className="font-serif text-2xl font-bold text-oab-accent">{averageSimScore} / 10</span>
                <p className="text-[10px] text-slate-400">Média geral das notas finais</p>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* SECTION B: TRILHA DE ESTUDOS */}
      {activeSection === 'trilha' && (
        <div className="space-y-6" id="p2-trilha-modules">
          <div>
            <h2 className="font-serif text-2xl font-bold text-oab-primary">Trilha de Aprendizado de 2ª Fase</h2>
            <p className="text-xs text-slate-500 mt-1">
              Siga os módulos estruturais de estudo para cobrir de ponta a ponta todo o edital de {activeArea}.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Timeline track */}
            <div className="lg:col-span-8 space-y-6">
              {PHASE2_MODULES.map((mod, index) => {
                const isCompleted = mod.milestones.every(m => completedMilestones.includes(`${mod.id}-${m}`));
                return (
                  <div key={mod.id} className="bg-white border border-slate-200 p-5 flex flex-col md:flex-row gap-4 relative">
                    {/* Left circle number icon */}
                    <div className="flex md:flex-col items-center justify-center shrink-0">
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center font-mono text-xs font-bold ${
                        isCompleted ? 'bg-emerald-50 text-emerald-600 border border-emerald-200' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {index + 1}
                      </div>
                    </div>

                    {/* Module info and milestones checklist */}
                    <div className="flex-1 space-y-3">
                      <div>
                        <h3 className="font-serif text-base font-bold text-oab-primary">{mod.title}</h3>
                        <p className="text-xs text-slate-500 leading-relaxed mt-1">{mod.description}</p>
                      </div>

                      <div className="bg-slate-50 border border-slate-200 p-3 space-y-2">
                        <span className="block text-[9px] font-mono text-slate-400 uppercase tracking-wider">Metas e Atividades:</span>
                        <div className="space-y-2">
                          {mod.milestones.map((milestone) => {
                            const milestoneKey = `${mod.id}-${milestone}`;
                            const isMileDone = completedMilestones.includes(milestoneKey);
                            return (
                              <label key={milestone} className="flex items-center space-x-2.5 text-xs text-slate-600 cursor-pointer select-none">
                                <input
                                  type="checkbox"
                                  checked={isMileDone}
                                  onChange={() => handleToggleMilestone(milestoneKey)}
                                  className="rounded border-slate-300 text-oab-accent focus:ring-oab-accent h-4 w-4"
                                />
                                <span className={isMileDone ? 'line-through text-slate-400' : ''}>{milestone}</span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Sidebar Stats and checklist details */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-white border border-slate-200 p-5 space-y-4">
                <h3 className="font-mono text-xs uppercase text-slate-400 tracking-wider">Metas da Trilha</h3>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-xs text-slate-600">
                    <span>Atividades Concluídas</span>
                    <span className="font-bold text-oab-primary">{milestonesCompletedCount} de {totalMilestonesCount}</span>
                  </div>
                  <div className="w-full bg-slate-100 h-1">
                    <div className="bg-oab-accent h-1" style={{ width: `${(milestonesCompletedCount / totalMilestonesCount) * 100}%` }}></div>
                  </div>
                </div>

                <div className="p-3 bg-amber-50/50 border border-amber-100 text-xs text-amber-800 rounded">
                  <span className="font-bold flex items-center mb-1">
                    <AlertTriangle className="h-4 w-4 mr-1 shrink-0" />
                    Como usar esta trilha:
                  </span>
                  Cada módulo representa um ciclo semanal de estudos de 2ª fase. Marque os marcos à medida que estuda o material associado.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION C: BIBLIOTECA DE PEÇAS */}
      {activeSection === 'pecas' && (
        <div className="space-y-6" id="p2-pieces-library">
          <div>
            <h2 className="font-serif text-2xl font-bold text-oab-primary">Biblioteca de Peças Prático-Profissionais</h2>
            <p className="text-xs text-slate-500 mt-1">
              Consulte os esqueletos formais das peças exigidas pela FGV na área de {activeArea}, juntamente com os pedidos essenciais e checklists de autocorreção.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Sidebar list of pieces */}
            <div className="lg:col-span-4 space-y-3">
              <h3 className="font-mono text-xs uppercase text-slate-400 tracking-wider">Peças para {activeArea}</h3>
              <div className="space-y-2">
                {areaPieces.map((piece) => {
                  const isSelected = piece.id === selectedPieceId;
                  const isStarred = favorites.includes(piece.id);
                  const status = pieceStatuses[piece.id] || 'Pendente';
                  return (
                    <div
                      key={piece.id}
                      onClick={() => setSelectedPieceId(piece.id)}
                      className={`p-4 border cursor-pointer transition-all flex justify-between items-center ${
                        isSelected ? 'bg-oab-primary text-white border-oab-primary shadow-sm' : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-center space-x-2">
                          <span className={`h-1.5 w-1.5 rounded-full ${
                            status === 'Revisado' ? 'bg-emerald-500' : status === 'Estudando' ? 'bg-amber-500' : 'bg-slate-300'
                          }`}></span>
                          <h4 className="text-xs font-serif font-bold truncate">{piece.title}</h4>
                        </div>
                        <span className={`block text-[9px] font-mono ${isSelected ? 'text-slate-300' : 'text-slate-400'}`}>
                          Prioridade: {piece.importance}
                        </span>
                      </div>

                      <div className="flex items-center space-x-2 shrink-0">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleFav(piece.id);
                          }}
                          className={`p-1 hover:scale-110 transition-transform ${isSelected ? 'text-oab-accent' : 'text-slate-400 hover:text-slate-600'}`}
                        >
                          {isStarred ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Main piece browser page layout */}
            <div className="lg:col-span-8">
              {selectedPiece ? (
                <div className="bg-white border border-slate-200 p-6 space-y-6">
                  
                  {/* Item Header Banner */}
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between border-b border-slate-100 pb-4 gap-4">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-mono text-[9px] bg-slate-100 text-slate-500 px-2 py-0.5 uppercase border border-slate-200">
                          {selectedPiece.importance} Importância
                        </span>
                        {favorites.includes(selectedPiece.id) && (
                          <span className="text-[10px] text-oab-accent flex items-center font-bold">
                            <BookmarkCheck className="h-3 w-3 mr-0.5" /> Favorita
                          </span>
                        )}
                      </div>
                      <h3 className="font-serif text-xl font-bold text-oab-primary mt-1">{selectedPiece.title}</h3>
                      <p className="text-[10px] text-slate-400 mt-0.5">Área: {selectedPiece.area}</p>
                    </div>

                    <div className="flex items-center space-x-2 self-stretch sm:self-auto">
                      <select
                        value={pieceStatuses[selectedPiece.id] || 'Pendente'}
                        onChange={(e) => updatePieceStatus(selectedPiece.id, e.target.value as any)}
                        className="text-xs font-semibold text-slate-600 bg-slate-50 border border-slate-200 p-1.5 focus:outline-none cursor-pointer"
                      >
                        <option value="Pendente">Marcar como Pendente</option>
                        <option value="Estudando">Marcar como Estudando</option>
                        <option value="Revisado">Marcar como Concluído / Revisado</option>
                      </select>
                    </div>
                  </div>

                  {/* Technical Information tabs content */}
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-mono text-xs uppercase text-slate-400 tracking-wider mb-2">Cabimento da Peça</h4>
                      <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 border border-slate-200 p-3">
                        {selectedPiece.cabimento}
                      </p>
                    </div>

                    <div>
                      <h4 className="font-mono text-xs uppercase text-slate-400 tracking-wider mb-2">Esqueleto / Estrutura Processual</h4>
                      <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 border border-slate-200 p-3 whitespace-pre-line">
                        {selectedPiece.estrutura}
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <h4 className="font-mono text-xs uppercase text-slate-400 tracking-wider">Passo a Passo de Redação</h4>
                        <ul className="list-decimal list-inside text-xs text-slate-600 space-y-1 bg-slate-50/50 p-3 border border-slate-200">
                          {selectedPiece.passoAPasso.map((p, idx) => (
                            <li key={idx} className="leading-relaxed">{p}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="space-y-2">
                        <h4 className="font-mono text-xs uppercase text-slate-400 tracking-wider">Fundamentos de Direito Principais</h4>
                        <ul className="list-disc list-inside text-xs text-slate-600 space-y-1 bg-slate-50/50 p-3 border border-slate-200">
                          {selectedPiece.fundamentos.map((f, idx) => (
                            <li key={idx} className="leading-relaxed font-mono text-[11px]">{f}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-mono text-xs uppercase text-slate-400 tracking-wider mb-2">Pedidos Recomendados</h4>
                        <ul className="list-disc list-inside text-xs text-slate-600 space-y-1 bg-slate-50/50 p-3 border border-slate-200">
                          {selectedPiece.pedidos.map((p, idx) => (
                            <li key={idx} className="leading-relaxed">{p}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-rose-50 border border-rose-100 p-3 space-y-1.5">
                        <h4 className="font-mono text-xs uppercase text-rose-800 font-bold flex items-center">
                          <AlertCircle className="h-4 w-4 mr-1 shrink-0 text-rose-600" />
                          Erros Fatais (Zera na Prova)
                        </h4>
                        <ul className="list-disc list-inside text-[11px] text-rose-700 space-y-1">
                          {selectedPiece.errosFatais.map((e, idx) => (
                            <li key={idx} className="leading-relaxed">{e}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Commented template display */}
                    <div className="space-y-2">
                      <h4 className="font-mono text-xs uppercase text-slate-400 tracking-wider">Esqueleto de Redação e Peça Exemplo</h4>
                      <div className="bg-slate-900 text-slate-200 p-4 font-mono text-[11px] leading-relaxed overflow-y-auto max-h-72 border border-slate-800 whitespace-pre-wrap">
                        {selectedPiece.template}
                      </div>
                    </div>

                    {/* Resources section: Notes box */}
                    <div className="bg-slate-50 border border-slate-200 p-4 space-y-3">
                      <h4 className="font-mono text-xs uppercase text-slate-400 tracking-wider">Suas Anotações de Estudo</h4>
                      <div className="flex gap-3">
                        <textarea
                          value={userNote}
                          onChange={(e) => setUserNote(e.target.value)}
                          placeholder="Anote artigos quentes, teses ou regras de competência que você tem dificuldade de memorizar..."
                          className="flex-1 text-xs border border-slate-200 bg-white p-2.5 focus:outline-none focus:ring-1 focus:ring-oab-accent font-serif"
                          rows={3}
                          id="textarea-p2-piece-notes"
                        />
                        <button
                          onClick={handleSaveNote}
                          className="bg-oab-primary hover:bg-slate-800 text-white font-mono text-xs font-bold px-4 cursor-pointer transition-colors flex flex-col items-center justify-center shrink-0"
                        >
                          <Save className="h-4 w-4 mb-1" />
                          <span>Salvar</span>
                        </button>
                      </div>
                    </div>

                    {/* Golden Tips box */}
                    <div className="bg-amber-50 border border-amber-200 p-4 text-xs text-amber-800 space-y-1.5">
                      <span className="font-serif font-bold block text-amber-950">Dicas Práticas da Banca:</span>
                      <ul className="list-disc list-inside space-y-1 text-slate-700">
                        {selectedPiece.tips.map((t, idx) => (
                          <li key={idx} className="leading-relaxed">{t}</li>
                        ))}
                      </ul>
                    </div>

                  </div>
                </div>
              ) : (
                <div className="text-center py-16 bg-white border border-slate-200 text-slate-400">
                  Nenhuma peça selecionada para visualização técnica.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SECTION D: QUESTÕES DISCURSIVAS */}
      {activeSection === 'discursivas' && (
        <div className="space-y-6" id="p2-discursives">
          <div>
            <h2 className="font-serif text-2xl font-bold text-oab-primary">Questões Discursivas Práticas</h2>
            <p className="text-xs text-slate-500 mt-1">
              Pratique a escrita sintética baseada em sílabas legais. Escreva no rascunho de resposta e confira o espelho de pontuação do edital da FGV.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* List of discursives */}
            <div className="lg:col-span-4 space-y-3">
              <h3 className="font-mono text-xs uppercase text-slate-400 tracking-wider">Questões da Prova</h3>
              <div className="space-y-2">
                {areaDiscursives.map((q) => {
                  const isSelected = q.id === activeDiscursiveId;
                  const isDone = discursiveStatuses[q.id] === 'Respondida';
                  return (
                    <div
                      key={q.id}
                      onClick={() => setActiveDiscursiveId(q.id)}
                      className={`p-4 border cursor-pointer transition-all flex flex-col justify-between ${
                        isSelected ? 'bg-oab-primary text-white border-oab-primary' : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className={`h-1.5 w-1.5 rounded-full ${isDone ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
                          <h4 className="text-xs font-serif font-bold truncate">{q.theme}</h4>
                        </div>
                        <span className={`block text-[9px] font-mono ${isSelected ? 'text-slate-300' : 'text-slate-400'}`}>
                          Dificuldade: {q.difficulty} • 1.25 pt
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Interactive Answer workspace */}
            <div className="lg:col-span-8">
              {activeDiscursive ? (
                <div className="bg-white border border-slate-200 p-6 space-y-6">
                  
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div>
                      <h3 className="font-serif text-lg font-bold text-oab-primary">{activeDiscursive.title}</h3>
                      <span className="text-[10px] font-mono text-slate-400">Tema: {activeDiscursive.theme}</span>
                    </div>
                    <span className="text-xs font-mono font-bold text-oab-accent">1.25 pontos</span>
                  </div>

                  {/* Statement box */}
                  <div className="bg-slate-50 border border-slate-200 p-4 font-serif text-xs leading-relaxed text-slate-800">
                    {activeDiscursive.statement}
                  </div>

                  {/* Write rascunho workspace */}
                  <div className="space-y-2">
                    <label className="block text-[10px] font-mono text-slate-400 uppercase">Seu Rascunho de Resposta Técnica (Gabarito do Aluno)</label>
                    <textarea
                      value={discursiveDraft}
                      onChange={(e) => setDiscursiveDraft(e.target.value)}
                      placeholder="Redija aqui sua resposta fundamentada de forma objetiva, sempre indicando os artigos de lei e justificativa de forma expressa..."
                      className="w-full text-xs font-serif border border-slate-200 p-3.5 focus:outline-none focus:ring-1 focus:ring-oab-accent"
                      rows={6}
                      id="textarea-p2-discursive-draft"
                    />
                    <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
                      <span>Mínimo sugerido: 100 caracteres</span>
                      <span>Total digitado: {discursiveDraft.length} caracteres</span>
                    </div>
                  </div>

                  {/* Buttons */}
                  <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-4">
                    <button
                      onClick={handleMarkDiscursiveAsSolved}
                      className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-mono text-xs font-bold py-2 px-4 cursor-pointer transition-colors"
                    >
                      Marcar como Concluída
                    </button>

                    <button
                      onClick={() => setShowDiscursiveKey(!showDiscursiveKey)}
                      className="bg-oab-primary hover:bg-slate-800 text-white font-mono text-xs font-bold py-2.5 px-5 cursor-pointer transition-colors flex items-center justify-center space-x-1"
                    >
                      <Eye className="h-4 w-4" />
                      <span>{showDiscursiveKey ? 'Esconder Espelho de Correção' : 'Revelar Espelho FGV'}</span>
                    </button>
                  </div>

                  {/* Grading criteria key box */}
                  {showDiscursiveKey && (
                    <div className="bg-emerald-50 border border-emerald-200 p-5 space-y-4 animate-fadeIn">
                      <div>
                        <span className="font-mono text-[9px] bg-emerald-100 text-emerald-800 px-2 py-0.5 uppercase tracking-wide inline-block">
                          Espelho Oficial de Pontuação
                        </span>
                        <h4 className="font-serif text-sm font-bold text-emerald-950 mt-1">Como pontuar no edital</h4>
                      </div>

                      <div className="text-xs text-slate-700 space-y-3 leading-relaxed">
                        <div className="bg-white/60 p-3.5 border border-emerald-200 font-serif">
                          <span className="font-bold block text-emerald-900 mb-1">Gabarito Esperado:</span>
                          {activeDiscursive.espelhoCorrecao}
                        </div>

                        <div className="space-y-1.5">
                          <span className="font-bold block text-emerald-900">Teses principais exigidas:</span>
                          <ul className="list-disc list-inside space-y-1">
                            {activeDiscursive.expectedTeses.map((t, idx) => (
                              <li key={idx} className="text-slate-600 leading-relaxed font-mono text-[11.5px]">{t}</li>
                            ))}
                          </ul>
                        </div>

                        <div className="p-3 bg-amber-50 text-amber-900 text-xs border border-amber-200">
                          <span className="font-bold block mb-1">Comentários do Professor OAB 3F:</span>
                          <p className="text-slate-700 leading-relaxed font-serif">{activeDiscursive.professorObservations}</p>
                        </div>
                      </div>
                    </div>
                  )}

                </div>
              ) : (
                <div className="text-center py-16 bg-white border border-slate-200 text-slate-400">
                  Nenhuma questão discursiva disponível.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SECTION E: SIMULADOR OFICIAL */}
      {activeSection === 'simulador' && (
        <div className="space-y-6" id="p2-simulator">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="font-serif text-2xl font-bold text-oab-primary">Simulador de Sessão Real de Prova</h2>
              <p className="text-xs text-slate-500 mt-1">
                Realize um simulado completo com a estrutura de {activeArea} sob contagem regressiva regulamentar de 5 horas.
              </p>
            </div>

            {isExamRunning && (
              <div className="bg-rose-50 border border-rose-200 p-3.5 flex items-center space-x-3 text-rose-800 self-stretch sm:self-auto">
                <Clock className="h-5 w-5 text-rose-600 shrink-0 animate-pulse" />
                <div>
                  <span className="block text-[9px] font-mono uppercase text-rose-600">Tempo de Prova Restante</span>
                  <span className="text-sm font-mono font-bold tracking-wider">{formatTime(timeLeft)}</span>
                </div>
              </div>
            )}
          </div>

          {!isExamRunning && !simResultFeedback ? (
            <div className="bg-white border border-slate-200 p-6 space-y-6 text-center max-w-xl mx-auto">
              <div className="mx-auto h-12 w-12 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center">
                <Clock className="h-6 w-6 text-oab-accent" />
              </div>
              <div className="space-y-2">
                <h3 className="font-serif text-lg font-bold text-oab-primary">Instruções do Simulado Real OAB</h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  O simulado é composto por 1 Peça Prático-Profissional (5.0 pontos) e 4 Questões Discursivas (1.25 pontos cada, somando 5.0 pontos). Sua nota final será calculada estatisticamente de acordo com a presença de palavras-chave estruturais de lei e jurisprudência.
                </p>
              </div>

              <div className="p-3 bg-slate-50 text-xs text-slate-600 text-left border border-slate-200">
                <strong>Simulado Disponível:</strong> {activeSimulado ? activeSimulado.title : `Simulado Padrão ${activeArea}`}
              </div>

              <button
                onClick={handleStartExam}
                className="bg-oab-primary hover:bg-slate-800 text-white font-mono text-xs font-bold py-3 px-6 cursor-pointer transition-colors"
              >
                Começar Cronômetro e Simulado
              </button>
            </div>
          ) : null}

          {/* Active Simulating environment */}
          {isExamRunning && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="p2-active-simulation">
              
              {/* Left pane: Scenario and questions description */}
              <div className="lg:col-span-4 space-y-6 overflow-y-auto max-h-[800px] pr-2">
                
                {/* Simulated piece box */}
                <div className="bg-white border border-slate-200 p-4 space-y-3">
                  <span className="text-[9px] font-mono bg-slate-50 text-slate-400 px-2 py-0.5 border border-slate-200 uppercase inline-block">
                    Peça Prática (5,0 pts)
                  </span>
                  <h3 className="font-serif text-sm font-bold text-oab-primary">Caso Fático Proposto:</h3>
                  <p className="text-xs text-slate-700 leading-relaxed font-serif bg-slate-50 p-3.5 border border-slate-150">
                    {activeSimulado ? activeSimulado.pecaEnunciado : "Enunciado fático descritivo para redação profissional."}
                  </p>
                </div>

                {/* Simulated questions box */}
                <div className="bg-white border border-slate-200 p-4 space-y-4">
                  <span className="text-[9px] font-mono bg-slate-50 text-slate-400 px-2 py-0.5 border border-slate-200 uppercase inline-block">
                    Questões Discursivas (5,0 pts)
                  </span>
                  
                  {activeSimulado && activeSimulado.questoesEnunciados.map((qText, qIdx) => (
                    <div key={qIdx} className="space-y-1.5 border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                      <span className="text-[10px] font-mono text-slate-400 uppercase font-bold">Questão {qIdx + 1} (1.25 pt)</span>
                      <p className="text-xs text-slate-700 leading-relaxed font-serif">{qText}</p>
                    </div>
                  ))}
                </div>

              </div>

              {/* Right pane: Professional Draft Text editors */}
              <div className="lg:col-span-8 space-y-6">
                <div className="bg-white border border-slate-200 p-5 space-y-5">
                  
                  {/* Tabs within simulator (Piece vs Discursive writing sheets) */}
                  <div className="border-b border-slate-100 pb-3">
                    <h3 className="font-serif text-base font-bold text-oab-primary">Folha de Respostas Digital OAB</h3>
                  </div>

                  <div className="space-y-4">
                    {/* Piece Editor */}
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-mono text-slate-400 uppercase">
                        Folha de Resposta — Redação da Peça Prática (Máximo 150 linhas)
                      </label>
                      <textarea
                        value={simPieceDraft}
                        onChange={(e) => setSimPieceDraft(e.target.value)}
                        placeholder="EXCELENTÍSSIMO SENHOR DOUTOR JUIZ..."
                        className="w-full font-mono text-xs border border-slate-200 p-4 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-oab-accent min-h-[350px] leading-relaxed"
                        id="textarea-sim-piece-draft"
                      />
                    </div>

                    {/* Discursive Editors */}
                    <div className="space-y-4 pt-4 border-t border-slate-100">
                      <h4 className="font-mono text-xs uppercase text-slate-400 tracking-wider">Folha de Resposta — Questões Discursivas</h4>
                      
                      {[0, 1, 2, 3].map((idx) => (
                        <div key={idx} className="space-y-1.5">
                          <label className="block text-[10px] font-mono text-slate-400 uppercase">
                            Espaço de Resposta — Questão {idx + 1} (Máximo 30 linhas)
                          </label>
                          <textarea
                            value={simQuestionsDrafts[idx]}
                            onChange={(e) => {
                              const val = e.target.value;
                              setSimQuestionsDrafts(prev => {
                                const copy = [...prev];
                                copy[idx] = val;
                                return copy;
                              });
                            }}
                            placeholder={`Escreva a resposta da Questão ${idx + 1} aqui...`}
                            className="w-full font-serif text-xs border border-slate-200 p-3 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-oab-accent"
                            rows={3}
                          />
                        </div>
                      ))}
                    </div>

                    {/* Submit footer banner */}
                    <div className="flex justify-between items-center pt-4 border-t border-slate-100">
                      <span className="text-[10px] font-mono text-slate-400">
                        OAB 3F garante salvamento automático local em segundo plano.
                      </span>

                      <button
                        onClick={handleManualSubmitExam}
                        className="bg-rose-600 hover:bg-rose-700 text-white font-mono text-xs font-bold py-2.5 px-5 cursor-pointer transition-colors"
                      >
                        Enviar Prova para Correção
                      </button>
                    </div>

                  </div>

                </div>
              </div>

            </div>
          )}

          {/* Simulation Feedback Result box */}
          {simResultFeedback && (
            <div className="bg-slate-50 border border-slate-200 p-6 max-w-2xl mx-auto space-y-4">
              <div className="flex items-center space-x-3 border-b border-slate-200 pb-3">
                <CheckCircle className="h-6 w-6 text-emerald-500 shrink-0" />
                <div>
                  <h3 className="font-serif text-lg font-bold text-oab-primary">Avaliação de Simulado Concluída</h3>
                  <span className="text-[10px] font-mono text-slate-400">Enviado em {simResultFeedback.date}</span>
                </div>
              </div>

              {/* Score Display Card */}
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-white p-3 border border-slate-150">
                  <span className="block text-[9px] font-mono text-slate-400 uppercase">Nota Final</span>
                  <span className={`text-2xl font-serif font-extrabold block ${
                    simResultFeedback.score >= 6.0 ? 'text-emerald-600' : 'text-rose-600'
                  }`}>{simResultFeedback.score}</span>
                  <span className="text-[9px] text-slate-400">Mínimo: 6,0</span>
                </div>

                <div className="bg-white p-3 border border-slate-150">
                  <span className="block text-[9px] font-mono text-slate-400 uppercase">Porcentagem</span>
                  <span className="text-2xl font-serif font-bold text-oab-primary block">{simResultFeedback.percentage}%</span>
                  <span className="text-[9px] text-slate-400">Aproveitamento</span>
                </div>

                <div className="bg-white p-3 border border-slate-150">
                  <span className="block text-[9px] font-mono text-slate-400 uppercase">Tempo de Prova</span>
                  <span className="text-2xl font-serif font-bold text-oab-primary block">{simResultFeedback.timeSpentMinutes}</span>
                  <span className="text-[9px] text-slate-400">Minutos despendidos</span>
                </div>
              </div>

              {/* Feedback text */}
              <div className="bg-white border border-slate-200 p-4 space-y-2">
                <span className="block text-[10px] font-mono text-slate-400 uppercase">Comentários da Mesa de Banca</span>
                <p className="text-xs text-slate-600 leading-relaxed font-serif whitespace-pre-wrap">
                  {simResultFeedback.feedback}
                </p>
              </div>

              <div className="flex justify-end space-x-3 pt-3">
                <button
                  onClick={() => setSimResultFeedback(null)}
                  className="bg-oab-primary hover:bg-slate-800 text-white font-mono text-xs font-bold py-2 px-4 cursor-pointer transition-colors"
                >
                  Novo Treinamento de Prova
                </button>
              </div>
            </div>
          )}

        </div>
      )}

      {/* SECTION F: REVISÕES */}
      {activeSection === 'revisao' && (
        <div className="space-y-6" id="p2-revision">
          <div>
            <h2 className="font-serif text-2xl font-bold text-oab-primary">Revisões Urgentes e Súmulas Quentes</h2>
            <p className="text-xs text-slate-500 mt-1">
              Revise as peças marcadas em estudo e leia as súmulas/artigos de lei cruciais que a banca OAB costuma cobrar de forma recorrente.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Urgent Items Left column */}
            <div className="lg:col-span-8 space-y-6">
              
              {/* Pieces currently marked as "Estudando" */}
              <div className="bg-white border border-slate-200 p-5 space-y-4">
                <h3 className="font-serif text-base font-bold text-oab-primary flex items-center">
                  <Activity className="h-5 w-5 mr-2 text-oab-accent" />
                  Peças Técnicas em Processo de Memorização
                </h3>

                {areaPieces.filter(p => pieceStatuses[p.id] === 'Estudando').length === 0 ? (
                  <p className="text-xs text-slate-400 py-2 leading-relaxed">
                    Nenhuma peça marcada &quot;Em Estudo&quot;. Adicione peças na Biblioteca de Peças para que elas constem neste painel de revisão rápida!
                  </p>
                ) : (
                  <div className="space-y-3">
                    {areaPieces.filter(p => pieceStatuses[p.id] === 'Estudando').map((piece) => (
                      <div key={piece.id} className="flex justify-between items-center p-3.5 bg-slate-50 border border-slate-200 rounded">
                        <div className="space-y-1">
                          <h4 className="text-xs font-serif font-bold text-oab-primary">{piece.title}</h4>
                          <span className="text-[10px] font-mono text-slate-400">Importância: {piece.importance}</span>
                        </div>
                        <button
                          onClick={() => {
                            setSelectedPieceId(piece.id);
                            setActiveSection('pecas');
                          }}
                          className="bg-white border border-slate-200 text-slate-700 font-mono text-[10px] font-bold py-1.5 px-3 hover:bg-slate-50 cursor-pointer transition-colors"
                        >
                          Revisar Agora
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Urgent legislation */}
              <div className="bg-white border border-slate-200 p-5 space-y-4">
                <h3 className="font-serif text-base font-bold text-oab-primary">Artigos Quentes e Súmulas Quentes da Área</h3>
                <div className="space-y-3">
                  <div className="p-3 bg-amber-50 border border-amber-100 rounded">
                    <span className="font-mono text-[10px] text-amber-800 font-bold block uppercase mb-1">Súmula Recorrente</span>
                    <p className="text-xs text-slate-700 leading-relaxed font-serif">
                      Verifique no seu Vade Mecum as remissões cruzadas de súmulas do STF e STJ relativas à competência territorial de {activeArea}. A banca zera preliminares de inadequação territorial!
                    </p>
                  </div>

                  <div className="p-3 bg-amber-50 border border-amber-100 rounded">
                    <span className="font-mono text-[10px] text-amber-800 font-bold block uppercase mb-1">Regra de Competência Principal</span>
                    <p className="text-xs text-slate-700 leading-relaxed font-serif">
                      Lembre-se: em {activeArea}, o endereçamento incorreto da petição inicial ou recurso reduz até 0.5 pontos diretamente do espelho estrutural da peça. Marque os códigos de competência com abas.
                    </p>
                  </div>
                </div>
              </div>

            </div>

            {/* Revision stats and recommendations sidebar */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-white border border-slate-200 p-5 space-y-4">
                <h3 className="font-mono text-xs uppercase text-slate-400 tracking-wider">Itens de Checklists Pendentes</h3>
                
                <div className="space-y-3 text-xs text-slate-600">
                  <div className="flex justify-between items-center">
                    <span>Peças Revisadas</span>
                    <span className="font-bold text-oab-primary">{piecesRevisadasCount} de {totalPiecesCount}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Metas Pendentes</span>
                    <span className="font-bold text-slate-500">{totalMilestonesCount - milestonesCompletedCount}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION G: DESEMPENHO */}
      {activeSection === 'desempenho' && (
        <div className="space-y-6" id="p2-performance">
          <div>
            <h2 className="font-serif text-2xl font-bold text-oab-primary">Painel de Desempenho e Notas</h2>
            <p className="text-xs text-slate-500 mt-1">
              Monitore suas notas registradas nos simulados de 2ª Fase de {activeArea} e visualize seu crescimento estrutural.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Simulation History list */}
            <div className="lg:col-span-8 space-y-6">
              <div className="bg-white border border-slate-200 p-5 space-y-4">
                <h3 className="font-serif text-base font-bold text-oab-primary">Histórico de Simulados de 2ª Fase</h3>

                {areaSimHistory.length === 0 ? (
                  <p className="text-xs text-slate-400 py-4 leading-relaxed">
                    Nenhum resultado registrado ainda para {activeArea}. Acesse a aba &quot;Simulador Oficial&quot; e faça seu primeiro treinamento sob relógio para gerar estatísticas!
                  </p>
                ) : (
                  <div className="space-y-3">
                    {areaSimHistory.map((item) => {
                      const passed = item.score >= 6.0;
                      return (
                        <div key={item.id} className="p-4 bg-slate-50 border border-slate-200 rounded flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                          <div className="space-y-1">
                            <h4 className="text-xs font-serif font-bold text-oab-primary">{item.title}</h4>
                            <span className="text-[10px] font-mono text-slate-400">Data: {item.date} • Tempo: {item.timeSpentMinutes} minutos</span>
                          </div>

                          <div className="flex items-center space-x-3 self-stretch sm:self-auto justify-between sm:justify-start">
                            <span className={`text-xs px-2.5 py-1 font-mono font-bold uppercase rounded ${
                              passed ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-rose-50 text-rose-600 border border-rose-100'
                            }`}>
                              {passed ? 'Aprovado' : 'Reprovado'}
                            </span>
                            <span className="font-serif text-xl font-extrabold text-oab-primary">{item.score} / 10</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar widgets */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-white border border-slate-200 p-5 space-y-4">
                <h3 className="font-mono text-xs uppercase text-slate-400 tracking-wider">Métricas Gerais da Oficina</h3>
                
                <div className="space-y-4">
                  <div className="space-y-1">
                    <span className="block text-[10px] font-mono text-slate-400 uppercase">Média das Notas</span>
                    <span className="font-serif text-2xl font-bold text-oab-primary">{averageSimScore} / 10</span>
                    <p className="text-[10px] text-slate-400">Mínimo necessário para aprovação: 6,0</p>
                  </div>

                  <div className="space-y-1">
                    <span className="block text-[10px] font-mono text-slate-400 uppercase">Aproveitamento</span>
                    <span className="font-serif text-2xl font-bold text-oab-accent">
                      {areaSimHistory.length > 0
                        ? `${Math.round((areaSimHistory.filter(i => i.score >= 6.0).length / areaSimHistory.length) * 100)}%`
                        : '80%'
                      }
                    </span>
                    <p className="text-[10px] text-slate-400">Taxa de aprovação em testes</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
    </div>
  );
}
