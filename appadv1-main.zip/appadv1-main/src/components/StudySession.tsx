/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Clock,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  FileText,
  CheckSquare,
  ArrowLeft,
  ChevronRight,
  Flame,
  Award,
  Sparkles,
  Save,
  ShieldAlert,
  HelpCircle,
  BookOpen,
  CalendarDays
} from 'lucide-react';
import { WeeklyTask } from '../types';

interface StudySessionProps {
  task: WeeklyTask;
  onBack: () => void;
  onUpdateTasks: React.Dispatch<React.SetStateAction<WeeklyTask[]>>;
  onUpdateTaskStatus: (taskId: string, newStatus: 'pending' | 'in_progress' | 'completed') => void;
  onAddStudyHours: (hours: number) => void;
}

export default function StudySession({
  task,
  onBack,
  onUpdateTasks,
  onUpdateTaskStatus,
  onAddStudyHours
}: StudySessionProps) {
  // Session core states - load from task if it was in_progress
  const [sessionTime, setSessionTime] = useState<number>(() => {
    return task.realStudyTimeSeconds || 0;
  });
  const [sessionIsPlaying, setSessionIsPlaying] = useState<boolean>(false);
  const [sessionNotes, setSessionNotes] = useState<string>(() => {
    return task.notes || '';
  });
  
  // Auto-save notification feedback
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Completed micro-steps states
  const [completedSteps, setCompletedSteps] = useState<Record<string, boolean>>(() => {
    // If the task has saved notes or status completed, some steps might be completed
    return {};
  });

  // Flow completion screen state
  const [showSuccessSummary, setShowSuccessSummary] = useState<boolean>(false);
  const [hoursEarned, setHoursEarned] = useState<number>(0);
  const [totalSecondsStudied, setTotalSecondsStudied] = useState<number>(0);

  // Timer interval hook
  useEffect(() => {
    let interval: any = null;
    if (sessionIsPlaying && !showSuccessSummary) {
      interval = setInterval(() => {
        setSessionTime((prev) => {
          const nextTime = prev + 1;
          // Periodically save elapsed time to avoid losing data if tab is closed (every 10 seconds)
          if (nextTime % 10 === 0) {
            onUpdateTasks(prevTasks => prevTasks.map(t => {
              if (t.id === task.id) {
                return {
                  ...t,
                  realStudyTimeSeconds: nextTime,
                  status: 'in_progress'
                };
              }
              return t;
            }));
          }
          return nextTime;
        });
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [sessionIsPlaying, task.id, showSuccessSummary, onUpdateTasks]);

  // Handle task status transition on initial open
  useEffect(() => {
    // If the task was pending, change it to in_progress upon start of active study session
    if (task.status === 'pending') {
      onUpdateTaskStatus(task.id, 'in_progress');
      onUpdateTasks(prev => prev.map(t => {
        if (t.id === task.id) {
          return {
            ...t,
            status: 'in_progress',
            startedAt: t.startedAt || new Date().toISOString()
          };
        }
        return t;
      }));
    }
  }, [task.status, task.id, onUpdateTaskStatus, onUpdateTasks]);

  // Auto-save notes helper with debounce-like visual indicator
  useEffect(() => {
    const handler = setTimeout(() => {
      if (sessionNotes !== (task.notes || '')) {
        setIsSaving(true);
        onUpdateTasks(prev => prev.map(t => {
          if (t.id === task.id) {
            return {
              ...t,
              notes: sessionNotes
            };
          }
          return t;
        }));
        setTimeout(() => setIsSaving(false), 800);
      }
    }, 1000);

    return () => clearTimeout(handler);
  }, [sessionNotes, task.id, task.notes, onUpdateTasks]);

  // Stopwatch formatting
  const formatStopwatch = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;

    const pad = (val: number) => val.toString().padStart(2, '0');
    if (hrs > 0) {
      return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
    }
    return `${pad(mins)}:${pad(secs)}`;
  };

  // Micro-steps (checkpoints) determined dynamically based on task type
  const checklistItems = useMemo(() => {
    const taskType = task.type || 'teoria';
    switch (taskType) {
      case 'teoria':
        return [
          { id: 'step_1', label: '📖 Assistir à aula ou ler capítulo teórico de base' },
          { id: 'step_2', label: '✍️ Fazer anotações no caderno da sessão sobre conceitos centrais' },
          { id: 'step_3', label: '💡 Identificar 3 artigos cruciais ou pegadinhas de prova' },
          { id: 'step_4', label: '🔁 Concluir com revisão rápida mental do tema' }
        ];
      case 'questoes':
        return [
          { id: 'step_1', label: '✍️ Resolver a bateria recomendada de questões com foco total' },
          { id: 'step_2', label: '🔍 Ler atentamente os comentários das questões erradas' },
          { id: 'step_3', label: '⚠️ Identificar pegadinhas clássicas da banca FGV e anotá-las' },
          { id: 'step_4', label: '📈 Registrar número de acertos na aba de Desempenho' }
        ];
      case 'peca':
        return [
          { id: 'step_1', label: '📂 Analisar o problema prático e identificar a peça cabível' },
          { id: 'step_2', label: '📌 Estruturar o esqueleto/teses de mérito com consulta ao Vade Mecum' },
          { id: 'step_3', label: '⚖️ Redigir a fundamentação jurídica fundamentando nos artigos corretos' },
          { id: 'step_4', label: '✍️ Finalizar pedidos, fechamento e conferir com o espelho' }
        ];
      case 'revisao':
        return [
          { id: 'step_1', label: '🔁 Ler resumos ou anotações anteriores da matéria' },
          { id: 'step_2', label: '⚡ Resolver flashcards atrasados do assunto' },
          { id: 'step_3', label: '📚 Revisar os principais artigos da Lei Seca correspondentes' },
          { id: 'step_4', label: '🎯 Confirmar entendimento dos pontos de maior incidência' }
        ];
      case 'simulado':
        return [
          { id: 'step_1', label: '📈 Separar ambiente silencioso para simulação de prova real' },
          { id: 'step_2', label: '⏱️ Controlar tempo de resolução por questão (máx 3-4 min)' },
          { id: 'step_3', label: '📝 Conferir gabarito oficial e mapear erros por disciplina' },
          { id: 'step_4', label: '🔄 Agendar revisões específicas para os temas deficitários' }
        ];
      case 'discursiva':
        return [
          { id: 'step_1', label: '📝 Ler os enunciados das questões discursivas propostas' },
          { id: 'step_2', label: '🔍 Localizar as respostas exatas na legislação ou súmulas' },
          { id: 'step_3', label: '⚖️ Redigir as respostas de forma clara, objetiva e direta' },
          { id: 'step_4', label: '🎯 Comparar com o padrão de resposta oficial e corrigir' }
        ];
      default:
        return [
          { id: 'step_1', label: '🎯 Ler o escopo da tarefa programada' },
          { id: 'step_2', label: '⚡ Executar o estudo focado com atenção plena' },
          { id: 'step_3', label: '📝 Registrar anotações, leis secas ou dúvidas relevantes' },
          { id: 'step_4', label: '✅ Finalizar todas as submetas pedagógicas planejadas' }
        ];
    }
  }, [task.type]);

  // Compute session progress percentage based on completed checkpoints
  const sessionProgressPct = useMemo(() => {
    const total = checklistItems.length;
    const completed = checklistItems.filter(item => completedSteps[item.id]).length;
    return Math.round((completed / total) * 100);
  }, [checklistItems, completedSteps]);

  // Toggle checklist checkpoints
  const handleToggleStep = (stepId: string) => {
    setCompletedSteps(prev => ({
      ...prev,
      [stepId]: !prev[stepId]
    }));
  };

  // Core functions: Iniciar / Pausar
  const handleToggleTimer = () => {
    setSessionIsPlaying(!sessionIsPlaying);
  };

  // Core function: Save note manually
  const handleManualSaveNotes = () => {
    setIsSaving(true);
    onUpdateTasks(prev => prev.map(t => {
      if (t.id === task.id) {
        return {
          ...t,
          notes: sessionNotes
        };
      }
      return t;
    }));
    setTimeout(() => setIsSaving(false), 600);
  };

  // Core function: Complete active study session
  const handleCompleteSession = () => {
    // Calculate hours studied based on stopwatch
    // Minimum 1 min earned for quick tests so stats show up nicely, or real time
    const finalSeconds = sessionTime;
    const studiedHrs = parseFloat((finalSeconds / 3600).toFixed(2));
    
    // Update task in state
    onUpdateTasks(prev => prev.map(t => {
      if (t.id === task.id) {
        return {
          ...t,
          status: 'completed',
          realStudyTimeSeconds: finalSeconds,
          notes: sessionNotes,
          completedAt: new Date().toISOString()
        };
      }
      return t;
    }));

    // Update global status callback
    onUpdateTaskStatus(task.id, 'completed');

    // Credit study hours in student progress
    // If study hours calculated is zero, we give 0.1h minimum for visual progress feedback in general charts
    const hoursToCredit = studiedHrs > 0 ? studiedHrs : 0.1;
    onAddStudyHours(hoursToCredit);

    // Save notes permanently to StudentProgress as well for backup
    if (sessionNotes.trim()) {
      // Trigger update of state locally
    }

    // Capture stats for completion success summary screen
    setHoursEarned(hoursToCredit);
    setTotalSecondsStudied(finalSeconds);
    setSessionIsPlaying(false);
    setShowSuccessSummary(true);
  };

  // Core function: Cancel and exit session
  const handleCancelSession = () => {
    if (confirm("Deseja interromper esta sessão? O tempo deste ciclo não concluído será descartado, mas suas notas serão mantidas como rascunho.")) {
      setSessionIsPlaying(false);
      onBack();
    }
  };

  // Pedagogical guidance tips depending on task type
  const pedagogicalTip = useMemo(() => {
    const taskType = task.type || 'teoria';
    switch (taskType) {
      case 'teoria':
        return {
          title: "Instrução de Absorção de Conteúdo",
          text: "A 1ª Fase exige decoreba de lei seca combinada com doutrina básica. Ao assistir aulas ou ler a teoria, priorize anotar termos técnicos e prazos constitucionais ou processuais. Não tente copiar tudo; faça resumos esquematizados de 1-2 páginas no máximo."
        };
      case 'questoes':
        return {
          title: "Metodologia de Resolução Reversa",
          text: "A banca FGV cria cenários hipotéticos longos. Dica de aprovação: comece lendo a última frase da questão para saber qual instituto jurídico é exigido, depois leia as alternativas. Faça anotações das justificativas e das famosas pegadinhas."
        };
      case 'peca':
        return {
          title: "Engenharia de Peça da 2ª Fase",
          text: "Treinar a estrutura de endereçamento, qualificação, teses e fechamento é 80% do caminho para a aprovação na 2ª Fase. Utilize seu Vade Mecum impresso para se acostumar a folhear os índices remissivos rapidamente. O tempo de prova é escasso."
        };
      case 'revisao':
        return {
          title: "Técnica de Espaçamento Pedagógico",
          text: "A curva do esquecimento é cruel. Use a revisão rápida para ler os pontos chaves anotados no seu caderno da sessão. Se errar um flashcard, marque-o para revisar no dia seguinte. O segredo é a repetição de alta frequência."
        };
      default:
        return {
          title: "Foco de Alto Desempenho",
          text: "Evite distrações digitais neste momento. Deixe as abas de redes sociais fechadas e estude por ciclos limpos de concentração ativa. Anote suas principais dificuldades pedagógicas no Caderno de Notas abaixo."
        };
    }
  }, [task.type]);

  // Read-only session mode (if task is already completed)
  const isReadOnly = task.status === 'completed';

  // If the user wants to restart/re-study a completed task
  const handleRestartStudy = () => {
    if (confirm("Você deseja estudar esta meta novamente? O status retornará para 'Em andamento' e o cronômetro será zerado para uma nova sessão de estudos.")) {
      setSessionTime(0);
      setSessionNotes(task.notes || '');
      setCompletedSteps({});
      setShowSuccessSummary(false);
      onUpdateTaskStatus(task.id, 'in_progress');
      onUpdateTasks(prev => prev.map(t => {
        if (t.id === task.id) {
          return {
            ...t,
            status: 'in_progress',
            realStudyTimeSeconds: 0,
            completedAt: undefined,
            startedAt: new Date().toISOString()
          };
        }
        return t;
      }));
      setSessionIsPlaying(true);
    }
  };

  // --- RENDERING SUCCESS CELEBRATION PANELS ---
  if (showSuccessSummary) {
    return (
      <div className="max-w-3xl mx-auto py-8 px-4 animate-fade-in" id="study-session-success-screen">
        <div className="bg-white border border-[#E5E1D8] shadow-xl rounded-2xl overflow-hidden">
          {/* Header Banner Success */}
          <div className="bg-oab-primary text-white p-8 text-center relative overflow-hidden">
            {/* Ambient Background Glows */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none"></div>
            
            <div className="relative z-10 space-y-3">
              <div className="inline-flex items-center justify-center p-3 bg-[#D4AF37]/20 border border-[#D4AF37]/40 rounded-full text-[#D4AF37] animate-bounce">
                <Award className="h-10 w-10" />
              </div>
              <h2 className="text-2xl font-serif font-bold text-white tracking-tight">Sessão Finalizada com Sucesso!</h2>
              <p className="text-xs text-slate-300 max-w-md mx-auto">
                Mais um passo sólido rumo à sua carteira da OAB 2026. A consistência pedagógica gera a aprovação.
              </p>
            </div>
          </div>

          {/* Body stats block */}
          <div className="p-8 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-slate-50 border border-slate-150 p-4 rounded-xl text-center">
                <span className="block text-[10px] uppercase font-bold text-slate-400">Tempo de Foco Real</span>
                <span className="text-xl font-mono font-black text-slate-800 mt-1 block">
                  {formatStopwatch(totalSecondsStudied)}
                </span>
                <span className="text-[9px] text-slate-400 mt-0.5 block">cronometrado com precisão</span>
              </div>

              <div className="bg-amber-50/40 border border-amber-200 p-4 rounded-xl text-center">
                <span className="block text-[10px] uppercase font-bold text-amber-700">Meta Semanal Alimentada</span>
                <span className="text-xl font-mono font-black text-amber-800 mt-1 block">
                  +{hoursEarned.toFixed(2)}h
                </span>
                <span className="text-[9px] text-amber-600 mt-0.5 block">adicionadas ao seu progresso</span>
              </div>

              <div className="bg-emerald-50/40 border border-emerald-200 p-4 rounded-xl text-center">
                <span className="block text-[10px] uppercase font-bold text-emerald-700">Disciplina Estudada</span>
                <span className="text-xs font-black text-emerald-800 mt-2 block truncate">
                  {task.discipline}
                </span>
                <span className="text-[9px] text-emerald-600 mt-0.5 block">plano de estudos atualizado</span>
              </div>
            </div>

            {/* Task summary info */}
            <div className="border border-[#E5E1D8] rounded-xl p-5 space-y-3 bg-[#FAF9F6]">
              <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Resumo da Meta Concluída</h4>
              <div className="space-y-1">
                <h5 className="text-sm font-bold text-slate-850">{task.title}</h5>
                <p className="text-xs text-slate-600 leading-relaxed">{task.description}</p>
              </div>
            </div>

            {/* Notes output block */}
            {sessionNotes.trim() && (
              <div className="space-y-2">
                <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                  <FileText className="h-4 w-4 text-slate-400" /> Notas Consolidadas da Sessão
                </h4>
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 font-mono whitespace-pre-wrap leading-relaxed max-h-40 overflow-y-auto">
                  {sessionNotes}
                </div>
              </div>
            )}

            {/* Motivational text */}
            <div className="flex items-start gap-3 bg-amber-50/30 border border-amber-150 p-4 rounded-xl">
              <Sparkles className="h-5 w-5 text-[#D4AF37] shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <h5 className="text-xs font-bold text-slate-800">Dica de Fixação Pós-Sessão</h5>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Não pare seu estudo sem antes registrar as dúvidas mais quentes no seu caderno. Próximo passo recomendado é conferir se você tem flashcards correspondentes pendentes na aba de <strong>Revisão</strong>!
                </p>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-4 border-t border-slate-100">
              <button
                onClick={onBack}
                className="w-full sm:w-auto px-6 py-2.5 bg-oab-primary hover:bg-slate-850 text-white font-bold text-xs uppercase tracking-wider rounded-lg transition-all cursor-pointer shadow-sm text-center"
              >
                Voltar ao Cronograma de Estudos
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // --- MAIN SCREEN RENDERING (EXECUTION MODE / READ-ONLY DETAILED MODE) ---
  return (
    <div className="space-y-6 max-w-5xl mx-auto py-2 animate-fade-in" id="active-study-session-view">
      {/* Navigation header row */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#E5E1D8] pb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 hover:bg-slate-100 border border-slate-200 rounded-lg text-slate-600 hover:text-slate-800 transition-colors cursor-pointer"
            title="Voltar"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div>
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block">Ambiente de Execução Ativa</span>
            <h2 className="text-lg font-serif font-bold text-slate-850">Sessão de Estudo OAB 3F</h2>
          </div>
        </div>

        {/* Action controls left header */}
        <div className="flex items-center gap-2">
          {isReadOnly ? (
            <button
              onClick={handleRestartStudy}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white text-[11px] font-black uppercase tracking-wider rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              Estudar Novamente
            </button>
          ) : (
            <button
              onClick={handleCancelSession}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:text-red-500 text-[11px] font-black uppercase tracking-wider rounded-lg transition-colors cursor-pointer bg-white"
            >
              Interromper Estudo
            </button>
          )}
        </div>
      </div>

      {/* Grid of contents */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (2 cols width) - Main timer cockpit + checklist + instructions */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* BLOCO B — Área principal de foco / cronômetro */}
          <div className="bg-white border border-[#E5E1D8] p-6 shadow-sm rounded-xl space-y-6 relative overflow-hidden">
            {/* Pulsing indicator when playing */}
            {sessionIsPlaying && (
              <div className="absolute top-0 left-0 right-0 h-1 bg-emerald-500 animate-pulse"></div>
            )}

            <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
              <div className="space-y-2 text-center sm:text-left">
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${isReadOnly ? 'bg-emerald-100 text-emerald-800' : sessionIsPlaying ? 'bg-emerald-600 text-white' : 'bg-amber-100 text-amber-800 animate-pulse'}`}>
                  <span className={`h-2 w-2 rounded-full ${isReadOnly ? 'bg-emerald-600' : sessionIsPlaying ? 'bg-white animate-ping' : 'bg-amber-600'}`}></span>
                  {isReadOnly ? 'Estudo Concluído' : sessionIsPlaying ? 'Cronômetro Rodando' : 'Sessão Pausada'}
                </span>
                <h3 className="text-sm font-extrabold text-slate-400 uppercase tracking-widest font-mono">Cronômetro de Execução</h3>
                <p className="text-xs text-slate-500">
                  {isReadOnly 
                    ? "Esta tarefa foi devidamente cumprida e registrada nesta semana." 
                    : "Mantenha o foco absoluto. O cronômetro parará automaticamente se você trocar de página para evitar lixo nas métricas."}
                </p>
              </div>

              {/* Central Clock Display */}
              <div className="text-center shrink-0">
                <div className={`px-8 py-4 rounded-2xl border transition-all shadow-3xs text-center min-w-[200px] ${sessionIsPlaying ? 'bg-emerald-50/40 border-emerald-300' : 'bg-slate-50 border-slate-200'}`}>
                  <span className="text-4xl font-mono font-black text-slate-850 tracking-tight block">
                    {formatStopwatch(sessionTime)}
                  </span>
                  <div className="flex items-center justify-center gap-1 mt-1 text-slate-400">
                    <Clock className="h-3.5 w-3.5" />
                    <span className="text-[9px] font-black uppercase tracking-wider">
                      Meta: {task.estimatedMinutes !== undefined ? task.estimatedMinutes : task.durationMinutes} min
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Controls Bar for Timer */}
            {!isReadOnly && (
              <div className="flex items-center justify-center sm:justify-start gap-3 pt-4 border-t border-slate-100">
                <button
                  onClick={handleToggleTimer}
                  className={`px-5 py-2.5 rounded-lg text-xs font-extrabold uppercase tracking-wider flex items-center gap-2 cursor-pointer transition-all ${sessionIsPlaying ? 'bg-amber-100 hover:bg-amber-200 text-amber-800 border border-amber-300' : 'bg-oab-primary hover:bg-slate-850 text-white shadow-sm'}`}
                >
                  {sessionIsPlaying ? (
                    <>
                      <Pause className="h-3.5 w-3.5 fill-amber-800 text-amber-800" />
                      <span>Pausar Estudo</span>
                    </>
                  ) : (
                    <>
                      <Play className="h-3.5 w-3.5 fill-white text-white" />
                      <span>{sessionTime > 0 ? 'Retomar Cronômetro' : 'Iniciar Estudo'}</span>
                    </>
                  )}
                </button>

                {sessionTime > 0 && (
                  <button
                    onClick={() => {
                      if (confirm("Quer realmente zerar o cronômetro? O tempo já estudado nesta sessão será resetado.")) {
                        setSessionTime(0);
                        setSessionIsPlaying(false);
                      }
                    }}
                    className="p-2.5 border border-slate-200 hover:border-red-200 text-slate-500 hover:text-red-500 rounded-lg transition-colors cursor-pointer bg-white"
                    title="Reiniciar Cronômetro"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                  </button>
                )}

                <div className="flex-1"></div>

                <button
                  onClick={handleCompleteSession}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-lg text-xs font-extrabold uppercase tracking-wider flex items-center gap-2 shadow-sm cursor-pointer transition-all"
                >
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Concluir Estudo</span>
                </button>
              </div>
            )}
          </div>

          {/* BLOCO C — Objetivo da sessão / instrução pedagógica */}
          <div className="bg-[#FAF9F6] border border-[#E5E1D8] p-5 rounded-xl space-y-3">
            <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
              <Sparkles className="h-4 w-4 text-[#D4AF37]" /> {pedagogicalTip.title}
            </h4>
            <p className="text-xs text-slate-700 leading-relaxed font-serif italic bg-white p-4 border border-slate-150 rounded-lg">
              "{pedagogicalTip.text}"
            </p>
          </div>

          {/* BLOCO E — Checklist ou microetapas da sessão */}
          <div className="bg-white border border-[#E5E1D8] p-6 shadow-sm rounded-xl space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h4 className="text-sm font-black text-slate-800 font-serif">Fluxo de Passos da Sessão</h4>
                <p className="text-xs text-slate-500">Mapeamento sequencial para garantir o aproveitamento de estudo</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-extrabold bg-slate-100 border border-slate-200 px-2 py-0.5 rounded text-slate-600">
                  {sessionProgressPct}% CONCLUÍDO
                </span>
              </div>
            </div>

            {/* Real Progress Bar */}
            <div className="w-full bg-slate-100 rounded-full h-1.5">
              <div 
                className="bg-emerald-600 h-1.5 rounded-full transition-all duration-300" 
                style={{ width: `${sessionProgressPct}%` }}
              ></div>
            </div>

            {/* Checklist items */}
            <div className="space-y-3 pt-1">
              {checklistItems.map((item) => {
                const isChecked = completedSteps[item.id] || isReadOnly;
                return (
                  <div 
                    key={item.id}
                    onClick={() => !isReadOnly && handleToggleStep(item.id)}
                    className={`p-3.5 rounded-xl border flex items-center gap-3 transition-colors cursor-pointer ${isChecked ? 'bg-emerald-50/30 border-emerald-150 text-slate-600' : 'bg-slate-50 border-slate-150 text-slate-800 hover:bg-white hover:border-slate-300'}`}
                  >
                    <div className={`h-5 w-5 rounded flex items-center justify-center border transition-all ${isChecked ? 'bg-emerald-600 border-emerald-600 text-white' : 'bg-white border-slate-300'}`}>
                      {isChecked && <CheckCircle2 className="h-3.5 w-3.5 text-white" />}
                    </div>
                    <span className={`text-xs font-medium ${isChecked ? 'line-through text-slate-400' : ''}`}>
                      {item.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Right Column (1 col width) - Task info + Notebook */}
        <div className="space-y-6">
          
          {/* BLOCO A — Cabeçalho da tarefa em estudo */}
          <div className="bg-white border border-[#E5E1D8] p-5 shadow-sm rounded-xl space-y-4">
            <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Identificação da Meta</h4>
            
            <div className="space-y-3.5">
              <div className="space-y-1">
                <span className="text-[9.5px] font-black uppercase tracking-wider text-[#D4AF37] bg-[#0F172A] px-2 py-0.5 rounded">
                  {task.discipline}
                </span>
                <h3 className="text-base font-bold text-slate-850 pt-1 leading-snug">{task.title}</h3>
                <p className="text-xs text-slate-500 leading-relaxed">{task.description}</p>
              </div>

              <div className="border-t border-slate-100 pt-3 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400 font-semibold">Tipo de Atividade:</span>
                  <span className="font-mono text-slate-700 capitalize font-bold">
                    {task.type || 'Teoria de base'}
                  </span>
                </div>
                {task.phaseRelated && (
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400 font-semibold">Foco Acadêmico:</span>
                    <span className="font-mono text-slate-700 font-bold">
                      {task.phaseRelated}
                    </span>
                  </div>
                )}
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400 font-semibold">Prioridade Pedagógica:</span>
                  <span className={`font-mono font-bold ${task.priority === 'Alta' ? 'text-red-600' : 'text-slate-600'}`}>
                    {task.priority}
                  </span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400 font-semibold">Estimativa Original:</span>
                  <span className="font-mono text-slate-700 font-bold">
                    {task.estimatedMinutes !== undefined ? task.estimatedMinutes : task.durationMinutes} min
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* BLOCO D — Caderno de notas da sessão */}
          <div className="bg-white border border-[#E5E1D8] p-5 shadow-sm rounded-xl space-y-4">
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2">
              <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                <FileText className="h-4 w-4 text-slate-400" /> Caderno de Anotações
              </h4>
              <span className="text-[9px] font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded font-mono">
                {isSaving ? 'Salvando...' : 'Salvo ✓'}
              </span>
            </div>

            <div className="space-y-3">
              <textarea
                placeholder="Anote artigos importantes (Ex: Art. 5, CF), resumos rápidos de súmulas, teses da peça prático-profissional ou as pegadinhas que você identificou..."
                value={sessionNotes}
                onChange={(e) => !isReadOnly && setSessionNotes(e.target.value)}
                readOnly={isReadOnly}
                className="w-full text-xs border border-slate-250 rounded-lg p-3 bg-slate-50/40 h-72 focus:outline-none focus:ring-1 focus:ring-oab-accent font-mono leading-relaxed"
              />

              {!isReadOnly && (
                <button
                  onClick={handleManualSaveNotes}
                  className="w-full py-2 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 font-bold text-[10px] uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Save className="h-3.5 w-3.5" />
                  <span>Salvar Anotações Agora</span>
                </button>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
