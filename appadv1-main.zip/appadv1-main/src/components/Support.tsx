/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Users, 
  MessageSquare, 
  HelpCircle, 
  Mail, 
  Sparkles, 
  Award, 
  Bell, 
  ShieldCheck, 
  Settings, 
  Check, 
  CheckCircle,
  Clock,
  ArrowRight,
  TrendingUp,
  X,
  AlertCircle,
  Bookmark,
  Crown
} from 'lucide-react';
import { SupportFAQ } from '../types';

// Import modular sub-components
import CommunityForum from './CommunityForum';
import CommunityFAQ from './CommunityFAQ';
import CommunitySupport from './CommunitySupport';
import CommunityMentorship from './CommunityMentorship';
import CommunityTestimonials from './CommunityTestimonials';
import CommunityAdmin from './CommunityAdmin';

// Import rich data and types
import { 
  INITIAL_ANNOUNCEMENTS, 
  INITIAL_TESTIMONIALS, 
  INITIAL_FORUM_QUESTIONS, 
  MENTORSHIP_MEETINGS, 
  MENTORSHIP_TASKS,
  ForumQuestion,
  SupportTicket,
  Announcement,
  Testimonial,
  MentorshipTask
} from './CommunityData';

interface SupportProps {
  faqs: SupportFAQ[];
  userPlan?: string;
  onNavigateToTab?: (tab: string) => void;
  progress?: any;
  setProgress?: any;
}

export default function Support({ faqs: initialFaqs, userPlan = 'gratuito', onNavigateToTab }: SupportProps) {
  // Navigation tabs within Community area
  const [activeTab, setActiveTab] = useState<'hub' | 'forum' | 'faq' | 'support' | 'mentorship' | 'testimonials' | 'rules' | 'admin'>('hub');

  // Load and persist state in localStorage so the community actually functions!
  const [questions, setQuestions] = useState<ForumQuestion[]>(() => {
    const saved = localStorage.getItem('oab3f_forum_questions');
    return saved ? JSON.parse(saved) : INITIAL_FORUM_QUESTIONS;
  });

  const [tickets, setTickets] = useState<SupportTicket[]>(() => {
    const saved = localStorage.getItem('oab3f_support_tickets');
    if (saved) return JSON.parse(saved);
    // Initial default ticket history
    return [
      {
        id: 'tkt-init-1',
        protocol: '#OAB-3F-1025',
        category: 'Inscrição & Cronogramas',
        description: 'Gostaria de saber quando abre a repescagem do Exame XL.',
        urgency: 'Normal',
        status: 'resolvido',
        timestamp: '18/06/2026, 14:20',
        replies: [
          {
            author: 'poprotaspires@gmail.com',
            role: 'aluno',
            text: 'Gostaria de saber quando abre a repescagem do Exame XL.',
            timestamp: '18/06/2026, 14:20'
          },
          {
            author: 'Suporte Pedagógico OAB 3F',
            role: 'suporte',
            text: 'Olá! A repescagem (reaproveitamento da 1ª fase) costuma abrir o edital cerca de duas semanas após o resultado preliminar da 2ª fase do Exame XXXIX. Fique tranquilo, adicionamos todos os prazos essenciais na sua aba Calendário OAB.',
            timestamp: '18/06/2026, 16:45'
          }
        ]
      }
    ];
  });

  const [faqs, setFaqs] = useState<SupportFAQ[]>(() => {
    const saved = localStorage.getItem('oab3f_faqs');
    return saved ? JSON.parse(saved) : initialFaqs;
  });

  const [announcements, setAnnouncements] = useState<Announcement[]>(() => {
    const saved = localStorage.getItem('oab3f_announcements');
    return saved ? JSON.parse(saved) : INITIAL_ANNOUNCEMENTS;
  });

  const [testimonials, setTestimonials] = useState<Testimonial[]>(() => {
    const saved = localStorage.getItem('oab3f_testimonials');
    return saved ? JSON.parse(saved) : INITIAL_TESTIMONIALS;
  });

  const [mentorshipTasks, setMentorshipTasks] = useState<MentorshipTask[]>(() => {
    const saved = localStorage.getItem('oab3f_mentorship_tasks');
    return saved ? JSON.parse(saved) : MENTORSHIP_TASKS;
  });

  // Save changes to localstorage on update
  useEffect(() => {
    localStorage.setItem('oab3f_forum_questions', JSON.stringify(questions));
  }, [questions]);

  useEffect(() => {
    localStorage.setItem('oab3f_support_tickets', JSON.stringify(tickets));
  }, [tickets]);

  useEffect(() => {
    localStorage.setItem('oab3f_faqs', JSON.stringify(faqs));
  }, [faqs]);

  useEffect(() => {
    localStorage.setItem('oab3f_announcements', JSON.stringify(announcements));
  }, [announcements]);

  useEffect(() => {
    localStorage.setItem('oab3f_testimonials', JSON.stringify(testimonials));
  }, [testimonials]);

  useEffect(() => {
    localStorage.setItem('oab3f_mentorship_tasks', JSON.stringify(mentorshipTasks));
  }, [mentorshipTasks]);

  // Read announcements marker
  const handleMarkAllRead = () => {
    setAnnouncements(prev => prev.map(ann => ({ ...ann, isRead: true })));
  };

  const handleMarkSingleRead = (id: string) => {
    setAnnouncements(prev => prev.map(ann => {
      if (ann.id === id) return { ...ann, isRead: true };
      return ann;
    }));
  };

  const unreadAnnouncementsCount = announcements.filter(ann => !ann.isRead).length;

  // Render navigation menu bar
  const navItems = [
    { id: 'hub', label: 'Central', icon: Users },
    { id: 'forum', label: 'Mural de Dúvidas', icon: MessageSquare },
    { id: 'faq', label: 'FAQ & Ajuda', icon: HelpCircle },
    { id: 'support', label: 'Atendimento', icon: Mail },
    { id: 'mentorship', label: 'Mentoria VIP', icon: Sparkles },
    { id: 'testimonials', label: 'Mural de Aprovados', icon: Award },
    { id: 'rules', label: 'Regras de Convivência', icon: ShieldCheck },
    { id: 'admin', label: 'Painel do Tutor', icon: Settings }
  ];

  return (
    <div className="space-y-6" id="community-oab3f-root">
      
      {/* Visual Title Banner */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 flex items-center">
            <Users className="h-5.5 w-5.5 mr-2 text-amber-500" />
            Comunidade OAB 3F
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Espaço integrado de acolhimento, suporte pedagógico, discussões jurídicas de 1ª e 2ª fase e mentoria estratégica.
          </p>
        </div>

        {/* Current status display */}
        <div className="flex items-center space-x-2 bg-slate-900 text-[#D4AF37] px-3.5 py-1.5 rounded-lg border border-slate-800">
          <Crown className="h-4 w-4 shrink-0" />
          <div className="text-left leading-tight">
            <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-widest">Plano do Aluno</span>
            <span className="text-[10px] font-black uppercase tracking-wider">{userPlan}</span>
          </div>
        </div>
      </div>

      {/* Primary Community Tabs Row */}
      <div className="flex overflow-x-auto gap-1 pb-1 scrollbar-none border-b border-slate-200">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`flex items-center space-x-1.5 px-3.5 py-2.5 text-xs font-semibold rounded-t-lg transition-all border-b-2 cursor-pointer shrink-0 ${
                isActive 
                  ? 'border-slate-900 text-slate-900 font-bold bg-white' 
                  : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-50'
              }`}
              id={`community-tab-${item.id}`}
            >
              <Icon className={`h-4 w-4 ${isActive ? 'text-slate-900' : 'text-slate-400'}`} />
              <span>{item.label}</span>
              {item.id === 'support' && tickets.filter(t => t.status === 'respondido').length > 0 && (
                <span className="h-2 w-2 rounded-full bg-blue-500 animate-pulse shrink-0" />
              )}
              {item.id === 'forum' && questions.filter(q => q.status === 'aberta').length > 0 && (
                <span className="bg-rose-100 text-rose-600 text-[8px] font-bold px-1.5 py-0.5 rounded-full font-mono">
                  {questions.filter(q => q.status === 'aberta').length}
                </span>
              )}
              {item.id === 'admin' && (
                <span className="bg-slate-800 text-[#D4AF37] text-[8px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded">
                  Admin
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* CORE MODULES ROUTING */}
      <div className="mt-4" id="community-active-content">
        
        {/* TAB 1: CENTRAL DA COMUNIDADE (HUB) */}
        {activeTab === 'hub' && (
          <div className="space-y-6 animate-fade-in" id="community-hub-view">
            
            {/* Welcome Greeting Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Main Welcome Message */}
              <div className="lg:col-span-8 bg-gradient-to-r from-slate-900 to-slate-950 border border-slate-800 rounded-xl p-6 text-white relative overflow-hidden shadow-lg flex flex-col justify-between">
                <div className="absolute top-0 right-0 w-64 h-64 bg-radial-gradient from-amber-500/10 via-transparent to-transparent pointer-events-none" />
                
                <div className="space-y-3 z-10">
                  <span className="bg-[#D4AF37] text-slate-900 text-[9px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full font-mono">
                    ★ BEM-VINDO À JORNADA OAB 3F
                  </span>
                  <h3 className="font-serif font-bold text-xl text-[#D4AF37]">
                    Sua preparação de excelência rumo à Aprovação!
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed max-w-2xl font-medium">
                    Aqui você não estuda sozinho. Nossa comunidade foi projetada para que você possa sanar suas dúvidas, interagir com coordenadores pedagógicos, compartilhar histórias de superação e obter o acompanhamento exato para passar na OAB.
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-3 border-t border-slate-800/80 pt-4 mt-6 text-center text-white/90 z-10 font-medium">
                  <div>
                    <span className="block text-lg font-black font-mono text-[#D4AF37]">{questions.length}</span>
                    <span className="text-[9px] text-slate-400 uppercase tracking-wider">Perguntas no Fórum</span>
                  </div>
                  <div>
                    <span className="block text-lg font-black font-mono text-[#D4AF37]">
                      {tickets.filter(t => t.status === 'resolvido' || t.status === 'encerrado').length}
                    </span>
                    <span className="text-[9px] text-slate-400 uppercase tracking-wider">Chamados Resolvidos</span>
                  </div>
                  <div>
                    <span className="block text-lg font-black font-mono text-[#D4AF37]">12 min</span>
                    <span className="text-[9px] text-slate-400 uppercase tracking-wider">Média de Resposta</span>
                  </div>
                </div>
              </div>

              {/* Weekly Highlights Widget */}
              <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                  <TrendingUp className="h-4 w-4 text-amber-500" /> Destaques Acadêmicos
                </h3>
                
                <div className="space-y-3.5">
                  <div className="space-y-0.5">
                    <span className="text-[10px] bg-amber-500/15 text-amber-800 font-bold px-1.5 py-0.5 rounded">Pergunta Útil</span>
                    <span className="block text-xs font-bold text-slate-800 leading-snug mt-1 cursor-pointer hover:underline" onClick={() => setActiveTab('forum')}>
                      Como fazer ROC de Mandado de Segurança?
                    </span>
                    <p className="text-[10.5px] text-slate-400 leading-tight">Resolvida pelo Prof. Lucas com farta fundamentação jurídica.</p>
                  </div>

                  <div className="space-y-0.5">
                    <span className="text-[10px] bg-emerald-500/15 text-emerald-800 font-bold px-1.5 py-0.5 rounded">Estudo Ativo</span>
                    <span className="block text-xs font-bold text-slate-800 leading-snug mt-1 cursor-pointer hover:underline" onClick={() => setActiveTab('mentorship')}>
                      Cronograma de 30 dias de Reta Final
                    </span>
                    <p className="text-[10.5px] text-slate-400 leading-tight">Ideal para quem precisa focar em Ética e Constitucional.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Action Cards Grid (Shortcuts, Module 1) */}
            <div className="space-y-2.5">
              <h3 className="text-[10.5px] font-black text-slate-400 uppercase tracking-widest px-1">Atalhos e Ferramentas Rápidas</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                
                <div 
                  onClick={() => setActiveTab('forum')}
                  className="bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-4 shadow-sm hover:shadow transition-all cursor-pointer flex flex-col justify-between gap-3 group"
                >
                  <div className="h-8 w-8 bg-blue-50 text-blue-500 rounded-lg flex items-center justify-center">
                    <MessageSquare className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 group-hover:text-slate-900 flex items-center gap-1">
                      Mural de Dúvidas <ArrowRight className="h-3.5 w-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </h4>
                    <span className="text-[10.5px] text-slate-400 block font-medium leading-tight mt-0.5">Comente em aulas ou veja respostas teóricas.</span>
                  </div>
                </div>

                <div 
                  onClick={() => setActiveTab('faq')}
                  className="bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-4 shadow-sm hover:shadow transition-all cursor-pointer flex flex-col justify-between gap-3 group"
                >
                  <div className="h-8 w-8 bg-purple-50 text-purple-500 rounded-lg flex items-center justify-center">
                    <HelpCircle className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 group-hover:text-slate-900 flex items-center gap-1">
                      FAQ & Ajuda <ArrowRight className="h-3.5 w-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </h4>
                    <span className="text-[10.5px] text-slate-400 block font-medium leading-tight mt-0.5">Base de conhecimento rápida sobre planos e cronograma.</span>
                  </div>
                </div>

                <div 
                  onClick={() => setActiveTab('support')}
                  className="bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-4 shadow-sm hover:shadow transition-all cursor-pointer flex flex-col justify-between gap-3 group"
                >
                  <div className="h-8 w-8 bg-emerald-50 text-emerald-500 rounded-lg flex items-center justify-center">
                    <Mail className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 group-hover:text-slate-900 flex items-center gap-1">
                      Atendimento <ArrowRight className="h-3.5 w-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </h4>
                    <span className="text-[10.5px] text-slate-400 block font-medium leading-tight mt-0.5">Abra chamados formais de suporte pedagógico.</span>
                  </div>
                </div>

                <div 
                  onClick={() => setActiveTab('mentorship')}
                  className="bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-4 shadow-sm hover:shadow transition-all cursor-pointer flex flex-col justify-between gap-3 group"
                >
                  <div className="h-8 w-8 bg-amber-50 text-amber-500 rounded-lg flex items-center justify-center">
                    <Sparkles className="h-4.5 w-4.5 text-amber-600" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 group-hover:text-slate-900 flex items-center gap-1">
                      Mentoria VIP <ArrowRight className="h-3.5 w-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </h4>
                    <span className="text-[10.5px] text-slate-400 block font-medium leading-tight mt-0.5">Encontros ao vivo e tarefas recomendadas de estudo.</span>
                  </div>
                </div>

              </div>
            </div>

            {/* Announcements Stream (Comunicados, Module 7) */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4" id="community-announcements-card">
              <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                <h3 className="text-sm font-black text-slate-800 flex items-center gap-1.5">
                  <Bell className="h-4.5 w-4.5 text-amber-500" />
                  Avisos e Comunicados Recentes ({unreadAnnouncementsCount})
                </h3>
                {unreadAnnouncementsCount > 0 && (
                  <button 
                    onClick={handleMarkAllRead}
                    className="text-[10.5px] font-bold text-amber-600 hover:text-amber-700 cursor-pointer"
                  >
                    Marcar todos como lidos
                  </button>
                )}
              </div>

              <div className="divide-y divide-slate-100">
                {announcements.map(ann => (
                  <div 
                    key={ann.id} 
                    className={`py-3.5 flex gap-4 items-start ${ann.isRead ? 'opacity-70' : 'bg-amber-500/5 -mx-4 px-4 rounded-xl'}`}
                    onClick={() => handleMarkSingleRead(ann.id)}
                  >
                    <div className="h-6 w-6 rounded-full bg-slate-900 text-[#D4AF37] flex items-center justify-center font-black text-[9px] shrink-0 font-serif shadow-xs">
                      OAB
                    </div>
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400">{ann.category}</span>
                        <span className="text-[9.5px] text-slate-400 font-mono font-medium">• {ann.timestamp}</span>
                        {ann.isUrgent && (
                          <span className="bg-rose-100 text-rose-700 text-[8px] font-black uppercase tracking-widest px-1.5 rounded-full">
                            Urgente
                          </span>
                        )}
                        {!ann.isRead && (
                          <span className="bg-amber-500 h-1.5 w-1.5 rounded-full shrink-0" />
                        )}
                      </div>
                      <h4 className="text-xs font-bold text-slate-800 leading-snug">{ann.title}</h4>
                      <p className="text-xs text-slate-500 leading-relaxed font-medium">{ann.text}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: COMENTÁRIOS E DÚVIDAS POR AULA (FORUM) */}
        {activeTab === 'forum' && (
          <CommunityForum 
            questions={questions}
            setQuestions={setQuestions}
            userPlan={userPlan}
          />
        )}

        {/* TAB 3: FAQ E BASE DE CONHECIMENTO */}
        {activeTab === 'faq' && (
          <CommunityFAQ 
            faqs={faqs}
            onNeedHelpClick={() => setActiveTab('support')}
          />
        )}

        {/* TAB 4: SUPORTE / ATENDIMENTO */}
        {activeTab === 'support' && (
          <CommunitySupport 
            tickets={tickets}
            setTickets={setTickets}
            onNavigateToFAQ={() => setActiveTab('faq')}
          />
        )}

        {/* TAB 5: MENTORIA / ACOMPANHAMENTO */}
        {activeTab === 'mentorship' && (
          <CommunityMentorship 
            userPlan={userPlan}
            onNavigateToTab={onNavigateToTab}
            meetings={MENTORSHIP_MEETINGS}
            tasks={mentorshipTasks}
            setTasks={setMentorshipTasks}
          />
        )}

        {/* TAB 6: MURAL DE APROVADOS E PROVA SOCIAL */}
        {activeTab === 'testimonials' && (
          <CommunityTestimonials 
            testimonials={testimonials}
            setTestimonials={setTestimonials}
          />
        )}

        {/* TAB 7: REGRAS DE CONVIVÊNCIA E DIRETRIZES (Module 8) */}
        {activeTab === 'rules' && (
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-6 animate-fade-in" id="community-rules-view">
            <div className="space-y-1.5 border-b border-slate-100 pb-4">
              <h3 className="font-serif font-black text-slate-900 text-lg flex items-center gap-1.5">
                <ShieldCheck className="h-5 w-5 text-emerald-500" /> Diretrizes e Regras da Comunidade OAB 3F
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                Para manter nosso ecossistema produtivo, focado e saudável, solicitamos que todos os candidatos observem as seguintes regras fundamentais:
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-600 leading-relaxed font-medium">
              <div className="space-y-4">
                <div className="space-y-1">
                  <span className="font-bold text-slate-800 block">1. Respeito Mútuo e Cortesia</span>
                  <p>A preparação para a OAB é uma jornada emocionalmente exigente. Trate todos os colegas de fórum com paciência, empatia e cordialidade. Discussões pessoais ou ataques não são tolerados.</p>
                </div>
                <div className="space-y-1">
                  <span className="font-bold text-slate-800 block">2. Foco Absoluto em Matéria Jurídica</span>
                  <p>O Mural de Dúvidas é destinado a debates jurídicos relacionados ao edital do Exame de Ordem. Evite tópicos políticos, debates ideológicos ou conteúdos promocionais de terceiros.</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-1">
                  <span className="font-bold text-slate-800 block">3. Uso de Linguagem Clara</span>
                  <p>Ao elaborar dúvidas, utilize títulos descritivos e informe sempre que possível o conteúdo de referência (ex: número da questão ou nome da aula). Isso agiliza o tempo de resposta da mentoria.</p>
                </div>
                <div className="space-y-1">
                  <span className="font-bold text-slate-800 block">4. Canal Correto de Escalabilidade</span>
                  <p>Dúvidas administrativas, problemas de pagamento ou bugs técnicos de utilização do app devem ser encaminhados diretamente via abertura de chamado na aba Atendimento, mantendo o Fórum livre para debates acadêmicos.</p>
                </div>
              </div>
            </div>

            <div className="bg-amber-500/5 border border-amber-500/20 p-4 rounded-xl text-xs text-slate-500 font-medium">
              <span className="font-bold text-slate-700 block mb-1">Aviso sobre o Tempo de Resposta Pedagógica:</span>
              Nossa equipe de professores e tutores oficiais monitora o Mural de Dúvidas de segunda a sexta-feira. O tempo médio estimado de feedback oficial é de até **12 horas úteis**, priorizando sempre alunos com planos VIP ativos.
            </div>
          </div>
        )}

        {/* TAB 8: PAINEL DO TUTOR (ADMIN CONTROL PANEL) */}
        {activeTab === 'admin' && (
          <CommunityAdmin 
            questions={questions}
            setQuestions={setQuestions}
            tickets={tickets}
            setTickets={setTickets}
            faqs={faqs}
            setFaqs={setFaqs}
            announcements={announcements}
            setAnnouncements={setAnnouncements}
          />
        )}

      </div>
    </div>
  );
}
