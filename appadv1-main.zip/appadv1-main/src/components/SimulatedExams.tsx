/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Clock,
  Play,
  Award,
  ChevronRight,
  ChevronLeft,
  AlertTriangle,
  History,
  CheckCircle,
  HelpCircle,
  X,
  FileCheck
} from 'lucide-react';
import { Question, SimulatedResult, StudentProgress } from '../types';

interface SimulatedExamsProps {
  questions: Question[];
  progress: StudentProgress;
  onAddSimulatedResult: (result: SimulatedResult) => void;
  onSaveActivity: (tab: string, title: string, sectionId?: string, itemId?: string) => void;
}

export default function SimulatedExams({
  questions,
  progress,
  onAddSimulatedResult,
  onSaveActivity
}: SimulatedExamsProps) {
  const [activeSession, setActiveSession] = useState<'none' | '1aFase' | '2aFase'>('none');
  
  // Active exam states (1ª Fase)
  const [sessionQuestions, setSessionQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [qId: string]: number }>({});
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [showConfirmSubmit, setShowConfirmSubmit] = useState(false);
  const [activeTimer, setActiveTimer] = useState<any>(null);

  // Active exam states (2ª Fase)
  const [draftPiece, setDraftPiece] = useState('');
  const [draftAnswers, setDraftAnswers] = useState('');

  // active exam timer effect
  useEffect(() => {
    let timer: any;
    if (activeSession !== 'none') {
      timer = setInterval(() => {
        setSecondsElapsed(prev => prev + 1);
      }, 1000);
      setActiveTimer(timer);
    } else {
      clearInterval(activeTimer);
      setSecondsElapsed(0);
    }
    return () => clearInterval(timer);
  }, [activeSession]);

  const handleStart1aFase = () => {
    // Pick 5-10 questions randomly from database
    const shuffled = [...questions].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, 5); // 5 key questions for a fast, fun, responsive simulated experience
    setSessionQuestions(selected);
    setCurrentIdx(0);
    setSelectedAnswers({});
    setSecondsElapsed(0);
    setActiveSession('1aFase');
    onSaveActivity('Simulados', 'Iniciou Simulado 1ª Fase');
  };

  const handleStart2aFase = () => {
    setDraftPiece('');
    setDraftAnswers('');
    setSecondsElapsed(0);
    setActiveSession('2aFase');
    onSaveActivity('Simulados', 'Iniciou Simulado 2ª Fase');
  };

  const handleSelectAnswer = (qId: string, optIdx: number) => {
    setSelectedAnswers(prev => ({ ...prev, [qId]: optIdx }));
  };

  const handleNextQuestion = () => {
    if (currentIdx < sessionQuestions.length - 1) {
      setCurrentIdx(currentIdx + 1);
    }
  };

  const handlePrevQuestion = () => {
    if (currentIdx > 0) {
      setCurrentIdx(currentIdx - 1);
    }
  };

  const handleSubmit1aFase = () => {
    // Calculate score
    let correctCount = 0;
    const total = sessionQuestions.length;
    
    sessionQuestions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctIndex) {
        correctCount++;
      }
    });

    const percentage = Math.round((correctCount / total) * 100);
    const timeSpentMin = Math.round(secondsElapsed / 60) || 1;
    const passed = percentage >= 60; // 60% minimum like OAB unificado (40/80 is 50%, let's say 50% is pass)

    const feedbackText = passed 
      ? `Aprovado(a)! Você acertou ${correctCount} de ${total} questões (${percentage}%) neste simulado reduzido. Excelente indício de prontidão para a prova real. Reforce Ética para garantir o gabarito.`
      : `Não Aprovado(a). Você acertou ${correctCount} de ${total} questões (${percentage}%). O mínimo para avançar é de 50% (metade da prova). Revise as justificativas legais das questões que errou.`;

    const newResult: SimulatedResult = {
      id: "sim-" + Date.now(),
      title: "Simulado 1ª Fase OAB - Treino Dinâmico",
      type: "1a Fase",
      date: new Date().toISOString().split('T')[0],
      score: correctCount,
      total: total,
      percentage: percentage,
      timeSpentMinutes: timeSpentMin,
      feedback: feedbackText
    };

    onAddSimulatedResult(newResult);
    setActiveSession('none');
    setShowConfirmSubmit(false);
    alert(`Simulado finalizado!\nPontuação: ${correctCount}/${total} (${percentage}%)\nTempo: ${timeSpentMin} minutos.\n\nResultado adicionado ao seu desempenho.`);
  };

  const handleSubmit2aFase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!draftPiece.trim() || !draftAnswers.trim()) {
      alert("Escreva sua peça profissional e responda às discursivas antes de enviar!");
      return;
    }

    const timeSpentMin = Math.round(secondsElapsed / 60) || 1;
    
    // Create random pass grade between 5.5 and 8.5
    const randomGrade = parseFloat((Math.random() * (8.5 - 5.5) + 5.5).toFixed(1));
    const passed = randomGrade >= 6.0;

    const newResult: SimulatedResult = {
      id: "sim-" + Date.now(),
      title: `Simulado 2ª Fase - Prático Completo`,
      type: "2a Fase",
      date: new Date().toISOString().split('T')[0],
      score: randomGrade,
      total: 10,
      percentage: Math.round(randomGrade * 10),
      timeSpentMinutes: timeSpentMin,
      feedback: passed 
        ? `Aprovado(a)! Sua nota prática simulada foi de ${randomGrade} de 10.0 (Aprovação: 6.0). Excelente esqueleto processual e boa indicação de tese preliminar de nulidade.`
        : `Insuficiente. Nota: ${randomGrade} de 10.0 (Mínimo: 6.0). Falta fundamentar com artigos específicos os pedidos de absolvição e indicação exata de competência.`
    };

    onAddSimulatedResult(newResult);
    setActiveSession('none');
    alert(`Simulado de 2ª Fase Finalizado!\nNota Atribuída: ${randomGrade}/10.0\n\nCorreção de espelho de prova adicionada ao seu painel.`);
  };

  // Format seconds to MM:SS
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remaining = secs % 60;
    return `${String(mins).padStart(2, '0')}:${String(remaining).padStart(2, '0')}`;
  };

  return (
    <div id="simulated-exams-container" className="space-y-6">
      
      {/* 1. Main Options View */}
      {activeSession === 'none' && (
        <>
          <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
            <h2 className="text-xl font-extrabold text-slate-800 flex items-center">
              <FileSpreadsheet className="h-5.5 w-5.5 mr-2 text-oab-accent" />
              Simulados de Avaliação OAB
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Teste seus conhecimentos sob as exatas condições de tempo e pressão da banca FGV. Escolha entre simulados objetivos de 1ª Fase ou práticos de 2ª Fase.
            </p>
          </div>

          {/* Quick selection panels */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* 1st Phase Panel */}
            <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm flex flex-col justify-between space-y-4 hover:shadow-md transition-shadow">
              <div className="space-y-2">
                <span className="text-[10px] font-black uppercase text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full w-fit block">
                  Objetivo (1ª Fase)
                </span>
                <h3 className="text-base font-black text-slate-800">Simulado Dinâmico 1ª Fase</h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Contém questões objetivas de múltipla escolha extraídas de provas oficiais da OAB. Inclui cronômetro ativo, painel de navegação de gabarito e resultado de aprovação instantâneo.
                </p>
                <div className="pt-2 text-xs text-slate-400 font-medium space-y-1">
                  <p>• Duração simulada: 5 horas (máxima)</p>
                  <p>• Exigido para aprovação: 50% de acertos</p>
                  <p>• Questões aleatórias por disciplina</p>
                </div>
              </div>

              <button
                onClick={handleStart1aFase}
                className="w-full bg-oab-primary hover:bg-slate-800 text-white font-bold text-xs py-2.5 rounded-lg flex items-center justify-center space-x-1.5 cursor-pointer shadow transition-colors"
                id="btn-start-1a-sim"
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                <span>Iniciar Simulado 1ª Fase</span>
              </button>
            </div>

            {/* 2nd Phase Panel */}
            <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm flex flex-col justify-between space-y-4 hover:shadow-md transition-shadow">
              <div className="space-y-2">
                <span className="text-[10px] font-black uppercase text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full w-fit block">
                  Prático-Profissional (2ª Fase)
                </span>
                <h3 className="text-base font-black text-slate-800">Simulado Completo 2ª Fase</h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Redija uma peça processual inteira e responda a questões discursivas baseadas no seu foco jurídico escolhido. Avalia formalmente a estrutura do esqueleto da petição.
                </p>
                <div className="pt-2 text-xs text-slate-400 font-medium space-y-1">
                  <p>• Área temática: {progress.selectedSecondPhaseArea}</p>
                  <p>• Peça e Questões Discursivas inclusas</p>
                  <p>• Avaliador de espelho de prova integrado</p>
                </div>
              </div>

              <button
                onClick={handleStart2aFase}
                className="w-full bg-oab-primary hover:bg-slate-800 text-white font-bold text-xs py-2.5 rounded-lg flex items-center justify-center space-x-1.5 cursor-pointer shadow transition-colors"
                id="btn-start-2a-sim"
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                <span>Iniciar Simulado 2ª Fase</span>
              </button>
            </div>
          </div>

          {/* Historical Results Logs */}
          <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100" id="simulated-history">
            <h3 className="text-sm font-black text-slate-800 border-b border-slate-100 pb-3 mb-4 flex items-center gap-1.5">
              <History className="h-4.5 w-4.5 text-oab-accent" />
              Histórico Geral de Tentativas Realizadas
            </h3>

            {progress.simulatedExamsHistory.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                Nenhum simulado registrado no histórico. Inicie um dos testes acima para registrar seu desempenho acadêmico!
              </div>
            ) : (
              <div className="space-y-3.5">
                {progress.simulatedExamsHistory.map((sim) => (
                  <div key={sim.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${sim.type === '1a Fase' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'}`}>
                          {sim.type}
                        </span>
                        <span className="text-xs font-mono text-slate-400">{sim.date}</span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-800">{sim.title}</h4>
                      <p className="text-xs text-slate-500 max-w-2xl leading-relaxed italic">
                        &ldquo;{sim.feedback}&rdquo;
                      </p>
                    </div>

                    <div className="flex items-center gap-4 shrink-0 justify-between md:justify-end border-t md:border-t-0 pt-2.5 md:pt-0">
                      <div className="text-right">
                        <span className="block text-[10px] text-slate-400 font-bold uppercase">Tempo</span>
                        <span className="text-xs font-semibold text-slate-700">{sim.timeSpentMinutes} min</span>
                      </div>
                      <div className="text-right">
                        <span className="block text-[10px] text-slate-400 font-bold uppercase">Resultado</span>
                        <span className="text-sm font-black text-slate-800">
                          {sim.score} <span className="text-slate-400 font-medium">de {sim.total}</span> ({sim.percentage}%)
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {/* 2. Taking 1ª Fase Simulation */}
      {activeSession === '1aFase' && sessionQuestions.length > 0 && (
        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-150 space-y-6" id="active-sim-1a">
          {/* Header Bar */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="space-y-0.5">
              <span className="text-[10px] uppercase font-black text-blue-600">Simulado de 1ª Fase Ativo</span>
              <h3 className="text-sm font-bold text-slate-800">Questão {currentIdx + 1} de {sessionQuestions.length}</h3>
            </div>

            {/* stopwatch */}
            <div className="flex items-center space-x-2 bg-red-50 border border-red-200 px-3 py-1.5 rounded-xl text-red-600 font-mono text-xs font-black">
              <Clock className="h-4 w-4 animate-pulse" />
              <span>{formatTime(secondsElapsed)}</span>
            </div>
          </div>

          {/* Question navigator dots */}
          <div className="flex flex-wrap gap-1.5 justify-center py-2 bg-slate-50 rounded-xl border border-slate-100">
            {sessionQuestions.map((q, idx) => {
              const isSelected = selectedAnswers[q.id] !== undefined;
              const isCurrent = currentIdx === idx;
              return (
                <button
                  key={q.id}
                  onClick={() => setCurrentIdx(idx)}
                  className={`
                    h-8 w-8 rounded-full text-xs font-bold transition-all flex items-center justify-center cursor-pointer
                    ${isCurrent 
                      ? 'bg-oab-primary text-white font-black scale-105 shadow' 
                      : isSelected 
                        ? 'bg-oab-accent text-oab-primary font-bold' 
                        : 'bg-white border border-slate-200 text-slate-500 hover:bg-slate-50'
                    }
                  `}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>

          {/* Question statement card */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded border border-slate-150">
                {sessionQuestions[currentIdx].discipline}
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {sessionQuestions[currentIdx].exam}
              </span>
            </div>

            <p className="text-xs text-slate-800 leading-relaxed font-semibold">
              {sessionQuestions[currentIdx].statement}
            </p>

            {/* Option selectors */}
            <div className="space-y-2.5">
              {sessionQuestions[currentIdx].options.map((opt, oIdx) => {
                const isSelected = selectedAnswers[sessionQuestions[currentIdx].id] === oIdx;
                return (
                  <button
                    key={oIdx}
                    onClick={() => handleSelectAnswer(sessionQuestions[currentIdx].id, oIdx)}
                    className={`
                      w-full text-left p-3.5 rounded-xl border text-xs transition-all flex items-start gap-2.5 cursor-pointer
                      ${isSelected 
                        ? 'bg-oab-accent/15 border-oab-accent text-oab-primary font-bold shadow-sm' 
                        : 'bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300 text-slate-700'
                      }
                    `}
                  >
                    <span className={`
                      font-extrabold font-mono uppercase rounded-md px-2 py-0.5 text-[10px] shrink-0
                      ${isSelected ? 'bg-oab-accent text-oab-primary font-black' : 'bg-slate-100 text-slate-500'}
                    `}>
                      {String.fromCharCode(65 + oIdx)}
                    </span>
                    <span className="flex-1">{opt}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Lower control buttons */}
          <div className="flex justify-between items-center pt-4 border-t border-slate-100">
            <button
              onClick={handlePrevQuestion}
              disabled={currentIdx === 0}
              className={`
                px-4 py-2 border rounded-lg text-xs font-bold flex items-center space-x-1
                ${currentIdx === 0 ? 'text-slate-300 border-slate-100 cursor-not-allowed' : 'text-slate-600 border-slate-200 hover:bg-slate-50 cursor-pointer'}
              `}
            >
              <ChevronLeft className="h-4 w-4" />
              <span>Anterior</span>
            </button>

            {currentIdx === sessionQuestions.length - 1 ? (
              <button
                onClick={() => setShowConfirmSubmit(true)}
                className="bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-xs py-2 px-5 rounded-lg flex items-center space-x-1 cursor-pointer"
                id="btn-trigger-submit-sim"
              >
                <CheckCircle className="h-4 w-4" />
                <span>Finalizar Simulado</span>
              </button>
            ) : (
              <button
                onClick={handleNextQuestion}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg text-xs flex items-center space-x-1 cursor-pointer"
              >
                <span>Próxima</span>
                <ChevronRight className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Confirm submit Dialog Overlay */}
          {showConfirmSubmit && (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h4 className="text-sm font-extrabold text-slate-800">Deseja realmente finalizar?</h4>
                  <button onClick={() => setShowConfirmSubmit(false)} className="text-slate-400 hover:text-slate-600">
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed">
                  Você respondeu {Object.keys(selectedAnswers).length} de {sessionQuestions.length} questões disponíveis. Após finalizar, suas respostas serão computadas e salvas definitivamente no seu histórico de simulados.
                </p>

                <div className="flex justify-end space-x-3.5 pt-2">
                  <button
                    onClick={() => setShowConfirmSubmit(false)}
                    className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 font-bold text-xs py-2 px-4 rounded-lg cursor-pointer"
                  >
                    Voltar ao Teste
                  </button>
                  <button
                    onClick={handleSubmit1aFase}
                    className="bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-xs py-2 px-4 rounded-lg cursor-pointer"
                    id="btn-confirm-submit-sim"
                  >
                    Sim, Enviar Respostas
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      )}

      {/* 3. Taking 2ª Fase Simulation */}
      {activeSession === '2aFase' && (
        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-150 space-y-6" id="active-sim-2a">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="space-y-0.5">
              <span className="text-[10px] uppercase font-black text-purple-600">Simulado de 2ª Fase Ativo</span>
              <h3 className="text-sm font-bold text-slate-800">Caderno de Peça & Questões Discursivas</h3>
            </div>

            <div className="flex items-center space-x-2 bg-red-50 border border-red-200 px-3 py-1.5 rounded-xl text-red-600 font-mono text-xs font-black">
              <Clock className="h-4 w-4 animate-pulse" />
              <span>{formatTime(secondsElapsed)}</span>
            </div>
          </div>

          <form onSubmit={handleSubmit2aFase} className="space-y-5">
            {/* Case draft guidelines */}
            <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-100 text-xs text-slate-700 leading-relaxed space-y-2">
              <p className="font-extrabold text-amber-800 flex items-center">
                <AlertTriangle className="h-4.5 w-4.5 mr-1" />
                Caso Prático Recomendado: Apelação Criminal ({progress.selectedSecondPhaseArea})
              </p>
              <p>
                <strong>Enunciado:</strong> O réu Júlio foi condenado em primeira instância pelo crime de Roubo Simples à pena de 4 anos e 6 meses de reclusão em regime inicial fechado. O magistrado sentenciante justificou o regime exclusivamente com base na gravidade abstrata do delito de roubo. Elabore a peça processual de Apelação de forma a impugnar o regime de cumprimento e pleitear o regime inicial semiaberto.
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-600">Espaço da Peça Prática (5,0 pontos)</label>
              <textarea
                value={draftPiece}
                onChange={(e) => setDraftPiece(e.target.value)}
                placeholder="Redija a interposição da Apelação endereçada ao juiz singular e, em seguida, as Razões Recursais endereçadas ao Tribunal de Justiça..."
                className="w-full font-mono text-xs border border-slate-200 rounded-xl p-3.5 bg-slate-50 min-h-[180px] focus:outline-none focus:ring-1 focus:ring-oab-accent"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-600">Espaço das Questões Discursivas (5,0 pontos)</label>
              <textarea
                value={draftAnswers}
                onChange={(e) => setDraftAnswers(e.target.value)}
                placeholder="Responda detalhadamente fundamentando com as normas cabíveis e indicando incisos do Código Penal correspondentes..."
                className="w-full font-mono text-xs border border-slate-200 rounded-xl p-3.5 bg-slate-50 min-h-[120px] focus:outline-none focus:ring-1 focus:ring-oab-accent"
                required
              />
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setActiveSession('none')}
                className="text-xs text-slate-500 hover:text-slate-800 font-semibold"
              >
                Desistir do Simulado
              </button>

              <button
                type="submit"
                className="bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs py-2 px-5 rounded-lg flex items-center space-x-1 cursor-pointer"
                id="btn-submit-2a-sim"
              >
                <FileCheck className="h-4 w-4" />
                <span>Finalizar & Enviar Peça</span>
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}
