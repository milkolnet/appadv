/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Scale,
  Bookmark,
  BookmarkCheck,
  Search,
  CheckCircle,
  FileText,
  AlertTriangle,
  FileCheck,
  Award
} from 'lucide-react';
import { JuridicalPiece, StudentProgress } from '../types';

interface LawPiecesProps {
  pieces: JuridicalPiece[];
  progress: StudentProgress;
  onToggleFavoritePiece: (pieceId: string) => void;
  onSaveActivity: (tab: string, title: string, sectionId?: string, itemId?: string) => void;
}

export default function LawPieces({
  pieces,
  progress,
  onToggleFavoritePiece,
  onSaveActivity
}: LawPiecesProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPiece, setSelectedPiece] = useState<JuridicalPiece>(pieces[0]);
  const [onlyFavorites, setOnlyFavorites] = useState(false);

  // Filter pieces list
  const filteredPieces = pieces.filter((piece) => {
    const matchesSearch = piece.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          piece.area.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFav = !onlyFavorites || progress.favoritePieces.includes(piece.id);
    return matchesSearch && matchesFav;
  });

  const handleSelectPiece = (piece: JuridicalPiece) => {
    setSelectedPiece(piece);
    onSaveActivity('Peças', `Analisou Peça: ${piece.title}`, 'piece-' + piece.id);
  };

  return (
    <div id="law-pieces-container" className="space-y-6">
      
      {/* Overview block */}
      <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-800 flex items-center">
            <Scale className="h-5.5 w-5.5 mr-2 text-oab-accent" />
            Biblioteca de Peças Processuais (2ª Fase)
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Estude e domine o endereçamento, fundamentação fática, teses de defesa e os pedidos formais das peças mais cotadas na 2ª Fase OAB.
          </p>
        </div>

        <button
          onClick={() => setOnlyFavorites(!onlyFavorites)}
          className={`
            px-4 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center space-x-1.5 shrink-0
            ${onlyFavorites 
              ? 'bg-amber-50 border-amber-300 text-amber-600 font-extrabold' 
              : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
            }
          `}
          id="btn-filter-fav-pieces"
        >
          <Bookmark className="h-4 w-4" />
          <span>{onlyFavorites ? 'Todas as Peças' : 'Minhas Peças Favoritas'}</span>
        </button>
      </div>

      {/* Grid search and workspace layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="pieces-workspace">
        
        {/* Left Column: catalog list */}
        <div className="lg:col-span-4 bg-white rounded-xl p-4 shadow-sm border border-slate-100 h-fit space-y-3">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar por nome ou área..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
              id="input-piece-search"
            />
          </div>

          <div className="space-y-2" id="pieces-catalog-list">
            {filteredPieces.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                Nenhuma peça coincide com a pesquisa ou foi marcada como favorita.
              </div>
            ) : (
              filteredPieces.map((piece) => {
                const isSelected = selectedPiece.id === piece.id;
                const isFav = progress.favoritePieces.includes(piece.id);
                return (
                  <div
                    key={piece.id}
                    onClick={() => handleSelectPiece(piece)}
                    className={`
                      p-3 rounded-lg border text-xs cursor-pointer transition-all flex items-center justify-between
                      ${isSelected 
                        ? 'bg-oab-primary border-oab-primary text-white font-bold' 
                        : 'bg-slate-50 border-slate-150 text-slate-700 hover:bg-slate-100'
                      }
                    `}
                    id={`piece-catalog-item-${piece.id}`}
                  >
                    <div>
                      <span className={`text-[9px] uppercase font-black block ${isSelected ? 'text-oab-accent' : 'text-slate-400'}`}>
                        {piece.area}
                      </span>
                      <h4 className="font-bold">{piece.title}</h4>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavoritePiece(piece.id);
                      }}
                      className="p-1 rounded text-slate-300 hover:text-amber-500 cursor-pointer"
                    >
                      {isFav ? (
                        <BookmarkCheck className="h-4 w-4 text-amber-500 fill-current" />
                      ) : (
                        <Bookmark className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: detailed structure and templates */}
        <div className="lg:col-span-8 bg-white rounded-xl p-5 shadow-sm border border-slate-100 space-y-6" id="piece-catalog-detail">
          {selectedPiece ? (
            <>
              {/* title panel */}
              <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                <div>
                  <span className="text-[10px] uppercase font-black text-oab-accent tracking-wider bg-amber-50 px-2 py-0.5 rounded">
                    {selectedPiece.area}
                  </span>
                  <h3 className="text-base font-extrabold text-slate-800 mt-2">{selectedPiece.title}</h3>
                </div>

                <button
                  onClick={() => onToggleFavoritePiece(selectedPiece.id)}
                  className="bg-slate-50 hover:bg-slate-100 border border-slate-200 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1 cursor-pointer transition-colors"
                  id={`btn-detail-fav-piece-${selectedPiece.id}`}
                >
                  {progress.favoritePieces.includes(selectedPiece.id) ? (
                    <>
                      <BookmarkCheck className="h-4 w-4 text-amber-500 fill-current" />
                      <span>Salvo nos Favoritos</span>
                    </>
                  ) : (
                    <>
                      <Bookmark className="h-4 w-4 text-slate-400" />
                      <span>Salvar nos Favoritos</span>
                    </>
                  )}
                </button>
              </div>

              {/* structural breakdown step card */}
              <div className="space-y-3">
                <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                  Estrutura Lógica de Montagem (Passo a Passo)
                </h4>
                <div className="space-y-2">
                  {selectedPiece.structure.map((sect, sIdx) => (
                    <div key={sIdx} className="p-3 bg-slate-50/70 border border-slate-200 rounded-lg text-xs text-slate-700 leading-relaxed">
                      <span className="font-extrabold text-slate-800 block mb-0.5">{sect.section}</span>
                      <p>{sect.content}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* formal templates */}
              <div className="space-y-3">
                <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center justify-between">
                  <span>Esqueleto da Petição de Endereçamento</span>
                  <span className="text-[10px] font-mono text-slate-400">Padrão OAB/FGV</span>
                </h4>
                <div className="bg-slate-900 text-slate-300 p-4 rounded-xl font-mono text-[11px] leading-relaxed whitespace-pre-wrap max-h-[250px] overflow-y-auto border border-slate-800">
                  {selectedPiece.template}
                </div>
              </div>

              {/* structural checkpoints */}
              <div className="space-y-3">
                <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                  Lista de Verificação (Checklist para o Esqueleto)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {selectedPiece.checklist.map((item) => (
                    <div key={item.id} className="flex items-center space-x-2 p-2.5 bg-slate-50/50 rounded-lg border border-slate-150 text-xs">
                      <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0" />
                      <span className="text-slate-600 font-medium">{item.item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Golden recommendations */}
              <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-100 text-xs text-slate-700 space-y-1">
                <span className="font-extrabold text-amber-800 flex items-center">
                  <AlertTriangle className="h-4.5 w-4.5 mr-1" /> Requisitos de Pontuação na Prova Prática:
                </span>
                <ul className="list-disc pl-5 space-y-1 text-slate-600">
                  {selectedPiece.tips.map((tip, idx) => (
                    <li key={idx}>{tip}</li>
                  ))}
                </ul>
              </div>
            </>
          ) : (
            <div className="text-center py-16 text-slate-400 bg-white rounded-xl border border-slate-100">
              Selecione uma peça jurídica no catálogo esquerdo para estudar sua estrutura e modelo.
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
