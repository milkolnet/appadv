/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  BookOpenCheck,
  Search,
  Bookmark,
  BookmarkCheck,
  CheckCircle,
  XCircle,
  Filter,
  RefreshCw,
  Award,
  BookOpen,
  Check,
  Crown,
  X,
  Lock,
  ArrowLeft,
  ArrowRight,
  HelpCircle,
  Flame,
  ThumbsUp,
  Award as Trophy,
  Play,
  BarChart2,
  AlertTriangle,
  Lightbulb,
  Sparkles
} from 'lucide-react';
import { Question, StudentProgress } from '../types';

interface QuestionsBankProps {
  questions: Question[];
  progress: StudentProgress;
  onAnswerQuestion: (questionId: string, optionIdx: number, isCorrect: boolean) => void;
  onToggleFavoriteQuestion: (questionId: string) => void;
  onSaveActivity: (tab: string, title: string, sectionId?: string, itemId?: string) => void;
  userPlan?: string;
  onNavigateToTab?: (tab: string) => void;
}

export default function QuestionsBank({
  questions,
  progress,
  onAnswerQuestion,
  onToggleFavoriteQuestion,
  onSaveActivity,
  userPlan = 'gratuito',
  onNavigateToTab
}: QuestionsBankProps) {
  // Filter States
  const [selectedDiscipline, setSelectedDiscipline] = useState<string>('Todas');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('Todas');
  const [selectedPhase, setSelectedPhase] = useState<string>('Todas');
  const [selectedStatus, setSelectedStatus] = useState<string>('Todos'); // 'Todos' | 'unanswered' | 'correct' | 'incorrect' | 'favorite'
  const [selectedTrainingType, setSelectedTrainingType] = useState<string>('objetivas'); // 'objetivas' | 'rapido' | 'erradas'
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Active Resolution Workspace States
  const [activeQuestionId, setActiveQuestionId] = useState<string | null>(null);
  const [sprintQuestions, setSprintQuestions] = useState<Question[]>([]);
  const [sprintIdx, setSprintIdx] = useState<number>(0);
  const [sprintType, setSprintType] = useState<'individual' | 'rapido' | 'erradas'>('individual');
  const [selectedOptionIdx, setSelectedOptionIdx] = useState<number | null>(null);
  const [isAnswerConfirmed, setIsAnswerConfirmed] = useState<boolean>(false);

  // Sub-tabs / sections inside Questions tab
  const [activeSubTab, setActiveSubTab] = useState<'banco' | 'desempenho'>('banco');

  // Paywall feedback state
  const [showPaywallLimit, setShowPaywallLimit] = useState<boolean>(false);

  // ----------------- CALCULA ESTATÍSTICAS DO ALUNO -----------------
  const answeredList = useMemo(() => Object.keys(progress.answeredQuestions), [progress.answeredQuestions]);
  const totalCorrect = useMemo(() => {
    return Object.values(progress.answeredQuestions).filter(a => a.isCorrect).length;
  }, [progress.answeredQuestions]);
  const totalIncorrect = useMemo(() => answeredList.length - totalCorrect, [answeredList, totalCorrect]);
  const accuracyRate = useMemo(() => {
    return answeredList.length > 0 ? Math.round((totalCorrect / answeredList.length) * 100) : 0;
  }, [answeredList, totalCorrect]);

  // Unique list of disciplines
  const disciplinesList = useMemo(() => {
    return Array.from(new Set(questions.map(q => q.discipline)));
  }, [questions]);

  // Group performance by discipline
  const performanceByDiscipline = useMemo(() => {
    const map: { [discipline: string]: { total: number; correct: number; incorrect: number } } = {};
    
    // Initialize for all disciplines
    disciplinesList.forEach(d => {
      map[d] = { total: 0, correct: 0, incorrect: 0 };
    });

    // Count answers
    Object.entries(progress.answeredQuestions).forEach(([qId, ans]) => {
      const q = questions.find(item => item.id === qId);
      if (q) {
        if (!map[q.discipline]) {
          map[q.discipline] = { total: 0, correct: 0, incorrect: 0 };
        }
        map[q.discipline].total += 1;
        if (ans.isCorrect) {
          map[q.discipline].correct += 1;
        } else {
          map[q.discipline].incorrect += 1;
        }
      }
    });

    return Object.entries(map).map(([discipline, stats]) => {
      const rate = stats.total > 0 ? Math.round((stats.correct / stats.total) * 100) : 0;
      return {
        discipline,
        ...stats,
        rate
      };
    }).sort((a, b) => b.total - a.total || b.rate - a.rate);
  }, [questions, progress.answeredQuestions, disciplinesList]);

  // Detect critical disciplines (under 60% accuracy with at least 1 answered question)
  const worstDisciplineObj = useMemo(() => {
    const answeredDeps = performanceByDiscipline.filter(d => d.total > 0);
    if (answeredDeps.length === 0) return null;
    return [...answeredDeps].sort((a, b) => a.rate - b.rate || b.total - a.total)[0];
  }, [performanceByDiscipline]);

  // ----------------- FILTRO DE QUESTÕES -----------------
  const filteredQuestions = useMemo(() => {
    return questions.filter((q) => {
      // 1. Discipline
      if (selectedDiscipline !== 'Todas' && q.discipline !== selectedDiscipline) {
        return false;
      }
      // 2. Difficulty
      if (selectedDifficulty !== 'Todas' && q.difficulty !== selectedDifficulty) {
        return false;
      }
      // 3. Phase Filter
      const qPhase = q.phase || '1fase';
      if (selectedPhase !== 'Todas') {
        if (selectedPhase === '1fase' && qPhase !== '1fase') return false;
        if (selectedPhase === '2fase' && qPhase !== '2fase') return false;
      }
      // 4. Status Filter
      const ans = progress.answeredQuestions[q.id];
      const isFavorited = progress.favoriteQuestions.includes(q.id);
      if (selectedStatus === 'unanswered' && ans !== undefined) {
        return false;
      }
      if (selectedStatus === 'correct' && (!ans || !ans.isCorrect)) {
        return false;
      }
      if (selectedStatus === 'incorrect' && (!ans || ans.isCorrect)) {
        return false;
      }
      if (selectedStatus === 'favorite' && !isFavorited) {
        return false;
      }

      // 5. Search Text Query
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const textToSearch = `${q.statement} ${q.theme} ${q.discipline} ${q.explanation}`.toLowerCase();
        if (!textToSearch.includes(query)) {
          return false;
        }
      }

      return true;
    });
  }, [questions, progress.answeredQuestions, progress.favoriteQuestions, selectedDiscipline, selectedDifficulty, selectedPhase, selectedStatus, searchQuery]);

  // ----------------- RESET FILTROS -----------------
  const handleClearFilters = () => {
    setSelectedDiscipline('Todas');
    setSelectedDifficulty('Todas');
    setSelectedPhase('Todas');
    setSelectedStatus('Todos');
    setSearchQuery('');
  };

  // ----------------- INICIALIZAR TREINOS ESPECIAIS -----------------
  const handleStartTreinoRapido = () => {
    // Premium limits check
    if (userPlan === 'gratuito' && answeredList.length >= 10) {
      setShowPaywallLimit(true);
      return;
    }

    // Get unanswered questions (or fallback to any if all are answered)
    let available = questions.filter(q => progress.answeredQuestions[q.id] === undefined);
    if (available.length === 0) {
      available = [...questions];
    }

    // Shuffle and pick 5
    const shuffled = [...available].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, 5);

    if (selected.length > 0) {
      setSprintQuestions(selected);
      setSprintIdx(0);
      setSprintType('rapido');
      setSelectedOptionIdx(null);
      setIsAnswerConfirmed(false);
      setActiveQuestionId(selected[0].id);
      onSaveActivity('Questões', 'Iniciou Treino Rápido (5 questões)');
    }
  };

  const handleStartRevisaoErradas = () => {
    // Get all incorrectly answered questions
    const incorrectIds = Object.entries(progress.answeredQuestions)
      .filter(([_, ans]) => !ans.isCorrect)
      .map(([qId]) => qId);

    const available = questions.filter(q => incorrectIds.includes(q.id));

    if (available.length === 0) {
      alert("Você não possui nenhuma questão errada registrada para revisar!");
      return;
    }

    setSprintQuestions(available);
    setSprintIdx(0);
    setSprintType('erradas');
    setSelectedOptionIdx(null);
    setIsAnswerConfirmed(false);
    setActiveQuestionId(available[0].id);
    onSaveActivity('Questões', `Iniciou Revisão de Erradas (${available.length} questões)`);
  };

  const handleOpenIndividualQuestion = (q: Question) => {
    setSprintQuestions([q]);
    setSprintIdx(0);
    setSprintType('individual');
    
    // If already answered, load confirmed state
    const savedAns = progress.answeredQuestions[q.id];
    if (savedAns !== undefined) {
      setSelectedOptionIdx(savedAns.selectedOption);
      setIsAnswerConfirmed(true);
    } else {
      setSelectedOptionIdx(null);
      setIsAnswerConfirmed(false);
    }
    
    setActiveQuestionId(q.id);
  };

  // ----------------- FLUXO DE SUBMISSÃO DA RESPOSTA -----------------
  const handleAnswerSubmit = (q: Question) => {
    if (selectedOptionIdx === null) return;

    // Free plan constraints
    if (userPlan === 'gratuito') {
      const answeredToday = Object.keys(progress.answeredQuestions).length;
      if (answeredToday >= 10 && progress.answeredQuestions[q.id] === undefined) {
        setShowPaywallLimit(true);
        return;
      }
    }

    const isCorrect = q.correctIndex === selectedOptionIdx;
    onAnswerQuestion(q.id, selectedOptionIdx, isCorrect);
    setIsAnswerConfirmed(true);
    onSaveActivity('Questões', `Respondeu Questão: ${q.discipline} (${isCorrect ? 'Acertou' : 'Errou'})`, 'q-' + q.id);
  };

  // Navigation inside active sprint session
  const handleNextSprintQuestion = () => {
    const nextIdx = sprintIdx + 1;
    if (nextIdx < sprintQuestions.length) {
      setSprintIdx(nextIdx);
      const nextQ = sprintQuestions[nextIdx];
      
      const savedAns = progress.answeredQuestions[nextQ.id];
      if (savedAns !== undefined) {
        setSelectedOptionIdx(savedAns.selectedOption);
        setIsAnswerConfirmed(true);
      } else {
        setSelectedOptionIdx(null);
        setIsAnswerConfirmed(false);
      }
      setActiveQuestionId(nextQ.id);
    } else {
      // Finished session!
      alert("Sessão de treino concluída com sucesso!");
      setActiveQuestionId(null);
      setSprintQuestions([]);
    }
  };

  const handlePrevSprintQuestion = () => {
    const prevIdx = sprintIdx - 1;
    if (prevIdx >= 0) {
      setSprintIdx(prevIdx);
      const prevQ = sprintQuestions[prevIdx];
      
      const savedAns = progress.answeredQuestions[prevQ.id];
      if (savedAns !== undefined) {
        setSelectedOptionIdx(savedAns.selectedOption);
        setIsAnswerConfirmed(true);
      } else {
        setSelectedOptionIdx(null);
        setIsAnswerConfirmed(false);
      }
      setActiveQuestionId(prevQ.id);
    }
  };

  // Render variables
  const activeQuestion = useMemo(() => {
    if (!activeQuestionId) return null;
    return questions.find(q => q.id === activeQuestionId) || null;
  }, [activeQuestionId, questions]);

  return (
    <div id="questions-module-root" className="space-y-6">

      {/* DEMONSTRATION PAYWALL BANNER FOR FREE USERS */}
      {userPlan === 'gratuito' && (
        <div className="bg-gradient-to-r from-amber-500/10 to-[#D4AF37]/10 border-2 border-[#D4AF37]/40 rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm animate-fade-in">
          <div className="space-y-1">
            <span className="bg-[#D4AF37] text-slate-900 text-[9px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full font-mono">
              ★ MODO DEGUSTAÇÃO ★
            </span>
            <h3 className="font-serif font-extrabold text-sm text-slate-800 flex items-center gap-1.5 mt-1">
              Você está na versão gratuita ({10 - Math.min(10, answeredList.length)} de 10 tentativas restantes)
            </h3>
            <p className="text-xs text-slate-600 max-w-xl leading-relaxed">
              Responda a até 10 questões comentadas para avaliar o sistema. Assine o plano premium para liberar mais de 2.500 questões, simulados e estatísticas de desempenho acadêmico avançadas.
            </p>
          </div>
          {onNavigateToTab && (
            <button
              onClick={() => onNavigateToTab('monetizacao')}
              className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-4 py-2.5 rounded-lg text-xs tracking-wider uppercase transition-all shrink-0 cursor-pointer"
            >
              Liberar Questões Ilimitadas
            </button>
          )}
        </div>
      )}

      {/* STRATEGIC HEADER & METRICS SUMMARY */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="bg-slate-900 text-[#D4AF37] text-[10px] font-bold px-2.5 py-0.5 rounded uppercase tracking-wider">
              Treino Oficial
            </span>
            <span className="text-xs text-slate-400 font-semibold">• 1ª Fase OAB 2026</span>
          </div>
          <h2 className="text-xl font-serif font-black text-slate-900 flex items-center gap-2">
            <BookOpenCheck className="h-6 w-6 text-[#D4AF37]" />
            Banco de Questões Comentadas
          </h2>
          <p className="text-xs text-slate-500 max-w-lg leading-relaxed">
            Resolva questões anteriores da FGV com correção imediata, justificativa legal e acompanhamento de acertos por disciplina.
          </p>
        </div>

        {/* Dynamic Performance Bubbles */}
        <div className="flex flex-wrap gap-3 w-full md:w-auto shrink-0">
          <div className="flex-1 min-w-[100px] bg-slate-50 border border-slate-100 p-3 rounded-xl text-center">
            <span className="block text-[9px] text-slate-400 font-black uppercase tracking-wider">Resolvidas</span>
            <span className="text-lg font-black text-slate-800 font-mono">{answeredList.length}</span>
          </div>
          <div className="flex-1 min-w-[100px] bg-emerald-50 border border-emerald-100 p-3 rounded-xl text-center">
            <span className="block text-[9px] text-emerald-600 font-black uppercase tracking-wider">Aproveitamento</span>
            <span className="text-lg font-black text-emerald-800 font-mono">{accuracyRate}%</span>
          </div>
          <div className="flex-1 min-w-[100px] bg-amber-50 border border-amber-100 p-3 rounded-xl text-center">
            <span className="block text-[9px] text-amber-700 font-black uppercase tracking-wider">Favoritas</span>
            <span className="text-lg font-black text-slate-800 font-mono">{progress.favoriteQuestions.length}</span>
          </div>
        </div>
      </div>

      {/* SUB-TABS NAVIGATION (BANCO DE QUESTÕES VS DESEMPENHO ACADÊMICO) */}
      <div className="flex border-b border-slate-200 gap-1">
        <button
          onClick={() => {
            setActiveSubTab('banco');
            setActiveQuestionId(null); // return to lists
          }}
          className={`px-5 py-3 font-semibold text-xs tracking-wider uppercase transition-colors flex items-center gap-2 border-b-2 cursor-pointer
            ${activeSubTab === 'banco' 
              ? 'border-slate-900 text-slate-900 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
        >
          <BookOpen className="h-4 w-4" />
          Banco & Filtros
        </button>
        <button
          onClick={() => {
            setActiveSubTab('desempenho');
            setActiveQuestionId(null); // return to lists
          }}
          className={`px-5 py-3 font-semibold text-xs tracking-wider uppercase transition-colors flex items-center gap-2 border-b-2 cursor-pointer
            ${activeSubTab === 'desempenho' 
              ? 'border-slate-900 text-slate-900 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
        >
          <BarChart2 className="h-4 w-4" />
          Desempenho por Matéria
        </button>
      </div>

      {/* -------------------- VIEW 1: BANCO DE QUESTÕES E FILTROS -------------------- */}
      {activeSubTab === 'banco' && !activeQuestion && (
        <div className="space-y-6">
          
          {/* SPECIAL PRACTICE HOTBOX (TREINO RÁPIDO & REVISÃO) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Quick Practice Sprint */}
            <div className="bg-[#FAF9F6] border border-slate-200 p-5 rounded-xl flex flex-col justify-between hover:border-[#D4AF37] transition-all">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="bg-slate-900 text-white text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded font-mono">
                    TREINO EXCLUSIVO
                  </span>
                  <Flame className="h-3.5 w-3.5 text-amber-500 animate-pulse" />
                </div>
                <h4 className="text-sm font-black text-slate-800">Treino Rápido ⚡</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Gere instantaneamente uma bateria aleatória de <strong>5 questões não respondidas</strong> do banco para aquecer o cérebro.
                </p>
              </div>
              <button
                onClick={handleStartTreinoRapido}
                className="mt-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer uppercase tracking-wider transition-colors"
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                Iniciar Treino Rápido
              </button>
            </div>

            {/* Error Revision Sprint */}
            <div className={`border p-5 rounded-xl flex flex-col justify-between transition-all
              ${totalIncorrect > 0 
                ? 'bg-red-50/30 border-red-200 hover:border-red-400' 
                : 'bg-slate-50/50 border-slate-200 opacity-60'
              }`}
            >
              <div className="space-y-1.5">
                <span className="bg-red-600 text-white text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded font-mono inline-block">
                  NEUTRALIZAR ERROS
                </span>
                <h4 className="text-sm font-black text-slate-800">Revisão de Erradas 🚨</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Pratique novamente todas as questões que você já errou. Ideal para fixar o assunto e eliminar pontos cegos.
                </p>
              </div>
              <button
                onClick={handleStartRevisaoErradas}
                disabled={totalIncorrect === 0}
                className={`mt-4 font-bold text-xs py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 uppercase tracking-wider transition-colors
                  ${totalIncorrect > 0
                    ? 'bg-red-600 hover:bg-red-700 text-white cursor-pointer'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Refazer Erradas ({totalIncorrect})
              </button>
            </div>

            {/* Smart Advice Card */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-5 rounded-xl flex flex-col justify-between">
              <div className="space-y-1.5">
                <div className="flex items-center gap-1.5 text-amber-400 font-bold text-[10px] uppercase font-mono">
                  <Sparkles className="h-3.5 w-3.5" /> IA Recomendação
                </div>
                <h4 className="text-sm font-black text-white">Radar OAB de Foco</h4>
                {worstDisciplineObj ? (
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Seu desempenho em <strong className="text-amber-400">{worstDisciplineObj.discipline}</strong> está crítico ({worstDisciplineObj.rate}%). Sugerimos filtrar questões dessa matéria para subir sua média.
                  </p>
                ) : (
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Comece resolvendo pelo menos 5 questões de qualquer disciplina para receber uma análise em tempo real dos seus maiores gaps de aprendizado.
                  </p>
                )}
              </div>
              <button
                onClick={() => {
                  if (worstDisciplineObj) {
                    setSelectedDiscipline(worstDisciplineObj.discipline);
                    setSelectedStatus('unanswered');
                  } else {
                    setSelectedDiscipline('Ética Profissional');
                  }
                }}
                className="mt-4 bg-[#D4AF37] hover:bg-yellow-600 text-slate-900 font-extrabold text-xs py-2 px-3 rounded-lg text-center cursor-pointer uppercase tracking-wider transition-colors"
              >
                Focar em Vulnerabilidade
              </button>
            </div>

          </div>

          {/* FILTERS TOOLBAR */}
          <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100 space-y-4">
            <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider flex items-center gap-1.5">
              <Filter className="h-4 w-4 text-slate-400" />
              Painel de Filtros Avançados
            </h3>
            
            {/* Main Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
              
              {/* Search input */}
              <div className="relative md:col-span-2">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Buscar palavras-chave, lei ou tema..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-900 focus:border-slate-900"
                />
              </div>

              {/* Discipline dropdown */}
              <div>
                <select
                  value={selectedDiscipline}
                  onChange={(e) => setSelectedDiscipline(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 focus:outline-none cursor-pointer"
                >
                  <option value="Todas">Todas as Matérias</option>
                  {disciplinesList.map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              {/* Difficulty dropdown */}
              <div>
                <select
                  value={selectedDifficulty}
                  onChange={(e) => setSelectedDifficulty(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 focus:outline-none cursor-pointer"
                >
                  <option value="Todas">Dificuldade (Todas)</option>
                  <option value="Fácil">Fácil</option>
                  <option value="Média">Média</option>
                  <option value="Difícil">Difícil</option>
                </select>
              </div>

              {/* Phase selection */}
              <div>
                <select
                  value={selectedPhase}
                  onChange={(e) => setSelectedPhase(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 focus:outline-none cursor-pointer"
                >
                  <option value="Todas">Fases da OAB</option>
                  <option value="1fase">1ª Fase Objetiva</option>
                  <option value="2fase">2ª Fase Peça/Questões</option>
                </select>
              </div>

            </div>

            {/* Special category tabs */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
              <div className="flex flex-wrap gap-1.5">
                {[
                  { id: 'Todos', label: 'Todas as Questões' },
                  { id: 'unanswered', label: 'Não respondidas' },
                  { id: 'correct', label: 'Respondidas Corretas' },
                  { id: 'incorrect', label: 'Respondidas Erradas (Revisar)' },
                  { id: 'favorite', label: 'Favoritas ❤️' }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setSelectedStatus(tab.id)}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-all border cursor-pointer
                      ${selectedStatus === tab.id
                        ? 'bg-slate-950 border-slate-950 text-white font-bold shadow-xs'
                        : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                      }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <button
                onClick={handleClearFilters}
                className="text-slate-400 hover:text-slate-600 flex items-center gap-1 bg-slate-50 hover:bg-slate-100 px-3 py-1.5 rounded-lg transition-all font-semibold cursor-pointer"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Limpar Filtros
              </button>
            </div>

          </div>

          {/* LIST OF FILTERED QUESTIONS */}
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs font-bold text-slate-500 px-1">
              <span>{filteredQuestions.length} questões encontradas</span>
              <span>Exibindo de acordo com seus critérios de filtro</span>
            </div>

            {filteredQuestions.length === 0 ? (
              <div className="bg-white border border-slate-150 rounded-xl p-16 text-center text-slate-400">
                <Filter className="h-10 w-10 mx-auto text-slate-200 mb-3" />
                <h4 className="font-bold text-sm text-slate-700">Nenhuma questão corresponde aos filtros</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Tente desativar alguns filtros ou limpar a pesquisa para exibir mais questões do exame de ordem.
                </p>
                <button
                  onClick={handleClearFilters}
                  className="mt-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs px-4 py-2 rounded-lg transition-all"
                >
                  Limpar todos os filtros
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {filteredQuestions.map((q, idx) => {
                  const savedAns = progress.answeredQuestions[q.id];
                  const isAnswered = savedAns !== undefined;
                  const isCorrect = isAnswered && savedAns.isCorrect;
                  const isFavorited = progress.favoriteQuestions.includes(q.id);
                  const qPhase = q.phase || '1fase';

                  return (
                    <div
                      key={q.id}
                      className="bg-white hover:bg-slate-50/50 rounded-xl p-5 border border-slate-200 shadow-xs transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      {/* Meta context and title preview */}
                      <div className="space-y-2 flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-[9px] font-black uppercase tracking-wider text-[#0F172A] bg-slate-100 border border-slate-200 px-2 py-0.5 rounded">
                            {q.discipline}
                          </span>
                          <span className="text-[10px] font-semibold text-slate-400">
                            • {q.theme}
                          </span>
                          <span className="text-[10px] font-mono text-slate-400">
                            ({q.exam})
                          </span>
                          <span className={`text-[9px] font-bold uppercase px-1.5 py-0.2 rounded-full
                            ${q.difficulty === 'Fácil' ? 'bg-emerald-50 text-emerald-600' : q.difficulty === 'Média' ? 'bg-amber-50 text-amber-600' : 'bg-red-50 text-red-600'}`}
                          >
                            {q.difficulty}
                          </span>
                          <span className="text-[9px] bg-slate-100 text-slate-500 px-1.5 py-0.2 rounded">
                            {qPhase === '1fase' ? 'Objetiva A/B/C/D' : 'Escrita Peça/Dissertativa'}
                          </span>
                        </div>

                        {/* Question headline */}
                        <p className="text-xs text-slate-700 leading-relaxed font-semibold line-clamp-2 pr-6">
                          <span className="font-black text-slate-900 mr-1 text-sm">Q.</span>
                          {q.statement}
                        </p>
                      </div>

                      {/* Status badges and Resolution trigger action */}
                      <div className="flex items-center justify-between md:justify-end gap-3 border-t md:border-t-0 border-slate-100 pt-3 md:pt-0 shrink-0">
                        
                        {/* Status visual badge */}
                        <div className="flex items-center gap-1.5">
                          {isAnswered ? (
                            isCorrect ? (
                              <span className="bg-emerald-50 text-emerald-700 text-[10px] font-black uppercase tracking-wide px-2.5 py-1 rounded flex items-center gap-1">
                                <CheckCircle className="h-3.5 w-3.5" /> Acertou
                              </span>
                            ) : (
                              <span className="bg-red-50 text-red-700 text-[10px] font-black uppercase tracking-wide px-2.5 py-1 rounded flex items-center gap-1">
                                <XCircle className="h-3.5 w-3.5" /> Errou
                              </span>
                            )
                          ) : (
                            <span className="bg-blue-50 text-blue-700 text-[10px] font-black uppercase tracking-wide px-2.5 py-1 rounded">
                              Pendente
                            </span>
                          )}

                          {isFavorited && (
                            <span className="text-amber-500" title="Questão Favorita">
                              ❤️
                            </span>
                          )}
                        </div>

                        {/* Action trigger */}
                        <button
                          onClick={() => handleOpenIndividualQuestion(q)}
                          className={`font-black text-[10.5px] uppercase tracking-wider px-4 py-2 rounded-lg cursor-pointer transition-all
                            ${isAnswered 
                              ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200' 
                              : 'bg-[#0F172A] hover:bg-slate-800 text-[#D4AF37] hover:text-white'
                            }`}
                        >
                          {isAnswered ? 'Revisar Justificativa' : 'Resolver Questão ⚡'}
                        </button>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}

          </div>

        </div>
      )}

      {/* -------------------- VIEW 2: DESEMPENHO ACADÊMICO POR DISCIPLINA -------------------- */}
      {activeSubTab === 'desempenho' && (
        <div className="space-y-6">
          
          <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-150 space-y-4">
            <div>
              <h3 className="text-base font-black text-slate-800">Seu Boletim por Matéria</h3>
              <p className="text-xs text-slate-400">Análise de acertos e erros consolidada em cada matéria oficial testada</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {performanceByDiscipline.map((item, idx) => {
                let ratingColor = "bg-slate-200 text-slate-600";
                let progressBg = "bg-slate-200";
                let progressFill = "bg-slate-400";

                if (item.total > 0) {
                  if (item.rate >= 75) {
                    ratingColor = "bg-emerald-50 text-emerald-800 border border-emerald-100";
                    progressBg = "bg-emerald-100/50";
                    progressFill = "bg-emerald-600";
                  } else if (item.rate >= 50) {
                    ratingColor = "bg-amber-50 text-amber-800 border border-amber-100";
                    progressBg = "bg-amber-100/50";
                    progressFill = "bg-amber-500";
                  } else {
                    ratingColor = "bg-red-50 text-red-800 border border-red-100";
                    progressBg = "bg-red-100/50";
                    progressFill = "bg-red-500";
                  }
                }

                return (
                  <div
                    key={item.discipline}
                    className="p-4 bg-white border border-slate-200 rounded-xl flex flex-col justify-between hover:shadow-xs transition-all space-y-3"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-xs font-black text-slate-800">{item.discipline}</span>
                        <p className="text-[10px] text-slate-400 font-semibold">
                          {item.total} respondidas ({item.correct} acertos, {item.incorrect} erros)
                        </p>
                      </div>
                      <span className={`text-[10.5px] font-black px-2 py-0.5 rounded font-mono ${ratingColor}`}>
                        {item.total > 0 ? `${item.rate}%` : 'Sem dados'}
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="space-y-1">
                      <div className={`w-full h-2 rounded-full ${progressBg} overflow-hidden`}>
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${progressFill}`}
                          style={{ width: `${item.total > 0 ? item.rate : 0}%` }}
                        ></div>
                      </div>
                      <div className="flex justify-between text-[8.5px] font-bold text-slate-400 uppercase">
                        <span>Foco Necessário</span>
                        <span>Aprovado (&gt;60%)</span>
                      </div>
                    </div>
                  </div>
                );
              })}

            </div>
          </div>

        </div>
      )}

      {/* -------------------- RESOLUTION ACTIVE WORKSPACE (BLOCO 4) -------------------- */}
      {activeQuestion && (
        <div className="bg-white rounded-xl p-6 shadow-sm border-2 border-slate-200 space-y-6 animate-scale-in">
          
          {/* Header area */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setActiveQuestionId(null);
                  setSprintQuestions([]);
                }}
                className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-800 transition-colors cursor-pointer flex items-center gap-1.5 font-bold text-xs uppercase"
              >
                <ArrowLeft className="h-4 w-4" /> Voltar
              </button>
              
              <span className="text-slate-300">|</span>
              
              <span className="text-[10px] font-black uppercase text-slate-900 bg-amber-50 border border-[#D4AF37]/30 px-2.5 py-1 rounded font-mono">
                {activeQuestion.discipline}
              </span>
              <span className="text-[10px] text-slate-400 font-semibold">• {activeQuestion.theme}</span>
              <span className="text-[10px] text-slate-400 font-bold">({activeQuestion.exam})</span>
            </div>

            {/* Favorite inside workspace */}
            <div className="flex items-center gap-2">
              <span className={`text-[9.5px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full
                ${activeQuestion.difficulty === 'Fácil' ? 'bg-emerald-50 text-emerald-600' : activeQuestion.difficulty === 'Média' ? 'bg-amber-50 text-amber-600' : 'bg-red-50 text-red-600'}`}>
                {activeQuestion.difficulty}
              </span>
              
              <button
                onClick={() => onToggleFavoriteQuestion(activeQuestion.id)}
                className="p-1.5 rounded-lg border border-slate-200 text-slate-400 hover:text-amber-500 transition-colors cursor-pointer flex items-center gap-1 text-[10.5px] font-bold"
                title={progress.favoriteQuestions.includes(activeQuestion.id) ? "Remover dos favoritos" : "Adicionar aos favoritos"}
              >
                {progress.favoriteQuestions.includes(activeQuestion.id) ? (
                  <>
                    <BookmarkCheck className="h-4 w-4 text-amber-500 fill-current" />
                    <span className="text-slate-700">Favoritada</span>
                  </>
                ) : (
                  <>
                    <Bookmark className="h-4 w-4" />
                    <span>Favoritar</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Sequential Sprint tracker progress bar */}
          {sprintQuestions.length > 1 && (
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-150 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-extrabold text-slate-700 uppercase tracking-wider font-mono">
                  Sessão de Treino ({sprintType === 'rapido' ? 'Treino Rápido' : 'Revisão de Erradas'})
                </span>
                <span className="font-bold text-slate-500 font-mono">
                  Questão {sprintIdx + 1} de {sprintQuestions.length}
                </span>
              </div>
              <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-slate-900 rounded-full transition-all duration-300"
                  style={{ width: `${((sprintIdx + 1) / sprintQuestions.length) * 100}%` }}
                ></div>
              </div>
            </div>
          )}

          {/* Statement prompt */}
          <div className="space-y-3">
            <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Enunciado da Questão:</h4>
            <p className="text-sm font-semibold text-slate-800 leading-relaxed font-serif bg-slate-50/50 p-4 border border-slate-100 rounded-xl">
              {activeQuestion.statement}
            </p>
          </div>

          {/* Options Selectors */}
          <div className="space-y-3">
            <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Alternativas:</h4>
            
            <div className="grid grid-cols-1 gap-2.5">
              {activeQuestion.options.map((option, idx) => {
                const isSelected = selectedOptionIdx === idx;
                const isCorrect = activeQuestion.correctIndex === idx;
                
                let optStyle = "bg-white border-slate-200 hover:bg-slate-50 text-slate-700";
                let badgeStyle = "bg-slate-100 text-slate-600";
                
                if (isAnswerConfirmed) {
                  if (isCorrect) {
                    optStyle = "bg-emerald-50 border-emerald-300 text-emerald-800 font-semibold ring-1 ring-emerald-300";
                    badgeStyle = "bg-emerald-200 text-emerald-800";
                  } else if (isSelected) {
                    optStyle = "bg-red-50 border-red-300 text-red-800 font-semibold ring-1 ring-red-300";
                    badgeStyle = "bg-red-200 text-red-800";
                  } else {
                    optStyle = "bg-white border-slate-100 text-slate-450 opacity-50";
                  }
                } else if (isSelected) {
                  optStyle = "bg-slate-950 border-slate-950 text-white font-semibold shadow-xs ring-1 ring-slate-950";
                  badgeStyle = "bg-white/20 text-white";
                }

                return (
                  <button
                    key={idx}
                    disabled={isAnswerConfirmed}
                    onClick={() => setSelectedOptionIdx(idx)}
                    className={`w-full text-left p-4 rounded-xl border text-xs transition-all flex items-start gap-3
                      ${optStyle} ${!isAnswerConfirmed ? 'cursor-pointer' : 'cursor-default'}`}
                  >
                    <span className={`font-extrabold font-mono uppercase rounded-lg px-2 py-0.5 text-[10.5px] shrink-0 ${badgeStyle}`}>
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span className="flex-1 leading-relaxed pr-6">{option}</span>
                    
                    {isAnswerConfirmed && isCorrect && (
                      <Check className="h-4.5 w-4.5 text-emerald-600 ml-auto shrink-0" />
                    )}
                    {isAnswerConfirmed && isSelected && !isCorrect && (
                      <X className="h-4.5 w-4.5 text-red-600 ml-auto shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Immediate correction banner / explanation */}
          {isAnswerConfirmed && (
            <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 space-y-4 animate-fadeIn">
              
              {/* Correctness notification banner */}
              <div className="flex items-center gap-2.5">
                {selectedOptionIdx === activeQuestion.correctIndex ? (
                  <div className="bg-emerald-100 text-emerald-800 text-xs font-black uppercase tracking-wider px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                    <CheckCircle className="h-4 w-4" /> Gabarito Correto! +10XP 🏆
                  </div>
                ) : (
                  <div className="bg-red-100 text-red-800 text-xs font-black uppercase tracking-wider px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                    <XCircle className="h-4 w-4" /> Resposta Incorreta! ❌
                  </div>
                )}
                
                <span className="text-xs text-slate-500 font-semibold font-mono">
                  Gabarito oficial: <strong className="text-slate-800 uppercase font-bold">{String.fromCharCode(65 + activeQuestion.correctIndex)}</strong>
                </span>
              </div>

              {/* Legal explanation */}
              <div className="space-y-1.5 pt-1.5 border-t border-slate-200/60">
                <h5 className="text-xs font-black uppercase text-slate-800 flex items-center gap-1.5">
                  <BookOpen className="h-4 w-4 text-[#D4AF37]" />
                  Fundamentação Jurídica & Gabarito Comentado:
                </h5>
                <p className="text-xs text-slate-600 leading-relaxed bg-white p-3 border border-slate-150 rounded-lg">
                  {activeQuestion.explanation}
                </p>
              </div>

            </div>
          )}

          {/* Action buttons footer */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-100">
            <button
              onClick={() => {
                setActiveQuestionId(null);
                setSprintQuestions([]);
              }}
              className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-250 font-bold text-xs px-5 py-2.5 rounded-lg uppercase tracking-wider transition-all cursor-pointer"
            >
              Voltar à Lista
            </button>

            <div className="flex gap-2">
              
              {/* If not confirmed, render "CONFIRMAR" */}
              {!isAnswerConfirmed ? (
                <button
                  onClick={() => handleAnswerSubmit(activeQuestion)}
                  disabled={selectedOptionIdx === null}
                  className={`font-black text-xs px-6 py-2.5 rounded-lg uppercase tracking-widest transition-all
                    ${selectedOptionIdx !== null
                      ? 'bg-slate-950 text-[#D4AF37] hover:bg-slate-800 cursor-pointer shadow-xs'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    }`}
                >
                  Confirmar Resposta 🎯
                </button>
              ) : (
                /* Sequential or single next trigger */
                sprintQuestions.length > 1 ? (
                  <div className="flex gap-2">
                    {sprintIdx > 0 && (
                      <button
                        onClick={handlePrevSprintQuestion}
                        className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs px-4 py-2.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <ArrowLeft className="h-3.5 w-3.5" /> Anterior
                      </button>
                    )}
                    <button
                      onClick={handleNextSprintQuestion}
                      className="bg-[#0F172A] hover:bg-slate-800 text-[#D4AF37] hover:text-white font-black text-xs px-5 py-2.5 rounded-lg uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      {sprintIdx === sprintQuestions.length - 1 ? 'Concluir Treino' : 'Próxima Questão'}
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      // Move to another random unanswered question
                      const nextCandidates = questions.filter(item => item.id !== activeQuestion.id && progress.answeredQuestions[item.id] === undefined);
                      if (nextCandidates.length > 0) {
                        const randomNext = nextCandidates[Math.floor(Math.random() * nextCandidates.length)];
                        handleOpenIndividualQuestion(randomNext);
                      } else {
                        setActiveQuestionId(null);
                        setSprintQuestions([]);
                      }
                    }}
                    className="bg-[#0F172A] hover:bg-slate-800 text-[#D4AF37] hover:text-white font-black text-xs px-5 py-2.5 rounded-lg uppercase tracking-widest transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <span>Próxima Aleatória</span>
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                )
              )}

            </div>
          </div>

        </div>
      )}

      {/* LIMIT OVERLAY PAYWALL MODAL */}
      {showPaywallLimit && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 animate-scale-in">
            <div className="bg-slate-900 text-white p-4 flex justify-between items-center">
              <span className="font-serif font-bold text-sm tracking-tight flex items-center gap-1.5">
                <Crown className="h-4.5 w-4.5 text-[#D4AF37]" /> Limite de Questões Atingido
              </span>
              <button
                onClick={() => setShowPaywallLimit(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="h-4.5 w-4.5" />
              </button>
            </div>
            <div className="p-6 space-y-4 text-center">
              <div className="w-12 h-12 bg-amber-100 text-[#D4AF37] rounded-full flex items-center justify-center mx-auto shadow-inner">
                <Lock className="h-6 w-6" />
              </div>
              <h4 className="font-serif font-black text-slate-900">Desbloqueie Questões Ilimitadas</h4>
              <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto">
                Você já resolveu suas 10 questões permitidas no modo degustação. Garanta o plano premium e tenha acesso a resoluções infinitas para garantir sua aprovação de 1ª Fase!
              </p>
              
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-left space-y-1 text-xs">
                <span className="font-bold text-slate-700 block">O que você recebe no premium:</span>
                <span className="block text-slate-600">• +2.500 questões oficiais e simulados completos</span>
                <span className="block text-slate-600">• Gabaritos comentados e fundamentação jurídica</span>
                <span className="block text-slate-600">• Radar de desempenho detalhado com estatísticas</span>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  onClick={() => setShowPaywallLimit(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex-1 cursor-pointer"
                >
                  Voltar depois
                </button>
                {onNavigateToTab && (
                  <button
                    onClick={() => {
                      setShowPaywallLimit(false);
                      onNavigateToTab('monetizacao');
                    }}
                    className="bg-slate-950 text-white hover:bg-slate-800 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex-1 cursor-pointer"
                  >
                    Ver Planos OAB 3F
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
