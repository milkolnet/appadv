/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import OABPromptsLibrary from './OABPromptsLibrary';
import OABCuratedEsteira from './OABCuratedEsteira';
import {
  BookOpen,
  CheckCircle2,
  XCircle,
  FileText,
  Briefcase,
  Layers,
  Database,
  Sliders,
  Settings,
  Users,
  TrendingUp,
  Target,
  Search,
  Filter,
  DollarSign,
  AlertTriangle,
  ClipboardList,
  Clock,
  Compass,
  ArrowRight,
  ChevronDown,
  ChevronRight,
  Code,
  Zap,
  HelpCircle,
  MessageSquare,
  Sparkles,
  RefreshCw,
  Award,
  Bell,
  CheckSquare,
  Copy,
  Calendar,
  Share2,
  Check,
  Play,
  Flame,
  Scale,
  ListTodo
} from 'lucide-react';

// Interfaces for structures
interface BlockSection {
  id: string;
  number: number;
  title: string;
  category: 'business' | 'pedagogy' | 'tech' | 'operation';
  summary: string;
}

export default function OABMasterDocumentation() {
  // Navigation states
  const [activeViewMode, setActiveViewMode] = useState<'pacote_execucao' | 'documentacao_mestra' | 'prompts_implementacao' | 'esteira_curada'>('pacote_execucao');
  const [selectedBlockId, setSelectedBlockId] = useState('bloco1');
  const [selectedCapituloId, setSelectedCapituloId] = useState('cap1');
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'business' | 'pedagogy' | 'tech' | 'operation'>('all');
  
  // Interactive Checklist (Saved in localStorage)
  const [checklistItems, setChecklistItems] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('oab_checklist_progress');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Simulator States
  const [simSelectedPlan, setSimSelectedPlan] = useState<'mensal' | 'anual' | 'completo'>('anual');
  const [simUsersCount, setSimUsersCount] = useState<number>(350);
  const [simOnboardingStep, setSimOnboardingStep] = useState<number>(1);
  const [simAnswers, setSimAnswers] = useState<Record<string, string>>({
    fase: '1a_fase',
    tempo: '2_4_horas',
    dificuldade: 'direito_constitucional',
    historico: 'primeira_tentativa'
  });
  
  // Copy Tones for Block 5
  const [selectedTone, setSelectedTone] = useState<'profissional' | 'emocional' | 'agressivo' | 'premium'>('profissional');

  // Clipboard feedback state
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Save checklist progress
  useEffect(() => {
    localStorage.setItem('oab_checklist_progress', JSON.stringify(checklistItems));
  }, [checklistItems]);

  const toggleChecklistItem = (id: string) => {
    setChecklistItems(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Expanded Accordions helper
  const [expandedAccordions, setExpandedAccordions] = useState<Record<string, boolean>>({
    'prd-rf': true,
    'flow-aluno-1': true,
    'entity-users': true,
  });

  const toggleAccordion = (key: string) => {
    setExpandedAccordions(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  // Block definitions for the "Pacote de Execução Final" (15 Blocks)
  const executionBlocks = [
    { id: 'bloco1', title: 'BLOCO 1: Visão do Pacote de Execução', icon: Compass, desc: 'Planejamento ágil de lançamento, o que está pronto e o escopo do MVP.' },
    { id: 'bloco2', title: 'BLOCO 2: Copy Real de Telas do App', icon: Sparkles, desc: 'Textos de alta conversão em português para todas as 20 telas principais.' },
    { id: 'bloco3', title: 'BLOCO 3: Estrutura Textual do Onboarding', icon: Sliders, desc: 'Perguntas estruturadas, regras de decisão e lógica de personalização.' },
    { id: 'bloco4', title: 'BLOCO 4: Textos do Dashboard e Área do Aluno', icon: BookOpen, desc: 'Mensagens dinâmicas, feedbacks pedagógicos, consistência e alertas.' },
    { id: 'bloco5', title: 'BLOCO 5: Monetização e Telas de Oferta', icon: DollarSign, desc: 'Preços, paywalls de 1ª/2ª fase, quebra de objeções e 4 variações de tom.' },
    { id: 'bloco6', title: 'BLOCO 6: Dados Iniciais (Seed) do App', icon: Database, desc: 'Modelagem prática de tabelas, tags, disciplinas e eventos para importação.' },
    { id: 'bloco7', title: 'BLOCO 7: Estrutura Mínima do Conteúdo MVP', icon: Layers, desc: 'Disciplinas prioritárias, módulos mínimos e estratégia para 2ª fase.' },
    { id: 'bloco8', title: 'BLOCO 8: Exercícios, Simulados e Revisão', icon: CheckSquare, desc: 'A mecânica do estudo ativo: regras de espaçamento e feedback.' },
    { id: 'bloco9', title: 'BLOCO 9: Estrutura Inicial do Admin', icon: Settings, desc: 'Especificação do painel de controle mínimo e gestão de alunos.' },
    { id: 'bloco10', title: 'BLOCO 10: Banners e Campanhas Internas', icon: Bell, desc: 'Banners para o dashboard, paywalls contextuais e reengajamento.' },
    { id: 'bloco11', title: 'BLOCO 11: Automações de Lançamento', icon: Zap, desc: 'Régua de e-mail, WhatsApp e push de boas-vindas até recuperação.' },
    { id: 'bloco12', title: 'BLOCO 12: Checklist AppSell AI', icon: ListTodo, desc: 'Checklist interativo de 10 etapas para subir as configurações do app.' },
    { id: 'bloco13', title: 'BLOCO 13: Cronograma Prático', icon: Clock, desc: 'Cronograma passo a passo de 12 dias para subir e publicar o app.' },
    { id: 'bloco14', title: 'BLOCO 14: Lançamento Comercial do MVP', icon: Target, desc: 'Oferta irresistível, funil de ativação de leads e sequência de conversão.' },
    { id: 'bloco15', title: 'BLOCO 15: Kit de Validação dos 30 Dias', icon: TrendingUp, desc: 'KPIs cruciais, sinais de alerta e manual de otimização de pós-lançamento.' },
  ];

  // 18 original strategic chapters (Reference Documentation)
  const strategicChapters = [
    { id: 'cap1', title: '1. Visão Executiva do OAB 3F', cat: 'business', desc: 'Resumo executivo do projeto, o método e proposta de valor pedagógica.' },
    { id: 'cap2', title: '2. PRD do Produto (Requirements)', cat: 'business', desc: 'Objetivos, requisitos funcionais (RF) e não funcionais (RNF) estruturais.' },
    { id: 'cap3', title: '3. Proposta Pedagógica e Método 3F', cat: 'pedagogy', desc: 'Fundamentos acadêmicos do método de 3 fases e curva de esquecimento.' },
    { id: 'cap4', title: '4. Perfis de Usuário e Jornadas', cat: 'pedagogy', desc: 'Tipologias de personas de estudantes e as trilhas de conversão no trial.' },
    { id: 'cap5', title: '5. Arquitetura Funcional', cat: 'tech', desc: 'Estrutura macro dos domínios do sistema com inputs, processamentos e saídas.' },
    { id: 'cap6', title: '6. Mapa de Telas e Navegação', cat: 'tech', desc: 'Organização estrutural dos fluxos de interface e áreas restritas.' },
    { id: 'cap7', title: '7. Fluxos de Experiência do Aluno', cat: 'pedagogy', desc: 'Passo a passo dos 10 caminhos operacionais críticos do estudante.' },
    { id: 'cap8', title: '8. Fluxos Operacionais do Admin', cat: 'operation', desc: 'A jornada operacional do administrador para inserção e moderação de conteúdo.' },
    { id: 'cap9', title: '9. Regras de Negócio por Módulo', cat: 'tech', desc: 'Critérios rígidos e algoritmos que controlam o comportamento integrado.' },
    { id: 'cap10', title: '10. Monetização, Planos e Acessos', cat: 'business', desc: 'Regras de gating, proteção de paywall e gestão de assinaturas recorrentes.' },
    { id: 'cap11', title: '11. CRM, Growth e Campanhas', cat: 'business', desc: 'Funis de leads, réguas automatizadas de retenção e acionamento de banners.' },
    { id: 'cap12', title: '12. Estrutura de Dados e Entidades', cat: 'tech', desc: 'Modelagem de dados com definições de tabelas, campos essenciais e chaves.' },
    { id: 'cap13', title: '13. Eventos, Gatilhos e Automações', cat: 'tech', desc: 'Tabela de telemetria de eventos-chave de conversão e engajamento.' },
    { id: 'cap14', title: '14. Operação de Conteúdo & Atualização', cat: 'operation', desc: 'Curadoria pedagógica, atualização legislativa e banco de questões FGV.' },
    { id: 'cap15', title: '15. Suporte, Comunidade & Mentoria', cat: 'operation', desc: 'Políticas de atendimento, SLA, moderação de fórum e upsell VIP.' },
    { id: 'cap16', title: '16. Analytics e Métricas de Produto', cat: 'business', desc: 'Métricas de engajamento, comerciais e de eficiência operacional.' },
    { id: 'cap17', title: '17. MVP e Roadmap de Lançamento', cat: 'business', desc: 'Fases táticas de lançamento para focar no core e adiar complexidades.' },
    { id: 'cap18', title: '18. Governança, Manutenção & Evolução', cat: 'operation', desc: 'Rotinas semanais e mensais de suporte técnico e conformidade.' },
  ];

  // Pricing calculations
  const financialProjection = useMemo(() => {
    let price = 0;
    if (simSelectedPlan === 'mensal') price = 59.90;
    if (simSelectedPlan === 'anual') price = 399.00;
    if (simSelectedPlan === 'completo') price = 699.00;

    const mrr = simSelectedPlan === 'mensal' 
      ? (simUsersCount * price) 
      : (simUsersCount * (price / 12));

    const totalRevenue = simUsersCount * price;
    return {
      individualPrice: price,
      estimatedMrr: mrr.toFixed(2),
      totalRevenue: totalRevenue.toFixed(2)
    };
  }, [simSelectedPlan, simUsersCount]);

  // Onboarding Logic simulation helper
  const onboardingResultRule = useMemo(() => {
    let focusMatters = '';
    if (simAnswers.dificuldade === 'direito_constitucional') focusMatters = 'Constitucional (Peso Máximo) e Administrativo';
    if (simAnswers.dificuldade === 'direito_penal') focusMatters = 'Penal, Processo Penal e Legislação Extravagante';
    if (simAnswers.dificuldade === 'direito_civil') focusMatters = 'Civil, Processo Civil e Consumidor';
    if (simAnswers.dificuldade === 'etica_profissional') focusMatters = 'Ética Profissional (Garante 8 pontos críticos!)';

    let scheduleStyle = '';
    if (simAnswers.tempo === 'menos_2_horas') scheduleStyle = 'Reta Final Ultra Focada (Foco em Ética, Constitucional, Administrativo, Tributário - 80% do estudo focado em questões)';
    if (simAnswers.tempo === '2_4_horas') scheduleStyle = 'Plano de Estudo Padrão OAB 3F (Focalização de Resumo + 15 questões diárias + revisão)';
    if (simAnswers.tempo === 'mais_4_horas') scheduleStyle = 'Aceleração de Conteúdo (Duplo módulo diário de Leitura de Resumo + 30 questões com simulação ativa)';

    return {
      focus: focusMatters,
      style: scheduleStyle
    };
  }, [simAnswers]);

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8 font-sans text-left bg-slate-50 min-h-screen" id="master-execution-container">
      
      {/* Editorial Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-amber-600 font-mono text-xs uppercase tracking-widest font-bold">
            <Award className="h-4 w-4 animate-pulse" />
            <span>Ferramenta Operacional Ativa</span>
          </div>
          <h1 className="text-3xl font-display font-black text-slate-900 tracking-tight">
            Pacote de Execução Final <span className="text-amber-500">OAB 3F</span>
          </h1>
          <p className="text-slate-500 text-sm max-w-2xl leading-relaxed">
            Seu centro unificado de ativos, copys prontas, automações estruturadas e seeds de banco de dados para lançar a plataforma com o menor esforço operacional no AppSell AI.
          </p>
        </div>

        {/* Global View Switcher */}
        <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200/60 shrink-0 w-full md:w-auto overflow-x-auto gap-1">
          <button
            onClick={() => setActiveViewMode('pacote_execucao')}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-md text-xs font-bold transition-all shrink-0 justify-center ${
              activeViewMode === 'pacote_execucao'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
            }`}
          >
            <Zap className="h-3.5 w-3.5 text-amber-400" />
            <span>15 Blocos de Execução</span>
          </button>
          <button
            onClick={() => setActiveViewMode('documentacao_mestra')}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-md text-xs font-bold transition-all shrink-0 justify-center ${
              activeViewMode === 'documentacao_mestra'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5 text-blue-500" />
            <span>18 Capítulos Planejamento</span>
          </button>
          <button
            onClick={() => setActiveViewMode('prompts_implementacao')}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-md text-xs font-bold transition-all shrink-0 justify-center ${
              activeViewMode === 'prompts_implementacao'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
            }`}
          >
            <Code className="h-3.5 w-3.5 text-emerald-500" />
            <span>Biblioteca de Micro-Prompts</span>
          </button>
          <button
            onClick={() => setActiveViewMode('esteira_curada')}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-md text-xs font-bold transition-all shrink-0 justify-center ${
              activeViewMode === 'esteira_curada'
                ? 'bg-slate-900 text-white shadow-sm border border-emerald-500/20'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
            }`}
          >
            <Sparkles className="h-3.5 w-3.5 text-emerald-500 animate-pulse" />
            <span>Esteira MVP Curada (Prompt 23)</span>
          </button>
        </div>
      </div>

      {/* Top operational metrics widget */}
      {activeViewMode === 'pacote_execucao' && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 border border-slate-200 rounded-xl shadow-sm">
            <span className="text-slate-400 text-[10px] font-mono uppercase block">Prontidão do MVP</span>
            <p className="text-2xl font-black text-emerald-600">100% Pronto</p>
            <p className="text-[10px] text-slate-500 mt-1">Totalmente estruturado</p>
          </div>
          <div className="bg-white p-4 border border-slate-200 rounded-xl shadow-sm">
            <span className="text-slate-400 text-[10px] font-mono uppercase block">Copywriting</span>
            <p className="text-2xl font-black text-slate-900">20 Telas Escritas</p>
            <p className="text-[10px] text-slate-500 mt-1">Pronto para Ctrl+C/Ctrl+V</p>
          </div>
          <div className="bg-white p-4 border border-slate-200 rounded-xl shadow-sm">
            <span className="text-slate-400 text-[10px] font-mono uppercase block">Seeds de Sistema</span>
            <p className="text-2xl font-black text-slate-900">10 Tabelas Seed</p>
            <p className="text-[10px] text-slate-500 mt-1">Estruturas completas</p>
          </div>
          <div className="bg-white p-4 border border-slate-200 rounded-xl shadow-sm">
            <span className="text-slate-400 text-[10px] font-mono uppercase block">Checklist Lançamento</span>
            <p className="text-2xl font-black text-amber-500">
              {Object.values(checklistItems).filter(Boolean).length} / 10 Concluídos
            </p>
            <p className="text-[10px] text-slate-500 mt-1">Acompanhe seu progresso real</p>
          </div>
        </div>
      )}

      {/* Dynamic Main View Area */}
      {activeViewMode === 'esteira_curada' ? (
        <OABCuratedEsteira />
      ) : activeViewMode === 'prompts_implementacao' ? (
        <OABPromptsLibrary />
      ) : (
        /* Main Grid: Sidebar + Pane */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* =======================================
            LEFT SIDEBAR NAVIGATION
            ======================================= */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-4 space-y-4 shadow-sm sticky top-6">
          <div className="space-y-1">
            <span className="text-xs font-black text-slate-900 uppercase tracking-wider block">
              {activeViewMode === 'pacote_execucao' ? 'Menu de Execução' : 'Referência Estratégica'}
            </span>
            <p className="text-[11px] text-slate-400 leading-tight">
              {activeViewMode === 'pacote_execucao' 
                ? 'Selecione um bloco prático para extrair textos, seeds e configurações.' 
                : 'Capítulos de planejamento detalhado do projeto para validação conceitual.'}
            </p>
          </div>

          <div className="border-t border-slate-100 my-2 pt-2">
            <div className="max-h-[580px] overflow-y-auto space-y-1.5 pr-1 text-xs">
              
              {/* Dynamic rendering based on View Mode */}
              {activeViewMode === 'pacote_execucao' ? (
                executionBlocks.map((b) => {
                  const Icon = b.icon;
                  const isSelected = selectedBlockId === b.id;
                  return (
                    <button
                      key={b.id}
                      onClick={() => setSelectedBlockId(b.id)}
                      className={`w-full text-left p-3 rounded-lg border transition-all flex items-start space-x-3 ${
                        isSelected
                          ? 'bg-slate-900 border-slate-900 text-white shadow-md'
                          : 'bg-slate-50 hover:bg-slate-100 border-slate-200/60 text-slate-700'
                      }`}
                    >
                      <Icon className={`mt-0.5 h-4 w-4 shrink-0 ${isSelected ? 'text-amber-400' : 'text-slate-400'}`} />
                      <div className="space-y-0.5">
                        <span className="font-bold text-xs leading-tight block">{b.title}</span>
                        <p className={`text-[10px] line-clamp-1 leading-normal ${isSelected ? 'text-slate-300' : 'text-slate-500'}`}>
                          {b.desc}
                        </p>
                      </div>
                    </button>
                  );
                })
              ) : (
                strategicChapters.map((c) => {
                  const isSelected = selectedCapituloId === c.id;
                  return (
                    <button
                      key={c.id}
                      onClick={() => setSelectedCapituloId(c.id)}
                      className={`w-full text-left p-2.5 rounded-lg border transition-all flex items-start space-x-2.5 ${
                        isSelected
                          ? 'bg-slate-900 border-slate-900 text-white shadow-md'
                          : 'bg-slate-50 hover:bg-slate-100 border-slate-200/60 text-slate-700'
                      }`}
                    >
                      <div className={`mt-0.5 font-mono font-bold text-[9px] h-5 w-5 rounded-full flex items-center justify-center shrink-0 ${
                        isSelected ? 'bg-amber-400 text-slate-900' : 'bg-slate-200 text-slate-700'
                      }`}>
                        {c.id.replace('cap', '')}
                      </div>
                      <div className="space-y-0.5">
                        <span className="font-bold text-xs leading-tight block">{c.title}</span>
                        <p className={`text-[10px] line-clamp-1 leading-normal ${isSelected ? 'text-slate-300' : 'text-slate-500'}`}>
                          {c.desc}
                        </p>
                      </div>
                    </button>
                  );
                })
              )}

            </div>
          </div>
        </div>

        {/* =======================================
            RIGHT PANEL CONTENT AREA
            ======================================= */}
        <div className="lg:col-span-8 bg-white border border-slate-200 shadow-sm rounded-xl p-6 sm:p-8 min-h-[600px] text-xs leading-relaxed text-slate-700 font-sans">
          
          {/* =========================================================================
              VIEW MODE: PACOTE DE EXECUÇÃO FINAL (15 BLOCKS)
              ========================================================================= */}
          {activeViewMode === 'pacote_execucao' && (
            <div className="space-y-6 animate-fade-in">

              {/* BLOCO 1: VISÃO DO PACOTE DE EXECUÇÃO */}
              {selectedBlockId === 'bloco1' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Compass className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Documento de Lançamento</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 1 — Visão Executiva do Pacote de Execução</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Este <strong>Pacote de Execução Final</strong> representa os insumos concretos exigidos para configurar o aplicativo <strong>OAB 3F</strong> de forma imediata. Ele elimina a barreira do planejamento e entra diretamente na fase de preenchimento, fornecendo os textos reais, as estruturas lógicas do onboarding, ofertas configuradas e réguas de automação para um lançamento de alta conversão.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-lg space-y-2">
                      <div className="flex items-center space-x-1.5 text-emerald-800 font-bold">
                        <CheckCircle2 className="h-4 w-4" />
                        <span>Pronto para o MVP</span>
                      </div>
                      <p className="text-[11px] text-emerald-700 leading-normal">
                        Você já pode copiar os textos de tela, a lógica do onboarding, as ofertas comerciais com paywall configurado e importar as tabelas iniciais.
                      </p>
                    </div>

                    <div className="bg-amber-50 border border-amber-100 p-4 rounded-lg space-y-2">
                      <div className="flex items-center space-x-1.5 text-amber-800 font-bold">
                        <Sliders className="h-4 w-4" />
                        <span>Alimentação Manual</span>
                      </div>
                      <p className="text-[11px] text-amber-700 leading-normal">
                        As questões comentadas e resumos de PDF devem ser adicionados gradualmente via Admin do professor à medida que as turmas progridem.
                      </p>
                    </div>

                    <div className="bg-slate-50 border border-slate-200 p-4 rounded-lg space-y-2">
                      <div className="flex items-center space-x-1.5 text-slate-800 font-bold">
                        <Zap className="h-4 w-4" />
                        <span>Fase Segura</span>
                      </div>
                      <p className="text-[11px] text-slate-700 leading-normal">
                        A área da 2ª Fase do Exame pode ser mantida com lista de espera pré-venda ativa, acelerando a validação e caixa rápido da 1ª Fase.
                      </p>
                    </div>
                  </div>

                  <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-3">
                    <h3 className="font-bold text-slate-900 text-xs">Divisão de Responsabilidades no AppSell AI</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] text-slate-600">
                      <div className="space-y-1">
                        <p className="font-bold text-slate-800">1. Textos e Copy de Telas (Ctrl+C / Ctrl+V)</p>
                        <p>Copie os enunciados reais da splash screen, login, paywalls e dashboard. Cada tela já está escrita no formato final de alta retenção.</p>
                      </div>
                      <div className="space-y-1">
                        <p className="font-bold text-slate-800">2. Estrutura de Onboarding e Plano</p>
                        <p>Siga a árvore lógica de perguntas e respostas para construir o fluxo interativo que cria o plano personalizado do aluno.</p>
                      </div>
                      <div className="space-y-1">
                        <p className="font-bold text-slate-800">3. Dados e Seeds Iniciais</p>
                        <p>Use a estrutura de tags de segmentação e lista de disciplinas para alimentar o banco de dados no momento da configuração.</p>
                      </div>
                      <div className="space-y-1">
                        <p className="font-bold text-slate-800">4. Campanhas e Automações</p>
                        <p>Cadastre as réguas de envio automatizadas de WhatsApp e Push para recuperar abandonos e parabenizar streaks de estudos.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 2: COPY REAL DE TELAS DO APP (20 Screens) */}
              {selectedBlockId === 'bloco2' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Sparkles className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Copywriting de Conversão</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 2 — Copy Real das Telas do Aplicativo</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Aqui estão as copys 100% reais, escritas em português do Brasil, prontas para serem coladas nos campos de texto da interface do seu aplicativo. Use os botões de cópia para facilitar o seu trabalho.
                  </p>

                  {/* Copy Screen List */}
                  <div className="space-y-6">

                    {/* Screen 1: Splash */}
                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="font-mono text-[10px] font-bold text-amber-600 uppercase bg-amber-50 px-2 py-0.5 rounded">1. Tela de Abertura / Splash Screen</span>
                        <button
                          onClick={() => handleCopy(`Frase Principal: OAB 3F\nFrase de Apoio: Do primeiro dia de estudo à aprovação final na Ordem.\nCTA / Mensagem: Carregando seu plano de estudos inteligente...`, 'splash')}
                          className="flex items-center space-x-1 text-slate-500 hover:text-slate-900 text-[10px] font-bold"
                        >
                          {copiedId === 'splash' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                          <span>{copiedId === 'splash' ? 'Copiado!' : 'Copiar Texto'}</span>
                        </button>
                      </div>
                      <div className="bg-white border border-slate-100 p-3 rounded text-[11px] font-mono text-slate-600 space-y-1">
                        <p><strong className="text-slate-900">Frase Principal:</strong> OAB 3F</p>
                        <p><strong className="text-slate-900">Frase de Apoio:</strong> Do primeiro dia de estudo à aprovação final na Ordem.</p>
                        <p><strong className="text-slate-900">CTA / Mensagem:</strong> Carregando seu plano de estudos inteligente...</p>
                      </div>
                    </div>

                    {/* Screen 2: Welcome */}
                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="font-mono text-[10px] font-bold text-amber-600 uppercase bg-amber-50 px-2 py-0.5 rounded">2. Tela de Boas-vindas / Entrada</span>
                        <button
                          onClick={() => handleCopy(`Headline: Seu plano diário rumo à aprovação na OAB\nSubheadline: Pare de perder tempo com resumos gigantes e aulas cansativas. Tenha um cronograma dinâmico de estudo focado, questões comentadas e revisões automatizadas.\nBenefícios Rápidos:\n- Plano de estudos individual adaptativo\n- Questões comentadas pelos melhores professores\n- Revisão inteligente focada nos seus erros\nCTA Principal: Começar minha preparação ativa\nCTA Secundário: Já tenho uma conta`, 'welcome')}
                          className="flex items-center space-x-1 text-slate-500 hover:text-slate-900 text-[10px] font-bold"
                        >
                          {copiedId === 'welcome' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                          <span>{copiedId === 'welcome' ? 'Copiado!' : 'Copiar Texto'}</span>
                        </button>
                      </div>
                      <div className="bg-white border border-slate-100 p-3 rounded text-[11px] font-mono text-slate-600 space-y-1">
                        <p><strong className="text-slate-900">Headline:</strong> Seu plano diário rumo à aprovação na OAB</p>
                        <p><strong className="text-slate-900">Subheadline:</strong> Pare de perder tempo com resumos gigantes e aulas cansativas. Tenha um cronograma dinâmico de estudo focado, questões comentadas e revisões automatizadas.</p>
                        <p><strong className="text-slate-900">Benefícios Rápidos:</strong></p>
                        <ul className="list-disc pl-4 space-y-0.5">
                          <li>Plano de estudos individual adaptativo</li>
                          <li>Questões comentadas pelos melhores professores</li>
                          <li>Revisão inteligente focada nos seus erros</li>
                        </ul>
                        <p className="mt-1"><strong className="text-slate-900">CTA Principal:</strong> Começar minha preparação ativa</p>
                        <p><strong className="text-slate-900">CTA Secundário:</strong> Já tenho uma conta</p>
                      </div>
                    </div>

                    {/* Screen 3: Login */}
                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="font-mono text-[10px] font-bold text-amber-600 uppercase bg-amber-50 px-2 py-0.5 rounded">3. Tela de Login</span>
                        <button
                          onClick={() => handleCopy(`Título: Bom ver você de volta!\nSubtítulo: Digite suas credenciais para continuar sua jornada de estudos.\nCampos:\n- Email (ex: seuemail@dominio.com)\n- Senha (segura e pessoal)\nBotão: Entrar e Estudar\nLink: Esqueci minha senha\nIncentivo: A aprovação é construída um dia de cada vez. Vamos vencer hoje!`, 'login_copy')}
                          className="flex items-center space-x-1 text-slate-500 hover:text-slate-900 text-[10px] font-bold"
                        >
                          {copiedId === 'login_copy' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                          <span>{copiedId === 'login_copy' ? 'Copiado!' : 'Copiar Texto'}</span>
                        </button>
                      </div>
                      <div className="bg-white border border-slate-100 p-3 rounded text-[11px] font-mono text-slate-600 space-y-1">
                        <p><strong className="text-slate-900">Título:</strong> Bom ver você de volta!</p>
                        <p><strong className="text-slate-900">Subtítulo:</strong> Digite suas credenciais para continuar sua jornada de estudos.</p>
                        <p><strong className="text-slate-900">Campos:</strong> Email / Senha</p>
                        <p><strong className="text-slate-900">Botão:</strong> Entrar e Estudar</p>
                        <p><strong className="text-slate-900">Link:</strong> Esqueci minha senha</p>
                        <p><strong className="text-slate-900">Frase de Incentivo:</strong> A aprovação é construída um dia de cada vez. Vamos vencer hoje!</p>
                      </div>
                    </div>

                    {/* Screen 19: Paywall */}
                    <div className="border border-slate-200 rounded-xl p-4 bg-amber-50 border-amber-200 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="font-mono text-[10px] font-bold text-amber-800 uppercase bg-amber-100 px-2 py-0.5 rounded">19. Tela de Plano Bloqueado / Paywall Principal</span>
                        <button
                          onClick={() => handleCopy(`Headline: Desbloqueie o seu Passe para a Aprovação!\nSubheadline: Você atingiu o limite de estudos gratuito de hoje. Garanta acesso completo e ilimitado para passar de primeira.\nBenefícios:\n- Cronograma adaptativo inteligente diário até a data da prova\n- Banco ilimitado com mais de 5.000 questões FGV com gabarito comentado\n- Simulados completos com diagnóstico em tempo real de fraquezas\n- Treinos de Peças Práticas da 2ª Fase com esqueletos jurídicos\nCTA Principal: Desbloquear Meu Acesso Premium\nCTA Secundário: Continuar com conta gratuita limitada`, 'paywall_main')}
                          className="flex items-center space-x-1 text-amber-900 hover:text-black text-[10px] font-bold"
                        >
                          {copiedId === 'paywall_main' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                          <span>{copiedId === 'paywall_main' ? 'Copiado!' : 'Copiar Texto'}</span>
                        </button>
                      </div>
                      <div className="bg-white border border-amber-100 p-3 rounded text-[11px] font-mono text-slate-600 space-y-1">
                        <p><strong className="text-slate-900">Headline:</strong> Desbloqueie o seu Passe para a Aprovação!</p>
                        <p><strong className="text-slate-900">Subheadline:</strong> Você atingiu o limite de estudos gratuito de hoje. Garanta acesso completo e ilimitado para passar de primeira.</p>
                        <p><strong className="text-slate-900">Bullets de Benefícios:</strong></p>
                        <ul className="list-disc pl-4 space-y-0.5 text-slate-600">
                          <li>Cronograma adaptativo inteligente diário até a data da prova</li>
                          <li>Banco ilimitado com mais de 5.000 questões FGV com gabarito comentado</li>
                          <li>Simulados completos com diagnóstico em tempo real de fraquezas</li>
                          <li>Treinos de Peças Práticas da 2ª Fase com esqueletos jurídicos</li>
                        </ul>
                        <p className="mt-1"><strong className="text-slate-900">CTA Principal:</strong> Desbloquear Meu Acesso Premium (R$ 399/ano - Equivalente a R$ 33,25/mês)</p>
                      </div>
                    </div>

                    {/* Show more screens toggle summary */}
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                      <h4 className="font-bold text-xs text-slate-800 mb-2">Resumo das Outras 16 Copys Prontas de Telas</h4>
                      <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-500">
                        <div><strong>4. Cadastro:</strong> "Crie sua conta em 30 segundos. Suas informações acadêmicas estão seguras."</div>
                        <div><strong>5. Recuperação:</strong> "Enviaremos um token de acesso instantâneo para redefinição no seu e-mail."</div>
                        <div><strong>6. Onboarding:</strong> "Vamos calibrar seu cérebro para o exame. Responda estas perguntas rápidas."</div>
                        <div><strong>7. Dashboard:</strong> "Sua meta para hoje: Constitucional e 15 questões de Fixação ativa."</div>
                        <div><strong>8. Meu Plano:</strong> "Tarefas do dia concluídas! Você avançou 2% na trilha geral de aprovação."</div>
                        <div><strong>9. Biblioteca:</strong> "Os 17 temas mais quentes catalogados. Sem poluição visual, direto ao ponto."</div>
                        <div><strong>10. Questões:</strong> "Resposta Correta! Súmula Vinculante nº 10 explicada com detalhes."</div>
                        <div><strong>11. Simulados:</strong> "Seu cronômetro está rodando. 80 questões, simule o ambiente oficial FGV."</div>
                        <div><strong>12. Revisão:</strong> "A revisão é o segredo do LTV cerebral. Aqui estão seus 5 tópicos pendentes."</div>
                        <div><strong>13. Desempenho:</strong> "Seu índice de acerto em Ética é de 85%. Excelente! Continue mantendo."</div>
                        <div><strong>14. Calendário:</strong> "Faltam apenas 45 dias para a prova. Alerta de inscrição aberta."</div>
                        <div><strong>15. 2ª fase:</strong> "Direito Penal ou Constitucional. Guia prático de confecção de peças e teses."</div>
                        <div><strong>16. Suporte:</strong> "Dúvida pedagógica ou técnica? Nosso SLA é de menos de 4 horas de resposta."</div>
                        <div><strong>17. Comunidade:</strong> "Fórum ativo dos futuros advogados de 2026. Compartilhe suas vitórias e dúvidas."</div>
                        <div><strong>18. Assinatura:</strong> "Plano Anual Ativo. Seu passaporte de aprovação está garantido até 2027."</div>
                        <div><strong>20. Pós-compra:</strong> "Parabéns pelo investimento! Seu plano personalizado foi totalmente liberado."</div>
                      </div>
                    </div>

                  </div>
                </div>
              )}

              {/* BLOCO 3: ESTRUTURA TEXTUAL DO ONBOARDING */}
              {selectedBlockId === 'bloco3' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Sliders className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Funil de Ativação</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 3 — Estrutura Textual do Onboarding Inteligente</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Um fluxo de onboarding interativo que coleta informações estratégicas do aluno e gera um sentimento de alta personalização, engajando o usuário no aplicativo desde o primeiro segundo de uso.
                  </p>

                  {/* Interactive Onboarding Simulator */}
                  <div className="bg-slate-900 text-white rounded-xl p-5 border border-slate-800 space-y-4">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-2 text-[10px] font-mono">
                      <span className="text-amber-400 font-bold">SIMULADOR OPERACIONAL DO ONBOARDING</span>
                      <span>Etapa {simOnboardingStep} de 4</span>
                    </div>

                    {simOnboardingStep === 1 && (
                      <div className="space-y-3 animate-fade-in">
                        <p className="text-xs font-bold text-slate-100">Pergunta 1: Qual é a sua meta imediata no Exame de Ordem?</p>
                        <div className="grid grid-cols-1 gap-2">
                          <button
                            onClick={() => { setSimAnswers(prev => ({ ...prev, fase: '1a_fase' })); setSimOnboardingStep(2); }}
                            className={`p-2.5 rounded-lg border text-left text-xs transition-all ${simAnswers.fase === '1a_fase' ? 'bg-amber-500/10 border-amber-500 text-amber-400' : 'bg-slate-800 border-slate-700 hover:bg-slate-700/50'}`}
                          >
                            Quero passar na 1ª Fase (80 Questões Objetivas)
                          </button>
                          <button
                            onClick={() => { setSimAnswers(prev => ({ ...prev, fase: '2a_fase' })); setSimOnboardingStep(2); }}
                            className={`p-2.5 rounded-lg border text-left text-xs transition-all ${simAnswers.fase === '2a_fase' ? 'bg-amber-500/10 border-amber-500 text-amber-400' : 'bg-slate-800 border-slate-700 hover:bg-slate-700/50'}`}
                          >
                            Já passei na 1ª e quero focar na 2ª Fase (Peça e Escritas)
                          </button>
                          <button
                            onClick={() => { setSimAnswers(prev => ({ ...prev, fase: 'ambas' })); setSimOnboardingStep(2); }}
                            className={`p-2.5 rounded-lg border text-left text-xs transition-all ${simAnswers.fase === 'ambas' ? 'bg-amber-500/10 border-amber-500 text-amber-400' : 'bg-slate-800 border-slate-700 hover:bg-slate-700/50'}`}
                          >
                            Quero me preparar de forma completa para ambas as fases
                          </button>
                        </div>
                        <p className="text-[10px] text-slate-400"><strong>Influência técnica:</strong> Filtra as trilhas exibidas na biblioteca e prioriza os simulados iniciais do usuário.</p>
                      </div>
                    )}

                    {simOnboardingStep === 2 && (
                      <div className="space-y-3 animate-fade-in">
                        <p className="text-xs font-bold text-slate-100">Pergunta 2: Quantas horas você tem disponíveis para estudar por dia?</p>
                        <div className="grid grid-cols-1 gap-2">
                          <button
                            onClick={() => { setSimAnswers(prev => ({ ...prev, tempo: 'menos_2_horas' })); setSimOnboardingStep(3); }}
                            className={`p-2.5 rounded-lg border text-left text-xs transition-all ${simAnswers.tempo === 'menos_2_horas' ? 'bg-amber-500/10 border-amber-500 text-amber-400' : 'bg-slate-800 border-slate-700 hover:bg-slate-700/50'}`}
                          >
                            Menos de 2 horas (Estudo de alta densidade/questões)
                          </button>
                          <button
                            onClick={() => { setSimAnswers(prev => ({ ...prev, tempo: '2_4_horas' })); setSimOnboardingStep(3); }}
                            className={`p-2.5 rounded-lg border text-left text-xs transition-all ${simAnswers.tempo === '2_4_horas' ? 'bg-amber-500/10 border-amber-500 text-amber-400' : 'bg-slate-800 border-slate-700 hover:bg-slate-700/50'}`}
                          >
                            De 2 a 4 horas (Recomendado para o método 3F)
                          </button>
                          <button
                            onClick={() => { setSimAnswers(prev => ({ ...prev, tempo: 'mais_4_horas' })); setSimOnboardingStep(3); }}
                            className={`p-2.5 rounded-lg border text-left text-xs transition-all ${simAnswers.tempo === 'mais_4_horas' ? 'bg-amber-500/10 border-amber-500 text-amber-400' : 'bg-slate-800 border-slate-700 hover:bg-slate-700/50'}`}
                          >
                            Mais de 4 horas (Estudo intensivo e simulados recorrentes)
                          </button>
                        </div>
                        <p className="text-[10px] text-slate-400"><strong>Influência técnica:</strong> Define a duração do cronômetro diário e calcula a quantidade de subtemas recomendados por meta.</p>
                      </div>
                    )}

                    {simOnboardingStep === 3 && (
                      <div className="space-y-3 animate-fade-in">
                        <p className="text-xs font-bold text-slate-100">Pergunta 3: Qual disciplina você considera seu maior pesadelo?</p>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <button
                            onClick={() => { setSimAnswers(prev => ({ ...prev, dificuldade: 'direito_constitucional' })); setSimOnboardingStep(4); }}
                            className="p-2 bg-slate-800 border border-slate-700 hover:bg-slate-700/50 rounded-lg text-left"
                          >
                            Dir. Constitucional
                          </button>
                          <button
                            onClick={() => { setSimAnswers(prev => ({ ...prev, dificuldade: 'direito_penal' })); setSimOnboardingStep(4); }}
                            className="p-2 bg-slate-800 border border-slate-700 hover:bg-slate-700/50 rounded-lg text-left"
                          >
                            Dir. Penal e Processo
                          </button>
                          <button
                            onClick={() => { setSimAnswers(prev => ({ ...prev, dificuldade: 'direito_civil' })); setSimOnboardingStep(4); }}
                            className="p-2 bg-slate-800 border border-slate-700 hover:bg-slate-700/50 rounded-lg text-left"
                          >
                            Dir. Civil e Processo
                          </button>
                          <button
                            onClick={() => { setSimAnswers(prev => ({ ...prev, dificuldade: 'etica_profissional' })); setSimOnboardingStep(4); }}
                            className="p-2 bg-slate-800 border border-slate-700 hover:bg-slate-700/50 rounded-lg text-left"
                          >
                            Ética Profissional
                          </button>
                        </div>
                        <p className="text-[10px] text-slate-400"><strong>Influência técnica:</strong> Aumenta em 20% a carga de questões e revisões inteligentes deste tema nos primeiros 15 dias de cronograma.</p>
                      </div>
                    )}

                    {simOnboardingStep === 4 && (
                      <div className="space-y-4 animate-fade-in text-xs leading-relaxed">
                        <div className="p-3 bg-slate-800 border border-slate-700 rounded-lg space-y-2">
                          <p className="font-bold text-amber-400">🚀 PLANO PERSONALIZADO GERADO COM SUCESSO!</p>
                          <div className="space-y-1.5 text-slate-300 text-[11px]">
                            <p><strong>Foco Prioritário:</strong> {onboardingResultRule.focus}</p>
                            <p><strong>Carga Horária Adaptada:</strong> {onboardingResultRule.style}</p>
                            <p><strong>Meta Diária Sugerida:</strong> Assistir resumo crítico + resolver 15 questões + revisar 5 erros passados.</p>
                          </div>
                        </div>

                        <div className="flex space-x-2">
                          <button
                            onClick={() => setSimOnboardingStep(1)}
                            className="bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded text-[10px] font-bold"
                          >
                            Reiniciar Teste
                          </button>
                          <button
                            onClick={() => handleCopy(JSON.stringify(simAnswers, null, 2), 'onboard_json')}
                            className="bg-amber-500 text-slate-950 hover:bg-amber-400 px-3 py-1.5 rounded text-[10px] font-bold flex items-center space-x-1"
                          >
                            {copiedId === 'onboard_json' ? <Check className="h-3 w-3 text-slate-900" /> : <Copy className="h-3 w-3" />}
                            <span>Copiar Configuração JSON</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-2 text-[11px]">
                    <h3 className="font-bold text-slate-900 text-xs">A Tela Final de Onboarding Concluído</h3>
                    <p className="text-slate-600">
                      <strong>Headline:</strong> Seu Plano de Estudos Personalizado está Pronto!
                    </p>
                    <p className="text-slate-600">
                      <strong>Texto Explicativo:</strong> Processamos suas respostas e estruturamos um roteiro adaptativo diário focado no peso real das matérias cobradas pela FGV. Você estudará com base ativa, reduzindo seu tempo total de estudo e blindando sua mente contra esquecimentos.
                    </p>
                    <p className="text-slate-600">
                      <strong>CTA do Botão:</strong> Entrar no Meu Dashboard e Começar
                    </p>
                  </div>
                </div>
              )}

              {/* BLOCO 4: TEXTOS DO DASHBOARD E ÁREA DO ALUNO */}
              {selectedBlockId === 'bloco4' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <BookOpen className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Ambiente Interno</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 4 — Biblioteca de Mensagens do Dashboard e Aluno</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Mensagens dinâmicas baseadas no comportamento de estudos do estudante. Utilize esses textos nas lógicas condicionais do dashboard para criar sentimentos de acolhimento e urgência.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
                    <div className="p-4 bg-red-50 border border-red-100 rounded-lg space-y-1.5">
                      <span className="font-bold text-red-800 text-[10px] font-mono block uppercase">1. Aluno Atrasado (Mais de 3 dias sem logar)</span>
                      <p className="text-slate-700 italic">
                        "Lucas, seu cronograma de estudos detectou 3 dias sem registro de tarefas. Não se preocupe com o acumulado! Nosso algoritmo adaptativo reorganizou suas próximas metas para você não ficar sobrecarregado. Vamos dar apenas o primeiro passo de hoje?"
                      </p>
                    </div>

                    <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-lg space-y-1.5">
                      <span className="font-bold text-emerald-800 text-[10px] font-mono block uppercase">2. Aluno Consistente (Streak ativo de 5+ dias)</span>
                      <p className="text-slate-700 italic">
                        "Incrível, Lucas! Você está mantendo uma ofensiva de estudos de 5 dias seguidos. Seu cérebro está no pico de retenção. Mantenha o ritmo! Ética profissional espera por você hoje."
                      </p>
                    </div>

                    <div className="p-4 bg-amber-50 border border-amber-100 rounded-lg space-y-1.5 col-span-1 md:col-span-2">
                      <span className="font-bold text-amber-800 text-[10px] font-mono block uppercase">3. Feedbacks Pedagógicos Inteligentes (Gabarito de Questões)</span>
                      <div className="space-y-1.5 text-slate-700 mt-1">
                        <p><strong>Em caso de Acerto:</strong> "Excelente escolha! A fundamentação está no artigo 5º, inciso LVII da CF/88 (Princípio da Presunção de Inocência). Meta diária atualizada!"</p>
                        <p><strong>Em caso de Erro:</strong> "Quase lá! Lembre-se que o agravo de instrumento na OAB segue o rito de prazo de 15 dias úteis (Art. 1.003, § 5º do CPC). Essa questão foi enviada para suas revisões agendadas de amanhã para fixação definitiva."</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 5: MONETIZAÇÃO E OFERTAS (4 Tones) */}
              {selectedBlockId === 'bloco5' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <DollarSign className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Copywriting Comercial</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 5 — Monetização, Planos e Variações de Tom</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Sua tabela de preços de lançamento com <strong>4 variações estratégicas de tom</strong>. Altere o tom abaixo para visualizar e copiar a melhor copy para o seu público-alvo.
                  </p>

                  {/* Pricing Table Specs */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="border border-slate-200 rounded-lg p-3 bg-slate-50 text-center">
                      <span className="text-[9px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-mono uppercase font-bold">Plano Mensal</span>
                      <p className="text-lg font-black text-slate-900 mt-1">R$ 59,90</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">Cancelamento recorrente</p>
                    </div>
                    <div className="border border-amber-300 rounded-lg p-3 bg-amber-50 text-center relative">
                      <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-[8px] bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">Recomendado</span>
                      <span className="text-[9px] bg-amber-200 text-amber-800 px-1.5 py-0.5 rounded font-mono uppercase font-bold mt-1 inline-block">Plano Anual</span>
                      <p className="text-lg font-black text-slate-900 mt-1">R$ 399,00</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">Equivale a R$ 33,25/mês</p>
                    </div>
                    <div className="border border-slate-200 rounded-lg p-3 bg-slate-50 text-center">
                      <span className="text-[9px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-mono uppercase font-bold">Completo (1ª + 2ª)</span>
                      <p className="text-lg font-black text-slate-900 mt-1">R$ 699,00</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">Até a aprovação final</p>
                    </div>
                  </div>

                  {/* Tone Selector */}
                  <div className="space-y-4">
                    <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200/60 max-w-md">
                      {(['profissional', 'emocional', 'agressivo', 'premium'] as const).map((t) => (
                        <button
                          key={t}
                          onClick={() => setSelectedTone(t)}
                          className={`flex-1 py-1 px-2 text-[10px] font-bold rounded capitalize transition-all ${
                            selectedTone === t ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>

                    {/* Render Selected Copy Tone */}
                    <div className="border border-slate-200 rounded-xl p-5 bg-slate-50/50 space-y-3 relative">
                      <div className="flex justify-between items-center border-b border-slate-200/60 pb-2">
                        <span className="text-xs font-bold text-slate-900">Copy do Paywall de Vendas — Tom {selectedTone.toUpperCase()}</span>
                        <button
                          onClick={() => handleCopy(`Paywall Tone ${selectedTone}: ${selectedTone === 'profissional' ? 'Foco regulatório e aprovação métrica' : selectedTone === 'emocional' ? 'Foco no sonho, família e superação de ansiedade' : selectedTone === 'agressivo' ? 'Foco na escassez de tempo e gatilho de preço' : 'Foco em mentoria VIP e acompanhamento individualizado'}`, 'paywall_tone')}
                          className="flex items-center space-x-1 text-slate-500 hover:text-slate-900 text-[10px] font-bold"
                        >
                          {copiedId === 'paywall_tone' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                          <span>{copiedId === 'paywall_tone' ? 'Copiado!' : 'Copiar Copy'}</span>
                        </button>
                      </div>

                      {selectedTone === 'profissional' && (
                        <div className="space-y-2 text-xs">
                          <p><strong>Headline:</strong> Garanta sua aprovação no Exame de Ordem com validação estatística e metodologia ativa de alta performance.</p>
                          <p><strong>Descrição:</strong> Pare de estudar sem rumo e sem medir seus resultados. O OAB 3F foi arquitetado com base em análise rigorosa das últimas 15 edições da banca FGV, mapeando as matérias que de fato determinam a sua aprovação. Com nossa assinatura premium, você acessa um cronograma individual e banco de dados de desempenho para controlar sua evolução científica rumo aos 40 pontos regulamentares.</p>
                          <p><strong>Objeções quebradas:</strong> "Será que serve para mim?" : O plano é 100% individualizado e ajusta-se à sua rotina semanal de tempo disponível.</p>
                        </div>
                      )}

                      {selectedTone === 'emocional' && (
                        <div className="space-y-2 text-xs">
                          <p><strong>Headline:</strong> Chegou a hora de tirar o peso da ansiedade das suas costas e ver seu nome na lista dos aprovados da OAB.</p>
                          <p><strong>Descrição:</strong> Sabemos o quanto você se esforçou na faculdade de Direito e a pressão gigantesca que sente de amigos e familiares para passar na prova da Ordem. O medo de falhar não deve impedir você de realizar seu sonho de vestir a beca e advogar. Deixe que o OAB 3F organize sua rotina de estudos de forma leve, acolhedora e segura. Estude um pouquinho por dia, com foco, e sinta o alívio de saber que está no caminho certo.</p>
                          <p><strong>Objeções quebradas:</strong> "Não tenho tempo" : Com apenas 1h30 por dia de estudo ativo direcionado, você absorve mais do que em 4h de cursinhos tradicionais cansativos.</p>
                        </div>
                      )}

                      {selectedTone === 'agressivo' && (
                        <div className="space-y-2 text-xs">
                          <p><strong>Headline:</strong> O relógio está correndo. Não jogue fora mais 6 meses da sua vida esperando o próximo Exame de Ordem!</p>
                          <p><strong>Descrição:</strong> Cada dia sem estudar do jeito certo aproxima você da reprovação e adia o seu direito de exercer a profissão que escolheu. Os cursinhos convencionais adoram que você reprove para vender readequações caras. Nós jogamos diferente. Queremos você aprovado agora. Libere o plano premium hoje e tenha acesso imediato aos segredos de fixação que os cursinhos de R$ 1.500 escondem de você por um preço ridículo.</p>
                          <p><strong>Objeções quebradas:</strong> "Acho caro" : Menos de R$ 1,10 por dia de preparação ativa. Muito mais barato do que pagar uma nova taxa de inscrição de R$ 320 da FGV.</p>
                        </div>
                      )}

                      {selectedTone === 'premium' && (
                        <div className="space-y-2 text-xs">
                          <p><strong>Headline:</strong> Sua aprovação acelerada com mentoria de elite, planos individualizados de estudo e curadoria executiva.</p>
                          <p><strong>Descrição:</strong> Um ambiente de altíssimo nível para quem não aceita nada menos que a excelência. O plano Completo OAB 3F oferece resumos lapidados, análise profunda de jurisprudência do STF/STJ, simulados com diagnósticos e suporte premium via mentores homologados. O passaporte definitivo para quem preza pela velocidade de aprendizado, foco estratégico e proteção integral de tempo.</p>
                          <p><strong>Objeções quebradas:</strong> "Já tenho material" : Nenhum material estático substitui a nossa inteligência dinâmica de revisão espaçada de erros.</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 6: DADOS INICIAIS (SEED) DO APP */}
              {selectedBlockId === 'bloco6' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Database className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Banco de Dados</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 6 — Dados Iniciais (Seed) do Sistema</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Copie a estrutura JSON de seeds para popular rapidamente as tabelas do banco de dados no lançamento (disciplinas prioritárias, status do sistema e tags de segmentação).
                  </p>

                  <div className="bg-slate-900 rounded-xl p-5 border border-slate-800 text-white font-mono text-[10px] space-y-3">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                      <span className="text-amber-400 font-bold">TABELA: SEED_DISCIPLINAS_OAB.JSON</span>
                      <button
                        onClick={() => handleCopy(`[
  { "id": "disc_01", "nome": "Ética Profissional", "peso_questoes": 8, "prioridade_mvp": "Alta", "grupo": "Grupo A" },
  { "id": "disc_02", "nome": "Direito Constitucional", "peso_questoes": 6, "prioridade_mvp": "Alta", "grupo": "Grupo A" },
  { "id": "disc_03", "nome": "Direito Administrativo", "peso_questoes": 5, "prioridade_mvp": "Alta", "grupo": "Grupo A" },
  { "id": "disc_04", "nome": "Direito Penal", "peso_questoes": 6, "prioridade_mvp": "Alta", "grupo": "Grupo A" },
  { "id": "disc_05", "nome": "Processo Penal", "peso_questoes": 6, "prioridade_mvp": "Média", "grupo": "Grupo B" },
  { "id": "disc_06", "nome": "Direito Civil", "peso_questoes": 6, "prioridade_mvp": "Alta", "grupo": "Grupo A" },
  { "id": "disc_07", "nome": "Processo Civil", "peso_questoes": 6, "prioridade_mvp": "Média", "grupo": "Grupo B" },
  { "id": "disc_08", "nome": "Direito Tributário", "peso_questoes": 5, "prioridade_mvp": "Média", "grupo": "Grupo B" }
]`, 'seed_disc')}
                        className="flex items-center space-x-1 text-slate-400 hover:text-white"
                      >
                        {copiedId === 'seed_disc' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                        <span>Copiar Seed</span>
                      </button>
                    </div>
                    <pre className="overflow-x-auto text-[10px] text-slate-300 leading-tight">
{`[
  { "id": "disc_01", "nome": "Ética Profissional", "peso_questoes": 8, "prioridade_mvp": "Alta" },
  { "id": "disc_02", "nome": "Direito Constitucional", "peso_questoes": 6, "prioridade_mvp": "Alta" },
  { "id": "disc_03", "nome": "Direito Administrativo", "peso_questoes": 5, "prioridade_mvp": "Alta" },
  { "id": "disc_04", "nome": "Direito Penal", "peso_questoes": 6, "prioridade_mvp": "Alta" },
  { "id": "disc_05", "nome": "Processo Penal", "peso_questoes": 6, "prioridade_mvp": "Média" },
  { "id": "disc_06", "nome": "Direito Civil", "peso_questoes": 6, "prioridade_mvp": "Alta" },
  { "id": "disc_07", "nome": "Processo Civil", "peso_questoes": 6, "prioridade_mvp": "Média" }
]`}
                    </pre>
                  </div>

                  <div className="border border-slate-200 rounded-xl overflow-hidden text-[11px]">
                    <div className="bg-slate-900 text-white font-mono p-2.5 font-bold uppercase text-[9px]">
                      Tags de Segmentação de Alunos (Tags CRM)
                    </div>
                    <div className="grid grid-cols-3 bg-slate-100 p-2 font-mono text-[9px] font-bold text-slate-700">
                      <div>NOME DA TAG</div>
                      <div>GATILHO DE ATIVAÇÃO</div>
                      <div>AÇÃO CORRESPONDENTE</div>
                    </div>
                    <div className="grid grid-cols-3 p-2 border-b border-slate-100">
                      <div className="font-bold text-red-600 font-mono">aluno_atrasado_3d</div>
                      <div>3 dias sem registrar estudo ativo</div>
                      <div>Envia push + e-mail de replanejamento automático</div>
                    </div>
                    <div className="grid grid-cols-3 p-2 border-b border-slate-100">
                      <div className="font-bold text-emerald-600 font-mono">aluno_streak_5d</div>
                      <div>Conclui metas por 5 dias consecutivos</div>
                      <div>Dispara badge comemorativo e oferta de mentoria VIP</div>
                    </div>
                    <div className="grid grid-cols-3 p-2">
                      <div className="font-bold text-amber-600 font-mono">paywall_limit_reached</div>
                      <div>Estudante gratuito atinge 10 questões/dia</div>
                      <div>Aciona overlay de bloqueio com banner comercial</div>
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 7: ESTRUTURA MÍNIMA DO CONTEÚDO MVP */}
              {selectedBlockId === 'bloco7' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Layers className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Priorização Enxuta</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 7 — Estrutura Mínima do Conteúdo MVP</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Para o MVP rodar em tempo recorde e com alta percepção de valor, dividimos as 17 disciplinas oficiais da OAB. Foque em cadastrar o <strong>Grupo de Alta Relevância (A)</strong> antes do lançamento.
                  </p>

                  <div className="space-y-4">
                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-2">
                      <h3 className="font-bold text-slate-900 text-xs">Grupo A: Disciplinas Core (Obrigatório para o Lançamento)</h3>
                      <p className="text-[11px] text-slate-500">Mapeiam mais de 65% das questões necessárias para aprovação na prova.</p>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-semibold text-slate-700">
                        <div className="p-2 bg-white rounded border border-slate-200 flex justify-between">
                          <span>1. Ética</span>
                          <span className="text-amber-600">8 Questões</span>
                        </div>
                        <div className="p-2 bg-white rounded border border-slate-200 flex justify-between">
                          <span>2. Constitucional</span>
                          <span className="text-amber-600">6 Questões</span>
                        </div>
                        <div className="p-2 bg-white rounded border border-slate-200 flex justify-between">
                          <span>3. Civil</span>
                          <span className="text-amber-600">6 Questões</span>
                        </div>
                        <div className="p-2 bg-white rounded border border-slate-200 flex justify-between">
                          <span>4. Penal</span>
                          <span className="text-amber-600">6 Questões</span>
                        </div>
                      </div>
                    </div>

                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-2">
                      <h3 className="font-bold text-slate-900 text-xs">Estratégia de 2ª Fase Sem Atrito Operacional</h3>
                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        Em vez de produzir centenas de horas de peças de Direito Penal, Constitucional, Civil e Trabalho no primeiro dia:
                      </p>
                      <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-500">
                        <li>Deixe o menu 2ª Fase ativo no app com um banner elegante: <strong>"Selecione sua área para a 2ª Fase"</strong>.</li>
                        <li>Ao clicar, mostre um questionário simples de interesse e uma tela de pré-venda exclusiva com <strong>50% de desconto</strong> para os aprovados.</li>
                        <li>Isso gera caixa instantâneo antes mesmo de você sentar para redigir ou catalogar os esqueletos estruturais de peças jurídicas.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 8: EXERCÍCIOS, SIMULADOS E REVISÃO */}
              {selectedBlockId === 'bloco8' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <CheckSquare className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Lógica Educacional</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 8 — Mecânica de Exercícios, Simulados e Revisão</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    O cérebro da plataforma baseia-se na retroalimentação contínua. Veja as regras operacionais que comandam as interações de treino:
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
                    <div className="border border-slate-200 rounded-xl p-4 space-y-2">
                      <h4 className="font-bold text-slate-900">A Regra da Revisão de Erros (Spaced Repetition)</h4>
                      <p className="text-slate-500 text-[11px] leading-relaxed">
                        Toda vez que o estudante resolve uma questão e erra, o sistema grava o ID da disciplina e cria uma tarefa pendente chamada <strong>"Revisar [Subtema]"</strong> para ser acionada nas notificações exatamente 24 horas depois. Se ele acertar na revisão, o próximo agendamento vai para 7 dias depois.
                      </p>
                    </div>

                    <div className="border border-slate-200 rounded-xl p-4 space-y-2">
                      <h4 className="font-bold text-slate-900">Configuração de Simulados do MVP</h4>
                      <p className="text-slate-500 text-[11px] leading-relaxed">
                        Configure <strong>3 Simulados Centrais</strong> no banco de dados para o lançamento:
                        <br /><strong>1. Simulado Diagnóstico (Início):</strong> 40 questões rápidas para calibrar o cronograma.
                        <br /><strong>2. Simulado Intermediário (Meio):</strong> 80 questões clássicas com cronômetro de 5 horas.
                        <br /><strong>3. Simulado Final (Reta Final):</strong> 80 questões inéditas de fixação.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 9: ESTRUTURA INICIAL DO ADMIN */}
              {selectedBlockId === 'bloco9' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Settings className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Painel do Operador</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 9 — Estrutura Inicial do Painel Admin MVP</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Especificação do painel de controle mínimo necessário para operar o aplicativo OAB 3F com segurança e eficácia no lançamento.
                  </p>

                  <div className="border border-slate-200 rounded-xl overflow-hidden text-[11px]">
                    <div className="bg-slate-950 text-white font-mono p-3 font-bold text-[9px] uppercase">
                      Módulos de Gerenciamento do Admin
                    </div>
                    <div className="grid grid-cols-3 bg-slate-100 p-2 font-mono text-[9px] font-bold text-slate-700">
                      <div>MÓDULO</div>
                      <div>CAMPOS ESSENCIAIS DE CONTROLE</div>
                      <div>AÇÃO RÁPIDA OPERACIONAL</div>
                    </div>
                    <div className="grid grid-cols-3 p-2.5 border-b border-slate-100">
                      <div className="font-bold text-slate-900">Gestão de Alunos</div>
                      <div>ID, Nome, Email, Status da Assinatura, Tag CRM, Streak Ativo.</div>
                      <div>Adicionar dias premium / Resetar onboarding.</div>
                    </div>
                    <div className="grid grid-cols-3 p-2.5 border-b border-slate-100">
                      <div className="font-bold text-slate-900">Inserção de Conteúdo</div>
                      <div>Matéria, Subtema, PDF do Resumo, Questões associadas.</div>
                      <div>Subir novo PDF / Atualizar lei seca.</div>
                    </div>
                    <div className="grid grid-cols-3 p-2.5">
                      <div className="font-bold text-slate-900">Banco de Questões FGV</div>
                      <div>Enunciado, Alternativas A-D, Gabarito Certo, Comentário do Professor.</div>
                      <div>Importar via planilha CSV.</div>
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 10: BANNERS E CAMPANHAS INTERNAS */}
              {selectedBlockId === 'bloco10' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Bell className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Comunicação Contextual</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 10 — Banners e Campanhas Internas de Vendas</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Modelagem e gatilhos para ativação de banners publicitários e ofertas premium de forma contextual no dashboard do estudante.
                  </p>

                  <div className="space-y-4">
                    <div className="border border-slate-200 rounded-xl p-4 bg-amber-50 border-amber-200 space-y-2">
                      <span className="text-[9px] font-mono font-bold text-amber-800 uppercase bg-amber-100 px-2 py-0.5 rounded inline-block">Banner Premium</span>
                      <h4 className="font-bold text-slate-950 text-sm">Banner de Upgrade Recorrente (Para Contas Gratuitas)</h4>
                      <p className="text-[11px] text-slate-700 leading-relaxed">
                        <strong>Título do Banner:</strong> Quer garantir sua aprovação de primeira na OAB?
                        <br /><strong>Subtítulo:</strong> Desbloqueie o banco de dados completo de simulados, revisões e cronograma sem limite. Equivalente a R$ 33,25 por mês.
                        <br /><strong>CTA:</strong> Assinar Plano Premium OAB 3F
                      </p>
                    </div>

                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-2">
                      <span className="text-[9px] font-mono font-bold text-slate-700 bg-slate-200 px-2 py-0.5 rounded inline-block">Campanha Reta Final</span>
                      <h4 className="font-bold text-slate-900 text-sm">Banner de Alerta de Prova (Faltando 15 Dias)</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        <strong>Título:</strong> Cronômetro Ativo! Faltam apenas 15 dias para o Exame oficial FGV.
                        <br /><strong>Subtítulo:</strong> Acesse nossa Trilha Intensiva de Revisão para focar apenas nas Súmulas Vinculantes mais cobradas.
                        <br /><strong>CTA:</strong> Acessar Trilha Intensiva
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 11: AUTOMAÇÕES E COMUNICAÇÕES DE LANÇAMENTO */}
              {selectedBlockId === 'bloco11' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Zap className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Régua de CRM</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 11 — Automações e Comunicações de Lançamento</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Sua régua de mensagens automatizadas para acionar via e-mail, push notifications ou WhatsApp. Copie os textos prontas para engajar e converter.
                  </p>

                  <div className="space-y-4">
                    {/* Automation 1 */}
                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3">
                      <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                        <span className="font-bold text-xs text-slate-900">Automação 1: Boas-vindas Acadêmicas</span>
                        <span className="text-[9px] bg-slate-200 text-slate-700 px-1.5 py-0.2 rounded font-mono">Gatilho: Novo Cadastro</span>
                      </div>
                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        <strong>Canal:</strong> E-mail ou WhatsApp
                        <br /><strong>Mensagem:</strong> "Olá, [Nome]! Que alegria ver você no OAB 3F. Seu plano de estudos inteligente está pronto para ser iniciado. Sabia que alunos que resolvem questões no primeiro dia de acesso aumentam sua chance de aprovação em 3x? Entre no aplicativo agora e conclua sua meta de Ética Profissional de hoje!"
                        <br /><strong>CTA:</strong> Acessar Meu Plano Diário
                      </p>
                    </div>

                    {/* Automation 2 */}
                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3">
                      <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                        <span className="font-bold text-xs text-slate-900">Automação 2: Abandono de Checkout</span>
                        <span className="text-[9px] bg-red-100 text-red-800 px-1.5 py-0.2 rounded font-mono font-bold">Gatilho: Sai sem assinar paywall</span>
                      </div>
                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        <strong>Canal:</strong> WhatsApp Automatizado
                        <br /><strong>Mensagem:</strong> "Olá, [Nome], tudo bem? Notamos que você se interessou pelo nosso Plano Premium OAB 3F, mas não concluiu a assinatura. Para ajudar você a tomar a melhor decisão para o seu futuro, liberamos um cupom exclusivo de 15% de desconto nas próximas 2 horas. Use o código PASSARDEPRIMEIRA no link abaixo."
                        <br /><strong>CTA:</strong> Ativar Desconto de 15%
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 12: CHECKLIST DE IMPLEMENTAÇÃO DENTRO DO APPSELL AI */}
              {selectedBlockId === 'bloco12' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <ListTodo className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Quadro de Tarefas Interativo</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 12 — Checklist de Implementação Real</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Acompanhe seu progresso real de montagem do app. Marque as tarefas abaixo conforme for executando na plataforma do AppSell AI (seus cliques são salvos automaticamente no navegador).
                  </p>

                  {/* Interactive Checklist UI */}
                  <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm bg-white font-sans text-xs">
                    <div className="bg-slate-900 text-white p-3 font-bold flex justify-between items-center text-[10px] uppercase">
                      <span>Progresso da Implementação</span>
                      <span>{Math.round((Object.values(checklistItems).filter(Boolean).length / 10) * 100)}% CONCLUÍDO</span>
                    </div>

                    <div className="divide-y divide-slate-100">
                      {[
                        { id: 'step1', title: 'Configurar Páginas e Menus Base', desc: 'Ativar o menu lateral com todas as abas estruturadas no Sidebar.tsx.' },
                        { id: 'step2', title: 'Adicionar Telas de Onboarding', desc: 'Implementar as 4 perguntas básicas de cadastro e lógica de filtro de matérias.' },
                        { id: 'step3', title: 'Cadastrar Tabela de Ofertas Comerciais', desc: 'Registrar os planos Mensal, Anual e Completo com integrações de gateway.' },
                        { id: 'step4', title: 'Personalizar Banners Publicitários', desc: 'Subir os criativos de paywall e banners de incentivo de streaks no dashboard.' },
                        { id: 'step5', title: 'Popular Banco de Questões Core', desc: 'Importar as primeiras 50 questões comentadas de Ética e Constitucional.' },
                        { id: 'step6', title: 'Ativar Algoritmo de Revisão', desc: 'Implementar a lógica que reagenda questões erradas para 24 horas depois.' },
                        { id: 'step7', title: 'Subir Resumos em PDF para Biblioteca', desc: 'Vincular arquivos estáticos leves ou links de leitura direta ao aplicativo.' },
                        { id: 'step8', title: 'Implementar Lista de Espera da 2ª Fase', desc: 'Criar gatilho de pré-venda e coleta de leads de Direito Penal e Civil.' },
                        { id: 'step9', title: 'Cadastrar Campanhas de CRM', desc: 'Preencher os templates das réguas automatizadas de e-mail e push.' },
                        { id: 'step10', title: 'Simular Teste Geral de Compra (QA)', desc: 'Testar do onboarding ao paywall com cartão de testes para validar o fluxo.' },
                      ].map((item, index) => {
                        const checked = !!checklistItems[item.id];
                        return (
                          <div
                            key={item.id}
                            onClick={() => toggleChecklistItem(item.id)}
                            className={`p-3.5 flex items-start space-x-3 cursor-pointer transition-all hover:bg-slate-50/50 ${
                              checked ? 'bg-emerald-50/20' : ''
                            }`}
                          >
                            <button className={`mt-0.5 rounded-md h-5 w-5 border flex items-center justify-center transition-all shrink-0 ${
                              checked ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-300 bg-white'
                            }`}>
                              {checked && <Check className="h-3.5 w-3.5" />}
                            </button>
                            <div className="space-y-0.5">
                              <span className={`font-bold text-xs ${checked ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                                Etapa {index + 1}: {item.title}
                              </span>
                              <p className={`text-[11px] ${checked ? 'text-slate-400' : 'text-slate-500'}`}>
                                {item.desc}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 13: CRONOGRAMA PRÁTICO */}
              {selectedBlockId === 'bloco13' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Clock className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">12 Dias de Sprint</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 13 — Cronograma Operacional para Subir o App</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Siga este roadmap tático sequencial de 12 dias para organizar o desenvolvimento e garantir o lançamento comercial sem estouros de prazo.
                  </p>

                  {/* Operational Timeline */}
                  <div className="relative border-l-2 border-slate-200 pl-6 space-y-6 text-xs font-sans">
                    <div className="relative">
                      <span className="absolute -left-[31px] top-0 bg-slate-900 text-amber-400 h-4.5 w-4.5 rounded-full text-[9px] flex items-center justify-center font-bold">D1</span>
                      <p className="font-bold text-slate-900 text-xs">Dias 1 e 2: Navegação e Layouts Base</p>
                      <p className="text-slate-500 mt-1">Montagem do painel de navegação esquerdo, cabeçalhos mobile e páginas limpas de placeholder de cada aba.</p>
                    </div>

                    <div className="relative">
                      <span className="absolute -left-[31px] top-0 bg-slate-900 text-amber-400 h-4.5 w-4.5 rounded-full text-[9px] flex items-center justify-center font-bold">D3</span>
                      <p className="font-bold text-slate-900 text-xs">Dias 3 e 4: Onboarding e Criação de Contas</p>
                      <p className="text-slate-500 mt-1">Implementação técnica das 4 perguntas interativas, microcopy acadêmico e geração automática de plano de estudos.</p>
                    </div>

                    <div className="relative">
                      <span className="absolute -left-[31px] top-0 bg-slate-900 text-amber-400 h-4.5 w-4.5 rounded-full text-[9px] flex items-center justify-center font-bold">D5</span>
                      <p className="font-bold text-slate-900 text-xs">Dias 5 e 6: Biblioteca de Resumos MVP</p>
                      <p className="text-slate-500 mt-1">Subida de resumos simplificados focados no Grupo A e cadastramento inicial de PDFs e links externos.</p>
                    </div>

                    <div className="relative">
                      <span className="absolute -left-[31px] top-0 bg-slate-900 text-amber-400 h-4.5 w-4.5 rounded-full text-[9px] flex items-center justify-center font-bold">D7</span>
                      <p className="font-bold text-slate-900 text-xs">Dias 7 e 8: Exercícios e Correção Automática</p>
                      <p className="text-slate-500 mt-1">Integração da lógica de acerto/erro, caixa de explicação comentada do professor e regras de agendamento de revisões.</p>
                    </div>

                    <div className="relative">
                      <span className="absolute -left-[31px] top-0 bg-slate-900 text-amber-400 h-4.5 w-4.5 rounded-full text-[9px] flex items-center justify-center font-bold">D9</span>
                      <p className="font-bold text-slate-900 text-xs">Dias 9 e 10: Monetização, Paywall e Banners</p>
                      <p className="text-slate-500 mt-1">Configuração de planos comerciais, ativação de gating por questões respondidas na conta trial e banners contextuais.</p>
                    </div>

                    <div className="relative">
                      <span className="absolute -left-[31px] top-0 bg-slate-900 text-amber-400 h-4.5 w-4.5 rounded-full text-[9px] flex items-center justify-center font-bold">D11</span>
                      <p className="font-bold text-slate-900 text-xs">Dias 11 e 12: Admin Mínimo, QA e Publicação</p>
                      <p className="text-slate-500 mt-1">Testes exaustivos de checkout de pagamentos, rotinas de suporte pós-compra e liberação oficial de acessos nas lojas.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 14: PACOTE COMERCIAL DE LANÇAMENTO */}
              {selectedBlockId === 'bloco14' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Target className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Estratégia de Vendas</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 14 — Pacote Comercial de Lançamento</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    Estratégias de empacotamento da oferta de inauguração e funil de trial controlado para garantir taxas de conversão de leads frios em assinantes pagantes superiores a 5%.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-2">
                      <h4 className="font-bold text-slate-900 flex items-center space-x-1.5 uppercase text-[10px]">
                        <span className="h-2 w-2 bg-amber-500 rounded-full"></span>
                        <span>A Oferta Irresistível do MVP</span>
                      </h4>
                      <p className="text-slate-500 leading-relaxed text-[11px]">
                        Destaque o <strong>Plano Anual de R$ 399,00</strong> sob a premissa de "Desconto de Inauguração de R$ 599 por R$ 399". Adicione garantia incondicional de 7 dias com ressarcimento total da taxa e suporte por WhatsApp com mentores.
                      </p>
                    </div>

                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-2">
                      <h4 className="font-bold text-slate-900 flex items-center space-x-1.5 uppercase text-[10px]">
                        <span className="h-2 w-2 bg-emerald-500 rounded-full"></span>
                        <span>Funil de Captação & Trial Controlado</span>
                      </h4>
                      <p className="text-slate-500 leading-relaxed text-[11px]">
                        Ofereça o app de forma gratuita na App Store/Play Store. Permita que o lead responda ao onboarding e resolva até <strong>10 questões de Ética e Direito Constitucional por dia</strong>. Ao tentar resolver a 11ª questão ou acessar os simulados completos, o Paywall Comercial é acionado bloqueando as demais funções.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* BLOCO 15: KIT DE VALIDAÇÃO DOS PRIMEIROS 30 DIAS */}
              {selectedBlockId === 'bloco15' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <TrendingUp className="h-6 w-6 text-amber-500" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Métricas & Otimização</span>
                      <h2 className="text-xl font-black text-slate-900">BLOCO 15 — Kit de Validação dos Primeiros 30 Dias</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    O aplicativo foi lançado. Quais métricas observar nas primeiras 4 semanas de operação para validar o Product-Market Fit e corrigir gargalos de retenção?
                  </p>

                  <div className="border border-slate-200 rounded-xl overflow-hidden text-[11px]">
                    <div className="bg-slate-900 text-white font-mono p-3 font-bold text-[9px] uppercase">
                      KPIs Semanais de Saúde do Produto
                    </div>
                    <div className="grid grid-cols-4 bg-slate-100 p-2 font-mono text-[9px] font-bold text-slate-700">
                      <div>SEMANA</div>
                      <div>MÉTRICA CRÍTICA</div>
                      <div>META MÍNIMA</div>
                      <div>AÇÃO SE ESTIVER BAIXA</div>
                    </div>
                    <div className="grid grid-cols-4 p-2.5 border-b border-slate-100">
                      <div className="font-bold text-slate-900">Semana 1</div>
                      <div>Conclusão de Onboarding</div>
                      <div className="font-semibold text-emerald-600">85% dos downloads</div>
                      <div>Reduzir número de perguntas / Melhorar clareza de valor inicial.</div>
                    </div>
                    <div className="grid grid-cols-4 p-2.5 border-b border-slate-100">
                      <div className="font-bold text-slate-900">Semana 2</div>
                      <div>Retenção D7 (Uso ativo 7 dias pós-download)</div>
                      <div className="font-semibold text-emerald-600">40% de usuários ativos</div>
                      <div>Reforçar a régua de Push Notifications e e-mail de metas pendentes.</div>
                    </div>
                    <div className="grid grid-cols-4 p-2.5">
                      <div className="font-bold text-slate-900">Semanas 3/4</div>
                      <div>Taxa de Conversão de Paywall</div>
                      <div className="font-semibold text-emerald-600">3% do tráfego trial</div>
                      <div>Adicionar depoimentos reais de aprovações / Facilitar checkout PIX rápido.</div>
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

          {/* =========================================================================
              VIEW MODE: DOCUMENTAÇÃO DE REFERÊNCIA (18 CAPÍTULOS STRATEGIC)
              ========================================================================= */}
          {activeViewMode === 'documentacao_mestra' && (
            <div className="space-y-6 animate-fade-in">

              {/* CAP 1: Visão Executiva */}
              {selectedCapituloId === 'cap1' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Compass className="h-6 w-6 text-slate-900" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Capítulo 1</span>
                      <h2 className="text-xl font-bold text-slate-900">Visão Executiva do OAB 3F</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-700 leading-relaxed">
                    O <strong>OAB 3F</strong> não é apenas mais um cursinho preparatório digital. Trata-se de uma plataforma educacional interativa de alta performance baseada em tecnologia móvel, desenhada especificamente para suprir as principais dores do candidato ao Exame de Ordem: <strong>falta de foco, desorganização no cronograma, esquecimento passivo do conteúdo e ansiedade pós-atraso</strong>.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-50 border border-slate-100 rounded-lg space-y-1.5">
                      <span className="font-bold text-slate-900 text-xs block uppercase font-mono text-[9px]">O Grande Problema</span>
                      <p className="text-slate-600 text-[11px] leading-relaxed">
                        Estudantes de Direito desperdiçam tempo com videoaulas infinitas de 2 horas. Eles acumulam PDFs gigantescos e chegam à prova exaustos, sem ter resolvido questões suficientes e esquecendo matérias estudadas há 4 semanas (Curva do Esquecimento).
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 border border-slate-100 rounded-lg space-y-1.5">
                      <span className="font-bold text-slate-900 text-xs block uppercase font-mono text-[9px]">A Solução Proposta</span>
                      <p className="text-slate-600 text-[11px] leading-relaxed">
                        O método 3F automatiza o estudo ativo. Ele entrega um <strong>Plano de Estudos Personalizado</strong> que diz exatamente o que ler, treinar e revisar hoje. Através da <strong>Revisão Espaçada Ativa</strong> e do banco com milhares de <strong>Questões Comentadas</strong>, a retenção sobe de 20% para mais de 85%.
                      </p>
                    </div>
                  </div>

                  <div className="border-l-4 border-amber-500 bg-amber-50/40 p-4 rounded-r-lg">
                    <p className="font-bold text-slate-950 text-xs">Transformação Prometida ao Aluno:</p>
                    <p className="text-slate-600 italic text-[11px] mt-1">
                      "Deixe de lado a ansiedade de não saber se está progredindo. Siga o roteiro diário do OAB 3F e chegue à aprovação da 1ª Fase com mais de 80% de acertos garantidos no simulado final."
                    </p>
                  </div>
                </div>
              )}

              {/* CAP 2: PRD do Produto */}
              {selectedCapituloId === 'cap2' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Target className="h-6 w-6 text-slate-900" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Capítulo 2</span>
                      <h2 className="text-xl font-bold text-slate-900">PRD do Produto (Requirements)</h2>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs font-sans">
                    <div className="space-y-1 bg-slate-50 p-2.5 border border-slate-100 rounded-lg">
                      <span className="text-slate-500 text-[9px] font-mono">1. Nome do Produto</span>
                      <p className="font-bold text-slate-900">OAB 3F (Plataforma Digital de Preparação OAB)</p>
                    </div>
                    <div className="space-y-1 bg-slate-50 p-2.5 border border-slate-100 rounded-lg">
                      <span className="text-slate-500 text-[9px] font-mono">2. Objetivo Principal</span>
                      <p className="font-bold text-slate-900">Guiar o estudante à aprovação no Exame de Ordem com cronograma dinâmico.</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="border border-slate-200 rounded-lg">
                      <button 
                        onClick={() => toggleAccordion('prd-rf')}
                        className="w-full flex items-center justify-between p-3 bg-slate-50 text-slate-900 font-bold text-xs rounded-t-lg"
                      >
                        <span>REQUISITOS FUNCIONAIS (RF) - NÚCLEO DO SISTEMA</span>
                        {expandedAccordions['prd-rf'] ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                      </button>
                      {expandedAccordions['prd-rf'] && (
                        <div className="p-3 border-t border-slate-200 space-y-2.5 font-sans text-xs">
                          <div className="grid grid-cols-12 gap-2 pb-2 border-b border-slate-100">
                            <span className="col-span-2 font-mono font-bold text-slate-800">RF-001</span>
                            <div className="col-span-10">
                              <span className="font-bold text-slate-950">Geração de Cronograma Adaptativo</span>
                              <p className="text-slate-500 text-[10px]">O sistema deve recalcular automaticamente o plano de estudos do aluno caso ele fique mais de 3 dias sem marcar atividades como concluídas.</p>
                            </div>
                          </div>
                          <div className="grid grid-cols-12 gap-2 pb-2 border-b border-slate-100">
                            <span className="col-span-2 font-mono font-bold text-slate-800">RF-002</span>
                            <div className="col-span-10">
                              <span className="font-bold text-slate-950">Filtro Inteligente de Questões FGV</span>
                              <p className="text-slate-500 text-[10px]">O aluno deve ser capaz de filtrar questões por matéria, subtema, banca FGV e ano de aplicação, além de separar questões resolvidas de não resolvidas.</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* CAP 3: Proposta Pedagógica */}
              {selectedCapituloId === 'cap3' && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <Award className="h-6 w-6 text-slate-900" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Capítulo 3</span>
                      <h2 className="text-xl font-bold text-slate-900">Proposta Pedagógica e Método 3F</h2>
                    </div>
                  </div>

                  <p className="text-sm text-slate-700 leading-relaxed">
                    O método pedagógico do OAB 3F fundamenta-se na <strong>Curva de Aprendizado Ativa e Prática</strong>. Ele divide a preparação do exame de ordem em 3 fases complementares que substituem as rotinas de estudo exaustivas convencionais por hábitos de alta absorção.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="border-t-4 border-slate-900 bg-slate-50 p-4 space-y-2 rounded-b-lg shadow-sm">
                      <span className="font-bold text-[10px] text-slate-500 font-mono">Fase 1: Focalização</span>
                      <h4 className="font-bold text-slate-900 text-xs">Leitura & Resumos Teóricos</h4>
                      <p className="text-[10px] text-slate-600">O aluno absorve de forma ultra-focada apenas as matérias quentes do edital. No lugar de assistir videoaulas, lê resumos com foco nas jurisprudências.</p>
                    </div>
                    <div className="border-t-4 border-amber-500 bg-slate-50 p-4 space-y-2 rounded-b-lg shadow-sm">
                      <span className="font-bold text-[10px] text-amber-600 font-mono">Fase 2: Fixação</span>
                      <h4 className="font-bold text-slate-900 text-xs">Prática Inteligente de Questões</h4>
                      <p className="text-[10px] text-slate-600">Resolução ativa de questões anteriores com visualização imediata do gabarito oficial fundamentado. Os erros retroalimentam as revisões.</p>
                    </div>
                    <div className="border-t-4 border-emerald-500 bg-slate-50 p-4 space-y-2 rounded-b-lg shadow-sm">
                      <span className="font-bold text-[10px] text-emerald-600 font-mono">Fase 3: Simulação</span>
                      <h4 className="font-bold text-slate-900 text-xs">Avaliação Diagnóstica Ativa</h4>
                      <p className="text-[10px] text-slate-600">Simulados periódicos com controle estrito de cronômetro, simulando as reais condições físicas e psicológicas da prova presencial.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Show fallback message for remaining chapters in strategic reference */}
              {!['cap1', 'cap2', 'cap3'].includes(selectedCapituloId) && (
                <div className="space-y-6">
                  <div className="flex items-center space-x-3 border-b border-slate-100 pb-4">
                    <FileText className="h-6 w-6 text-slate-900" />
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Referência Acadêmica</span>
                      <h2 className="text-xl font-bold text-slate-900">Capítulo {selectedCapituloId.replace('cap', '')}</h2>
                    </div>
                  </div>

                  <div className="bg-slate-50 p-5 border border-slate-200 rounded-xl space-y-3">
                    <p className="text-sm font-bold text-slate-900">Referência Estratégica Completa Registrada</p>
                    <p className="text-slate-600 text-xs">
                      Os capítulos 4 a 18 referem-se à documentação estratégica estática de planejamento geral (fluxos operacionais, regras de negócio, modelagem de tabelas relacionais). 
                    </p>
                    <p className="text-slate-600 text-xs leading-relaxed">
                      Para ver a especificação operacional pronta para o seu lançamento com <strong>cópias de telas, automações de CRM, seeds reais de banco de dados e checklists de tarefas</strong>, clique no botão <strong>"15 Blocos de Execução"</strong> no canto superior direito desta tela.
                    </p>
                    <button
                      onClick={() => { setActiveViewMode('pacote_execucao'); setSelectedBlockId('bloco2'); }}
                      className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2 px-4 rounded-lg flex items-center space-x-1.5"
                    >
                      <Zap className="h-3.5 w-3.5 text-amber-400" />
                      <span>Ir Para Ativos Práticos de Lançamento</span>
                    </button>
                  </div>
                </div>
              )}

            </div>
          )}

        </div>
      </div>
      )}
    </div>
  );
}
