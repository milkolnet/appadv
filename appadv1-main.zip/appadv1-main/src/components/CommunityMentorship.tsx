/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Calendar, 
  Sparkles, 
  CheckSquare, 
  Send, 
  Lock, 
  Crown, 
  ExternalLink,
  Clock,
  Video,
  Bookmark,
  Check,
  CheckCircle
} from 'lucide-react';
import { MentorshipMeeting, MentorshipTask } from './CommunityData';

interface CommunityMentorshipProps {
  userPlan: string;
  onNavigateToTab?: (tab: string) => void;
  meetings: MentorshipMeeting[];
  tasks: MentorshipTask[];
  setTasks: React.Dispatch<React.SetStateAction<MentorshipTask[]>>;
}

export default function CommunityMentorship({ 
  userPlan, 
  onNavigateToTab,
  meetings,
  tasks,
  setTasks
}: CommunityMentorshipProps) {
  const [questionText, setQuestionText] = useState('');
  const [successMsg, setSuccessMsg] = useState(false);

  // Toggle tasks
  const handleToggleTask = (id: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        return { ...t, completed: !t.completed };
      }
      return t;
    }));
  };

  const handleAskMentor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim()) return;

    setSuccessMsg(true);
    setQuestionText('');
    setTimeout(() => {
      setSuccessMsg(false);
    }, 4000);
  };

  const isVipPlan = userPlan === 'vip' || userPlan === 'completo';

  return (
    <div className="relative animate-fade-in" id="community-mentorship-workspace">
      
      {/* LOCK COVER OVERLAY FOR NON-VIP MEMBERS */}
      {!isVipPlan && (
        <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-md z-30 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full overflow-hidden text-center p-8 space-y-6 animate-scale-in">
            <div className="w-14 h-14 bg-amber-100 text-[#D4AF37] rounded-full flex items-center justify-center mx-auto shadow-inner">
              <Lock className="h-7 w-7" />
            </div>
            
            <div className="space-y-1.5">
              <span className="bg-[#D4AF37] text-slate-900 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full font-mono">
                RECURSO VIP OAB 3F
              </span>
              <h3 className="font-serif font-black text-xl text-slate-900">
                Acesso Exclusivo à Mentoria
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto">
                Acelere sua aprovação com acompanhamento semanal, planos de ação individuais de reta final, cronogramas cirúrgicos e plantões de dúvidas diretamente com nossos mentores especialistas.
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-left space-y-2 text-xs">
              <span className="font-bold text-slate-700 block uppercase tracking-wider text-[9.5px]">Benefícios da Mentoria VIP:</span>
              <div className="space-y-1 text-slate-600">
                <span className="block">• Encontros de Mentoria semanais ao vivo</span>
                <span className="block">• Metas individuais de estudo e simulados</span>
                <span className="block">• Canal de dúvidas direto com os professores</span>
                <span className="block">• Correção personalizada de peças práticas (2ª fase)</span>
              </div>
            </div>

            {onNavigateToTab && (
              <button
                onClick={() => onNavigateToTab('monetizacao')}
                className="w-full bg-slate-900 hover:bg-slate-800 text-[#D4AF37] font-bold px-6 py-3 rounded-lg text-xs tracking-wider uppercase transition-all shadow-md cursor-pointer"
              >
                Fazer Upgrade para VIP & Mentoria
              </button>
            )}
          </div>
        </div>
      )}

      {/* MAIN CONTENT (BLURRED IF NOT VIP) */}
      <div className={`grid grid-cols-1 lg:grid-cols-12 gap-6 ${!isVipPlan ? 'filter blur-xs pointer-events-none select-none h-[400px] overflow-hidden' : ''}`}>
        
        {/* Left Column: Meetings & Mentor Action Plan */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Mentor Meta Checklist */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <h3 className="text-sm font-black text-slate-800 flex items-center gap-1.5 border-b border-slate-100 pb-3">
              <CheckSquare className="h-4.5 w-4.5 text-oab-accent" />
              Metas e Tarefas Semanais da Mentoria
            </h3>

            <div className="space-y-2.5">
              {tasks.map(tsk => (
                <div 
                  key={tsk.id}
                  onClick={() => handleToggleTask(tsk.id)}
                  className={`p-3.5 border rounded-xl flex items-start gap-3 cursor-pointer transition-all ${
                    tsk.completed 
                      ? 'bg-slate-50/70 border-slate-200 text-slate-400 line-through' 
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className={`h-4.5 w-4.5 rounded-md border flex items-center justify-center shrink-0 mt-0.5 ${
                    tsk.completed ? 'bg-slate-900 border-slate-900 text-white' : 'border-slate-300 bg-white'
                  }`}>
                    {tsk.completed && <Check className="h-3 w-3" />}
                  </div>
                  <div>
                    <span className="text-xs font-bold block">{tsk.title}</span>
                    <span className="text-[10.5px] text-slate-400 block font-medium leading-tight mt-0.5">{tsk.description}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Mentoring Meetings Timeline */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <h3 className="text-sm font-black text-slate-800 flex items-center gap-1.5 border-b border-slate-100 pb-3">
              <Calendar className="h-4.5 w-4.5 text-oab-accent" />
              Agenda de Encontros de Mentoria
            </h3>

            <div className="space-y-4">
              {meetings.map(meet => (
                <div key={meet.id} className="border border-slate-150 rounded-xl p-4 flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded ${
                        meet.type === 'live' ? 'bg-rose-500/10 text-rose-500' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {meet.type === 'live' ? '● Ao Vivo' : 'Gravado'}
                      </span>
                      <span className="text-xs text-slate-400 font-medium font-mono">{meet.date} às {meet.time}</span>
                    </div>
                    <h4 className="font-serif font-bold text-slate-900 text-xs sm:text-sm">{meet.title}</h4>
                    <p className="text-xs text-slate-500 leading-snug">{meet.description}</p>
                  </div>

                  {meet.type === 'live' && meet.zoomUrl && (
                    <a 
                      href={meet.zoomUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-rose-500 hover:bg-rose-600 text-white text-[11px] font-bold py-2 px-3.5 rounded-lg flex items-center gap-1 cursor-pointer transition-colors shrink-0"
                    >
                      <Video className="h-3.5 w-3.5" /> Entrar no Zoom <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: Guidelines & Ask Mentor */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Ask Mentor Form */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <h3 className="text-sm font-black text-slate-800 flex items-center gap-1.5 border-b border-slate-100 pb-3 mb-4">
              <Sparkles className="h-4.5 w-4.5 text-[#D4AF37]" />
              Escrever ao seu Mentor
            </h3>

            {successMsg ? (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-center space-y-2 text-emerald-800 animate-fade-in">
                <CheckCircle className="h-7 w-7 text-emerald-600 mx-auto" />
                <h4 className="text-xs font-bold">Mensagem enviada com sucesso!</h4>
                <p className="text-[10px] text-emerald-700 leading-relaxed">
                  Sua dúvida foi registrada em sua planilha individual. O mentor responderá com uma avaliação estratégica no seu painel ou por WhatsApp cadastrado em até 24 horas.
                </p>
              </div>
            ) : (
              <form onSubmit={handleAskMentor} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Qual sua maior dificuldade nos estudos esta semana?</label>
                  <textarea
                    placeholder="Ex: Estou acertando 38 pontos nos simulados, sempre travando em Civil e Administrativo. O que faço para subir para 42?"
                    value={questionText}
                    onChange={(e) => setQuestionText(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg p-2.5 h-32 focus:outline-none focus:ring-1 focus:ring-slate-400"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2.5 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Send className="h-3.5 w-3.5" /> Enviar Mensagem ao Mentor
                </button>
              </form>
            )}
          </div>

          {/* Golden Rules of Mentoring */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 text-slate-300 p-5 rounded-xl space-y-3 shadow-md">
            <h4 className="text-xs font-black uppercase text-[#D4AF37] tracking-wider flex items-center gap-1">
              <Crown className="h-4 w-4" /> Diretrizes de Sucesso do Método
            </h4>
            <div className="space-y-3.5 text-xs">
              <div className="space-y-0.5">
                <span className="font-bold text-white block">1. Diagnóstico de Erros</span>
                <p className="text-slate-400 leading-snug">Cada questão errada é um convite para marcar sua fundamentação legislativa de vermelho no Vade Mecum.</p>
              </div>
              <div className="space-y-0.5">
                <span className="font-bold text-white block">2. Cronograma Blindado</span>
                <p className="text-slate-400 leading-snug">Siga a ordem sequencial proposta de Ética Profissional e Direito Constitucional nos primeiros 10 dias.</p>
              </div>
              <div className="space-y-0.5">
                <span className="font-bold text-white block">3. Simulação Pura</span>
                <p className="text-slate-400 leading-snug">Faça os simulados semanais sem consultas externas e sob controle rigoroso de tempo de 5 horas.</p>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
