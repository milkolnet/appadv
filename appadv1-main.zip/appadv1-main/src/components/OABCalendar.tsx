/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar,
  Clock,
  Plus,
  AlertCircle,
  Bell,
  Trash2,
  CalendarDays,
  ListFilter,
  Check,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  ChevronDown,
  Award,
  FileText,
  Sparkles,
  Layers,
  ShieldAlert,
  ArrowUpRight,
  Activity,
  Info,
  History,
  Sliders,
  Target,
  Compass,
  X,
  Volume2,
  Send,
  UserCheck,
  Zap,
  BookOpen,
  Settings
} from 'lucide-react';
import { WeeklyTask, StudentProgress, OABCalendarEvent } from '../types';

interface OABCalendarProps {
  events: OABCalendarEvent[];
  onAddEvent: (newEvent: OABCalendarEvent) => void;
  onDeleteEvent: (eventId: string) => void;
  weeklyTasks: WeeklyTask[];
  onToggleTask: (taskId: string) => void;
  onAddTask: (task: Omit<WeeklyTask, 'id'>) => void;
  onDeleteTask: (taskId: string) => void;
  progress: StudentProgress;
  setProgress: React.Dispatch<React.SetStateAction<StudentProgress>>;
  onNavigateToTab: (tab: string) => void;
  weeklyStudyHours: number;
  studyHoursGoal: number;
  onAddStudyHours: (hours: number) => void;
  onUpdateTasks: React.Dispatch<React.SetStateAction<WeeklyTask[]>>;
  onStartStudyTask?: (taskId: string) => void;
}

// Support Categories for Filter (Section 10)
type FilterCategory = 
  | 'todos' 
  | 'eventos_oab' 
  | 'tarefas_plano' 
  | 'revisoes' 
  | 'simulados' 
  | 'fase1' 
  | 'fase2' 
  | 'pecas' 
  | 'discursivas' 
  | 'avisos' 
  | 'concluidos' 
  | 'pendentes';

// Notification Item Interface
interface ToastNotification {
  id: string;
  category: string;
  title: string;
  description: string;
  timestamp: string;
  urgent: boolean;
}

export default function OABCalendar({
  events,
  onAddEvent,
  onDeleteEvent,
  weeklyTasks,
  onToggleTask,
  onAddTask,
  onDeleteTask,
  progress,
  setProgress,
  onNavigateToTab,
  weeklyStudyHours,
  studyHoursGoal,
  onAddStudyHours,
  onUpdateTasks,
  onStartStudyTask
}: OABCalendarProps) {
  // Navigation for internal sections (Seções do Calendário)
  // 'geral' = Seção 1 (Tela principal/Dashboard)
  // 'oficial' = Seção 2 (Calendário Oficial da OAB)
  // 'agenda' = Seção 3 (Agenda pessoal do aluno com visões Diária/Semanal/Mensal)
  // 'revisoes' = Seção 4 (Integração com Revisões)
  // 'simulados' = Seção 5 (Integração com Simulados)
  // 'segundafase' = Seção 6 (Integração com a 2ª Fase)
  // 'comunicacao' = Seção 9 (Central de Avisos)
  // 'historico' = Seção 12 (Histórico e Rastreio de Agenda)
  const [activeSubSection, setActiveSubSection] = useState<'geral' | 'oficial' | 'agenda' | 'revisoes' | 'simulados' | 'segundafase' | 'comunicacao' | 'historico'>('geral');
  
  // Section 10: Multi-filter states
  const [calendarFilter, setCalendarFilter] = useState<FilterCategory>('todos');

  // Calendar Views inside Agenda: 'diaria' | 'semanal' | 'mensal'
  const [agendaView, setAgendaView] = useState<'diaria' | 'semanal' | 'mensal'>('diaria');

  // Currently selected date for Daily view (simulating June/July 2026)
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string>('2026-06-25'); // Thursday
  
  // Custom interactive alerts list (Section 7)
  const [activeAlerts, setActiveAlerts] = useState([
    { id: 'al-1', type: 'estudo', text: 'Você tem 3 tarefas pendentes hoje para cumprir sua meta.', discipline: 'Ética Profissional', urgent: true, resolved: false },
    { id: 'al-2', type: 'revisao', text: 'Revisão de 7 dias de Direito Civil pendente desde ontem.', discipline: 'Direito Civil', urgent: true, resolved: false },
    { id: 'al-3', type: 'simulado', text: 'Simulado de Constitucional agendado para amanhã de manhã.', discipline: 'Direito Constitucional', urgent: false, resolved: false },
    { id: 'al-4', type: 'desempenho', text: 'Seu desempenho médio em Processo Penal caiu abaixo de 50%.', discipline: 'Processo Penal', urgent: true, resolved: false },
    { id: 'al-5', type: 'desempenho', text: 'Você está acumulando erros em Direito Tributário (Controle de Constitucionalidade Tributário).', discipline: 'Direito Tributário', urgent: false, resolved: false },
    { id: 'al-6', type: 'prova', text: 'Faltam exatamente 80 dias para a prova de 1ª Fase do XL Exame!', exam: '1ª Fase', urgent: true, resolved: false },
    { id: 'al-7', type: 'prova', text: 'Atenção: Período de inscrições para o XL Exame inicia em 18 dias.', exam: 'Inscrição', urgent: true, resolved: false },
    { id: 'al-8', type: 'fase2', text: 'Peça de Reclamação Trabalhista recomendada ainda não estudada.', discipline: 'Direito do Trabalho', urgent: false, resolved: false }
  ]);

  // Section 9: Custom announcements and communications
  const [courseAnnouncements, setCourseAnnouncements] = useState([
    { id: 'ann-1', title: '🚨 Plantão de Dúvidas de Ética ao Vivo', date: '2026-06-26', category: 'Mentoria', text: 'Nesta sexta-feira teremos uma mentoria intensiva abordando prerrogativas da advocacia e sanções disciplinares mais cobradas pela FGV.', read: false, urgent: true },
    { id: 'ann-2', title: '📚 Novo PDF de Super Resumos: Recursos Penais', date: '2026-06-24', category: 'Materiais', text: 'Disponibilizamos na biblioteca um compilado de apelação criminal, recursos em sentido estrito e agravos em execução.', read: true, urgent: false },
    { id: 'ann-3', title: '⚖️ Comunicado OAB: Publicação Retificadora do Edital', date: '2026-06-22', category: 'OAB Oficial', text: 'A FGV publicou uma retificação técnica sobre os locais de prova e isenções de taxa do XL Exame. Confira o documento.', read: false, urgent: true },
    { id: 'ann-4', title: '🚀 Atualização do App: Caderno de Erros Otimizado', date: '2026-06-20', category: 'Atualização', text: 'Novo algoritmo de repetição inteligente acoplado aos seus erros mais frequentes na 1ª fase.', read: true, urgent: false },
    { id: 'ann-5', title: '🔥 Alerta Reta Final: Foco em Ética e Constitucional', date: '2026-06-15', category: 'Dicas', text: 'Nossos dados históricos indicam que candidatos que dominam Ética (8 questões) e Constitucional (6 questões) têm 82% mais chances de aprovação.', read: false, urgent: false }
  ]);

  // Section 8: Simulated live push notification toasts state
  const [activeToasts, setActiveToasts] = useState<ToastNotification[]>([]);

  // Simulation form states for adding personal calendar events
  const [showAddPersonalForm, setShowAddPersonalForm] = useState(false);
  const [personalTitle, setPersonalTitle] = useState('');
  const [personalDate, setPersonalDate] = useState('2026-06-25');
  const [personalType, setPersonalType] = useState<'aula' | 'questao' | 'revisao' | 'simulado' | 'peca' | 'discursiva'>('questao');
  const [personalDiscipline, setPersonalDiscipline] = useState('Ética Profissional');
  const [personalDesc, setPersonalDesc] = useState('');
  const [personalPriority, setPersonalPriority] = useState<'Baixa' | 'Média' | 'Alta'>('Média');

  // Track simulated user actions for Section 12 (History Tracker)
  const [resolvedAlertsCount, setResolvedAlertsCount] = useState(3);
  const [notificationsHistory, setNotificationsHistory] = useState<string[]>([
    "Notificação recebida: Período de inscrições do XL Exame está próximo (25/06/2026)",
    "Notificação recebida: Faça sua revisão de 24 horas em Direito Civil (24/06/2026)",
    "Notificação recebida: Simulado Geral da OAB já disponível na plataforma (23/06/2026)",
    "Notificação recebida: Dica estratégica do dia de Processo Penal liberada (22/06/2026)"
  ]);

  // Simulate today's date: June 25, 2026
  const SIMULATED_TODAY_DATE = '2026-06-25';

  // --- REVIEWS DATA (Section 4) ---
  const scheduledReviews = useMemo(() => {
    return [
      { id: 'rev-1', title: 'Revisão 24h: Direitos dos Advogados (Estatuto)', discipline: 'Ética Profissional', type: '24h', flashcardsCount: 15, delayDays: 0, completed: false },
      { id: 'rev-2', title: 'Revisão 7d: Direito das Obrigações & Contratos', discipline: 'Direito Civil', type: '7d', flashcardsCount: 12, delayDays: 1, completed: false },
      { id: 'rev-3', title: 'Revisão 30d: Remédios Constitucionais', discipline: 'Direito Constitucional', type: '30d', flashcardsCount: 20, delayDays: 0, completed: false },
      { id: 'rev-4', title: 'Revisão Especial: Nulidades no Processo Penal', discipline: 'Processo Penal', type: 'atrasada', flashcardsCount: 8, delayDays: 3, completed: false },
      { id: 'rev-5', title: 'Estruturação de Contestação Trabalhista (2ª Fase)', discipline: 'Direito do Trabalho', type: 'peça 2ª Fase', flashcardsCount: 5, delayDays: 0, completed: false }
    ];
  }, []);

  // Use a local state for reviews to allow interactivity (resolving, rescheduling)
  const [reviewsState, setReviewsState] = useState(scheduledReviews);

  // --- SIMULADOS DATA (Section 5) ---
  const scheduledSimulados = [
    { id: 'sim-sch-1', name: 'I Simulado Nacional XL Exame de Ordem', phase: '1ª Fase', date: '2026-07-05', duration: '5 horas (80 questões)', status: 'agendado' },
    { id: 'sim-sch-2', name: 'Simulado Prático-Profissional Penal', phase: '2ª Fase', date: '2026-07-12', duration: '5 horas (Peça + 4 questões)', status: 'pendente' },
    { id: 'sim-sch-3', name: 'Simulado Final de Diagnóstico 1ª Fase', phase: '1ª Fase', date: '2026-08-30', duration: '5 horas (80 questões)', status: 'agendado' },
    { id: 'sim-sch-4', name: 'Mini-Simulado de Ética e Constitucional', phase: '1ª Fase', date: '2026-06-24', duration: '2 horas (30 questões)', status: 'atrasado' }
  ];
  const [simuladosState, setSimuladosState] = useState(scheduledSimulados);

  // --- SECOND PHASE AGENDAMENTO WEEKLY PLAN (Section 6) ---
  const secondPhaseChecklists: { [key: string]: string[] } = {
    'Direito Penal': [
      'Estudo de Peça: Memoriais de Alegações Finais (Art. 403, §3º CPP)',
      'Prática de Discursivas: Teoria da Pena e Dosimetria',
      'Revisão: Habeas Corpus e Cabimentos Recursais',
      'Estudo de Peça: Resposta à Acusação (Art. 396 CPP)',
      'Simulado Prático Completo de 5 Horas'
    ],
    'Direito Constitucional': [
      'Estudo de Peça: Mandado de Segurança Individual e Coletivo',
      'Prática de Discursivas: Controle de Constitucionalidade',
      'Revisão: Ação Direta de Inconstitucionalidade (ADI)',
      'Estudo de Peça: Recurso Ordinário Constitucional (ROC)',
      'Simulado Prático Completo de Constitucional'
    ],
    'Direito do Trabalho': [
      'Estudo de Peça: Reclamação Trabalhista Completa',
      'Prática de Discursivas: Jornada de Trabalho e Horas Extras',
      'Revisão: Recurso Ordinário (RO)',
      'Estudo de Peça: Contestação Trabalhista',
      'Simulado Prático de 2ª Fase do Trabalho'
    ],
    'Direito Civil': [
      'Estudo de Peça: Petição Inicial de Alimentos / Indenizatória',
      'Prática de Discursivas: Direito de Família e Sucessões',
      'Revisão: Recurso de Apelação e Agravo de Instrumento',
      'Estudo de Peça: Contestação Cível com Preliminares',
      'Simulado Prático Geral Cível'
    ]
  };

  const selectedArea = progress.selectedSecondPhaseArea || 'Direito Penal';
  const areaChecklist = secondPhaseChecklists[selectedArea] || secondPhaseChecklists['Direito Penal'];

  const [phase2Interactivity, setPhase2Interactivity] = useState([
    { id: 'p2-1', day: 'Terça-feira', task: `Treinar Peça: Contestação em ${selectedArea}`, type: 'Peça Prática', completed: false },
    { id: 'p2-2', day: 'Quinta-feira', task: `Revisar Artigos Importantes de ${selectedArea}`, type: 'Revisão Artigos', completed: false },
    { id: 'p2-3', day: 'Sábado', task: `Simulado Prático Completo de ${selectedArea} (5 horas)`, type: 'Simulado Prático', completed: false },
    { id: 'p2-4', day: 'Domingo', task: 'Resolver 4 Questões Discursivas FGV anteriores', type: 'Discursiva', completed: true }
  ]);

  // --- CALENDAR COUNTDOWNS (Seção 1 - Contagem Regressiva) ---
  const countdowns = useMemo(() => {
    const today = new Date(SIMULATED_TODAY_DATE);
    const date1st = new Date('2026-09-13'); // Prova de 1ª Fase
    const date2nd = new Date('2026-11-15'); // Prova de 2ª Fase
    const dateInsc = new Date('2026-07-13'); // Inscrições

    const diffInsc = Math.ceil((dateInsc.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    const diff1st = Math.ceil((date1st.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    const diff2nd = Math.ceil((date2nd.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    return {
      insc: diffInsc,
      phase1: diff1st,
      phase2: diff2nd
    };
  }, []);

  // --- SECTION 11: AUTOMATIC PRIORITIZATION LOGIC ---
  const criticalPriorities = useMemo(() => {
    const list = [];
    
    // 1. Prova muito próxima
    if (countdowns.phase1 <= 90) {
      list.push({
        id: 'prio-crit-1',
        title: '🚨 XL Exame se Aproximando!',
        description: `Faltam ${countdowns.phase1} dias para a Prova Objetiva de 1ª Fase. É hora de intensificar a resolução de questões focado na FGV.`,
        badge: 'Exame OAB',
        type: 'danger'
      });
    }

    // 2. Revisões atrasadas
    const delayedReviews = reviewsState.filter(r => r.type === 'atrasada' && !r.completed);
    if (delayedReviews.length > 0) {
      list.push({
        id: 'prio-crit-2',
        title: '🔁 Revisões pendentes acumuladas',
        description: `Você tem ${delayedReviews.length} revisões agendadas atrasadas. Revise agora para evitar que o conteúdo suma da sua memória de longo prazo.`,
        badge: 'Revisão Crítica',
        type: 'warning'
      });
    }

    // 3. Simulados pendentes
    const overdueMocks = simuladosState.filter(s => s.status === 'atrasado');
    if (overdueMocks.length > 0) {
      list.push({
        id: 'prio-crit-3',
        title: '📈 Simulado em atraso!',
        description: `O "${overdueMocks[0].name}" está pendente. Simulados são essenciais para treinar o gerenciamento de tempo (5 horas de prova).`,
        badge: 'Simulado',
        type: 'warning'
      });
    }

    // 4. Baixo desempenho Ética ou Processos
    list.push({
      id: 'prio-crit-4',
      title: '🛡️ Matéria Estratégica: Ética Profissional',
      description: 'O Estatuto da Advocacia garante 8 pontos preciosos na 1ª fase. Mantenha o percentual acima de 80%.',
      badge: 'Desempenho',
      type: 'info'
    });

    return list;
  }, [countdowns, reviewsState, simuladosState]);

  // --- FILTERING GRAPH & DATA (Section 10) ---
  const filteredPersonalAgendaItems = useMemo(() => {
    return weeklyTasks.filter(task => {
      // Apply filters from Section 10
      if (calendarFilter === 'todos') return true;
      if (calendarFilter === 'tarefas_plano') return true;
      if (calendarFilter === 'fase1' && !task.title.includes('Peça') && !task.title.includes('Discursiva')) return true;
      if (calendarFilter === 'fase2' && (task.title.includes('Peça') || task.title.includes('Discursiva') || task.discipline === 'Peça Prática' || task.discipline === selectedArea)) return true;
      if (calendarFilter === 'pecas' && task.title.includes('Peça')) return true;
      if (calendarFilter === 'discursivas' && task.title.includes('Discursiva')) return true;
      if (calendarFilter === 'concluidos') return task.status === 'completed';
      if (calendarFilter === 'pendentes') return task.status !== 'completed';
      return false;
    });
  }, [weeklyTasks, calendarFilter, selectedArea]);

  // Filter for OAB Events
  const filteredOABEvents = useMemo(() => {
    return events.filter(ev => {
      if (calendarFilter === 'todos') return true;
      if (calendarFilter === 'eventos_oab') return true;
      if (calendarFilter === 'fase1' && ev.type === 'prova1') return true;
      if (calendarFilter === 'fase2' && ev.type === 'prova2') return true;
      if (calendarFilter === 'simulados' && ev.title.includes('Simulado')) return true;
      return false;
    });
  }, [events, calendarFilter]);

  // Sort events by date ascending
  const sortedOABEvents = useMemo(() => {
    return [...filteredOABEvents].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [filteredOABEvents]);

  // Sort personal items for daily view
  const dayNameMapping: { [key: string]: string } = {
    '2026-06-22': 'Segunda-feira',
    '2026-06-23': 'Terça-feira',
    '2026-06-24': 'Quarta-feira',
    '2026-06-25': 'Quinta-feira',
    '2026-06-26': 'Sexta-feira',
    '2026-06-27': 'Sábado',
    '2026-06-28': 'Domingo'
  };

  const selectedDayName = useMemo(() => {
    return dayNameMapping[selectedCalendarDate] || 'Quinta-feira';
  }, [selectedCalendarDate]);

  const dailyTasks = useMemo(() => {
    return weeklyTasks.filter(t => t.day === selectedDayName);
  }, [weeklyTasks, selectedDayName]);

  // --- ACTIONS ---

  // Alert handler (dismissing alerts)
  const handleDismissAlert = (alertId: string) => {
    setActiveAlerts(prev => prev.map(al => al.id === alertId ? { ...al, resolved: true } : al));
    setResolvedAlertsCount(prev => prev + 1);
    addNotificationHistory(`Alerta resolvido: ${activeAlerts.find(a => a.id === alertId)?.text}`);
  };

  const handleToggleAnnouncementRead = (annId: string) => {
    setCourseAnnouncements(prev => prev.map(ann => ann.id === annId ? { ...ann, read: true } : ann));
  };

  const handleMarkAllAnnouncementsRead = () => {
    setCourseAnnouncements(prev => prev.map(ann => ({ ...ann, read: true })));
    alert("Todos os avisos do curso foram marcados como lidos!");
  };

  // Quick Action: Add notification log helper
  const addNotificationHistory = (logText: string) => {
    setNotificationsHistory(prev => [logText, ...prev]);
  };

  // Live Toast Creator (Section 8 Simulation)
  const triggerPushNotificationSimulation = (category: string, title: string, description: string, urgent: boolean = false) => {
    const newToast: ToastNotification = {
      id: 'toast-' + Date.now(),
      category,
      title,
      description,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      urgent
    };

    setActiveToasts(prev => [...prev, newToast]);
    addNotificationHistory(`[Push Sent] [${category}] ${title} - ${description}`);

    // Auto-remove toast after 4.5 seconds
    setTimeout(() => {
      setActiveToasts(prev => prev.filter(t => t.id !== newToast.id));
    }, 4500);
  };

  // Helper convert date
  const formatDatePT = (dateStr: string) => {
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    const day = parseInt(parts[2], 10);
    const monthIdx = parseInt(parts[1], 10) - 1;
    return `${day} de ${months[monthIdx]}, ${parts[0]}`;
  };

  // Convert Day Name to short letters
  const getShortDay = (day: string) => {
    return day.substring(0, 3);
  };

  // Add customized task inside calendar
  const handleAddPersonalTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!personalTitle.trim()) return;

    onAddTask({
      day: dayNameMapping[personalDate] || 'Quinta-feira',
      title: `${personalType === 'aula' ? '📺 Aula: ' : personalType === 'questao' ? '✍️ Exercício: ' : personalType === 'revisao' ? '🔁 Revisão: ' : personalType === 'simulado' ? '📈 Simulado: ' : personalType === 'peca' ? '📂 Peça OAB: ' : '📝 Discursiva: '}${personalTitle}`,
      description: personalDesc || 'Adicionado via calendário pessoal do aluno.',
      durationMinutes: 45,
      discipline: personalDiscipline,
      priority: personalPriority
    });

    setPersonalTitle('');
    setPersonalDesc('');
    setShowAddPersonalForm(false);
    triggerPushNotificationSimulation(
      'Rotina de Estudos',
      'Meta de estudos inserida!',
      `A atividade "${personalTitle}" foi programada com sucesso na sua agenda.`,
      false
    );
  };

  // Adding reminder from official events
  const handleAddReminderFromOfficial = (ev: OABCalendarEvent) => {
    onAddEvent({
      id: "ev-rem-" + Date.now(),
      title: `[Lembrete] ${ev.title}`,
      date: ev.date,
      type: 'outro',
      description: `Lembrete estratégico para acompanhar: ${ev.description}`,
      isImportant: true
    });
    
    triggerPushNotificationSimulation(
      'Notificações OAB',
      'Lembrete de compromisso ativado!',
      `Avisaremos você quando a data "${ev.title}" estiver próxima.`,
      true
    );
    alert(`Lembrete estratégico configurado para o evento "${ev.title}"!`);
  };

  // SMART REVISION ACTIONS (Section 4 Interactivity)
  const handleToggleReviewCompleted = (id: string) => {
    setReviewsState(prev => prev.map(rev => {
      if (rev.id === id) {
        const nextState = !rev.completed;
        if (nextState) {
          onAddStudyHours(parseFloat((rev.flashcardsCount * 1.5 / 60).toFixed(1)));
          addNotificationHistory(`Revisão Concluída: ${rev.title}`);
          triggerPushNotificationSimulation('Desempenho', 'Revisão Bateu! 🎉', `Você concluiu a revisão de ${rev.discipline} e reforçou sua memória!`, false);
        }
        return { ...rev, completed: nextState };
      }
      return rev;
    }));
  };

  const handleRescheduleReview = (id: string) => {
    alert("Revisão reagendada para amanhã para evitar sobrecarga de conteúdos!");
    addNotificationHistory(`Revisão Reagendada: ${reviewsState.find(r => r.id === id)?.title}`);
  };

  // SIMULADOS ACTIONS (Section 5 Interactivity)
  const handleSimulateExamStart = (name: string, phase: string) => {
    alert(`Iniciando simulação prática: ${name} (${phase}). O cronômetro oficial de 5h foi acionado e o app gerou seu gabarito eletrônico.`);
    onNavigateToTab('simulados');
  };

  const handleRescheduleSimulado = (id: string) => {
    setSimuladosState(prev => prev.map(sim => {
      if (sim.id === id) {
        return { ...sim, date: '2026-07-20', status: 'agendado' };
      }
      return sim;
    }));
    alert("Simulado postergado com sucesso no seu planejamento.");
  };

  // 2ª FASE COMPONENT INTERACTIVITY (Section 6)
  const handleToggleP2Task = (id: string) => {
    setPhase2Interactivity(prev => prev.map(t => {
      if (t.id === id) {
        const next = !t.completed;
        if (next) {
          triggerPushNotificationSimulation('Notificações 2ª Fase', 'Mais 1 degrau alcançado!', `Você treinou sua atividade prática de 2ª fase com excelência.`, false);
        }
        return { ...t, completed: next };
      }
      return t;
    }));
  };

  return (
    <div id="oab-calendar-comprehensive-container" className="space-y-6 relative">
      
      {/* ⚠️ LIVE PUSH TOASTS SIMULATOR CONTAINER (Section 8 overlay) */}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
        {activeToasts.map(toast => (
          <div 
            key={toast.id} 
            className={`pointer-events-auto p-4 rounded-xl shadow-xl border flex gap-3 animate-fade-in transition-all bg-slate-900 text-white ${toast.urgent ? 'border-amber-400' : 'border-slate-800'}`}
          >
            <div className="shrink-0 mt-0.5">
              <Bell className={`h-5 w-5 ${toast.urgent ? 'text-amber-400 animate-bounce' : 'text-slate-400'}`} />
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex justify-between items-center gap-2">
                <span className="text-[9px] uppercase font-black tracking-widest text-amber-400">{toast.category}</span>
                <span className="text-[9px] text-slate-500 font-mono">{toast.timestamp}</span>
              </div>
              <h5 className="text-xs font-extrabold">{toast.title}</h5>
              <p className="text-[11px] text-slate-300 leading-relaxed font-medium">{toast.description}</p>
            </div>
            <button 
              onClick={() => setActiveToasts(prev => prev.filter(t => t.id !== toast.id))}
              className="text-slate-500 hover:text-white transition-colors self-start cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>

      {/* Main Tab Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-1">
          <div className="text-[10px] uppercase font-black tracking-widest text-oab-accent flex items-center gap-1.5">
            <CalendarRangeIcon className="h-4 w-4 text-oab-accent" /> CENTRO DE AGENDA E COMUNICAÇÃO
          </div>
          <h2 className="text-2xl font-black font-display text-oab-primary flex items-center gap-2">
            Calendário OAB <span className="bg-amber-100 text-amber-800 border border-amber-200 px-2 py-0.5 text-xs font-black rounded-lg">PRO</span>
          </h2>
          <p className="text-xs text-slate-500 max-w-2xl">
            Sua central de prazos oficiais, revisões diárias, agendamentos de simulados, avisos críticos da plataforma e alertas automáticos de rendimento.
          </p>
        </div>

        {/* Quick Action: Start Personal Planner form */}
        <button
          onClick={() => setShowAddPersonalForm(!showAddPersonalForm)}
          className="bg-oab-primary hover:bg-slate-850 text-white font-black text-xs py-3 px-5 rounded-lg flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer uppercase tracking-wider"
          id="btn-calendar-add-event"
        >
          <Plus className="h-4 w-4 stroke-[3]" />
          <span>Inserir na Agenda</span>
        </button>
      </div>

      {/* Interactive Section Selector Tabs */}
      <div className="overflow-x-auto pb-1" id="calendar-subsection-tabs">
        <div className="flex border-b border-slate-200 whitespace-nowrap min-w-max gap-1">
          {[
            { id: 'geral', label: '📊 Painel de Agenda' },
            { id: 'agenda', label: '📅 Agenda Pessoal' },
            { id: 'oficial', label: '⚖️ Calendário Oficial FGV' },
            { id: 'revisoes', label: '🔁 Revisões Integradas' },
            { id: 'simulados', label: '📈 Simulados Agendados' },
            { id: 'segundafase', label: '🎓 Cronograma 2ª Fase' },
            { id: 'comunicacao', label: `📢 Central de Avisos (${courseAnnouncements.filter(a => !a.read).length})` },
            { id: 'historico', label: '📜 Histórico & Rastreamento' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveSubSection(tab.id as any);
                // Clear filters when shifting sections to ensure proper viewing
                setCalendarFilter('todos');
              }}
              className={`
                py-3 px-4 text-xs font-bold transition-all border-b-2 cursor-pointer
                ${activeSubSection === tab.id 
                  ? 'border-oab-accent text-oab-primary font-extrabold bg-white' 
                  : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-100/50'}
              `}
              id={`calendar-tab-${tab.id}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* COMPREHENSIVE FILTERING ROW (Section 10) */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 shadow-3xs">
        <div className="flex items-center gap-2">
          <Sliders className="h-4.5 w-4.5 text-slate-400" />
          <span className="text-xs font-bold text-slate-600">Filtros Inteligentes:</span>
        </div>

        <div className="flex flex-wrap gap-1.5" id="calendar-filter-bar">
          {[
            { id: 'todos', label: 'Todos' },
            { id: 'eventos_oab', label: 'Datas OAB' },
            { id: 'tarefas_plano', label: 'Tarefas' },
            { id: 'revisoes', label: 'Revisões' },
            { id: 'simulados', label: 'Simulados' },
            { id: 'fase1', label: '1ª Fase' },
            { id: 'fase2', label: '2ª Fase' },
            { id: 'pecas', label: 'Peças' },
            { id: 'discursivas', label: 'Discursivas' },
            { id: 'avisos', label: 'Avisos' },
            { id: 'concluidos', label: 'Concluídas' },
            { id: 'pendentes', label: 'Pendentes' }
          ].map(filter => (
            <button
              key={filter.id}
              onClick={() => setCalendarFilter(filter.id as FilterCategory)}
              className={`
                px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer border
                ${calendarFilter === filter.id 
                  ? 'bg-oab-primary border-oab-primary text-white shadow-xs' 
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'}
              `}
              id={`filter-btn-${filter.id}`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* PERSONAL EVENT CREATOR MODAL FORM INLINE */}
      {showAddPersonalForm && (
        <div className="bg-amber-50/50 border border-amber-200 rounded-xl p-5 shadow-sm space-y-4 animate-fade-in">
          <div className="flex justify-between items-center border-b border-amber-200 pb-2">
            <h4 className="text-xs font-black text-slate-800 flex items-center gap-1">
              <Plus className="h-4 w-4 text-amber-600" /> Agendar Atividade ou Compromisso Pessoal
            </h4>
            <button onClick={() => setShowAddPersonalForm(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
              <X className="h-4 w-4" />
            </button>
          </div>

          <form onSubmit={handleAddPersonalTaskSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-[11px] font-black text-slate-500 uppercase mb-1">Título do Compromisso</label>
              <input
                type="text"
                value={personalTitle}
                onChange={(e) => setPersonalTitle(e.target.value)}
                placeholder="Ex: Treinar peças de Habeas Corpus"
                className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none bg-white"
                required
              />
            </div>

            <div>
              <label className="block text-[11px] font-black text-slate-500 uppercase mb-1">Data</label>
              <select
                value={personalDate}
                onChange={(e) => setPersonalDate(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none bg-white font-bold text-slate-700"
              >
                <option value="2026-06-22">Segunda (22/06)</option>
                <option value="2026-06-23">Terça (23/06)</option>
                <option value="2026-06-24">Quarta (24/06)</option>
                <option value="2026-06-25">Quinta (25/06) - HOJE</option>
                <option value="2026-06-26">Sexta (26/06)</option>
                <option value="2026-06-27">Sábado (27/06)</option>
                <option value="2026-06-28">Domingo (28/06)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-black text-slate-500 uppercase mb-1">Tipo de Atividade</label>
              <select
                value={personalType}
                onChange={(e: any) => setPersonalType(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none bg-white"
              >
                <option value="aula">📺 Aula em Vídeo</option>
                <option value="questao">✍️ Bloco de Questões</option>
                <option value="revisao">🔁 Ciclo de Revisão</option>
                <option value="simulado">📈 Simulado Geral</option>
                <option value="peca">📂 Peça Prática (2ª Fase)</option>
                <option value="discursiva">📝 Questão Discursiva</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-black text-slate-500 uppercase mb-1">Disciplina Principal</label>
              <select
                value={personalDiscipline}
                onChange={(e) => setPersonalDiscipline(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none bg-white"
              >
                <option value="Ética Profissional">Ética Profissional</option>
                <option value="Direito Constitucional">Direito Constitucional</option>
                <option value="Direito Civil">Direito Civil</option>
                <option value="Processo Civil">Processo Civil</option>
                <option value="Direito Penal">Direito Penal</option>
                <option value="Processo Penal">Processo Penal</option>
                <option value="Direito Administrativo">Direito Administrativo</option>
                <option value="Direito do Trabalho">Direito do Trabalho</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-black text-slate-500 uppercase mb-1">Prioridade</label>
              <select
                value={personalPriority}
                onChange={(e: any) => setPersonalPriority(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none bg-white font-bold"
              >
                <option value="Alta">🔴 Alta</option>
                <option value="Média">🟡 Média</option>
                <option value="Baixa">🟢 Baixa</option>
              </select>
            </div>

            <div className="md:col-span-3">
              <label className="block text-[11px] font-black text-slate-500 uppercase mb-1">Observações / Metas Rápidas</label>
              <textarea
                value={personalDesc}
                onChange={(e) => setPersonalDesc(e.target.value)}
                placeholder="Ex: Resolver 15 questões de provas anteriores focadas em competência..."
                className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none bg-white h-16"
              />
            </div>

            <div className="md:col-span-3 flex justify-end gap-2 pt-2 border-t border-amber-100">
              <button
                type="button"
                onClick={() => setShowAddPersonalForm(false)}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 py-2 px-3 rounded cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="bg-oab-primary hover:bg-slate-850 text-white font-black text-xs py-2 px-4 rounded-lg cursor-pointer transition-all"
              >
                Agendar Compromisso
              </button>
            </div>
          </form>
        </div>
      )}


      {/* ========================================================
          SUB-SECTION 1: DASHBOARD / TELA PRINCIPAL (Seção 1)
          ======================================================== */}
      {activeSubSection === 'geral' && (
        <div className="space-y-6">
          
          {/* Section 1: Countdowns Cards & Quick Status Row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            
            <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white p-5 rounded-xl border border-slate-800 shadow-sm flex flex-col justify-between min-h-[140px]">
              <div className="flex justify-between items-start">
                <span className="text-[9px] uppercase font-black tracking-widest text-amber-400">Próxima Prova OAB</span>
                <Clock className="h-4.5 w-4.5 text-amber-400" />
              </div>
              <div>
                <div className="text-3xl font-black font-mono text-amber-400 leading-tight">
                  {countdowns.phase1} <span className="text-xs font-normal text-slate-300">dias</span>
                </div>
                <h4 className="text-[11px] font-bold text-slate-300 mt-1">1ª Fase: 13 de Set, 2026</h4>
              </div>
              <p className="text-[10px] text-slate-500">Prova objetiva de 80 questões.</p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between min-h-[140px]">
              <div className="flex justify-between items-start">
                <span className="text-[9px] uppercase font-black tracking-widest text-slate-400">Próxima Revisão</span>
                <History className="h-4.5 w-4.5 text-blue-500" />
              </div>
              <div>
                <div className="text-lg font-black text-slate-850 truncate">
                  {reviewsState.filter(r => !r.completed)[0]?.title || "Nenhuma pendente"}
                </div>
                <h4 className="text-[11px] font-bold text-slate-400 mt-1">Revisão Pendente hoje</h4>
              </div>
              <button 
                onClick={() => setActiveSubSection('revisoes')}
                className="text-left text-[10px] font-bold text-oab-accent hover:underline flex items-center gap-0.5 mt-2 cursor-pointer"
              >
                Abrir revisor agora <ChevronRight className="h-3 w-3" />
              </button>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between min-h-[140px]">
              <div className="flex justify-between items-start">
                <span className="text-[9px] uppercase font-black tracking-widest text-slate-400">Próximo Simulado</span>
                <Target className="h-4.5 w-4.5 text-emerald-500" />
              </div>
              <div>
                <div className="text-lg font-black text-slate-850 truncate">
                  {simuladosState[0]?.name}
                </div>
                <h4 className="text-[11px] font-bold text-slate-400 mt-1">Bater meta em: {formatDatePT(simuladosState[0]?.date)}</h4>
              </div>
              <button 
                onClick={() => setActiveSubSection('simulados')}
                className="text-left text-[10px] font-bold text-oab-accent hover:underline flex items-center gap-0.5 mt-2 cursor-pointer"
              >
                Fazer simulação <ChevronRight className="h-3 w-3" />
              </button>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between min-h-[140px]">
              <div className="flex justify-between items-start">
                <span className="text-[9px] uppercase font-black tracking-widest text-slate-400">Prazo Crítico FGV</span>
                <ShieldAlert className="h-4.5 w-4.5 text-red-500 animate-pulse" />
              </div>
              <div>
                <div className="text-lg font-black text-red-600">
                  {countdowns.insc} dias p/ inscrição
                </div>
                <h4 className="text-[11px] font-bold text-slate-400 mt-1">Início: 13 de Julho, 2026</h4>
              </div>
              <button 
                onClick={() => setActiveSubSection('oficial')}
                className="text-left text-[10px] font-bold text-oab-accent hover:underline flex items-center gap-0.5 mt-2 cursor-pointer"
              >
                Ver edital completo <ChevronRight className="h-3 w-3" />
              </button>
            </div>

          </div>

          {/* Section 11: Auto-prioritization strategically highlighted (Seção 11) */}
          <div className="bg-slate-50 border-l-4 border-amber-500 rounded-xl p-5 shadow-3xs space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-amber-500 fill-amber-500 animate-pulse" />
              <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider">Priorização Inteligente & Conselhos de Aprovação</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {criticalPriorities.map((item) => (
                <div key={item.id} className="bg-white rounded-lg p-3 border border-slate-200 flex flex-col justify-between shadow-3xs">
                  <div className="space-y-1">
                    <div className="flex justify-between items-center">
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${item.type === 'danger' ? 'bg-red-50 text-red-600' : 'bg-amber-50 text-amber-700'}`}>
                        {item.badge}
                      </span>
                      <span className="text-[9px] text-slate-400 font-mono">Urgente</span>
                    </div>
                    <h4 className="text-xs font-extrabold text-slate-800 pt-1">{item.title}</h4>
                    <p className="text-[11px] text-slate-500 leading-relaxed font-medium">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Grid Layout: Agenda Preview vs Notifications & Announcements */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left side: Today agenda summary */}
            <div className="lg:col-span-7 bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
              <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                <div className="space-y-0.5">
                  <h3 className="text-sm font-black text-slate-800 flex items-center gap-1.5">
                    <Calendar className="h-4.5 w-4.5 text-oab-accent" /> Metas Relevantes do Dia
                  </h3>
                  <p className="text-xs text-slate-400">Atividades de hoje: Quinta-feira (25 de Junho)</p>
                </div>
                <button
                  onClick={() => setActiveSubSection('agenda')}
                  className="text-xs font-black text-oab-accent hover:underline flex items-center gap-0.5 cursor-pointer"
                  id="btn-ver-agenda-completa"
                >
                  Ver agenda completa <ChevronRight className="h-4 w-4" />
                </button>
              </div>

              {dailyTasks.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs">
                  Sem metas programadas para hoje no seu roteiro pessoal.
                </div>
              ) : (
                <div className="space-y-3">
                  {dailyTasks.slice(0, 4).map((task) => (
                    <div 
                      key={task.id}
                      className={`p-3 rounded-xl border flex justify-between items-center gap-3 transition-colors ${task.status === 'completed' ? 'bg-slate-50 border-slate-100 opacity-80' : 'bg-white border-slate-200'}`}
                    >
                      <div className="flex items-start gap-2.5 min-w-0">
                        <button
                          onClick={() => onToggleTask(task.id)}
                          className={`mt-0.5 h-5 w-5 rounded flex items-center justify-center border transition-all cursor-pointer ${task.status === 'completed' ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-300'}`}
                        >
                          {task.status === 'completed' && <Check className="h-3 w-3 stroke-[3]" />}
                        </button>
                        <div className="space-y-0.5 min-w-0">
                          <span className="text-[9px] font-black uppercase text-oab-accent">{task.discipline}</span>
                          <h4 className={`text-xs font-bold text-slate-800 truncate ${task.status === 'completed' ? 'line-through text-slate-400' : ''}`}>{task.title}</h4>
                        </div>
                      </div>

                      <div className="shrink-0 flex items-center gap-1">
                        <span className="text-[10px] text-slate-400 font-mono mr-1">{task.durationMinutes}m</span>
                        {task.status !== 'completed' ? (
                          <button
                            onClick={() => {
                              if (onStartStudyTask) {
                                onStartStudyTask(task.id);
                              } else {
                                onToggleTask(task.id);
                                triggerPushNotificationSimulation('Rotina de Estudos', 'Tarefa Concluída! 👍', `Você concluiu: ${task.title}`, false);
                              }
                            }}
                            className="bg-[#0F172A] hover:bg-slate-800 text-white font-extrabold text-[10px] px-2.5 py-1 rounded cursor-pointer transition-colors"
                          >
                            Estudar ⚡
                          </button>
                        ) : (
                          onStartStudyTask && (
                            <button
                              onClick={() => onStartStudyTask(task.id)}
                              className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-[10px] px-2 py-1 rounded cursor-pointer transition-colors"
                            >
                              Notas 🔍
                            </button>
                          )
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Right side: Course Warnings & Recent Push Notifications (Section 9 & 8) */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Avisos do Curso Card */}
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                  <h3 className="text-sm font-black text-slate-800 flex items-center gap-1.5">
                    <FileText className="h-4.5 w-4.5 text-blue-500" /> Avisos da Plataforma ({courseAnnouncements.filter(a => !a.read).length})
                  </h3>
                  <button 
                    onClick={() => setActiveSubSection('comunicacao')}
                    className="text-xs font-black text-oab-accent hover:underline cursor-pointer"
                  >
                    Ver todos
                  </button>
                </div>

                <div className="space-y-3">
                  {courseAnnouncements.slice(0, 3).map((ann) => (
                    <div 
                      key={ann.id} 
                      onClick={() => handleToggleAnnouncementRead(ann.id)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer ${!ann.read ? 'bg-blue-50/40 border-blue-100 font-bold' : 'bg-white border-slate-150'}`}
                    >
                      <div className="flex justify-between items-center">
                        <span className={`text-[8.5px] font-black px-1.5 py-0.5 rounded uppercase ${ann.urgent ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-500'}`}>
                          {ann.category}
                        </span>
                        <span className="text-[9px] text-slate-400 font-mono">{ann.date.split('-')[2]}/{ann.date.split('-')[1]}</span>
                      </div>
                      <h4 className="text-xs text-slate-800 mt-1 leading-tight">{ann.title}</h4>
                      <p className="text-[10.5px] text-slate-500 mt-0.5 font-medium line-clamp-2 leading-snug">{ann.text}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Push notifications tester panel (Section 8) */}
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
                <div className="space-y-0.5">
                  <h3 className="text-sm font-black text-slate-800 flex items-center gap-1.5">
                    <Bell className="h-4.5 w-4.5 text-amber-500" /> Teste de Notificações Push
                  </h3>
                  <p className="text-[10px] text-slate-400">Simule o disparo de alertas automáticos em seu navegador</p>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button 
                    onClick={() => triggerPushNotificationSimulation('Rotina de Estudos', 'Hora de Estudar! 📚', 'Sua meta diária de Ética está agendada.', false)}
                    className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 p-2 rounded-lg text-[10px] font-black flex flex-col items-center gap-1 transition-all cursor-pointer"
                  >
                    <Volume2 className="h-4 w-4 text-slate-400" />
                    <span>Estudo (Rotina)</span>
                  </button>

                  <button 
                    onClick={() => triggerPushNotificationSimulation('Desempenho', 'Reforço Sugerido! 💡', 'Desempenho em Processo Penal caiu. Revise nulidades.', true)}
                    className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 p-2 rounded-lg text-[10px] font-black flex flex-col items-center gap-1 transition-all cursor-pointer"
                  >
                    <Zap className="h-4 w-4 text-amber-500 animate-pulse" />
                    <span>Desempenho</span>
                  </button>

                  <button 
                    onClick={() => triggerPushNotificationSimulation('Notificações OAB', 'Inscrição Próxima! ⚖️', 'O prazo do XL Exame abre em poucos dias.', true)}
                    className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 p-2 rounded-lg text-[10px] font-black flex flex-col items-center gap-1 transition-all cursor-pointer"
                  >
                    <Award className="h-4 w-4 text-red-500" />
                    <span>Prova & OAB</span>
                  </button>

                  <button 
                    onClick={() => triggerPushNotificationSimulation('Notificações 2ª Fase', 'Esqueleto Prático! 📝', 'Não deixe de treinar o Mandado de Segurança hoje.', false)}
                    className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 p-2 rounded-lg text-[10px] font-black flex flex-col items-center gap-1 transition-all cursor-pointer"
                  >
                    <BookOpen className="h-4 w-4 text-blue-500" />
                    <span>2ª Fase</span>
                  </button>
                </div>
              </div>

            </div>
          </div>

        </div>
      )}

      {/* ========================================================
          SUB-SECTION 2: CALENDÁRIO OFICIAL DA OAB (Seção 2)
          ======================================================== */}
      {activeSubSection === 'oficial' && (
        <div className="space-y-6 bg-white rounded-xl p-5 border border-slate-200 shadow-sm">
          <div className="border-b border-slate-100 pb-3 flex justify-between items-center">
            <div>
              <h3 className="text-base font-black text-slate-800">Cronograma Oficial do Exame de Ordem (XL Exame)</h3>
              <p className="text-xs text-slate-400 mt-0.5">Marcos fundamentais divulgados pelo Conselho Federal da OAB e executados pela FGV.</p>
            </div>
          </div>

          <div className="space-y-4" id="official-fgv-timeline">
            {sortedOABEvents.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-xs">
                Nenhum evento oficial da OAB coincide com os filtros aplicados.
              </div>
            ) : (
              sortedOABEvents.map((ev) => {
                const isUrgent = ev.isImportant;
                return (
                  <div 
                    key={ev.id} 
                    className={`p-4 rounded-xl border flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 transition-all ${isUrgent ? 'bg-amber-50/20 border-amber-200 shadow-3xs' : 'bg-white border-slate-150 hover:border-slate-300'}`}
                  >
                    <div className="flex items-start gap-4">
                      {/* Date Badge */}
                      <div className={`px-4 py-2.5 rounded-lg text-center shrink-0 border flex flex-col justify-center min-w-[85px] ${isUrgent ? 'bg-amber-100 border-amber-300 text-amber-800 font-bold' : 'bg-slate-50 border-slate-200 text-slate-600'}`}>
                        <span className="block text-lg font-black leading-none">{ev.date.split('-')[2]}</span>
                        <span className="block text-[10px] uppercase font-black mt-0.5">
                          {['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'][parseInt(ev.date.split('-')[1], 10) - 1]}
                        </span>
                        <span className="block text-[8px] font-mono text-slate-400 mt-0.5">{ev.date.split('-')[0]}</span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className={`text-[8.5px] font-black px-2 py-0.5 rounded uppercase border ${
                            ev.type === 'prova1' ? 'bg-red-50 text-red-600 border-red-100' :
                            ev.type === 'prova2' ? 'bg-purple-50 text-purple-600 border-purple-100' :
                            ev.type === 'inscricao' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                            ev.type === 'recurso' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                            'bg-slate-100 text-slate-500'
                          }`}>
                            {ev.type === 'prova1' ? '1ª Fase' : ev.type === 'prova2' ? '2ª Fase' : ev.type === 'inscricao' ? 'Inscrições' : ev.type === 'recurso' ? 'Recursos' : ev.type}
                          </span>
                          {isUrgent && <span className="bg-red-600 text-white font-black text-[8px] px-1.5 py-0.5 rounded uppercase tracking-wider">Altamente Crítico</span>}
                        </div>
                        <h4 className="text-xs font-extrabold text-slate-800">{ev.title}</h4>
                        <p className="text-xs text-slate-500 leading-relaxed font-medium">{ev.description}</p>
                      </div>
                    </div>

                    <div className="self-end sm:self-center">
                      <button 
                        onClick={() => handleAddReminderFromOfficial(ev)}
                        className="bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-250 font-bold text-[11px] px-3.5 py-2 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <Bell className="h-3.5 w-3.5 text-oab-accent" />
                        <span>Me Lembre!</span>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ========================================================
          SUB-SECTION 3: AGENDA PESSOAL DO ALUNO (Seção 3)
          ======================================================== */}
      {activeSubSection === 'agenda' && (
        <div className="space-y-6">
          
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h3 className="text-base font-black text-slate-800">Minha Agenda Estratégica</h3>
              <p className="text-xs text-slate-400">Gerencie e acesse suas metas de estudo, aulas, blocos de questões e simulados diários.</p>
            </div>

            {/* View Selector: Diária, Semanal, Mensal */}
            <div className="flex border border-slate-200 rounded-lg p-1 bg-slate-50 gap-0.5">
              {[
                { id: 'diaria', label: 'Diária (Hoje)' },
                { id: 'semanal', label: 'Semanal' },
                { id: 'mensal', label: 'Mensal (Calendário)' }
              ].map(v => (
                <button
                  key={v.id}
                  onClick={() => setAgendaView(v.id as any)}
                  className={`px-3 py-1.5 rounded-md text-[11px] font-black cursor-pointer transition-all ${agendaView === v.id ? 'bg-oab-primary text-white shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                >
                  {v.label}
                </button>
              ))}
            </div>
          </div>

          {/* RENDERING VIEWS */}
          {agendaView === 'diaria' && (
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
              
              {/* Daily Date Selector Grid */}
              <div className="flex gap-2 overflow-x-auto pb-1 border-b border-slate-100 scrollbar-none">
                {[
                  { date: '2026-06-22', label: 'Seg', name: '22/06' },
                  { date: '2026-06-23', label: 'Ter', name: '23/06' },
                  { date: '2026-06-24', label: 'Qua', name: '24/06' },
                  { date: '2026-06-25', label: 'Qui', name: '25/06 - HOJE' },
                  { date: '2026-06-26', label: 'Sex', name: '26/06' },
                  { date: '2026-06-27', label: 'Sáb', name: '27/06' },
                  { date: '2026-06-28', label: 'Dom', name: '28/06' }
                ].map(day => (
                  <button
                    key={day.date}
                    onClick={() => setSelectedCalendarDate(day.date)}
                    className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex flex-col items-center gap-1 shrink-0 min-w-[90px] cursor-pointer border ${selectedCalendarDate === day.date ? 'bg-oab-primary border-oab-primary text-white shadow-sm' : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'}`}
                  >
                    <span>{day.label}</span>
                    <span className="text-[10px] font-mono">{day.name}</span>
                  </button>
                ))}
              </div>

              {/* Show items for selectedCalendarDate */}
              <div className="space-y-3">
                <h4 className="text-xs font-extrabold text-slate-400 uppercase tracking-widest">
                  Atividades para {selectedDayName} ({selectedCalendarDate.split('-')[2]}/{selectedCalendarDate.split('-')[1]})
                </h4>

                {dailyTasks.length === 0 ? (
                  <div className="text-center py-10 text-slate-400 text-xs">
                    Sem tarefas agendadas para este dia. Aproveite para descansar ou adiantar revisões acumuladas!
                  </div>
                ) : (
                  dailyTasks.map((task) => (
                    <div 
                      key={task.id}
                      className={`p-4 rounded-xl border flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 transition-all ${task.status === 'completed' ? 'bg-slate-50 border-slate-150 opacity-75' : 'bg-white border-slate-250 hover:border-slate-350 shadow-3xs'}`}
                    >
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <button
                          onClick={() => {
                            onToggleTask(task.id);
                            triggerPushNotificationSimulation('Rotina de Estudos', 'Tarefa Atualizada', `Status de "${task.title}" atualizado.`, false);
                          }}
                          className={`mt-0.5 h-5.5 w-5.5 rounded-md flex items-center justify-center border transition-all cursor-pointer ${task.status === 'completed' ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-300 hover:border-oab-accent bg-white'}`}
                        >
                          {task.status === 'completed' && <Check className="h-3.5 w-3.5 stroke-[3]" />}
                        </button>

                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[9px] font-black uppercase text-oab-primary bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                              {task.discipline}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono flex items-center gap-0.5">
                              <Clock className="h-3.5 w-3.5" /> {task.estimatedMinutes !== undefined ? task.estimatedMinutes : task.durationMinutes} min
                            </span>
                            <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${task.priority === 'Alta' ? 'bg-red-50 text-red-600' : 'bg-slate-50 text-slate-500'}`}>
                              {task.priority}
                            </span>
                          </div>
                          <h4 className={`text-xs font-bold text-slate-800 ${task.status === 'completed' ? 'line-through text-slate-400' : ''}`}>{task.title}</h4>
                          <p className={`text-[11px] text-slate-500 leading-relaxed ${task.status === 'completed' ? 'text-slate-400 font-normal' : ''}`}>{task.description}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                        {task.status !== 'completed' ? (
                          <button
                            onClick={() => {
                              if (onStartStudyTask) {
                                onStartStudyTask(task.id);
                              } else {
                                onToggleTask(task.id);
                                triggerPushNotificationSimulation('Desempenho', 'Ótimo esforço! 👍', 'Tarefa marcada como concluída.', false);
                              }
                            }}
                            className="bg-[#0F172A] hover:bg-slate-800 text-white font-extrabold text-[10.5px] uppercase px-3 py-1.5 rounded transition-all cursor-pointer"
                          >
                            Estudar ⚡
                          </button>
                        ) : (
                          onStartStudyTask && (
                            <button
                              onClick={() => onStartStudyTask(task.id)}
                              className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-[10.5px] uppercase px-3 py-1.5 rounded transition-all cursor-pointer"
                            >
                              Ver Notas
                            </button>
                          )
                        )}
                        <button
                          onClick={() => onDeleteTask(task.id)}
                          className="text-slate-300 hover:text-red-500 p-1 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {agendaView === 'semanal' && (
            <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
              {['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado', 'Domingo'].map(day => {
                const dayTasks = weeklyTasks.filter(t => t.day === day);
                const completedCount = dayTasks.filter(t => t.status === 'completed').length;
                return (
                  <div key={day} className="bg-white rounded-xl border border-slate-200 p-4 shadow-3xs flex flex-col justify-between space-y-3">
                    <div className="border-b border-slate-100 pb-2">
                      <h4 className="text-xs font-black text-slate-800">{day.split('-')[0]}</h4>
                      <div className="text-[10px] text-slate-400 font-bold mt-0.5">{completedCount}/{dayTasks.length} concluídas</div>
                    </div>

                    <div className="space-y-2 flex-1 min-h-[120px]">
                      {dayTasks.length === 0 ? (
                        <div className="text-[10px] text-slate-400 text-center py-8">Vazio</div>
                      ) : (
                        dayTasks.map(t => (
                          <div 
                            key={t.id} 
                            onClick={() => onToggleTask(t.id)}
                            className={`p-2 rounded-lg border text-[10px] cursor-pointer transition-all ${t.status === 'completed' ? 'bg-slate-50 border-slate-100 opacity-60 line-through text-slate-400' : 'bg-amber-50/15 border-amber-200 font-bold text-slate-700'}`}
                          >
                            <div className="truncate">{t.title}</div>
                            <div className="text-[8px] text-slate-400 font-mono mt-0.5">{t.durationMinutes}m</div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {agendaView === 'mensal' && (
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
              <div className="flex justify-between items-center pb-2">
                <h4 className="text-xs font-black text-slate-800">Junho de 2026</h4>
                <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Simulação Completa</span>
              </div>

              {/* Monthly calendar grid for June 2026 (Starts on Monday, 30 days) */}
              <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-slate-500 border-b border-slate-100 pb-2">
                <div>Seg</div>
                <div>Ter</div>
                <div>Qua</div>
                <div>Qui</div>
                <div>Sex</div>
                <div>Sáb</div>
                <div>Dom</div>
              </div>

              <div className="grid grid-cols-7 gap-2">
                {/* June 2026 1st starts on Monday, so no offset is needed */}
                {Array.from({ length: 30 }).map((_, index) => {
                  const dayNum = index + 1;
                  const dateStr = `2026-06-${dayNum.toString().padStart(2, '0')}`;
                  const mappedDayName = dayNameMapping[dateStr];
                  const hasTasks = mappedDayName && weeklyTasks.filter(t => t.day === mappedDayName).length > 0;
                  const isSelected = selectedCalendarDate === dateStr;
                  const isToday = dateStr === SIMULATED_TODAY_DATE;

                  return (
                    <button
                      key={dayNum}
                      onClick={() => {
                        if (mappedDayName) {
                          setSelectedCalendarDate(dateStr);
                          setAgendaView('diaria');
                        } else {
                          alert("Data de simulação fora da semana letiva do mock. Selecione entre 22 e 28 de Junho.");
                        }
                      }}
                      className={`
                        p-3 rounded-lg border transition-all flex flex-col justify-between items-center min-h-[50px] relative cursor-pointer
                        ${isSelected ? 'bg-oab-primary border-oab-primary text-white shadow-xs' : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'}
                        ${isToday ? 'ring-2 ring-oab-accent' : ''}
                      `}
                    >
                      <span className="text-xs font-mono font-bold">{dayNum}</span>
                      
                      {/* Interactive dot indicators */}
                      {hasTasks && (
                        <span className={`h-1.5 w-1.5 rounded-full ${isSelected ? 'bg-oab-accent' : 'bg-amber-500'} mt-1 block`}></span>
                      )}
                    </button>
                  );
                })}
              </div>

              <div className="bg-slate-50 rounded-lg p-3 text-[11px] text-slate-500 text-center font-bold">
                💡 Dica: Clique nos dias pontuados com metas (22 a 28 de junho) para abrir as atividades de forma dinâmica.
              </div>
            </div>
          )}

        </div>
      )}

      {/* ========================================================
          SUB-SECTION 4: INTEGRATION WITH REVIEWS (Seção 4)
          ======================================================== */}
      {activeSubSection === 'revisoes' && (
        <div className="space-y-6 bg-white rounded-xl p-5 border border-slate-200 shadow-sm">
          <div className="border-b border-slate-100 pb-3 flex justify-between items-center">
            <div>
              <h3 className="text-base font-black text-slate-800 flex items-center gap-1.5">
                <History className="h-4.5 w-4.5 text-blue-500" /> Revisões Ativas & Algoritmo Espaçado
              </h3>
              <p className="text-xs text-slate-400">Suas revisões programadas de 24h, 7d e 30d acopladas diretamente à sua curva de esquecimento.</p>
            </div>
          </div>

          <div className="space-y-4">
            {reviewsState.map((rev) => (
              <div 
                key={rev.id} 
                className={`p-4 rounded-xl border flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 transition-all ${rev.completed ? 'bg-slate-50 border-slate-150 opacity-70' : 'bg-white border-slate-200 hover:border-slate-350 shadow-3xs'}`}
              >
                <div className="flex items-start gap-3">
                  <div className={`mt-0.5 p-1.5 rounded-lg border ${
                    rev.type === '24h' ? 'bg-red-50 border-red-100 text-red-600' :
                    rev.type === '7d' ? 'bg-blue-50 border-blue-100 text-blue-600' :
                    rev.type === '30d' ? 'bg-indigo-50 border-indigo-100 text-indigo-600' :
                    rev.type === 'atrasada' ? 'bg-amber-50 border-amber-200 text-amber-700 font-extrabold' :
                    'bg-purple-50 border-purple-100 text-purple-600'
                  }`}>
                    <History className="h-4 w-4" />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black uppercase text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">{rev.discipline}</span>
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                        rev.type === '24h' ? 'bg-red-50 text-red-600' :
                        rev.type === '7d' ? 'bg-blue-50 text-blue-600' :
                        rev.type === '30d' ? 'bg-indigo-50 text-indigo-600' :
                        'bg-purple-50 text-purple-600'
                      }`}>{rev.type}</span>
                      {rev.delayDays > 0 && <span className="bg-red-100 text-red-700 text-[9px] font-black px-1.5 py-0.5 rounded">Atrasado {rev.delayDays}d</span>}
                    </div>
                    <h4 className={`text-xs font-extrabold text-slate-800 ${rev.completed ? 'line-through text-slate-400' : ''}`}>{rev.title}</h4>
                    <p className="text-[11px] text-slate-500 font-medium">Flashcards associados: {rev.flashcardsCount} unidades • Tempo médio: 15 minutos</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={() => {
                      onNavigateToTab('revisao');
                      triggerPushNotificationSimulation('Rotina de Estudos', 'Estudo Direcionado', 'Redirecionando para a área de flashcards...', false);
                    }}
                    className="bg-oab-primary hover:bg-slate-850 text-white font-black text-[10.5px] uppercase py-2 px-3.5 rounded-lg transition-all cursor-pointer shadow-3xs"
                  >
                    Estudar
                  </button>

                  <button
                    onClick={() => handleToggleReviewCompleted(rev.id)}
                    className={`border border-slate-250 font-bold text-[10.5px] py-2 px-3 rounded-lg cursor-pointer transition-all ${rev.completed ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-white text-slate-600 hover:bg-slate-50'}`}
                  >
                    {rev.completed ? 'Feito ✓' : 'Marcar Concluído'}
                  </button>

                  {!rev.completed && (
                    <button
                      onClick={() => handleRescheduleReview(rev.id)}
                      className="text-slate-400 hover:text-slate-600 text-[10px] font-bold p-1 transition-colors cursor-pointer"
                    >
                      Remarcar
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================
          SUB-SECTION 5: INTEGRATION WITH EXAMS (Seção 5)
          ======================================================== */}
      {activeSubSection === 'simulados' && (
        <div className="space-y-6 bg-white rounded-xl p-5 border border-slate-200 shadow-sm">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-base font-black text-slate-800 flex items-center gap-1.5">
              <Target className="h-4.5 w-4.5 text-emerald-500" /> Simulados Programados & Diagnósticos
            </h3>
            <p className="text-xs text-slate-400">Verifique os simulados de 1ª e 2ª Fase agendados pela equipe de professores do curso.</p>
          </div>

          <div className="space-y-4">
            {simuladosState.map((sim) => (
              <div 
                key={sim.id} 
                className="p-4 rounded-xl border border-slate-200 hover:border-slate-350 bg-white transition-all flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shadow-3xs"
              >
                <div className="flex items-start gap-3">
                  <div className={`mt-0.5 p-2 rounded-lg border ${sim.status === 'atrasado' ? 'bg-red-50 border-red-100 text-red-600 animate-pulse' : 'bg-slate-50 border-slate-200 text-slate-600'}`}>
                    <Award className="h-4.5 w-4.5" />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black uppercase text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">{sim.phase}</span>
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${sim.status === 'atrasado' ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-500'}`}>
                        {sim.status === 'agendado' ? 'Em breve' : sim.status === 'atrasado' ? 'Em atraso!' : sim.status}
                      </span>
                    </div>
                    <h4 className="text-xs font-extrabold text-slate-800">{sim.name}</h4>
                    <p className="text-[11px] text-slate-500 font-medium">Agendado para: {formatDatePT(sim.date)} • Duração recomendada: {sim.duration}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={() => handleSimulateExamStart(sim.name, sim.phase)}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[10.5px] uppercase py-2 px-3.5 rounded-lg transition-all cursor-pointer shadow-3xs"
                  >
                    Iniciar Simulado
                  </button>

                  <button
                    onClick={() => handleRescheduleSimulado(sim.id)}
                    className="bg-white hover:bg-slate-50 text-slate-600 border border-slate-250 font-bold text-[10.5px] py-2 px-3 rounded-lg transition-all cursor-pointer"
                  >
                    Remarcar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================
          SUB-SECTION 6: INTERAGRATION WITH 2ª FASE (Seção 6)
          ======================================================== */}
      {activeSubSection === 'segundafase' && (
        <div className="space-y-6 bg-white rounded-xl p-5 border border-slate-200 shadow-sm">
          <div className="border-b border-slate-100 pb-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="text-base font-black text-slate-800 flex items-center gap-1.5">
                <BookOpen className="h-4.5 w-4.5 text-purple-600" /> Cronograma de Estudos Práticos - 2ª Fase
              </h3>
              <p className="text-xs text-slate-400">Sua trilha especializada focada na estruturação de peças e resolução de discursivas em: <strong className="text-purple-600">{selectedArea}</strong>.</p>
            </div>
            
            <button 
              onClick={() => {
                setProgress(prev => ({
                  ...prev,
                  selectedSecondPhaseArea: selectedArea === 'Direito Penal' ? 'Direito Constitucional' : 'Direito Penal'
                }));
                triggerPushNotificationSimulation('Notificações 2ª Fase', 'Área de foco atualizada', 'Trilha personalizada regenerada com sucesso!', false);
              }}
              className="text-xs font-black text-oab-accent hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              Mudar Área de Foco <ChevronRight className="h-3 w-3" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Checklist of training */}
            <div className="lg:col-span-5 bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
              <h4 className="text-xs font-black uppercase text-slate-600 tracking-wider flex items-center gap-1.5">
                <CheckCircle2 className="h-4.5 w-4.5 text-slate-500" /> Roteiro Mínimo de Peças Práticas
              </h4>
              <p className="text-[11px] text-slate-400 leading-relaxed font-medium">As 5 atividades essenciais que você precisa treinar até a prova prática:</p>

              <div className="space-y-2">
                {areaChecklist.map((item, index) => (
                  <div key={index} className="bg-white p-3 rounded-lg border border-slate-150 flex items-center gap-2 text-xs font-semibold text-slate-700">
                    <div className="h-4 w-4 bg-purple-100 text-purple-700 rounded-full flex items-center justify-center text-[9px] font-black shrink-0">
                      {index + 1}
                    </div>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Weekly schedule details */}
            <div className="lg:col-span-7 space-y-3">
              <h4 className="text-xs font-black uppercase text-slate-600 tracking-wider">Compromissos Práticos da Semana</h4>
              
              <div className="space-y-2.5">
                {phase2Interactivity.map((t) => (
                  <div 
                    key={t.id}
                    className={`p-3.5 rounded-lg border flex justify-between items-center gap-3 transition-colors ${t.completed ? 'bg-slate-50 border-slate-150 opacity-75' : 'bg-white border-slate-200'}`}
                  >
                    <div className="flex items-start gap-2.5 min-w-0">
                      <button
                        onClick={() => handleToggleP2Task(t.id)}
                        className={`mt-0.5 h-5 w-5 rounded flex items-center justify-center border transition-all cursor-pointer ${t.completed ? 'bg-purple-600 border-purple-600 text-white' : 'border-slate-300'}`}
                      >
                        {t.completed && <Check className="h-3.5 w-3.5 stroke-[3]" />}
                      </button>

                      <div className="space-y-0.5 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] uppercase font-bold text-purple-600">{t.day}</span>
                          <span className="text-[8.5px] bg-purple-50 text-purple-700 border border-purple-100 px-1.5 py-0.5 rounded uppercase font-black">{t.type}</span>
                        </div>
                        <h4 className={`text-xs font-extrabold text-slate-800 truncate ${t.completed ? 'line-through text-slate-400' : ''}`}>{t.task}</h4>
                      </div>
                    </div>

                    <button
                      onClick={() => handleToggleP2Task(t.id)}
                      className={`text-[10px] font-bold px-2.5 py-1 rounded cursor-pointer transition-all ${t.completed ? 'bg-purple-50 text-purple-700' : 'bg-slate-100 text-slate-700 hover:bg-slate-250'}`}
                    >
                      {t.completed ? 'Feito ✓' : 'Praticar'}
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================
          SUB-SECTION 9: CENTRAL DE AVISOS (Seção 9)
          ======================================================== */}
      {activeSubSection === 'comunicacao' && (
        <div className="space-y-6 bg-white rounded-xl p-5 border border-slate-200 shadow-sm">
          <div className="border-b border-slate-100 pb-3 flex justify-between items-center">
            <div>
              <h3 className="text-base font-black text-slate-800 flex items-center gap-1.5">
                <FileText className="h-4.5 w-4.5 text-blue-500" /> Central de Comunicação & Avisos do Curso
              </h3>
              <p className="text-xs text-slate-400">Acompanhe avisos importantes, materiais de reta final e alterações publicadas pelos mentores.</p>
            </div>

            <button 
              onClick={handleMarkAllAnnouncementsRead}
              className="text-xs font-black text-oab-accent hover:underline cursor-pointer"
            >
              Marcar todos como lidos
            </button>
          </div>

          <div className="space-y-4">
            {courseAnnouncements.map((ann) => (
              <div 
                key={ann.id} 
                onClick={() => handleToggleAnnouncementRead(ann.id)}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ${!ann.read ? 'bg-blue-50/20 border-blue-200' : 'bg-white border-slate-150'}`}
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded border ${ann.urgent ? 'bg-red-100 text-red-600 border-red-200 animate-pulse' : 'bg-slate-50 text-slate-500 border-slate-200'}`}>
                      {ann.category}
                    </span>
                    <span className="text-[9.5px] text-slate-400 font-mono font-bold flex items-center gap-0.5">
                      <Clock className="h-3 w-3" /> Publicado em: {formatDatePT(ann.date)}
                    </span>
                    {!ann.read && <span className="bg-blue-600 text-white font-black text-[8px] px-1.5 py-0.5 rounded uppercase">Novo</span>}
                  </div>
                  <h4 className="text-xs font-extrabold text-slate-800 leading-tight">{ann.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed font-medium">{ann.text}</p>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleAnnouncementRead(ann.id);
                      alert("Artigo ou material marcado como lido!");
                    }}
                    className={`text-[10px] font-bold px-3 py-1.5 rounded-lg border cursor-pointer ${ann.read ? 'bg-slate-50 border-slate-200 text-slate-400' : 'bg-blue-100 border-blue-200 text-blue-700 font-black'}`}
                  >
                    {ann.read ? 'Lido ✓' : 'Marcar como Lido'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================
          SUB-SECTION 12: HISTÓRICO E RASTREIO (Seção 12)
          ======================================================== */}
      {activeSubSection === 'historico' && (
        <div className="space-y-6">
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm text-center space-y-2">
              <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Aproveitamento</span>
              <div className="text-3xl font-mono font-black text-slate-850">
                {weeklyTasks.length > 0 ? Math.round((weeklyTasks.filter(t => t.status === 'completed').length / weeklyTasks.length) * 100) : 100}%
              </div>
              <p className="text-[11px] text-slate-500 leading-normal font-semibold">Metas de estudo cumpridas no seu cronograma.</p>
            </div>

            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm text-center space-y-2">
              <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Alertas Resolvidos</span>
              <div className="text-3xl font-mono font-black text-emerald-600">
                {resolvedAlertsCount}
              </div>
              <p className="text-[11px] text-slate-500 leading-normal font-semibold">Gargalos de desempenho solucionados com o tutor.</p>
            </div>

            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm text-center space-y-2">
              <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Sequência Ativa</span>
              <div className="text-3xl font-mono font-black text-amber-500 flex items-center justify-center gap-1">
                4 <Sparkles className="h-5 w-5 fill-amber-500 text-amber-500" />
              </div>
              <p className="text-[11px] text-slate-500 leading-normal font-semibold">Dias seguidos de constância nos estudos do cronograma.</p>
            </div>

          </div>

          {/* Activity Timeline list */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-sm font-black text-slate-800 border-b border-slate-100 pb-3 flex items-center gap-1.5">
              <History className="h-4.5 w-4.5 text-oab-accent" /> Histórico de Ações da Agenda & Notificações Recorrentes
            </h3>

            <div className="space-y-3" id="history-timeline-logs">
              {notificationsHistory.map((log, idx) => (
                <div key={idx} className="p-3 rounded-lg bg-slate-50 border border-slate-150 flex items-start gap-2 text-xs font-semibold text-slate-700">
                  <span className="h-2 w-2 rounded-full bg-slate-400 mt-1.5 shrink-0"></span>
                  <span>{log}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* ========================================================
          ACTIVE CUSTOM ALERTS LIST (Section 7)
          ======================================================== */}
      <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
        <div className="flex justify-between items-center border-b border-slate-100 pb-3">
          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
            <AlertCircle className="h-4.5 w-4.5 text-amber-500" /> Notificações de Desempenho e Alertas de Estudo ({activeAlerts.filter(a => !a.resolved).length})
          </h3>
          
          <button 
            onClick={() => {
              setActiveAlerts(prev => prev.map(a => ({ ...a, resolved: true })));
              setResolvedAlertsCount(prev => prev + activeAlerts.filter(a => !a.resolved).length);
              alert("Todos os alertas pendentes foram resolvidos!");
            }}
            className="text-[11px] font-black text-oab-accent hover:underline cursor-pointer"
          >
            Limpar todos
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="alerts-grid">
          {activeAlerts.filter(a => !a.resolved).length === 0 ? (
            <div className="col-span-2 text-center py-6 text-slate-400 text-xs font-bold">
              🎉 Nenhum alerta pendente! Seu plano e desempenho estão 100% equilibrados.
            </div>
          ) : (
            activeAlerts.filter(a => !a.resolved).map((al) => (
              <div 
                key={al.id} 
                className={`p-4 rounded-xl border flex justify-between items-start gap-3 transition-colors ${al.urgent ? 'bg-red-50/30 border-red-200' : 'bg-slate-50/50 border-slate-200'}`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[8px] font-black uppercase px-1.5 py-0.5 rounded ${
                      al.type === 'estudo' ? 'bg-blue-100 text-blue-700' :
                      al.type === 'revisao' ? 'bg-amber-100 text-amber-700' :
                      al.type === 'desempenho' ? 'bg-purple-100 text-purple-700' :
                      al.type === 'prova' ? 'bg-red-100 text-red-700 font-extrabold animate-pulse' :
                      'bg-slate-200 text-slate-700'
                    }`}>
                      {al.type}
                    </span>
                    {al.discipline && <span className="text-[10px] text-slate-500 font-bold">{al.discipline}</span>}
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed font-semibold mt-1">{al.text}</p>
                </div>

                <button 
                  onClick={() => handleDismissAlert(al.id)}
                  className="text-slate-350 hover:text-emerald-600 p-1 rounded cursor-pointer transition-colors"
                  title="Resolver Alerta"
                >
                  <CheckCircle2 className="h-5 w-5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

    </div>
  );
}

// Simple internal icon component to bypass missing import error
function CalendarRangeIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <rect width="16" height="16" x="4" y="4" rx="2" />
      <path d="M9 2v4" />
      <path d="M15 2v4" />
      <path d="M4 10h16" />
      <path d="M19 14H5" />
    </svg>
  );
}
