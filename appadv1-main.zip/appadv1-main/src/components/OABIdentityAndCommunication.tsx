/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, 
  MessageSquare, 
  Palette, 
  Tv, 
  Compass, 
  Sliders, 
  CheckCircle, 
  Lock, 
  Crown, 
  FileText, 
  AlertTriangle, 
  ArrowRight, 
  Copy, 
  Check, 
  Users, 
  HelpCircle, 
  ShieldCheck, 
  TrendingUp, 
  Clock, 
  Calendar, 
  Volume2, 
  Send,
  Smartphone,
  CheckSquare,
  Award,
  BookOpen,
  Filter
} from 'lucide-react';

// Define the 15 Blocks data
interface CopySnippet {
  title: string;
  copy: string;
  context: string;
}

interface BlockData {
  id: string;
  title: string;
  icon: React.ComponentType<any>;
  description: string;
}

export default function OABIdentityAndCommunication() {
  const [activeTab, setActiveTab] = useState<'brand' | 'voice' | 'copy_areas' | 'ux_writing' | 'banners' | 'simulator'>('brand');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // States for tone & journey simulator
  const [selectedPersona, setSelectedPersona] = useState<string>('novo');
  const [selectedFormat, setSelectedFormat] = useState<'dashboard' | 'push' | 'button' | 'motivation' | 'upgrade' | 'email'>('dashboard');

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // 15 blocks descriptors
  const blocks: BlockData[] = [
    { id: '1', title: 'Posicionamento da Marca', icon: Compass, description: 'Como a OAB 3F se posiciona no mercado jurídico-acadêmico de alta performance.' },
    { id: '2', title: 'Tom de Voz e Linguagem', icon: Volume2, description: 'Diretrizes oficiais para uma comunicação clara, firme, didática e motivadora.' },
    { id: '3', title: 'Identidade Visual do App', icon: Palette, description: 'Estilo visual editorial, paleta de cores jurídica moderna e regras de design.' },
    { id: '4', title: 'Copy da Home/Dashboard', icon: Tv, description: 'Copywriting para a página inicial do candidato com foco em execução diária.' },
    { id: '5', title: 'Copy das Áreas Internas', icon: FileText, description: 'Textos estruturados para Questões, Cronogramas, Revisões, 2ª Fase e Simulados.' },
    { id: '6', title: 'UX Writing & Microcopy', icon: MessageSquare, description: 'Microtextos de botões, estados vazios, progresso, erro, confirmação e alertas.' },
    { id: '7', title: 'Banners e CTAs Comerciais', icon: Crown, description: 'Direcionamento de conversão para planos grátis, de 1ª fase, 2ª fase e mentoria.' },
    { id: '8', title: 'Onboarding e Retenção', icon: Sliders, description: 'Roteiro de captação inicial do perfil e mensagens para estudantes ausentes.' },
    { id: '9', title: 'Monetização e Upgrade', icon: Lock, description: 'Mensagens de paywall e gatilhos de urgência saudável para adesão premium.' },
    { id: '10', title: 'Consistência Textual', icon: ShieldCheck, description: 'Manual prático e padronização para manter a voz única do OAB 3F.' },
    { id: '11', title: 'Comunidade e Mentoria', icon: Users, description: 'Comunicação para o Mural de Dúvidas, Suporte financeiro/técnico e Mentorias.' },
    { id: '12', title: 'Naming de Áreas', icon: Sparkles, description: 'Lógica e estratégia para nomear as funcionalidades com alto valor percebido.' },
    { id: '13', title: 'Mensagens por Momento', icon: Clock, description: 'Segmentação textual baseada no progresso atual e estabilidade do aluno.' },
    { id: '14', title: 'Telas Especiais', icon: Smartphone, description: 'Copys exclusivas para telas de bloqueio, replanejamentos, resultados e vitórias.' },
    { id: '15', title: 'Integração de Canais', icon: Send, description: 'Sincronização da comunicação em toda a jornada do ecossistema.' }
  ];

  // Simulator Data for dynamic tone selection
  const simulatorPersonas = {
    novo: {
      name: "Camila Rodrigues",
      tag: "Novo Aluno (Acolhimento & Direção)",
      avatarBg: "bg-blue-600/10 text-blue-600",
      description: "Acabou de finalizar o onboarding. Precisa de instruções extremamente claras sobre como dar o primeiro passo, além de se sentir segura com a metodologia em 3 fases.",
      copy: {
        dashboard: {
          title: "Seja muito bem-vinda ao OAB 3F, Camila.",
          subtitle: "Seu diagnóstico pedagógico está concluído e seu cronograma estratégico já foi gerado. Hoje é o Dia 1 da sua jornada rumo à aprovação. Vamos começar pela tarefa prioritária de Direito Constitucional?",
          badge: "MÉTODO 3F — SEU DIA 1"
        },
        push: {
          title: "🚀 Seu Plano de Estudos OAB 3F está pronto!",
          subtitle: "Camila, traçamos sua rota ideal até o Exame XL. Toque aqui para dar o primeiro passo na sua preparação.",
          badge: "Notificação Push"
        },
        button: {
          title: "Iniciar Minha Primeira Aula",
          subtitle: "Ação inicial de onboarding",
          badge: "CTA Principal"
        },
        motivation: {
          title: "Todo grande resultado começa com o primeiro bloco.",
          subtitle: "Esqueça o peso do edital completo. O seu único compromisso hoje é cumprir a meta do dia de forma focada e consistente.",
          badge: "Mensagem Inspiradora"
        },
        upgrade: {
          title: "Desbloqueie o Ecossistema OAB 3F Premium",
          subtitle: "Não corra riscos. Tenha acesso a simulados ilimitados com gabarito comentado e ao Motor de Revisões Espaçadas que blinda você contra a curva do esquecimento.",
          badge: "Paywall Onboarding"
        },
        email: {
          title: "Seja bem-vinda ao Método OAB 3F, Camila!",
          subtitle: "Prezada Camila, \n\nSabemos que a preparação para o Exame da Ordem pode parecer desafiadora, mas você não está mais sozinha. A partir de agora, o Método OAB 3F guiará seus passos diariamente.\n\nSua trilha do dia já está ativa no seu aplicativo. Dedique seus 15 minutos iniciais para entender a base teórica e, em seguida, resolva as questões sugeridas. É este ciclo constante — Teoria, Treino e Revisão — que garantirá seu nome na lista dos aprovados.\n\nForte abraço,\nCoordenação Acadêmica OAB 3F",
          badge: "E-mail de Boas-Vindas"
        }
      }
    },
    travado: {
      name: "Bernardo Silva",
      tag: "Estudante Travado / Atrasado (Resgate & Retomada)",
      avatarBg: "bg-amber-600/10 text-amber-600",
      description: "Está há 5 dias sem acessar o aplicativo e possui 8 tarefas acumuladas. Precisa de acolhimento sem culpabilização, acompanhado de uma simplificação imediata da meta.",
      copy: {
        dashboard: {
          title: "Que bom ver você de volta, Bernardo.",
          subtitle: "Sabemos que a rotina é intensa e imprevistos acontecem. Não se preocupe com o conteúdo que ficou para trás: reorganizamos sua rota para que você retome sem sobrecarga. Vamos focar apenas no assunto crítico de hoje?",
          badge: "MÉTODO 3F — RETOMADA SEGURA"
        },
        push: {
          title: "⏳ Sem cobranças, Bernardo. Vamos retomar?",
          subtitle: "Reajustamos seu cronograma para não acumular matérias. 15 minutinhos hoje são suficientes para colocar o foco nos trilhos.",
          badge: "Notificação Push"
        },
        button: {
          title: "Recalibrar Meu Cronograma",
          subtitle: "Ação de reajuste automático de plano",
          badge: "CTA Secundário"
        },
        motivation: {
          title: "O progresso imperfeito é infinitamente melhor que a inércia.",
          subtitle: "Estudar 20 minutos hoje é uma vitória acadêmica gigante. Esqueça o ideal; faça o que é viável na sua realidade atual.",
          badge: "Mensagem Inspiradora"
        },
        upgrade: {
          title: "Seu Cronograma Recalcula Sozinho no Plano VIP",
          subtitle: "No plano VIP, quando você perde um dia, nosso motor acadêmico dilui as pendências de forma inteligente sem estressar você. Esqueça a sensação de atraso constante.",
          badge: "Paywall de Retenção"
        },
        email: {
          title: "Tudo bem, Bernardo? Vamos simplificar a rota?",
          subtitle: "Prezado Bernardo, \n\nPassamos aqui para lembrar que a preparação para a OAB é uma maratona, e não uma corrida de 100 metros. Ter dias difíceis ou semanas atípicas faz parte de qualquer processo vitorioso.\n\nNão se sinta culpado pelo cronograma pendente. Nosso sistema acabou de isolar as matérias mais fáceis e recorrentes para que você retome com passos curtos e recupere o ritmo. \n\nClique no link abaixo para reorganizar seu plano com apenas um clique e recomeçar de onde parou.\n\nEstamos com você,\nEquipe Pedagógica OAB 3F",
          badge: "E-mail de Resgate"
        }
      }
    },
    retatransicao: {
      name: "Mariana Costa",
      tag: "Aluno Reta Final 1ª Fase (Urgência Saudável & Foco)",
      avatarBg: "bg-red-600/10 text-red-600",
      description: "Faltam apenas 15 dias para a prova da 1ª fase. Ela está ansiosa e com medo. Precisa de urgência estratégica saudável, com foco nas disciplinas mais cobradas e leis secas.",
      copy: {
        dashboard: {
          title: "Foco total na reta final, Mariana.",
          subtitle: "Faltam 15 dias para a sua aprovação. Nosso radar pedagógico selecionou os tópicos de altíssima recorrência da FGV para garantir seus pontos de segurança. Hoje o foco é Ética Profissional (8 questões cruciais na prova). Pronto para treinar?",
          badge: "OPERAÇÃO RETA FINAL OAB"
        },
        push: {
          title: "🎯 Mariana, estas 5 regras de Ética caem SEMPRE!",
          subtitle: "Isolamos as pegadinhas mais clássicas da FGV para revisar em 10 minutos. Toque para garantir 3 pontos na prova.",
          badge: "Notificação Push"
        },
        button: {
          title: "Iniciar Maratona de Ética (Alta Recorrência)",
          subtitle: "Treino focado de alta pontuação",
          badge: "CTA Principal"
        },
        motivation: {
          title: "Nesta etapa, estratégia vence o cansaço.",
          subtitle: "Não tente ler livros inteiros agora. Foque em resolver questões comentadas, entender seus erros e dominar a Lei Seca dos artigos mais cobrados.",
          badge: "Mensagem Inspiradora"
        },
        upgrade: {
          title: "Garanta o Combo Reta Final OAB 3F",
          subtitle: "Tenha acesso às 300 questões resolvidas em vídeo pelos professores titulares, além dos modelos de resumos ultra-esquematizados de véspera para fixar na memória.",
          badge: "Paywall Reta Final"
        },
        email: {
          title: "Faltam 15 dias, Mariana. É hora do funil estratégico!",
          subtitle: "Prezada Mariana, \n\nA ansiedade costuma crescer à medida que o dia da prova se aproxima, mas a melhor resposta para o medo é a execução estratégica.\n\nA partir de hoje, seu plano entra em modo 'Funil de Aprovação'. Vamos focar exclusivamente nos tópicos que historicamente representam mais de 70% das questões da OAB. Não gaste energia com matérias secundárias.\n\nSua tarefa de hoje já está desenhada para extrair o máximo de retenção com o mínimo de tempo. Confie no método, resolva as questões selecionadas e garanta seus pontos fundamentais de ética e constitucional.\n\nA aprovação está logo ali,\nProf. Dr. Ricardo Abreu",
          badge: "E-mail de Alerta Pedagógico"
        }
      }
    },
    baixo_desempenho: {
      name: "Juliana Mendes",
      tag: "Desempenho Acadêmico em Risco (Orientação & Diagnóstico)",
      avatarBg: "bg-rose-600/10 text-rose-600",
      description: "Sua taxa média de acerto nas últimas 50 questões caiu para 42%. Está desanimada com simulados e se sente incapaz. Precisa de clareza analítica, sem tom de punição, guiando para o estudo reverso.",
      copy: {
        dashboard: {
          title: "Vamos desacelerar e ajustar a mira, Juliana.",
          subtitle: "Seu painel identificou que o assunto 'Contratos em Direito Civil' precisa de um reforço tático. Errar questões agora é excelente — significa que descobrimos o ponto fraco antes do dia da prova. Que tal uma revisão rápida da teoria focada nos seus erros?",
          badge: "DIAGNÓSTICO ACADÊMICO REVERSO"
        },
        push: {
          title: "🎯 Juliana, vamos blindar sua taxa de acertos?",
          subtitle: "Isolamos o tópico exato onde você teve dúvidas para uma revisão guiada sem pressão. Toque para destravar.",
          badge: "Notificação Push"
        },
        button: {
          title: "Estudar Meus Assuntos Críticos",
          subtitle: "Revisão baseada no histórico de erros",
          badge: "CTA Principal"
        },
        motivation: {
          title: "A resposta errada é o melhor mapa do seu acerto futuro.",
          subtitle: "Cada erro mapeado e compreendido é uma questão a menos que você errará na prova oficial. O erro didático constrói o aprovado.",
          badge: "Mensagem Inspiradora"
        },
        upgrade: {
          title: "Ative a Tutoria de Erros Inteligente (Plano VIP)",
          subtitle: "Estudantes VIP contam com mapeamento individualizado de pontos cegos. Nossa inteligência pedagógica aponta a página exata da doutrina e o artigo de lei para sanar cada fraqueza estrutural.",
          badge: "Paywall Desempenho"
        },
        email: {
          title: "Juliana, errar agora faz parte da estratégia de aprovação!",
          subtitle: "Prezada Juliana, \n\nAnalisamos o seu histórico recente e percebemos uma pequena queda no rendimento em Direito Civil. Queremos que você mude a perspectiva sobre isso: errar questões no simulado é o melhor diagnóstico que você poderia ter.\n\nO verdadeiro risco não é errar no aplicativo; é ir para o Exame oficial sem saber onde estão suas fragilidades pedagógicas. \n\nPreparamos uma trilha de estudo reverso específica para você: primeiro, você verá um resumo em formato de checklist de 5 minutos cobrindo as pegadinhas das suas questões erradas, e em seguida faremos um novo bloco de apenas 5 questões curtas. \n\nVamos juntos ajustar os detalhes para subir essa média?\n\nForte abraço,\nMentoria de Resultados OAB 3F",
          badge: "E-mail de Apoio ao Desempenho"
        }
      }
    },
    aprovado_fase1: {
      name: "Rafael Vasconcelos",
      tag: "Aprovado na 1ª Fase (Transição de Sucesso para 2ª Fase)",
      avatarBg: "bg-emerald-600/10 text-emerald-600",
      description: "Foi aprovado na 1ª fase com 42 pontos. Agora precisa fazer o upgrade obrigatório para a trilha intensiva de 2ª fase e escolher a área do Direito adequada com forte persuasão.",
      copy: {
        dashboard: {
          title: "Parabéns pela grande vitória, Rafael!",
          subtitle: "Você superou a barreira dos 40 pontos e provou que o método funciona. Agora, a história é outra: na 2ª Fase, você não assinalará letras, mas escreverá peças prático-profissionais reais. Vamos escolher sua especialidade e iniciar o treinamento prático de escrita?",
          badge: "UPGRADE PEDAGÓGICO — RUMO À CARTEIRA"
        },
        push: {
          title: "🏆 Rafael, a 1ª fase ficou para trás! E agora?",
          subtitle: "Sua carteira da OAB está a apenas uma peça de distância. Toque para escolher sua área da 2ª Fase e iniciar o plano.",
          badge: "Notificação Push"
        },
        button: {
          title: "Ativar Meu Plano de 2ª Fase",
          subtitle: "Transição e upgrade comercial estratégico",
          badge: "CTA Principal"
        },
        motivation: {
          title: "Na 2ª fase, a técnica estrutural bate o excesso de conhecimento.",
          subtitle: "Não se assuste com o tamanho da peça profissional. A aprovação reside no domínio do manuseio do Vade Mecum e na identificação correta da estrutura de cabimento.",
          badge: "Mensagem Inspiradora"
        },
        upgrade: {
          title: "Desbloqueie a Mentoria de Correção Individualizada de Peças",
          subtitle: "A maior causa de reprovação na 2ª fase é treinar redação sem ter quem corrija suas peças. Nosso plano de 2ª Fase inclui correções individuais detalhadas baseadas no espelho oficial da FGV.",
          badge: "Paywall de Transição"
        },
        email: {
          title: "Rafael, o primeiro passo foi dado. Vamos consolidar a aprovação?",
          subtitle: "Prezado Rafael, \n\nComemorar é essencial. Você venceu a cansativa 1ª fase e provou seu valor. Mas o trabalho não acabou: agora, o seu adversário não é uma prova de múltipla escolha, mas a redação de uma peça técnica jurídica profissional e 4 questões discursivas.\n\nA preparação da 2ª Fase exige treino ativo de escrita no papel físico, manuseio rápido do Vade Mecum e compreensão de teses de defesa.\n\nPreparamos uma oferta de transição especial para você migrar para a nossa trilha intensiva de 2ª fase, com acompanhamento de professores especialistas na área escolhida e correções quinzenais de peças com nota simulada.\n\nSua carteira vermelha está mais próxima do que nunca. Não mude o ritmo agora.\n\nUm grande abraço,\nProf. Dr. Ricardo Abreu",
          badge: "E-mail de Parabéns & Vendas"
        }
      }
    }
  };

  const activePersonaData = simulatorPersonas[selectedPersona as keyof typeof simulatorPersonas];
  const activeCopyItem = activePersonaData.copy[selectedFormat as keyof typeof activePersonaData.copy];

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8 font-sans" id="oab-identity-container">
      {/* Editorial Header */}
      <div className="border-b border-oab-accent/30 pb-6 mb-8 text-left">
        <div className="flex items-center space-x-2 text-oab-accent font-mono text-xs uppercase tracking-widest mb-1.5 font-bold">
          <Sparkles className="h-4 w-4 text-oab-accent" />
          <span>Diretrizes e Conteúdo de Produto</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-display font-bold tracking-tight text-slate-900 leading-tight">
          Identidade e Comunicação OAB 3F
        </h1>
        <p className="text-slate-600 mt-2 max-w-3xl font-sans text-sm sm:text-base leading-relaxed">
          Camada completa de <strong className="text-slate-950 font-semibold">Identidade Visual + Copywriting + UX Writing + Banners + Microcopy</strong>. 
          Este documento interativo define a voz da marca, a linha visual de alta autoridade jurídica e as estruturas textuais para conduzir o candidato do onboarding até a aprovação definitiva.
        </p>
      </div>

      {/* Main Tab Navigation */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-px" id="identity-main-tabs">
        <button
          onClick={() => setActiveTab('brand')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'brand' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Compass className="h-4 w-4" />
          <span>1. Posicionamento & Tom</span>
        </button>
        <button
          onClick={() => setActiveTab('voice')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'voice' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Palette className="h-4 w-4" />
          <span>2. Design & Linha Visual</span>
        </button>
        <button
          onClick={() => setActiveTab('copy_areas')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'copy_areas' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <FileText className="h-4 w-4" />
          <span>3. Copy das Áreas Internas</span>
        </button>
        <button
          onClick={() => setActiveTab('ux_writing')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'ux_writing' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <MessageSquare className="h-4 w-4" />
          <span>4. UX Writing & Microcopy</span>
        </button>
        <button
          onClick={() => setActiveTab('banners')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
            activeTab === 'banners' 
              ? 'border-oab-accent text-slate-950 bg-slate-100/50' 
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <Crown className="h-4 w-4" />
          <span>5. Banners & Monetização</span>
        </button>
        <button
          onClick={() => setActiveTab('simulator')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center space-x-2 text-amber-600 border-amber-600/20 bg-amber-500/5 animate-pulse`}
        >
          <Sliders className="h-4 w-4 text-amber-500" />
          <span>6. Simulador de Jornada</span>
        </button>
      </div>

      {/* ==========================================
          TAB 1: BRAND POSITIONING & VOICE
          ========================================== */}
      {activeTab === 'brand' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Brand Essence Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white p-6 border border-slate-200 shadow-sm relative overflow-hidden">
                <div className="absolute right-0 top-0 bg-oab-accent/10 text-oab-accent text-[10px] uppercase font-bold tracking-widest px-3 py-1 font-mono">
                  Posicionamento Oficial
                </div>
                <h3 className="text-xl font-display font-bold text-slate-900 mb-4 border-b border-slate-100 pb-2">
                  O Posicionamento Estratégico OAB 3F
                </h3>
                <p className="text-slate-700 text-sm leading-relaxed mb-4">
                  O <strong>OAB 3F</strong> não se apresenta como um mero repositório de videoaulas ou banco estático de questões. Ele se posiciona como um <strong>ecossistema completo e inteligente de preparação acadêmica de alta performance</strong>, baseado em uma metodologia rígida e validada de 3 fases que respeita o tempo real do aluno.
                </p>
                <div className="space-y-3 font-sans">
                  <div className="p-3 bg-slate-50 border-l-4 border-oab-accent text-xs">
                    <span className="block font-bold text-slate-950 mb-0.5">A Promessa Central da Marca:</span>
                    "Aprovação sem desperdício de tempo através de um plano adaptativo, que organiza suas revisões e treinos diários focando estritamente nas fraquezas reais e nos assuntos que caem de fato."
                  </div>
                  <div className="p-3 bg-slate-50 border-l-4 border-slate-800 text-xs">
                    <span className="block font-bold text-slate-950 mb-0.5">A Proposta de Valor Curta (Elevator Pitch):</span>
                    "OAB 3F: Da primeira fase à aprovação final com um cronograma inteligente que estuda por você os editais e constrói sua taxa de acerto ideal."
                  </div>
                </div>
              </div>

              {/* Pillars of Position */}
              <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
                <h3 className="text-lg font-display font-bold text-slate-900">Pilares Essenciais do Ecossistema</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 border border-slate-100 bg-slate-50/50 space-y-1.5">
                    <div className="flex items-center space-x-2 text-slate-900 font-bold text-xs sm:text-sm">
                      <span className="h-5 w-5 bg-oab-accent/10 rounded-full text-oab-accent flex items-center justify-center font-mono text-xs">1</span>
                      <span>Aprovação com Método</span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      A jornada acadêmica é cientificamente dividida em Teoria Básica, Treino Dinâmico de Questões e Revisão Espaçada Ativa. Zero adivinhação.
                    </p>
                  </div>
                  <div className="p-4 border border-slate-100 bg-slate-50/50 space-y-1.5">
                    <div className="flex items-center space-x-2 text-slate-900 font-bold text-xs sm:text-sm">
                      <span className="h-5 w-5 bg-oab-accent/10 rounded-full text-oab-accent flex items-center justify-center font-mono text-xs">2</span>
                      <span>Clareza e Direção Prática</span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      O candidato entra no sistema para executar tarefas diárias, e não para escolher o que estudar. O plano remove a fadiga de decisão.
                    </p>
                  </div>
                  <div className="p-4 border border-slate-100 bg-slate-50/50 space-y-1.5">
                    <div className="flex items-center space-x-2 text-slate-900 font-bold text-xs sm:text-sm">
                      <span className="h-5 w-5 bg-oab-accent/10 rounded-full text-oab-accent flex items-center justify-center font-mono text-xs">3</span>
                      <span>Acompanhamento Inteligente</span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      O motor rastreia o tempo de tela do candidato, taxa de acerto por sub-assunto e emite alertas antes que ele entre em zona de risco de abandono.
                    </p>
                  </div>
                  <div className="p-4 border border-slate-100 bg-slate-50/50 space-y-1.5">
                    <div className="flex items-center space-x-2 text-slate-900 font-bold text-xs sm:text-sm">
                      <span className="h-5 w-5 bg-oab-accent/10 rounded-full text-oab-accent flex items-center justify-center font-mono text-xs">4</span>
                      <span>Autoridade de Alto Nível</span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Linguagem e apresentação visual que simulam a sobriedade jurídica, mescladas com recursos de edutech modernos.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Tone of Voice Guidelines Sidebar */}
            <div className="space-y-6">
              <div className="bg-oab-primary text-slate-300 p-6 shadow-sm border border-slate-800 space-y-4">
                <h3 className="text-lg font-display font-bold text-oab-accent">Tom de Voz Oficial</h3>
                <p className="text-xs leading-relaxed opacity-90">
                  Nossa comunicação combina autoridade jurídica clássica com a proximidade acolhedora de um mentor particular. Devemos motivar com honestidade pedagógica, evitando jargões irreais ou abordagens infantis.
                </p>

                <div className="space-y-3.5 border-t border-slate-800 pt-4 text-xs font-mono">
                  <div>
                    <span className="text-emerald-400 font-semibold block">✓ COMO FALAMOS:</span>
                    <span className="block italic text-slate-200 mt-1">"Seu desempenho em Ética indica ótimo aproveitamento, mas isolamos 3 fraquezas em deveres disciplinares para treinar hoje."</span>
                  </div>
                  <div>
                    <span className="text-rose-400 font-semibold block">✗ COMO NÃO FALAMOS:</span>
                    <span className="block italic text-slate-400 mt-1">"E aí, concurseiro! Partiu destruir a prova com macetes secretos sem abrir nenhum livro? Vem com a gente!!!"</span>
                  </div>
                </div>

                <div className="space-y-2 border-t border-slate-800 pt-4">
                  <span className="text-xs font-bold text-white block">Regras Fundamentais de Linguagem:</span>
                  <ul className="space-y-1.5 text-xs text-slate-400 list-disc list-inside">
                    <li>Chamar o aluno pelo nome sempre que possível.</li>
                    <li>Substituir culpa por análise didática de erros.</li>
                    <li>Utilizar termos do edital oficial (e.g. "Peça Prático-Profissional").</li>
                    <li>Manter o foco em metas microscópicas viáveis.</li>
                  </ul>
                </div>
              </div>

              {/* Institutions Descriptions Cards */}
              <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-4">
                <h4 className="text-xs uppercase font-mono tracking-widest text-slate-500 font-bold">O App em Palavras</h4>
                
                <div className="space-y-3 text-xs">
                  <div className="border-b border-slate-100 pb-2">
                    <span className="font-bold text-slate-900 block mb-1">Versão em 1 Frase</span>
                    <p className="text-slate-600">"OAB 3F é um ecossistema de preparação estratégico que molda seu cronograma de acordo com seus erros reais até garantir sua aprovação final."</p>
                  </div>
                  <div className="border-b border-slate-100 pb-2">
                    <span className="font-bold text-slate-900 block mb-1">Versão em 3 Frases</span>
                    <p className="text-slate-600">"Prepare-se com um método científico que divide sua rotina entre teoria objetiva, treino intensivo e revisão ativa espaçada. O aplicativo analisa cada resposta marcada para identificar suas lacunas pedagógicas em tempo real. Garanta um caminho seguro sem desperdício de tempo ou acúmulo de matérias desnecessárias."</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 2: DESIGN & VISUAL IDENTITY
          ========================================== */}
      {activeTab === 'voice' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Aesthetic Guidelines overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 border border-slate-200 shadow-sm md:col-span-2 space-y-6">
              <h3 className="text-xl font-display font-bold text-slate-900 pb-2 border-b border-slate-100">
                Diretrizes de Identidade Visual e UI
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Para fugir do visual comum de "aplicativo de cursinho barato" com gradientes roxos amadores, o OAB 3F adota a estética <strong>"Editorial e Papel"</strong>. Ela utiliza elementos de design clássico que remetem a jornais jurídicos refinados, livros de doutrina caros e escritórios de advocacia de alta reputação, mantendo uma experiência digital fluida e responsiva.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 border border-slate-100 bg-slate-50/50 space-y-2">
                  <span className="text-xs font-mono font-bold text-slate-900 uppercase tracking-wider block">Visual Geral & Cantos</span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Cantos ligeiramente arredondados (borda de 4px) dão um aspecto impresso e sóbrio em vez dos cantos circulares agressivos do design de jogos móveis. Linhas finas, limpas e contrastes suaves são priorizados.
                  </p>
                </div>
                <div className="p-4 border border-slate-100 bg-slate-50/50 space-y-2">
                  <span className="text-xs font-mono font-bold text-slate-900 uppercase tracking-wider block">Gráficos e Indicadores</span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Uso de diagramação clássica e barras minimalistas. Ícones neutros importados do Lucide que evitam desenhos fofos ou em 3D.
                  </p>
                </div>
                <div className="p-4 border border-slate-100 bg-slate-50/50 space-y-2">
                  <span className="text-xs font-mono font-bold text-slate-900 uppercase tracking-wider block">Áreas Premium (Gold Highlight)</span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    A marcação VIP utiliza detalhes de ouro escovado/quente (#D4AF37) com fundo em azul marinho profundo, conferindo um senso imediato de exclusividade e alto valor.
                  </p>
                </div>
                <div className="p-4 border border-slate-100 bg-slate-50/50 space-y-2">
                  <span className="text-xs font-mono font-bold text-slate-900 uppercase tracking-wider block">Tipografia Contrastante</span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Títulos proeminentes na fonte clássica serifada <strong>"Playfair Display"</strong> (lembrando os melhores tribunais e livros jurídicos) pareados com textos em <strong>"Inter"</strong> e metadados técnicos em <strong>"JetBrains Mono"</strong>.
                  </p>
                </div>
              </div>
            </div>

            {/* Colors Palette Box */}
            <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
              <h3 className="text-lg font-display font-bold text-slate-900">Paleta de Cores Acadêmica</h3>
              <div className="space-y-3 font-sans text-xs">
                <div className="flex items-center justify-between p-2.5 border border-slate-100 bg-[#0F172A] text-white">
                  <span className="font-semibold">OAB Navy (Primary)</span>
                  <span className="font-mono">#0F172A</span>
                </div>
                <div className="flex items-center justify-between p-2.5 border border-slate-100 bg-[#1E293B] text-white">
                  <span className="font-semibold">Slate Slate (Secondary)</span>
                  <span className="font-mono">#1E293B</span>
                </div>
                <div className="flex items-center justify-between p-2.5 border border-slate-100 bg-[#D4AF37] text-slate-950">
                  <span className="font-bold">Warm Gold (Accent)</span>
                  <span className="font-mono">#D4AF37</span>
                </div>
                <div className="flex items-center justify-between p-2.5 border border-slate-100 bg-[#FAF9F6] text-slate-950">
                  <span className="font-semibold">Parchment Off-White (Canvas)</span>
                  <span className="font-mono">#FAF9F6</span>
                </div>
                <div className="flex items-center justify-between p-2.5 border border-slate-100 bg-[#F1F1ED] text-slate-950">
                  <span className="font-semibold">Soft Gray (Dividers/Bgs)</span>
                  <span className="font-mono">#F1F1ED</span>
                </div>
                <div className="flex items-center justify-between p-2.5 border border-slate-100 bg-[#10B981] text-white">
                  <span className="font-semibold">Emerald Success (Métrica)</span>
                  <span className="font-mono">#10B981</span>
                </div>
              </div>

              <div className="p-4 bg-amber-50/50 border border-amber-200/60 rounded text-[11px] text-amber-900 leading-relaxed">
                <strong>Nota de Designer:</strong> Evite sombras externas pretas e agressivas. Use sempre bordas finas sólidas em <span className="font-mono text-xs">#E5E1D8</span> para delimitar cards, imitando o design limpo de editoriais e papéis impressos.
              </div>
            </div>
          </div>

          {/* Visual Components Mockup Display */}
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-xl font-display font-bold text-slate-900 pb-2 border-b border-slate-100">
              Visualização de Componentes & Layouts Customizados
            </h3>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Header Dashboard Mockup */}
              <div className="border border-slate-200 p-4 space-y-4 rounded bg-[#FAF9F6] shadow-sm relative overflow-hidden">
                <span className="absolute top-2 right-2 text-[9px] font-mono text-slate-400 bg-slate-200/50 px-1.5 py-0.5 rounded">Dashboard</span>
                <div className="space-y-1 text-left">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-oab-accent font-bold">Foco Diário de Estudos</span>
                  <h4 className="text-lg font-display font-bold text-slate-900">Olá, Amanda</h4>
                  <p className="text-xs text-slate-600">Restam <span className="font-bold text-slate-900">45 dias</span> para o Exame OAB Nacional. Seu plano estratégico está em ritmo ideal.</p>
                </div>
                <div className="p-3 bg-white border border-slate-200 rounded text-xs space-y-2">
                  <div className="flex justify-between text-[11px] font-bold text-slate-900">
                    <span>Meta de Hoje: Direito Administrativo</span>
                    <span className="text-oab-accent">60 min</span>
                  </div>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-oab-accent h-full w-2/5"></div>
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>2 de 5 tópicos concluídos</span>
                    <span>40% de progresso</span>
                  </div>
                </div>
              </div>

              {/* Locked Component Mockup */}
              <div className="border border-slate-200 p-4 rounded bg-[#0F172A] text-slate-300 space-y-4 shadow-sm relative">
                <span className="absolute top-2 right-2 text-[9px] font-mono text-slate-500 bg-slate-800 px-1.5 py-0.5 rounded">Acesso VIP</span>
                <div className="flex items-start space-x-3 text-left">
                  <div className="p-2 bg-oab-accent/10 border border-oab-accent/30 rounded text-oab-accent">
                    <Lock className="h-5 w-5" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-display font-bold text-white">Análise Avançada de Peças 2ª Fase</h4>
                    <p className="text-xs text-slate-400">Modelos completos de Cabimento, Teses Recursais e Espelho de Pontuação FGV.</p>
                  </div>
                </div>
                <div className="border border-slate-800 p-3 bg-slate-950/45 rounded text-xs text-slate-400">
                  Esta funcionalidade de alto nível exige assinatura do Plano <strong className="text-oab-accent">Completo OAB 3F</strong>.
                </div>
                <button className="w-full bg-oab-accent hover:bg-oab-accent/90 text-oab-primary font-bold text-xs py-2 text-center rounded transition-colors flex items-center justify-center space-x-1.5">
                  <Crown className="h-3.5 w-3.5" />
                  <span>Liberar Trilha Completa</span>
                </button>
              </div>

              {/* Alert / Reorganization Card */}
              <div className="border border-slate-200 p-4 rounded bg-white text-slate-800 space-y-3 shadow-sm relative text-left">
                <div className="flex items-center space-x-2 text-amber-600">
                  <AlertTriangle className="h-4.5 w-4.5" />
                  <span className="text-xs font-mono font-bold uppercase tracking-wider">Ajuste de Rota Ativo</span>
                </div>
                <h4 className="text-sm font-display font-bold text-slate-900">Meta Semanal Desalinhada</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Percebemos que sua rotina ficou mais apertada esta semana. Não acumule frustração tentando estudar 4 horas hoje.
                </p>
                <div className="p-2 bg-[#F1F1ED] text-[11px] text-slate-700 font-mono border-l-2 border-slate-400">
                  💡 Ação sugerida: diluir as tarefas atrasadas em 15 minutos extras nos próximos 4 dias.
                </div>
                <button className="text-xs text-oab-accent hover:text-slate-950 font-bold flex items-center space-x-1">
                  <span>Recalcular cronograma agora</span>
                  <ArrowRight className="h-3 w-3" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 3: INTERNAL AREAS COPY (BLOCO 4 & 5)
          ========================================== */}
      {activeTab === 'copy_areas' && (
        <div className="space-y-8 animate-fade-in text-left">
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-xl font-display font-bold text-slate-900 pb-2 border-b border-slate-100">
              Copys Estruturadas para Áreas Internas (Blocos 4, 5 e 11)
            </h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Consulte e copie abaixo as diretrizes de copywriting oficiais das principais telas do ecossistema. Desenvolvidas com terminologia sóbria que inspira foco acadêmico.
            </p>

            <div className="space-y-6">
              {/* Internal Area Card 1 */}
              <div className="p-5 border border-slate-200 bg-slate-50/50 space-y-3 relative">
                <span className="absolute top-4 right-4 bg-slate-200 text-slate-800 font-mono text-[10px] font-bold px-2 py-0.5 rounded">ÁREA: CRONOGRAMA & MEU PLANO</span>
                <h4 className="text-base font-display font-bold text-slate-900">Meu Plano Inteligente</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
                  <div className="p-3 bg-white border border-slate-100">
                    <span className="font-bold text-slate-700 block mb-1">Headline Explicativa:</span>
                    <p className="text-slate-600 italic">"Seu trilho diário até a aprovação. Uma sequência lógica e focada baseada na sua disponibilidade real e no histórico de cobrança do Exame da Ordem."</p>
                  </div>
                  <div className="p-3 bg-white border border-slate-100">
                    <span className="font-bold text-slate-700 block mb-1">Copy de Atraso / Replanejamento:</span>
                    <p className="text-slate-600 italic">"Notamos que seu cronograma acumulou tarefas. Sem estresse ou sentimento de culpa: clique no botão abaixo para o motor de readequação acadêmica reorganizar suas metas semanais de forma viável."</p>
                  </div>
                </div>
                <div className="flex justify-end">
                  <button 
                    onClick={() => copyToClipboard("Seu trilho diário até a aprovação. Uma sequência lógica e focada baseada na sua disponibilidade real.", "area_plano")}
                    className="flex items-center space-x-1.5 text-xs text-oab-accent font-bold hover:text-slate-900"
                  >
                    {copiedId === 'area_plano' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    <span>{copiedId === 'area_plano' ? 'Copiado!' : 'Copiar Texto Base'}</span>
                  </button>
                </div>
              </div>

              {/* Internal Area Card 2 */}
              <div className="p-5 border border-slate-200 bg-slate-50/50 space-y-3 relative">
                <span className="absolute top-4 right-4 bg-slate-200 text-slate-800 font-mono text-[10px] font-bold px-2 py-0.5 rounded">ÁREA: BANCO DE QUESTÕES</span>
                <h4 className="text-base font-display font-bold text-slate-900">Mecanismo de Treino Ativo</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
                  <div className="p-3 bg-white border border-slate-100">
                    <span className="font-bold text-slate-700 block mb-1">Headline Explicativa:</span>
                    <p className="text-slate-600 italic">"Estudo reverso em ação. Não memorize teorias abstratas; aprenda como a FGV cobra na prática com questões comentadas palavra por palavra por professores especialistas."</p>
                  </div>
                  <div className="p-3 bg-white border border-slate-100">
                    <span className="font-bold text-slate-700 block mb-1">Copy de Erros & Acertos:</span>
                    <p className="text-slate-600 italic">"Você errou essa questão. Excelente! Cada erro mapeado agora é um ponto protegido que você garantirá no dia do exame. Leia a fundamentação jurídica do professor para preencher essa lacuna."</p>
                  </div>
                </div>
                <div className="flex justify-end">
                  <button 
                    onClick={() => copyToClipboard("Estudo reverso em ação. Não memorize teorias abstratas; aprenda como a FGV cobra na prática.", "area_questoes")}
                    className="flex items-center space-x-1.5 text-xs text-oab-accent font-bold hover:text-slate-900"
                  >
                    {copiedId === 'area_questoes' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    <span>{copiedId === 'area_questoes' ? 'Copiado!' : 'Copiar Texto Base'}</span>
                  </button>
                </div>
              </div>

              {/* Internal Area Card 3 */}
              <div className="p-5 border border-slate-200 bg-slate-50/50 space-y-3 relative">
                <span className="absolute top-4 right-4 bg-slate-200 text-slate-800 font-mono text-[10px] font-bold px-2 py-0.5 rounded">ÁREA: REVISÃO INTELIGENTE</span>
                <h4 className="text-base font-display font-bold text-slate-900">Motor de Revisão Espaçada Ativa</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
                  <div className="p-3 bg-white border border-slate-100">
                    <span className="font-bold text-slate-700 block mb-1">Explicação Teórica do Recurso:</span>
                    <p className="text-slate-600 italic">"Baseado na Curva do Esquecimento de Ebbinghaus, nosso algoritmo calcula o intervalo exato para sugerir revisões dos seus assuntos errados após 24 horas, 7 dias e 30 dias. Fixação científica de longo prazo."</p>
                  </div>
                  <div className="p-3 bg-white border border-slate-100">
                    <span className="font-bold text-slate-700 block mb-1">Aviso de Revisão Vencendo:</span>
                    <p className="text-slate-600 italic">"Atenção: 4 assuntos críticos estão entrando na zona de esquecimento permanente. Dedique 8 minutos para revisar estes tópicos hoje e manter o conhecimento consolidado."</p>
                  </div>
                </div>
                <div className="flex justify-end">
                  <button 
                    onClick={() => copyToClipboard("Baseado na Curva do Esquecimento, nosso algoritmo calcula o intervalo exato para sugerir revisões dos seus assuntos errados.", "area_revisao")}
                    className="flex items-center space-x-1.5 text-xs text-oab-accent font-bold hover:text-slate-900"
                  >
                    {copiedId === 'area_revisao' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    <span>{copiedId === 'area_revisao' ? 'Copiado!' : 'Copiar Texto Base'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 4: UX WRITING & MICROCOPY
          ========================================== */}
      {activeTab === 'ux_writing' && (
        <div className="space-y-8 animate-fade-in text-left">
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-xl font-display font-bold text-slate-900 pb-2 border-b border-slate-100">
              Manual de UX Writing & Microcopy (Bloco 6 e 10)
            </h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Diretrizes de escrita de interface para botões, estados vazios e confirmações para o aplicativo OAB 3F. Cada frase é desenhada para guiar a ação sem causar fricção.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Col 1: Buttons and Confirmations */}
              <div className="space-y-4">
                <h4 className="text-xs uppercase font-mono tracking-widest text-slate-500 font-bold">Botões de Alta Conversão</h4>
                <div className="border border-slate-150 rounded overflow-hidden divide-y divide-slate-100 bg-slate-50/30 text-xs">
                  <div className="p-3 flex justify-between items-center bg-white">
                    <div>
                      <span className="font-bold text-slate-900 block">Iniciar Meta do Dia</span>
                      <span className="text-[10px] text-slate-400">Botão principal do cronograma</span>
                    </div>
                    <button onClick={() => copyToClipboard("Iniciar Meta do Dia", "btn_1")} className="p-1 hover:bg-slate-100 rounded text-oab-accent"><Copy className="h-3.5 w-3.5" /></button>
                  </div>
                  <div className="p-3 flex justify-between items-center">
                    <div>
                      <span className="font-bold text-slate-900 block">Revisar Erros Críticos</span>
                      <span className="text-[10px] text-slate-400">Botão do motor de revisão</span>
                    </div>
                    <button onClick={() => copyToClipboard("Revisar Erros Críticos", "btn_2")} className="p-1 hover:bg-slate-100 rounded text-oab-accent"><Copy className="h-3.5 w-3.5" /></button>
                  </div>
                  <div className="p-3 flex justify-between items-center bg-white">
                    <div>
                      <span className="font-bold text-slate-900 block">Simular Tempo Regulamentar</span>
                      <span className="text-[10px] text-slate-400">Início de prova simulada</span>
                    </div>
                    <button onClick={() => copyToClipboard("Simular Tempo Regulamentar", "btn_3")} className="p-1 hover:bg-slate-100 rounded text-oab-accent"><Copy className="h-3.5 w-3.5" /></button>
                  </div>
                  <div className="p-3 flex justify-between items-center">
                    <div>
                      <span className="font-bold text-slate-900 block">Liberar Trilha Completa 2ª Fase</span>
                      <span className="text-[10px] text-slate-400">Upgrade de plano comercial</span>
                    </div>
                    <button onClick={() => copyToClipboard("Liberar Trilha Completa 2ª Fase", "btn_4")} className="p-1 hover:bg-slate-100 rounded text-oab-accent"><Copy className="h-3.5 w-3.5" /></button>
                  </div>
                </div>

                <h4 className="text-xs uppercase font-mono tracking-widest text-slate-500 font-bold mt-6">Mensagens de Sucesso & Confirmação</h4>
                <div className="border border-slate-150 rounded overflow-hidden divide-y divide-slate-100 bg-slate-50/30 text-xs">
                  <div className="p-3 bg-white">
                    <span className="font-bold text-slate-900 block mb-1">Revisão Concluída!</span>
                    <p className="text-slate-600 italic">"Parabéns! Você blindou estes 4 conceitos contra a curva do esquecimento hoje. Matérias devidamente fixadas na memória."</p>
                  </div>
                  <div className="p-3">
                    <span className="font-bold text-slate-900 block mb-1">Simulado Registrado</span>
                    <p className="text-slate-600 italic">"Suas respostas foram consolidadas com sucesso no espelho simulado. Seus gráficos de rendimento já foram atualizados."</p>
                  </div>
                </div>
              </div>

              {/* Col 2: Empty States */}
              <div className="space-y-4">
                <h4 className="text-xs uppercase font-mono tracking-widest text-slate-500 font-bold">Estados Vazios Pedagógicos (Não de Erro)</h4>
                
                <div className="border border-slate-150 rounded p-4 bg-[#FAF9F6] text-xs space-y-4">
                  <div className="border-b border-slate-200 pb-3">
                    <span className="font-bold text-slate-900 block mb-1">Nenhum Simulado Realizado Ainda</span>
                    <p className="text-slate-600 mb-2 leading-relaxed">
                      "Para calibrar seu plano estratégico, precisamos de dados de proficiência. O que acha de iniciar nosso Simulado Diagnóstico de 15 questões rápidas agora?"
                    </p>
                    <span className="text-[10px] text-slate-400 block font-mono">Gatilho de Ação: Botão [Iniciar Simulado Diagnóstico]</span>
                  </div>

                  <div className="border-b border-slate-200 pb-3">
                    <span className="font-bold text-slate-900 block mb-1">Nenhuma Revisão Pendente</span>
                    <p className="text-slate-600 mb-2 leading-relaxed">
                      "Excelente trabalho acadêmico! Todas as suas revisões espaçadas estão rigorosamente em dia. Sua memória de longo prazo agradece a consistência!"
                    </p>
                    <span className="text-[10px] text-slate-400 block font-mono">Apoio: Ícone de check de aprovação verde</span>
                  </div>

                  <div>
                    <span className="font-bold text-slate-900 block mb-1">Nenhum Material Salvo</span>
                    <p className="text-slate-600 mb-2 leading-relaxed">
                      "Adicione resumos, mapas mentais, PDFs e checklists à sua biblioteca particular para revisar rápido em trânsito com apenas um clique."
                    </p>
                    <span className="text-[10px] text-slate-400 block font-mono">Gatilho de Ação: Botão [Explorar Biblioteca de Apoio]</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 5: BANNERS & MONETIZATION
          ========================================== */}
      {activeTab === 'banners' && (
        <div className="space-y-8 animate-fade-in text-left">
          <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-xl font-display font-bold text-slate-900 pb-2 border-b border-slate-100">
              Copys para Banners, CTAs e Monetização (Blocos 7, 9 e 14)
            </h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Monetização integrada e elegante que se apresenta como um facilitador pedagógico natural na jornada de preparação para a OAB, e não como uma interrupção intrusiva.
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Commercial Banner 1 */}
              <div className="border border-oab-accent/30 p-5 bg-[#0F172A] text-slate-300 rounded space-y-4">
                <div className="flex items-center justify-between">
                  <span className="bg-oab-accent/10 border border-oab-accent/30 text-oab-accent text-[10px] font-mono uppercase font-bold tracking-widest px-2 py-0.5 rounded">
                    Home do Aluno Gratuito
                  </span>
                  <Crown className="h-4 w-4 text-oab-accent fill-current" />
                </div>
                <h4 className="text-lg font-display font-bold text-white">Não conte com a sorte. Tenha as ferramentas certas até o dia da prova.</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Estudantes premium do OAB 3F alcançam taxas de aprovação <strong className="text-white">3.4x maiores</strong> que usuários do plano livre. Desbloqueie revisões inteligentes ilimitadas, gabarito gravado em vídeo por professores e treinos intensivos.
                </p>
                <div className="flex items-center space-x-2 text-xs font-mono text-oab-accent-light bg-slate-950/45 p-2 rounded">
                  <span>✓ 2.340 questões comentadas</span>
                  <span>✓ Simulados oficiais FGV</span>
                  <span>✓ Relatório de fraquezas</span>
                </div>
                <button className="w-full bg-oab-accent text-oab-primary font-bold text-xs py-2 text-center rounded hover:bg-oab-accent/90 transition-colors">
                  Ativar Meu Plano Completo OAB 3F
                </button>
              </div>

              {/* Commercial Banner 2 */}
              <div className="border border-slate-200 p-5 bg-white text-slate-800 rounded space-y-4 shadow-sm">
                <div className="flex items-center justify-between">
                  <span className="bg-blue-50 border border-blue-200 text-blue-700 text-[10px] font-mono uppercase font-bold tracking-widest px-2 py-0.5 rounded">
                    Banner Reta Final (Faltam 15 dias)
                  </span>
                  <Clock className="h-4 w-4 text-blue-600" />
                </div>
                <h4 className="text-lg font-display font-bold text-slate-900">Funil Estratégico Reta Final OAB</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Faltam poucos dias para a prova. Deixe de lado os manuais pesados. Garanta acesso ao compilado exclusivo OAB 3F de véspera: <strong className="text-slate-950 font-semibold">"As 50 Súmulas mais cobradas pela FGV"</strong> e maratona de 12 horas de vídeo-dicas objetivas.
                </p>
                <div className="flex items-center justify-between text-xs pt-2">
                  <span className="text-slate-500 font-mono">Oferta exclusiva por tempo limitado</span>
                  <button className="bg-slate-950 hover:bg-slate-800 text-white font-bold px-3 py-1.5 text-xs rounded transition-all">
                    Ver Plano Reta Final
                  </button>
                </div>
              </div>

              {/* Commercial Banner 3 */}
              <div className="border border-slate-200 p-5 bg-slate-50 text-slate-800 rounded space-y-4 shadow-sm lg:col-span-2">
                <div className="flex items-center justify-between">
                  <span className="bg-emerald-50 border border-emerald-200 text-emerald-700 text-[10px] font-mono uppercase font-bold tracking-widest px-2 py-0.5 rounded">
                    Upgrade para Mentoria VIP (Alto Valor)
                  </span>
                  <Award className="h-4 w-4 text-emerald-600" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-2 space-y-2">
                    <h4 className="text-base font-display font-bold text-slate-900">Aceleração VIP: Mentoria & Correção de Peças por Professores</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Sua redação jurídica avaliada no detalhe fino. Submeta suas peças estruturadas no app e receba um feedback em áudio e PDF em até 48 horas analisando seu cumprimento de formalidades legais e teses fundamentais.
                    </p>
                  </div>
                  <div className="flex flex-col justify-center space-y-2">
                    <div className="text-center md:text-right">
                      <span className="text-[10px] text-slate-400 block">Investimento Seguro</span>
                      <span className="text-lg font-bold text-slate-950 font-mono">12x R$ 97,90</span>
                    </div>
                    <button className="bg-oab-accent text-oab-primary font-bold text-xs py-2 text-center rounded hover:bg-[#D4AF37]/90 transition-all">
                      Falar com Coordenador VIP
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          TAB 6: THE INTERACTIVE JOURNEY SIMULATOR
          ========================================== */}
      {activeTab === 'simulator' && (
        <div className="space-y-8 animate-fade-in text-left">
          {/* Main Simulator Card */}
          <div className="bg-white p-6 border border-oab-accent/20 shadow-md rounded relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-amber-500 text-slate-950 text-[10px] uppercase tracking-widest font-bold font-mono px-3 py-1">
              Motor de Testes
            </div>
            
            <h3 className="text-xl sm:text-2xl font-display font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center space-x-2">
              <Sliders className="h-5.5 w-5.5 text-amber-500" />
              <span>Simulador de Copy & Tom de Voz Adaptativo</span>
            </h3>
            <p className="text-xs text-slate-600 mt-1 max-w-3xl leading-relaxed">
              Diferente de sistemas engessados, o OAB 3F adapta sua linguagem cirurgicamente ao momento emocional e ao rendimento acadêmico do aluno. Selecione uma Persona e um Formato de Comunicação abaixo para ver a copy se adequar na prática!
            </p>

            {/* Selector Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6 border-t border-slate-100 pt-6">
              {/* Persona Selector (Col 1) */}
              <div className="space-y-3">
                <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider block">1. Selecione a Persona (Momento da Jornada)</span>
                <div className="space-y-2 divide-y divide-slate-100">
                  {Object.entries(simulatorPersonas).map(([key, data]) => (
                    <button
                      key={key}
                      onClick={() => setSelectedPersona(key)}
                      className={`w-full text-left p-3 rounded transition-all text-xs border ${
                        selectedPersona === key 
                          ? 'border-oab-accent bg-[#FAF9F6] shadow-sm' 
                          : 'border-transparent hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center space-x-2.5">
                        <div className={`h-7 w-7 rounded-full flex items-center justify-center font-bold font-mono text-[10px] ${data.avatarBg}`}>
                          {data.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <span className="font-bold text-slate-950 block">{data.name}</span>
                          <span className="text-[10px] text-slate-500">{data.tag}</span>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Format Selector (Col 2) */}
              <div className="space-y-3">
                <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider block">2. Selecione o Canal/Formato</span>
                <div className="grid grid-cols-1 gap-2">
                  <button
                    onClick={() => setSelectedFormat('dashboard')}
                    className={`p-3 text-left rounded text-xs border transition-all flex items-center space-x-2 ${
                      selectedFormat === 'dashboard' ? 'border-slate-800 bg-slate-900 text-white font-bold' : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Tv className="h-4 w-4" />
                    <span>Saudação do Dashboard</span>
                  </button>
                  <button
                    onClick={() => setSelectedFormat('push')}
                    className={`p-3 text-left rounded text-xs border transition-all flex items-center space-x-2 ${
                      selectedFormat === 'push' ? 'border-slate-800 bg-slate-900 text-white font-bold' : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Smartphone className="h-4 w-4" />
                    <span>Notificação Push</span>
                  </button>
                  <button
                    onClick={() => setSelectedFormat('button')}
                    className={`p-3 text-left rounded text-xs border transition-all flex items-center space-x-2 ${
                      selectedFormat === 'button' ? 'border-slate-800 bg-slate-900 text-white font-bold' : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <CheckSquare className="h-4 w-4" />
                    <span>UX Microcopy do Botão</span>
                  </button>
                  <button
                    onClick={() => setSelectedFormat('motivation')}
                    className={`p-3 text-left rounded text-xs border transition-all flex items-center space-x-2 ${
                      selectedFormat === 'motivation' ? 'border-slate-800 bg-slate-900 text-white font-bold' : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <MessageSquare className="h-4 w-4" />
                    <span>Mensagem de Incentivo</span>
                  </button>
                  <button
                    onClick={() => setSelectedFormat('upgrade')}
                    className={`p-3 text-left rounded text-xs border transition-all flex items-center space-x-2 ${
                      selectedFormat === 'upgrade' ? 'border-slate-800 bg-slate-900 text-white font-bold' : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Crown className="h-4 w-4" />
                    <span>Banner de Upgrade Contextual</span>
                  </button>
                  <button
                    onClick={() => setSelectedFormat('email')}
                    className={`p-3 text-left rounded text-xs border transition-all flex items-center space-x-2 ${
                      selectedFormat === 'email' ? 'border-slate-800 bg-slate-900 text-white font-bold' : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Send className="h-4 w-4" />
                    <span>E-mail Acadêmico / Retenção</span>
                  </button>
                </div>
              </div>

              {/* Dynamic Output Box (Col 3) */}
              <div className="bg-slate-50 p-4 border border-slate-200 rounded relative space-y-4">
                <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider block">3. Copy Gerada em Tempo Real</span>
                
                {/* Simulated Rendering */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                    <span className="text-[10px] font-mono uppercase bg-oab-accent/10 border border-oab-accent/30 text-oab-accent px-2 py-0.5 rounded font-bold">
                      {activeCopyItem.badge}
                    </span>
                    <button 
                      onClick={() => copyToClipboard(activeCopyItem.title + "\n" + activeCopyItem.subtitle, "simulated_copy")}
                      className="p-1 hover:bg-slate-200 rounded text-slate-400 hover:text-slate-800"
                    >
                      {copiedId === 'simulated_copy' ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
                    </button>
                  </div>

                  {/* Format specifics rendering */}
                  {selectedFormat === 'push' && (
                    <div className="bg-slate-950 text-white p-3 rounded-lg border border-slate-800 shadow-lg space-y-1 max-w-sm mx-auto text-left font-sans">
                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span className="font-bold flex items-center space-x-1">
                          <Sparkles className="h-3 w-3 text-oab-accent" />
                          <span>OAB 3F</span>
                        </span>
                        <span>Agora mesmo</span>
                      </div>
                      <h5 className="text-xs font-bold font-sans text-slate-100">{activeCopyItem.title}</h5>
                      <p className="text-[11px] text-slate-300 leading-normal">{activeCopyItem.subtitle}</p>
                    </div>
                  )}

                  {selectedFormat === 'button' && (
                    <div className="py-4 text-center">
                      <button className="bg-[#0F172A] hover:bg-[#1E293B] text-white text-xs font-bold py-2.5 px-5 rounded tracking-wide border border-oab-accent/30 shadow transition-all">
                        {activeCopyItem.title}
                      </button>
                      <span className="block text-[10px] text-slate-400 mt-1.5 italic">({activeCopyItem.subtitle})</span>
                    </div>
                  )}

                  {selectedFormat !== 'push' && selectedFormat !== 'button' && (
                    <div className="bg-white p-4 border border-slate-200 rounded text-left space-y-2">
                      <h5 className="text-sm font-display font-bold text-slate-900 leading-tight">
                        {activeCopyItem.title}
                      </h5>
                      <p className="text-xs text-slate-600 whitespace-pre-line leading-relaxed">
                        {activeCopyItem.subtitle}
                      </p>
                    </div>
                  )}

                  {/* Description meta */}
                  <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded text-[11px] text-slate-700 leading-relaxed pt-2.5">
                    <span className="font-bold text-slate-900 block mb-0.5">Estratégia Pedagógica Aplicada:</span>
                    {activePersonaData.description}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Manual de Consistência e Alinhamento */}
      <div className="bg-white p-6 border border-slate-200 shadow-sm space-y-6 text-left">
        <h3 className="text-xl font-display font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center space-x-2">
          <ShieldCheck className="h-5.5 w-5.5 text-oab-accent" />
          <span>Manual de Consistência e Diretrizes de Integração (Blocos 10, 11, 12, 13 e 15)</span>
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs leading-relaxed">
          <div className="space-y-2.5">
            <span className="font-display font-bold text-slate-950 text-sm block">Estratégia de Naming das Áreas</span>
            <p className="text-slate-600">
              Para elevar o valor percebido, cada funcionalidade do OAB 3F ganha nomes que evitam termos infantis.
            </p>
            <ul className="space-y-1.5 text-slate-700 font-sans">
              <li>• <strong className="text-slate-950">Início</strong> → Portal do Candidato</li>
              <li>• <strong className="text-slate-950">Meu Plano</strong> → Trilha de Aprovação</li>
              <li>• <strong className="text-slate-950">Questões</strong> → Treino Reverso Comentado</li>
              <li>• <strong className="text-slate-950">Desempenho</strong> → Radar de Proficiência</li>
              <li>• <strong className="text-slate-950">Biblioteca</strong> → Biblioteca de Doutrina e Peças</li>
            </ul>
          </div>

          <div className="space-y-2.5">
            <span className="font-display font-bold text-slate-950 text-sm block">Variação do Tom por Canal</span>
            <p className="text-slate-600">
              O tom varia conforme a intimidade e urgência necessária de cada canal operacional:
            </p>
            <ul className="space-y-1.5 text-slate-700">
              <li>• <strong className="text-slate-950">No App (Interface):</strong> Extremamente focado e focado na tarefa imediata.</li>
              <li>• <strong className="text-slate-950">Notificações Push:</strong> Curto, intrigante e voltado a garantir clique imediato.</li>
              <li>• <strong className="text-slate-950">Suporte & Chamados:</strong> Altamente polido, formal, prestativo e calmo.</li>
              <li>• <strong className="text-slate-950">Paywalls/Vendas:</strong> Focado no risco da reprovação tradicional vs. a segurança do método premium.</li>
            </ul>
          </div>

          <div className="space-y-2.5">
            <span className="font-display font-bold text-slate-950 text-sm block">Mural dos Aprovados (Inspiração)</span>
            <p className="text-slate-600">
              Nossa principal ferramenta de conversão orgânica reside nos depoimentos reais da comunidade:
            </p>
            <blockquote className="p-2.5 bg-slate-50 border-l-2 border-oab-accent text-[11px] text-slate-700 italic">
              "Fiz 38 pontos na prova anterior e me sentia estagnada. Com o motor de revisões baseadas nos meus erros de Ética do OAB 3F, saltei para 47 pontos e estou aprovada na 1ª fase."
              <span className="block font-sans font-bold text-slate-900 not-italic mt-1">— Mariana Mendes, São Paulo/SP</span>
            </blockquote>
          </div>
        </div>
      </div>
    </div>
  );
}
