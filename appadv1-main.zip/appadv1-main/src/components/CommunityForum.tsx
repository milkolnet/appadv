/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  MessageSquare, 
  Plus, 
  Search, 
  ThumbsUp, 
  Check, 
  CheckCircle, 
  ArrowLeft, 
  Send,
  AlertCircle,
  Clock,
  User,
  Tag
} from 'lucide-react';
import { ForumQuestion, ForumAnswer } from './CommunityData';

interface CommunityForumProps {
  questions: ForumQuestion[];
  setQuestions: React.Dispatch<React.SetStateAction<ForumQuestion[]>>;
  userPlan: string;
}

export default function CommunityForum({ questions, setQuestions, userPlan }: CommunityForumProps) {
  const [activeQuestionId, setActiveQuestionId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDiscipline, setSelectedDiscipline] = useState('Todas');
  const [showNewQuestionModal, setShowNewQuestionModal] = useState(false);
  
  // New Question Form
  const [newTitle, setNewTitle] = useState('');
  const [newText, setNewText] = useState('');
  const [newDiscipline, setNewDiscipline] = useState('Ética Profissional');
  const [newRef, setNewRef] = useState('Geral / Plataforma');

  // New Answer Form
  const [newAnswerText, setNewAnswerText] = useState('');

  const disciplinesList = [
    'Todas',
    'Ética Profissional',
    'Direito Constitucional',
    'Direito Penal',
    'Direito Civil',
    'Direito do Trabalho',
    'Processo Penal',
    'Processo Civil'
  ];

  const handleLikeQuestion = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setQuestions(prev => prev.map(q => {
      if (q.id === id) {
        const isLiked = q.isLikedByUser;
        return {
          ...q,
          likes: isLiked ? q.likes - 1 : q.likes + 1,
          isLikedByUser: !isLiked
        };
      }
      return q;
    }));
  };

  const handleLikeAnswer = (questionId: string, answerId: string) => {
    setQuestions(prev => prev.map(q => {
      if (q.id === questionId) {
        return {
          ...q,
          answers: q.answers.map(a => {
            if (a.id === answerId) {
              return { ...a, likes: a.likes + 1 };
            }
            return a;
          })
        };
      }
      return q;
    }));
  };

  const handleMarkResolved = (id: string) => {
    setQuestions(prev => prev.map(q => {
      if (q.id === id) {
        return { ...q, status: q.status === 'resolvida' ? 'respondida' : 'resolvida' };
      }
      return q;
    }));
  };

  const handleAddQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newText.trim()) return;

    const newQ: ForumQuestion = {
      id: `fq-${Date.now()}`,
      title: newTitle,
      text: newText,
      author: 'poprotaspires@gmail.com',
      discipline: newDiscipline,
      reference: newRef,
      timestamp: new Date().toLocaleString('pt-BR', { hour12: false }).slice(0, 16),
      status: 'aberta',
      likes: 0,
      answers: []
    };

    setQuestions(prev => [newQ, ...prev]);
    setNewTitle('');
    setNewText('');
    setShowNewQuestionModal(false);
  };

  const handleAddAnswer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnswerText.trim() || !activeQuestionId) return;

    const newA: ForumAnswer = {
      id: `fa-${Date.now()}`,
      author: 'poprotaspires@gmail.com',
      role: 'aluno',
      text: newAnswerText,
      timestamp: new Date().toLocaleString('pt-BR', { hour12: false }).slice(0, 16),
      likes: 0
    };

    setQuestions(prev => prev.map(q => {
      if (q.id === activeQuestionId) {
        return {
          ...q,
          status: q.status === 'aberta' ? 'respondida' : q.status,
          answers: [...q.answers, newA]
        };
      }
      return q;
    }));

    setNewAnswerText('');
  };

  // Filter logic
  const filteredQuestions = questions.filter(q => {
    const matchesSearch = q.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          q.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          q.author.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDiscipline = selectedDiscipline === 'Todas' || q.discipline === selectedDiscipline;
    return matchesSearch && matchesDiscipline;
  });

  const activeQuestion = questions.find(q => q.id === activeQuestionId);

  return (
    <div className="space-y-6" id="community-forum-workspace">
      {activeQuestion ? (
        /* SINGLE QUESTION VIEW (DETALHES) */
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm animate-fade-in">
          {/* Header */}
          <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
            <button 
              onClick={() => setActiveQuestionId(null)}
              className="flex items-center text-xs font-bold text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <ArrowLeft className="h-4 w-4 mr-1" /> Voltar ao Mural de Dúvidas
            </button>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                {activeQuestion.discipline}
              </span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                activeQuestion.status === 'resolvida' ? 'bg-emerald-500/20 text-emerald-400' :
                activeQuestion.status === 'respondida' ? 'bg-amber-500/20 text-amber-400' :
                'bg-rose-500/20 text-rose-400'
              }`}>
                {activeQuestion.status === 'resolvida' ? 'Resolvida' :
                 activeQuestion.status === 'respondida' ? 'Respondida' : 'Aberta'}
              </span>
            </div>
          </div>

          <div className="p-6 space-y-6">
            {/* Main Question Body */}
            <div className="space-y-3 pb-6 border-b border-slate-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-xs text-slate-400">
                  <div className="h-7 w-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold text-[10px]">
                    {activeQuestion.author[0].toUpperCase()}
                  </div>
                  <div>
                    <span className="font-semibold text-slate-700 block">{activeQuestion.author}</span>
                    <span className="text-[10px]">{activeQuestion.timestamp}</span>
                  </div>
                </div>
                <div className="text-[10.5px] text-amber-600 font-medium flex items-center gap-1 bg-amber-500/10 px-2.5 py-1 rounded-lg">
                  <Tag className="h-3 w-3" /> Contexto: <span className="font-bold">{activeQuestion.reference}</span>
                </div>
              </div>

              <h2 className="font-serif font-black text-lg text-slate-900 mt-2">{activeQuestion.title}</h2>
              <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line bg-slate-50 p-4 rounded-xl border border-slate-150">
                {activeQuestion.text}
              </p>

              <div className="flex items-center gap-4 pt-2">
                <button 
                  onClick={(e) => handleLikeQuestion(activeQuestion.id, e)}
                  className={`text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
                    activeQuestion.isLikedByUser ? 'bg-slate-900 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                  }`}
                >
                  <ThumbsUp className="h-3.5 w-3.5" />
                  <span>Útil ({activeQuestion.likes})</span>
                </button>

                {activeQuestion.author === 'poprotaspires@gmail.com' && (
                  <button 
                    onClick={() => handleMarkResolved(activeQuestion.id)}
                    className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <CheckCircle className="h-3.5 w-3.5" />
                    <span>{activeQuestion.status === 'resolvida' ? 'Reabrir Dúvida' : 'Marcar como Resolvida'}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Answer List */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                <MessageSquare className="h-4 w-4" /> Respostas ({activeQuestion.answers.length})
              </h3>

              {activeQuestion.answers.length === 0 ? (
                <div className="text-center p-8 bg-slate-50 rounded-xl border border-dashed border-slate-200 space-y-1">
                  <AlertCircle className="h-5 w-5 text-slate-400 mx-auto" />
                  <p className="text-xs text-slate-500 font-bold">Nenhuma resposta publicada ainda</p>
                  <p className="text-[10px] text-slate-400">Seja o primeiro a colaborar ou aguarde o retorno de um professor!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {activeQuestion.answers.map(ans => {
                    const isStaff = ans.role === 'professor' || ans.role === 'tutor';
                    return (
                      <div 
                        key={ans.id} 
                        className={`p-4 rounded-xl border leading-relaxed space-y-2 transition-all ${
                          isStaff 
                            ? 'bg-amber-500/5 border-amber-500/25 shadow-sm' 
                            : 'bg-white border-slate-150'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className={`h-6 w-6 rounded-full flex items-center justify-center font-bold text-[9px] ${
                              isStaff ? 'bg-slate-900 text-[#D4AF37]' : 'bg-slate-100 text-slate-600'
                            }`}>
                              {ans.author[0].toUpperCase()}
                            </div>
                            <div>
                              <span className="text-xs font-bold text-slate-800">{ans.author}</span>
                              {isStaff && (
                                <span className="ml-1.5 bg-[#D4AF37] text-slate-900 text-[8px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded">
                                  {ans.role}
                                </span>
                              )}
                            </div>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono">{ans.timestamp}</span>
                        </div>
                        <p className="text-xs text-slate-600 whitespace-pre-line">{ans.text}</p>
                        <div className="flex justify-between items-center pt-1 border-t border-slate-50 mt-1">
                          <button 
                            onClick={() => handleLikeAnswer(activeQuestion.id, ans.id)}
                            className="text-[10px] font-bold text-slate-400 hover:text-slate-600 flex items-center gap-1 cursor-pointer"
                          >
                            <ThumbsUp className="h-3 w-3" /> Curtir ({ans.likes})
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Answer Input Area */}
            <form onSubmit={handleAddAnswer} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <label className="block text-xs font-bold text-slate-700">Adicionar seu Comentário / Resposta</label>
              <textarea
                placeholder="Compartilhe seus conhecimentos, sugira fundamentação legal ou tire uma dúvida sobre esta resposta..."
                value={newAnswerText}
                onChange={(e) => setNewAnswerText(e.target.value)}
                className="w-full text-xs bg-white border border-slate-200 rounded-lg p-2.5 h-20 focus:outline-none focus:ring-1 focus:ring-slate-400"
                required
              />
              <button 
                type="submit"
                className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2 px-4 rounded-lg flex items-center gap-1.5 ml-auto cursor-pointer transition-colors"
              >
                <Send className="h-3.5 w-3.5" /> Enviar Resposta
              </button>
            </form>
          </div>
        </div>
      ) : (
        /* GRID DE QUESTÕES/DÚVIDAS */
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-4 border border-slate-200 rounded-xl shadow-sm">
            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto flex-1">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Buscar dúvidas por tema ou palavra-chave..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full text-xs pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-400"
                />
              </div>

              <select
                value={selectedDiscipline}
                onChange={(e) => setSelectedDiscipline(e.target.value)}
                className="text-xs border border-slate-200 rounded-lg p-2 bg-slate-50 focus:outline-none"
              >
                {disciplinesList.map(disc => (
                  <option key={disc} value={disc}>{disc}</option>
                ))}
              </select>
            </div>

            <button 
              onClick={() => setShowNewQuestionModal(true)}
              className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2 px-4 rounded-lg flex items-center gap-1.5 cursor-pointer w-full sm:w-auto justify-center transition-colors"
            >
              <Plus className="h-4 w-4" /> Perguntar à Comunidade
            </button>
          </div>

          {/* List of Questions */}
          {filteredQuestions.length === 0 ? (
            <div className="bg-white border border-slate-150 rounded-xl p-12 text-center space-y-2">
              <MessageSquare className="h-10 w-10 text-slate-300 mx-auto" />
              <h3 className="font-serif font-bold text-slate-700">Nenhuma dúvida encontrada</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Experimente mudar as palavras-chave ou o filtro de disciplinas para encontrar o que procura.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3">
              {filteredQuestions.map(q => (
                <div 
                  key={q.id}
                  onClick={() => setActiveQuestionId(q.id)}
                  className="bg-white hover:bg-slate-50 border border-slate-150 hover:border-slate-300 rounded-xl p-5 shadow-sm transition-all cursor-pointer flex flex-col justify-between gap-4"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-[9.5px] font-mono font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-200/65">
                          {q.discipline}
                        </span>
                        <span className="text-[10px] text-slate-400">• {q.author}</span>
                      </div>
                      <span className={`text-[9.5px] font-bold px-2 py-0.5 rounded-full ${
                        q.status === 'resolvida' ? 'bg-emerald-50 text-emerald-700' :
                        q.status === 'respondida' ? 'bg-amber-50 text-amber-700' :
                        'bg-rose-50 text-rose-700'
                      }`}>
                        {q.status === 'resolvida' ? 'Resolvida' :
                         q.status === 'respondida' ? 'Respondida' : 'Aberta'}
                      </span>
                    </div>

                    <h4 className="font-serif font-bold text-sm text-slate-900 group-hover:text-slate-800 tracking-tight leading-tight">
                      {q.title}
                    </h4>
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed font-medium">
                      {q.text}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-slate-50 text-[11px] text-slate-400">
                    <span className="font-mono text-[9.5px] text-amber-600 bg-amber-500/10 px-2 py-0.5 rounded">
                      Ref: {q.reference}
                    </span>
                    <div className="flex items-center gap-4">
                      <button 
                        onClick={(e) => handleLikeQuestion(q.id, e)}
                        className="flex items-center gap-1 hover:text-slate-600 transition-colors"
                      >
                        <ThumbsUp className="h-3.5 w-3.5 text-slate-400" /> Útil ({q.likes})
                      </button>
                      <span className="flex items-center gap-1 text-slate-600 font-bold">
                        <MessageSquare className="h-3.5 w-3.5 text-slate-400" /> {q.answers.length} {q.answers.length === 1 ? 'resposta' : 'respostas'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* NEW QUESTION MODAL */}
      {showNewQuestionModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-scale-in">
            <div className="bg-slate-900 text-white p-4 flex justify-between items-center">
              <span className="font-serif font-bold text-sm tracking-tight flex items-center gap-1.5">
                <MessageSquare className="h-4.5 w-4.5 text-[#D4AF37]" /> Enviar Nova Dúvida Acadêmica
              </span>
              <button 
                onClick={() => setShowNewQuestionModal(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleAddQuestion} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Disciplina</label>
                  <select
                    value={newDiscipline}
                    onChange={(e) => setNewDiscipline(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
                  >
                    {disciplinesList.filter(d => d !== 'Todas').map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Conteúdo de Referência (Aula/PDF)</label>
                  <select
                    value={newRef}
                    onChange={(e) => setNewRef(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
                  >
                    <option value="Geral / Plataforma">Geral / Plataforma</option>
                    <option value="Aula: Prerrogativas do Advogado">Aula: Prerrogativas do Advogado</option>
                    <option value="Aula: Teoria do Crime">Aula: Teoria do Crime</option>
                    <option value="Simulado Geral #1">Simulado Geral #1</option>
                    <option value="Peça Prática - Peças Iniciais">Peça Prática - Peças Iniciais</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Título da sua Dúvida</label>
                <input
                  type="text"
                  placeholder="Ex: Como diferenciar Erro de Tipo e de Proibição em caso concreto?"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-slate-400"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Descreva detalhadamente seu questionamento</label>
                <textarea
                  placeholder="Escreva sua dúvida jurídica de forma clara, citando se possível o artigo ou simulado..."
                  value={newText}
                  onChange={(e) => setNewText(e.target.value)}
                  className="w-full text-xs border border-slate-200 rounded-lg p-2.5 h-32 focus:outline-none focus:ring-1 focus:ring-slate-400"
                  required
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowNewQuestionModal(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex-1 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex-1 cursor-pointer transition-colors"
                >
                  Publicar Pergunta
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
