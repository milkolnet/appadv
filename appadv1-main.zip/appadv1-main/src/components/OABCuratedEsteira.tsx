import React, { useState } from 'react';
import {
  Sparkles,
  Zap,
  BookOpen,
  DollarSign,
  Settings,
  Calendar,
  AlertTriangle,
  ListTodo,
  CheckCircle2,
  Copy,
  Search,
  ChevronRight,
  Code,
  Users,
  ShieldAlert,
  ArrowRight,
  Lightbulb,
  Check
} from 'lucide-react';

interface CuratedPromptItem {
  id: string;
  code: string;
  name: string;
  objective: string;
  whatBuilds: string;
  whySimplified: string;
  promptText: string;
  expectedResult: string;
  dependencies: string;
  classification: 'Obrigatório no MVP' | 'Importante no MVP Robusto' | 'Pós-MVP Estratégico';
}

export default function OABCuratedEsteira() {
  const [activeTab, setActiveTab] = useState<'diagnostico' | 'arquitetura' | 'aluno' | 'monetizacao' | 'admin' | 'pos_mvp' | 'plano_operacional'>('diagnostico');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterClassification, setFilterClassification] = useState<string>('all');

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // --- COMPONENTES DA CAMADA 3 (ALUNO) ---
  const studentPrompts: CuratedPromptItem[] = [
    {
      id: 'u01',
      code: 'Prompt U01',
      name: 'Estrutura base do app + navegação do aluno',
      objective: 'Criar a casca principal de navegação responsiva do aplicativo.',
      whatBuilds: 'Menu lateral adaptável (desktop) e barra inferior (mobile) integrada, com cabeçalho de progresso, indicador de Streak (fogo) e área central dinâmica.',
      whySimplified: 'Elimina rotas complexas por URL; gerencia tudo com um estado React useState que chaveia componentes simples. Garante que o App Builder não se perca em sincronização de rotas complexas.',
      promptText: `Crie a estrutura de navegação master do app "OAB 3F". O design deve usar Tailwind CSS com cores elegantes (fundo slate-50).
Implemente uma barra lateral esquerda no desktop que se transforma em barra de navegação inferior em dispositivos móveis.
Os itens de menu devem ser:
- Dashboard (Ícone: LayoutDashboard)
- Meu Plano (Ícone: ListTodo)
- Estudo/Biblioteca (Ícone: BookOpen)
- Questões (Ícone: ClipboardList)
- Simulados (Ícone: Award)
- Revisão (Ícone: RefreshCw)
- Calendário OAB (Ícone: Calendar)
- Desempenho (Ícone: TrendingUp)
- Premium (Ícone: Sparkles, destacado em âmbar/dourado)

No cabeçalho, exiba a logo "OAB 3F" ao lado de um indicador de "Streak de Estudos" (um ícone de fogo com contador numérico de dias). Utilize um estado local (useState) simples para gerenciar a aba ativa e renderizar o componente correspondente no painel central de forma reativa.`,
      expectedResult: 'Navegação responsiva com troca fluida de abas locais sem recarregar a página.',
      dependencies: 'Instalação de lucide-react.',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u02',
      code: 'Prompt U02',
      name: 'Splash Screen + Boas-Vindas + Login',
      objective: 'Experiência de entrada limpa, persuasiva e login direto.',
      whatBuilds: 'Tela de introdução estilizada de alta conversão que, com um clique, exibe o formulário de login direto com e-mail e senha.',
      whySimplified: 'Unifica o que seriam três arquivos separados em uma única tela inteligente de login com estados de alternância, reduzindo complexidade e risco de erro no App Builder.',
      promptText: `Crie um fluxo unificado de Entrada para o OAB 3F.
A tela inicial deve ter um fundo escuro elegante (slate-950) com um gradiente suave.
1. Visão Splash/Boas-Vindas:
   - Logotipo brilhante "OAB 3F" com o lema "Método Científico em 3 Fases".
   - Subtítulo de impacto: "Estude por dados e garanta seus 40 pontos na OAB sem perder tempo."
   - Botão "Iniciar Preparação Inteligente" que altera o estado local para exibir o formulário de login.
2. Visão Formulário de Login (dentro do mesmo arquivo):
   - Título: "Acesse seu Painel"
   - Inputs estilizados com labels limpas: E-mail (com validação básica) e Senha (com botão de ver/ocultar).
   - Checkbox de "Lembrar de mim" e link de "Esqueci minha senha" (que simula envio de e-mail ao clicar).
   - Botão "Entrar no App" com efeito hover e redirecionamento para o dashboard principal.
   - Link de rodapé para "Não possui conta? Cadastre-se grátis".`,
      expectedResult: 'Uma tela de login interativa com transição simples entre apresentação do produto e formulário de entrada.',
      dependencies: 'Navegação básica (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u03',
      code: 'Prompt U03',
      name: 'Cadastro + recuperação de senha integrado',
      objective: 'Capturar novos alunos com o mínimo de barreiras de entrada.',
      whatBuilds: 'Formulário limpo de cadastro de novas contas com validação de força de senha e modal de recuperação rápida em caso de perda de credenciais.',
      whySimplified: 'Unifica as duas lógicas auxiliares de autenticação em um único arquivo de cadastro, utilizando modais integrados para recuperação de senha.',
      promptText: `Crie uma tela de Cadastro de Conta para o OAB 3F.
O formulário de cadastro deve conter:
- Nome Completo, E-mail principal, Senha Forte (exibir um indicador visual de força da senha em tempo real) e Confirmação de senha.
- Caixa de seleção aceitando os Termos de Uso.
- Botão "Criar Minha Conta Gratuita" em cor esmeralda ou azul, ocupando largura total.
- Link de rodapé: "Já tem conta? Entrar".
Integre no mesmo componente um Modal de "Recuperação de Senha" acionável por clique. O modal pede o e-mail do usuário e, ao clicar em "Enviar link", exibe uma notificação de sucesso com fundo verde ("Instruções enviadas! Verifique sua caixa de entrada.") de forma puramente interativa via state do React.`,
      expectedResult: 'Formulário de cadastro validado no cliente com modal acoplado de alteração de senha.',
      dependencies: 'Login (Prompt U02).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u04',
      code: 'Prompt U04',
      name: 'Minha conta / Perfil básico do aluno',
      objective: 'Oferecer controle básico de dados pessoais e visualização financeira.',
      whatBuilds: 'Painel simples de visualização e edição de dados, status de assinatura atual (Plano) e opção segura de logout.',
      whySimplified: 'Remove integrações complexas de envio de fotos e faturamento dinâmico externo. Usa campos de texto diretos salvos no localStorage.',
      promptText: `Crie a tela de "Configurações de Perfil" para o aluno do OAB 3F.
A tela deve ser dividida em 3 seções organizadas em um card único com fundo branco:
1. Dados do Aluno: Inputs editáveis para Nome, E-mail e WhatsApp de estudo.
2. Status da Assinatura: Caixa de destaque visual exibindo "Seu Plano Atual: Gratuito (Limite de 5 questões/dia)" com botão destacado "Fazer Upgrade para o Premium" em dourado/amber.
3. Segurança: Campos de senha atual e nova senha.
No rodapé, inclua os botões de ação "Salvar Alterações" (que exibe banner flutuante de sucesso) e o botão "Sair da Conta" (que limpa o estado de login e retorna à Splash). Armazene esses dados locais no localStorage do navegador para simular a persistência no MVP de forma rápida.`,
      expectedResult: 'Perfil estático funcional com persistência imediata no navegador (localStorage) para dados cadastrais básicos.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u05',
      code: 'Prompt U05',
      name: 'Onboarding essencial do OAB 3F',
      objective: 'Coletar os inputs cruciais de rotina para calibrar a experiência adaptativa.',
      whatBuilds: 'Questionário interativo e elegante em 4 passos com barra de progresso, perguntas de múltipla escolha e transição ágil.',
      whySimplified: 'Reduz o onboarding original (que tinha 7 telas cansativas) para apenas 4 perguntas de altíssima conversão que realmente impactam o plano diário de estudos.',
      promptText: `Crie o fluxo de "Onboarding do Estudante" para o OAB 3F.
Apresente uma interface limpa com barra de progresso reativa no topo (Passos 1 de 4).
Implemente as 4 seguintes perguntas em blocos sequenciais gerenciados localmente:
- Passo 1: "Qual o seu foco principal no Exame de Ordem?"
  - Opções com ícones: "1ª Fase OAB (Foco Geral)" ou "Interesse Futuro na 2ª Fase".
- Passo 2: "Quantas horas você tem livres por dia para estudar?"
  - Opções: "Até 1 hora (Foco Reta Final)", "2 horas (Método Padrão)" ou "Mais de 3 horas (Aceleração)".
- Passo 3: "Selecione as suas 2 maiores disciplinas de dificuldade:"
  - Lista de múltipla escolha (Ética, Constitucional, Administrativo, Civil, Penal, Tributário) com limite máximo de 2 marcações e feedback visual ativo nas selecionadas.
- Passo 4: "Qual o seu nível de preparação atual?"
  - Opções: "Iniciante (Do zero)", "Intermediário (Já fiz provas)" ou "Avançado (Mais de 35 pontos)".
Adicione botões "Voltar" e "Gerar Meu Plano Inteligente" (no passo final) que salva as respostas do usuário no localStorage.`,
      expectedResult: 'Questionário esteticamente agradável e fluido que avança passo a passo coletando inputs no estado local.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u06',
      code: 'Prompt U06',
      name: 'Regra simples de geração do plano inicial',
      objective: 'Sinalizar o cronograma personalizado de estudos com base nas respostas.',
      whatBuilds: 'Tela de processamento animada (loader de cálculo) que carrega um resumo das matérias e metas do cronograma customizado.',
      whySimplified: 'Substitui algoritmos complexos de IA no servidor por um mapeamento simples no cliente baseado nas respostas do onboarding, poupando tokens e tempo de desenvolvimento.',
      promptText: `Crie a tela de carregamento e resultado do plano de estudos para o OAB 3F.
1. Estado de Processamento: Ao entrar, exiba uma tela com um spinner animado e mensagens rápidas em sequência (ex: "Mapeando incidência FGV...", "Organizando disciplinas de Ética...", "Otimizando revisões de erros...").
2. Estado de Resultado (após 2 segundos de simulação):
   - Mensagem de sucesso: "Plano Científico Criado para Lucas!"
   - Card de Resumo do Perfil Calculado (ex: "Perfil: Foco Inteligente. Tempo sugerido: 2h/dia. Meta do Exame: 45+ pontos.").
   - Uma lista resumida das matérias foco com base nas dificuldades apontadas no onboarding (ex: se selecionou Ética e Constitucional, exibe-as como matérias prioritárias no cronograma).
   - Botão "Acessar Meu Cronograma Ativo" para abrir o dashboard do aluno.`,
      expectedResult: 'Animação de carregamento fictícia seguida da exibição de um card personalizado e botão para ir ao app.',
      dependencies: 'Onboarding (Prompt U05).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u07',
      code: 'Prompt U07',
      name: 'Dashboard principal + mensagens motivacionais',
      objective: 'Apresentar a central diária de conquistas do estudante de forma resumida.',
      whatBuilds: 'Painel inicial do aluno com estatísticas rápidas (streak, progresso total, questões resolvidas), seção de avisos rápidos e as tarefas diárias em foco.',
      whySimplified: 'Elimina múltiplos cards flutuantes que causavam desordem visual; concentra as informações chave do dia em apenas 3 blocos limpos.',
      promptText: `Crie a página "Dashboard Principal" para a área do aluno do OAB 3F.
A tela deve ser estruturada com as seguintes seções de forma visualmente limpa:
1. Cabeçalho de Boas-vindas: "Olá, Lucas! Faltam 45 dias para a prova da 1ª Fase."
2. Seção de Estatísticas Rápidas (3 cards horizontais ou grid de 3 colunas):
   - Card 1: Streak de Estudos (Ícone de Fogo, número de dias ativos).
   - Card 2: Questões Resolvidas (Ícone de Check, contagem e percentual de acerto).
   - Card 3: Progresso do Cronograma (Barra de progresso de conclusão do plano atual).
3. Bloco "Foco de Hoje" (Metas diárias de alta prioridade):
   - Box destacado exibindo a tarefa ativa do dia ("Ética Profissional: Teoria de Honorários Advocatícios + 10 questões comentadas").
   - Botão grande de "Iniciar Estudos de Hoje" que abre a respectiva matéria ou banco de questões.
4. Card Informativo de Dica Científica (Curadoria rápida sobre memorização de lei seca).`,
      expectedResult: 'Uma tela inicial impecável e focado, mostrando exatamente o que fazer no dia sem distrações.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u08',
      code: 'Prompt U08',
      name: 'Tela Meu Plano + lista de tarefas diárias',
      objective: 'Exibir a organização das tarefas da semana com controle de finalização.',
      whatBuilds: 'Cronograma semanal onde o estudante clica e conclui as tarefas do dia, atualizando o progresso no mesmo instante.',
      whySimplified: 'Substitui o calendário mensal completo por uma visualização de "Semana Ativa" de 7 dias, muito mais prática para desenvolvimento ágil.',
      promptText: `Crie a tela de "Meu Plano" de estudos do OAB 3F.
Implemente uma visão de "Semana Corrente" com abas rápidas para cada dia (Seg, Ter, Qua, Qui, Sex, Sáb, Dom).
Ao clicar em um dia da semana, exiba a lista de tarefas associadas àquele dia (ex: Segunda-feira: 1. Vídeo-aula Ética; 2. Resolver 10 questões Ética; 3. Revisar Direito Administrativo).
Cada tarefa deve conter:
- Um checkbox para marcar como concluída.
- Uma tag de categoria ("Teoria", "Prática" ou "Revisão").
- Indicação de tempo estimado (ex: "30 min").
Ao marcar uma tarefa como concluída, o progresso acumulado da semana deve atualizar dinamicamente no topo da página por meio de estado React local.`,
      expectedResult: 'Lista de tarefas diárias filtradas por dia da semana com checkboxes reativos que atualizam barra de progresso geral.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u09',
      code: 'Prompt U09',
      name: 'Replanejamento simplificado de rotina',
      objective: 'Ajustar pendências de estudo com facilidade, sem desestabilizar o plano.',
      whatBuilds: 'Botão de clique único que reorganiza tarefas atrasadas da semana para os próximos dias de forma uniforme.',
      whySimplified: 'Evita painéis avançados de inteligência artificial de remanejamento; substitui por um fluxo simples de "Recalcular Rotina" que remove o atraso visual do aluno.',
      promptText: `Crie um mecanismo de "Replanejamento Rápido" na tela do Meu Plano de estudos.
Insira um card de aviso se o usuário tiver tarefas pendentes/atrasadas na semana:
- Card: "Você possui 3 tarefas pendentes da semana passada. Não desanime! Deixe que nossa ferramenta organize isso para você."
- Botão destacado: "Reorganizar Minha Semana Ativa" (Ícone: RefreshCw).
Ao clicar no botão, mostre uma animação rápida de reordenação ("Ajustando matérias...") e distribua visualmente essas tarefas atrasadas no cronograma dos próximos 3 dias, limpando o status de atraso do usuário e exibindo aviso de sucesso verde.`,
      expectedResult: 'Um botão que simula o recálculo e remanejamento instantâneo de tarefas locais atrasadas com um clique.',
      dependencies: 'Lista de tarefas (Prompt U08).',
      classification: 'Importante no MVP Robusto'
    },
    {
      id: 'u10',
      code: 'Prompt U10',
      name: 'Biblioteca principal + Filtros + Página de Aulas',
      objective: 'Fornecer o acesso organizado aos resumos e materiais teóricos do curso.',
      whatBuilds: 'Grade de disciplinas prioritárias, listagem de capítulos teóricos, visualizador de PDFs/resumos e mini-player de vídeo-aula.',
      whySimplified: 'Unifica o repositório de conteúdos em uma tela de duas colunas (Esquerda: disciplinas e módulos; Direita: aula e materiais de leitura), reduzindo cliques e simplificando a árvore de arquivos.',
      promptText: `Crie a página de "Biblioteca / Materiais" para o OAB 3F.
A tela deve ser estruturada em duas colunas responsivas:
1. Coluna da Esquerda (Navegação):
   - Filtros de pesquisa por disciplina.
   - Lista das disciplinas chave (Estatuto da OAB, Direito Constitucional, Administrativo, Tributário).
   - Ao selecionar a disciplina, exibe a lista de módulos (ex: Módulo 1: Direitos do Advogado, Módulo 2: Órgãos da OAB).
2. Coluna da Direita (Visualização de Conteúdo):
   - Ao clicar em uma aula do módulo, renderize o conteúdo correspondente:
     - Um mini-player de vídeo (use um container cinza estilizado simulando reprodutor com botão de play e barra de progresso).
     - Link para download de "Resumo Focado em PDF (Método 3F)".
     - Lista de 3 principais artigos da lei seca associados àquela aula para leitura direta.`,
      expectedResult: 'Ambiente modular de estudo teórico que reúne vídeo-aulas, lei seca e PDFs no mesmo painel sem troca de tela.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u11',
      code: 'Prompt U11',
      name: 'Questões: filtros + resolução + feedback instantâneo',
      objective: 'O motor de estudo prático por meio de resolução de questões oficiais comentadas.',
      whatBuilds: 'Filtro por disciplina/assunto, tela de resolução de questões com opções de alternativas, correção instantânea colorida com comentários pedagógicos do professor.',
      whySimplified: 'Mantém apenas o essencial: filtros básicos, enunciado, alternativas, gabarito e comentário escrito. Exclui cronômetros de tempo por questão e rankings nesta etapa.',
      promptText: `Crie a tela de "Banco de Questões" para o OAB 3F.
A interface deve conter:
1. Filtro Superior: Seleção de Disciplina (Dropdown) e Nível de Dificuldade.
2. Container da Questão Ativa:
   - Identificação da questão (ex: "FGV - XXXV Exame de Ordem - Ética Profissional").
   - Enunciado da questão com tipografia legível.
   - 4 Alternativas de múltipla escolha (A, B, C, D) interativas.
3. Mecanismo de Resolução:
   - Botão "Responder Questão" (desabilitado até selecionar uma alternativa).
   - Ao clicar, exiba feedback visual imediato: Alternativa certa em verde, alternativa errada selecionada em vermelho, e revele o box "Comentário Estratégico do Professor" detalhando a fundamentação do artigo violado ou aplicável.
   - Botões auxiliares de rodapé: "Marcar para Revisão" (ícone de bandeira) e "Próxima Questão".`,
      expectedResult: 'Área interativa de exercícios com resposta em tempo real, cores de validação e exibição do gabarito fundamentado.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u12',
      code: 'Prompt U12',
      name: 'Simulados: iniciar + cronômetro ativo + gabarito final',
      objective: 'Preparar o aluno para o ritmo real da prova com exaustão controlada.',
      whatBuilds: 'Tela de introdução com regras, cronômetro regressivo na tela de resolução ativa e tela de resultado geral com taxa de acertos e matérias fracas.',
      whySimplified: 'Roda a lógica do cronômetro inteiramente no cliente via JavaScript (sem requisições constantes de servidor) e calcula os acertos na entrega das respostas acumuladas.',
      promptText: `Crie o módulo de "Simulados OAB" para o aplicativo OAB 3F.
A tela deve alternar entre 3 visões por estado local:
1. Apresentação do Simulado:
   - Card com título: "Simulado Geral FGV Oficial" (80 questões - limite de 5 horas).
   - Lista de instruções (sem consulta, sem pausas).
   - Botão grande: "Iniciar Simulado Agora".
2. Resolução Ativa:
   - Topo fixo com barra vermelha/escura exibindo cronômetro regressivo ativo ("Tempo Restante: 04:59:59") e botão de pânico "Entregar Prova".
   - Exibição de 1 questão por vez com botões para avançar/voltar.
   - Menu lateral retrátil com grade de botões (1 a 80) que ficam cinza se respondidos, permitindo ir direto para qualquer questão.
3. Resultado Final (exibido ao clicar em entregar):
   - Pontuação total (ex: "Nota: 42 de 80 acertos - Zona de Aprovação Segura!").
   - Diagnóstico por disciplina (gráfico de progresso simples indicando quais matérias o estudante foi pior).
   - Botão para "Ver Gabarito de Erros".`,
      expectedResult: 'Módulo de prova cronometrado com grade de navegação e relatório final automático de acertos/erros.',
      dependencies: 'Motor de questões (Prompt U11).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u13',
      code: 'Prompt U13',
      name: 'Revisão: Flashcards e controle de repetição espaçada',
      objective: 'Mecanismo de memorização rápida das matérias com maior índice de erros.',
      whatBuilds: 'Relação de revisões ativas e tela interativa de flashcards com animação 3D de virada e botões de classificação de retenção.',
      whySimplified: 'Simplifica algoritmos complexos de curva de esquecimento (como SuperMemo2); usa classificação local simples (Fácil, Médio, Difícil) para reagendar a exibição no estado React local.',
      promptText: `Crie a interface de "Revisão por Flashcards" para o OAB 3F.
O componente simula cartões físicos de estudo para memorização ativa:
- Exiba no topo o contador: "Revisões de Hoje: 8 cartões pendentes".
- Card de Flashcard Centralizado:
  - Lado A (Frente): Exibe pergunta de lei seca (ex: "Qual o prazo prescricional para a ação de cobrança de honorários advocatícios?").
  - Botão central "Virar Cartão" com animação de flip suave.
  - Lado B (Verso - revelado após clique): Exibe a resposta direta e artigo da lei ("Prazo de 5 anos - Art. 25 do Estatuto da OAB").
  - Botões de feedback de retenção de cor no rodapé:
    1. "Errei / Repetir Hoje" (Botão vermelho).
    2. "Lembrei com Esforço" (Botão amarelo - agenda para 3 dias).
    3. "Memorizado / Fácil" (Botão verde - agenda para 7 dias).
Ao clicar, carrega o próximo cartão da pilha do localStorage de forma instantânea.`,
      expectedResult: 'Componente dinâmico de flashcards com animação de giro e fluxo de auto-avaliação do estudante.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u14',
      code: 'Prompt U14',
      name: 'Desempenho: evolução + semáforo de matérias',
      objective: 'Visualização científica de pontos fortes e fracos do candidato.',
      whatBuilds: 'Gráficos simples de histórico de acertos e tabela com indicador de status tipo semáforo por disciplina (Vermelho, Amarelo, Verde) apontando onde focar.',
      whySimplified: 'Evita painéis analíticos complexos; utiliza barras horizontais coloridas de progresso nativas do Tailwind, que são leves e fáceis de programar no App Builder.',
      promptText: `Crie a tela de "Desempenho e Estatísticas" para o OAB 3F.
A tela deve organizar os dados estatísticos de forma muito clara e legível:
1. Resumo de Métricas (Grid de 4 colunas): Total de questões, taxa média de acerto (%), simulados feitos e horas estudadas.
2. Mapeamento por Disciplinas (O Semáforo OAB):
   - Liste as matérias chaves da prova.
   - Ao lado de cada matéria, coloque uma barra de progresso horizontal e um indicador visual de cor:
     - Verde (Acertos > 65%): "Zona Segura".
     - Amarelo (Acertos entre 50% e 65%): "Atenção necessária".
     - Vermelho (Acertos < 50%): "Alerta Crítico: Estude este tema!".
3. Bloco "Direcionamento da IA":
   - Texto de diagnóstico gerado dinamicamente no client: "Com base nas suas respostas, você precisa focar em Direito Administrativo nas próximas 48 horas para blindar sua pontuação."`,
      expectedResult: 'Relatório estatístico visual de performance com indicações diretas de prioridade com base em cores.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u15',
      code: 'Prompt U15',
      name: 'Calendário OAB + Alertas de datas FGV',
      objective: 'Exibir a linha do tempo do exame com notificações de datas de provas.',
      whatBuilds: 'Timeline estática de eventos oficiais (editais, inscrições, provas de 1ª e 2ª Fase) com relógio de contagem regressiva.',
      whySimplified: 'Substitui integrações pesadas de calendário externo por uma timeline estática de alta qualidade estilizada com Tailwind, garantindo carregamento instantâneo.',
      promptText: `Crie o componente de "Calendário OAB e Datas Críticas" do OAB 3F.
A tela exibe a contagem regressiva oficial para o próximo Exame de Ordem e a timeline de eventos:
1. Box Superior de Contagem Regressiva: Um contador visual grande com dias, horas e minutos restantes para o dia da prova objetiva (Ex: "Faltam: 45 dias, 12 horas, 08 minutos para a 1ª Fase OAB").
2. Linha do Tempo dos Eventos FGV (Timeline vertical):
   - Evento 1: "Publicação do Edital" (Data concluída - ícone verde de check).
   - Evento 2: "Período de Inscrições" (Data ativa - caixa destacada azul com botão de link para o site oficial da FGV).
   - Evento 3: "Prova da 1ª Fase" (Data futura com alerta em amarelo).
   - Evento 4: "Prova da 2ª Fase" (Data futura com alerta cinza).
Cada item da timeline deve conter descrição sucinta das regras ou taxas daquele dia.`,
      expectedResult: 'Visualizador cronológico das datas oficiais da prova OAB com contagem regressiva funcional e links de inscrição.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'u16',
      code: 'Prompt U16',
      name: 'Reta final simples + Checklist de pânico',
      objective: 'Garantir foco absoluto nas últimas duas semanas pré-prova.',
      whatBuilds: 'Painel com os 10 tópicos mais cobrados historicamente na OAB e um checklist de preparação mental e estrutural para o dia D.',
      whySimplified: 'Trabalha com checklist estático rico e estruturado diretamente no código, focado em alta conversão e utilidade sem processamento dinâmico.',
      promptText: `Crie a página de "Reta Final OAB" dentro do OAB 3F.
Essa seção especial é ativada para estudos intensivos e deve conter:
1. Box "Os 10 Mandamentos da Aprovação" (Checklist interativo de tarefas urgentes, ex: "Revisar as 5 principais peças de Ética", "Completar simulado de véspera", "Ler lei de abuso de autoridade"). O aluno marca as tarefas pendentes para o dia da prova.
2. Cards Informativos "Direto ao Ponto":
   - "Dicas de Véspera": Recomendações práticas (alimentação, o que levar de caneta, horários de portão da FGV).
   - "Os Temas Mais Quentes": Relação estática com os 5 artigos de lei seca mais cobrados de cada uma das 4 disciplinas principais.`,
      expectedResult: 'Central de reta final com checklist prático e roteiro de dicas de sobrevivência para o dia do exame.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Importante no MVP Robusto'
    },
    {
      id: 'u17',
      code: 'Prompt U17',
      name: 'Tela de transição e aquecimento para 2ª fase OAB',
      objective: 'Captar lead qualificado e engajar o aluno aprovado na 1ª fase.',
      whatBuilds: 'Página de apresentação do curso de 2ª Fase da OAB correspondente, vídeo de apresentação do método prático e um formulário para entrar na lista de espera ou comprar com desconto.',
      whySimplified: 'Não constrói o motor de correção de peças complexas de 2ª fase no MVP; substitui por um fluxo comercial informativo e de cadastro de interesse altamente otimizado.',
      promptText: `Crie a tela de "Preparação e Transição para a 2ª Fase OAB" do OAB 3F.
A tela é voltada para a captação de alunos que passaram ou buscam a segunda etapa e deve possuir:
1. Cabeçalho Promocional: "Aprovado na 1ª Fase? Garanta sua aprovação definitiva na 2ª Fase com a nossa mentoria estratégica de peças jurídicas."
2. Seleção de Área (Dropdown/Cards de especialidade): Direito Penal, Civil, Constitucional, Administrativo, Tributário ou Trabalho.
3. Seção Informativa do Método OAB 3F para 2ª Fase:
   - 3 pilares rápidos: "Esqueleto de Peças", "Simulado com Feedback", "Treino de Discursivas".
   - Vídeo simulado ou gif explicativo do curso.
4. Formulário de Pré-Inscrição/Interesse:
   - Input: WhatsApp e Nome.
   - Botão "Quero Entrar na Lista de Espera VIP e Garantir 35% de Desconto" (cor esmeralda/verde de alta conversão). Ao clicar, exibe mensagem confirmando o cadastro do lead.`,
      expectedResult: 'Página de vendas interna estruturada para a 2ª fase OAB com formulário interativo de coleta de leads.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    }
  ];

  // --- COMPONENTES DA CAMADA 4 (MONETIZACAO) ---
  const monetizationPrompts: CuratedPromptItem[] = [
    {
      id: 'm01',
      code: 'Prompt M01',
      name: 'Grade de planos + Comparativo Gratuito vs Premium',
      objective: 'Apresentar as opções comerciais do aplicativo de forma limpa.',
      whatBuilds: 'Tabela comparativa elegante com toggle de faturamento (mensal/anual), cards de planos com preço em destaque e benefícios com selo de garantia.',
      whySimplified: 'Foca em apenas dois planos reais (Gratuito e Premium Único) em vez de múltiplos planos híbridos que geravam confusão e sobrecarga de código.',
      promptText: `Crie a tela de "Planos e Assinaturas" para o OAB 3F.
A interface deve conter:
1. Cabeçalho de Vendas: "Acelere sua aprovação. Destrave acesso ilimitado a todo o banco de questões comentadas e simulados."
2. Seletor de Faturamento: Switch horizontal (Mensal R$ 39,90 vs Anual R$ 29,90/mês - destaque "Economize 25%").
3. Grade de 2 Planos Comparativos (lado a lado):
   - Card 1 (Plano Gratuito): R$ 0. Detalhes: Limite de 5 questões/dia, cronograma estático simples, sem simulados gerais oficiais. Botão "Continuar Limitado".
   - Card 2 (Plano Premium OAB 3F - Destacado com borda amber brilhante e tag "Recomendado"): Benefícios: Questões ilimitadas, todos os simulados gerais FGV, revisões por flashcards, suporte direto do professor. Botão "Quero Ser Premium Agora".
4. Selos de rodapé: "Garantia de 7 dias" e "Pagamento Seguro".`,
      expectedResult: 'Página comercial de alta conversão comparando planos gratuito e premium com gatilhos de faturamento.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'm02',
      code: 'Prompt M02',
      name: 'Paywall contextual inteligente',
      objective: 'Gerar o bloqueio persuasivo no exato momento de consumo de recursos premium.',
      whatBuilds: 'Modal flutuante de bloqueio de conteúdo esteticamente perfeito, exibido quando o usuário grátis excede 5 questões ou tenta abrir simulados.',
      whySimplified: 'Usa um único modal de paywall genérico parametrizável (muda o texto conforme o recurso clicado: "Simulados" ou "Limite de Questões"), economizando linhas de código.',
      promptText: `Crie o componente de "Paywall Contextual" para o OAB 3F.
Crie um modal de bloqueio responsivo que é ativado quando o aluno clica em um recurso exclusivo (ex: "Simulado FGV Oficial" ou "Questões Extras"):
- Fundo do modal com overlay escuro desfocado (backdrop-blur).
- Ilustração ou ícone grande de Cadeado Dourado / Estrela Brilhante.
- Título dinâmico (ex: "Excedeu seu limite diário!" ou "Recurso Premium Exclusivo!").
- Subtítulo persuasivo: "Alunos premium têm 3x mais chances de aprovação no Exame de Ordem estudando por simulados oficiais e questões ilimitadas."
- Botões de Ação:
  1. "Liberar Acesso Premium Instantâneo" (Botão grande, gradiente dourado, com efeito vibrante).
  2. "Voltar para o conteúdo grátis" (Botão de fechar discreto).`,
      expectedResult: 'Modal flutuante com bloqueio estético acionável por limites locais simulados de uso gratuito.',
      dependencies: 'Estrutura Base (Prompt U01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'm03',
      code: 'Prompt M03',
      name: 'Simulador de checkout + Compra confirmada',
      objective: 'Validar a jornada final de compra do aluno no MVP.',
      whatBuilds: 'Formulário simplificado de pagamento (PIX ou Cartão de Crédito) com simulador de aprovação de transação e tela de felicitação instantânea.',
      whySimplified: 'Simula a jornada financeira completa no client com feedbacks visuais ricos, evitando as complexidades imediatas de Webhooks de gateways de pagamento antes da validação.',
      promptText: `Crie a tela de "Checkout e Pagamento Seguro" para o OAB 3F.
A tela deve ser dividida em duas colunas:
1. Coluna 1 (Dados de Pagamento):
   - Opções de pagamento por abas: PIX (gera um código simulado Copia e Cola e QRCode fictício na tela com botão "Copiar Código") ou Cartão de Crédito (campos de Nome, Número do Cartão, Validade e CVV).
   - Botão "Finalizar Pagamento e Desbloquear App" (com loader animado).
2. Coluna 2 (Resumo do Pedido):
   - Card exibindo "Plano Premium OAB 3F", valor selecionado e garantia.
Ao clicar em finalizar pagamento, exiba uma tela inteira de Sucesso ("Compra Confirmada!") com confetes digitais, mensagem de parabéns ("Sua jornada rumo à aprovação começou!") e botão direcionando o aluno de volta ao Dashboard agora com status "Premium Ativo".`,
      expectedResult: 'Fluxo visual de pagamento com geração de PIX e formulário de cartão seguidos de tela de aprovação imediata.',
      dependencies: 'Grade de planos (Prompt M01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'm04',
      code: 'Prompt M04',
      name: 'Banner de upgrade interno no dashboard',
      objective: 'Lembrar de forma constante, mas elegante, as vantagens do plano pago.',
      whatBuilds: 'Barra ou card estético inserido discretamente no topo do dashboard do aluno com chamada para o upgrade.',
      whySimplified: 'Usa um componente de linha simples incorporado ao fluxo do painel do aluno, evitando pop-ups intrusivos e melhorando a usabilidade.',
      promptText: `Crie um "Banner de Upgrade" discreto e elegante para ser inserido no topo da página de Dashboard do aluno gratuito.
Design e elementos:
- Container horizontal com bordas arredondadas e fundo gradiente sutil em azul-escuro com detalhes dourados.
- Texto na esquerda: "Adquira acesso ilimitado ao banco de questões e todos os simulados oficiais OAB FGV por menos de R$ 1 por dia."
- Botão/CTA na direita: "Destravar Premium" (Ícone: Sparkles, botão em cor âmbar brilhante de tamanho compacto).
- Botão "x" discreto no canto para o usuário poder fechar o banner temporariamente (gerenciado por estado React).`,
      expectedResult: 'Banner responsivo com botão de CTA para upgrade, facilmente fechável e integrado no painel do estudante.',
      dependencies: 'Dashboard (Prompt U07).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'm05',
      code: 'Prompt M05',
      name: 'Oferta relâmpago de reta final',
      objective: 'Gatilho de escassez e urgência para conversão de leads frios nas semanas decisivas.',
      whatBuilds: 'Card de oferta temporária exibindo cronômetro de contagem regressiva de poucas horas com grande desconto.',
      whySimplified: 'Cria uma oferta agressiva direto no dashboard focada na "Reta Final" usando lógica de cronômetro local de cookies/localStorage.',
      promptText: `Crie um card de "Oferta Relâmpago de Reta Final" para o OAB 3F.
O card exibe um desconto especial temporário:
- Alerta visual vermelho/âmbar no dashboard: "OFERTA DE RETA FINAL OAB - 40% OFF".
- Título: "Restam poucas horas para blindar seus estudos de reta final com o método OAB 3F!"
- Cronômetro regressivo funcional (ex: "Seu cupom expira em: 01:45:12") rodando em tempo real no cliente.
- Preço promocional destacado de R$ 29,90 para R$ 19,90 mensais.
- Botão de compra direta que redireciona para o checkout com o desconto pré-aplicado.`,
      expectedResult: 'Card promocional temporário com cronômetro real gerando urgência na conversão do aluno gratuito.',
      dependencies: 'Checkout (Prompt M03).',
      classification: 'Importante no MVP Robusto'
    },
    {
      id: 'm06',
      code: 'Prompt M06',
      name: 'Régua de reengajamento baseada em inatividade',
      objective: 'Chamar de volta o aluno inativo por meio de notificações simuladas de e-mail/WhatsApp.',
      whatBuilds: 'Interface de testes simulando o disparo de mensagens para o WhatsApp do aluno caso ele passe mais de 3 dias sem logar.',
      whySimplified: 'Cria uma simulação da régua de automação no painel administrativa sem precisar contratar ferramentas externas de CRM (ex: ActiveCampaign) no dia 1.',
      promptText: `Crie a simulação de uma "Régua de Reengajamento por Inatividade" na área do aluno ou admin.
Construa uma caixa de alerta de simulação que demonstra como o app engaja o aluno inativo:
- Se o usuário não completa tarefas há mais de 2 dias, exiba uma caixa com a mensagem: "Notificação OAB 3F (WhatsApp): Lucas, seu streak de estudos está correndo perigo! Temos 10 novas questões de Ética te esperando hoje. Vamos garantir esses 40 pontos?"
- Botão "Retomar Estudos Agora" que direciona para a lista de tarefas pendentes.`,
      expectedResult: 'Exibição simulada de mensagens de CRM focadas em constância e reengajamento do aluno.',
      dependencies: 'Dashboard (Prompt U07).',
      classification: 'Pós-MVP Estratégico'
    }
  ];

  // --- COMPONENTES DA CAMADA 5 (ADMIN) ---
  const adminPrompts: CuratedPromptItem[] = [
    {
      id: 'adm01',
      code: 'Prompt ADM01',
      name: 'Estrutura base do Painel Administrativo',
      objective: 'Montar a área reservada para os professores gerirem a plataforma.',
      whatBuilds: 'Menu de controle do administrador com guias de Alunos, Conteúdos, Questões, Simulados e Métricas Financeiras simples.',
      whySimplified: 'Usa um painel compacto no mesmo app que pode ser acessado por uma rota oculta (/admin) ou senha mestra, dispensando um servidor/app separado.',
      promptText: `Crie a estrutura de navegação e layout para o "Painel Administrativo" do OAB 3F.
A interface de admin deve ser limpa e profissional, utilizando tons de cinza escuro (slate-900) e azul corporativo para contrastar com a área do aluno:
- Topo do painel com título "Painel OAB 3F - Gestor Pedagógico" e botão "Voltar para Área do Aluno".
- Menu de abas de controle esquerdo ou superior:
  1. Visão Geral / Métricas (Ícone: BarChart3)
  2. Alunos e Assinaturas (Ícone: Users)
  3. Biblioteca de Aulas (Ícone: FolderOpen)
  4. Banco de Questões (Ícone: Database)
  5. Chamados de Suporte (Ícone: MessageSquare)
Utilize controle de estado React simples para alternar as abas do admin na mesma página central de gerenciamento.`,
      expectedResult: 'Layout base corporativo do painel de administração que muda de guias reativamente.',
      dependencies: 'Instalação de lucide-react.',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'adm02',
      code: 'Prompt ADM02',
      name: 'Gestão de Alunos + Status de Assinatura',
      objective: 'Acompanhar a lista de estudantes cadastrados e moderar planos pagos.',
      whatBuilds: 'Tabela de usuários cadastrados com e-mail, data de cadastro, status do plano (Gratuito/Premium) e botão para ativar/cancelar assinatura manualmente.',
      whySimplified: 'Evita a montagem de um CRM robusto; foca em uma tabela simples com botões de ação rápida sobre o plano do aluno no localStorage.',
      promptText: `Crie a aba de "Gestão de Alunos" para o Painel Admin do OAB 3F.
A tela deve apresentar:
1. Caixa de Busca por nome ou e-mail de alunos cadastrados.
2. Tabela de Alunos de Alta Performance contendo:
   - Nome, E-mail, Data de Adesão, Plano Atual (com tags visuais: Verde para Premium, Cinza para Gratuito).
3. Ações de Gestão Rápida:
   - Botão "Ativar Premium Manualmente" (para liberar acesso a alunos que pagarem por fora).
   - Botão "Suspender Acesso" (para moderação de inadimplentes).
   - Botão "Ver Progresso" (exibe modal rápido com o streak e taxa de acerto do aluno selecionado).`,
      expectedResult: 'Tabela interativa de controle de usuários e gestão de status de planos de forma simples.',
      dependencies: 'Painel base de admin (Prompt ADM01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'adm03',
      code: 'Prompt ADM03',
      name: 'Gestão de Conteúdos, Disciplinas e Módulos',
      objective: 'Cadastrar e atualizar as matérias e resumos disponíveis na biblioteca.',
      whatBuilds: 'Formulário simples de inserção de novas matérias, módulos de aula, link de arquivos em PDF e links de vídeo.',
      whySimplified: 'Agrupa a criação de disciplinas e módulos de aula no mesmo formulário compacto, reduzindo etapas de cadastro de conteúdo.',
      promptText: `Crie a seção de "Gestão da Biblioteca" para o Painel Admin do OAB 3F.
A interface deve conter:
1. Formulário de "Adicionar Novo Módulo/Aula":
   - Campos de preenchimento: Seleção da Disciplina (Dropdown), Título do Módulo, Nome da Vídeo-aula, URL do Vídeo (simulado), e campo para upload ou link do PDF do Resumo Focado.
   - Botão "Publicar Aula na Biblioteca".
2. Lista de Aulas Cadastradas:
   - Exiba uma lista das aulas existentes agrupadas por matéria, com botões para Editar (abre campos com dados preenchidos) ou Excluir (com modal de confirmação).`,
      expectedResult: 'Formulário completo de adição e edição de módulos de aulas com listagem de controle no painel administrativo.',
      dependencies: 'Painel base de admin (Prompt ADM01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'adm04',
      code: 'Prompt ADM04',
      name: 'Gestão de Banco de Questões + Cadastro de Simulados',
      objective: 'Inserir novas questões oficiais e compor simulados de prova.',
      whatBuilds: 'Formulário de cadastro de questões (enunciado, alternativas, gabarito e comentários do professor) e ferramenta de seleção para compor simulados.',
      whySimplified: 'Utiliza um formulário linear para questões e associa as questões aos simulados através de uma simples tag numérica identificadora (ex: "Simulado 01").',
      promptText: `Crie a aba de "Gerenciamento de Questões e Simulados" para o Painel Administrativo.
A tela possui dois blocos funcionais:
1. Formulário de Cadastro de Questão OAB:
   - Campos: Disciplina (Dropdown), Assunto Específico, Enunciado Completo, Opções A, B, C, D (campos individuais de texto), Letra Correta (A/B/C/D) e Texto do Comentário do Professor.
   - Checkbox "Pertence a Simulado?" (se marcado, abre dropdown para escolher qual simulado, ex: "Simulado FGV Oficial 01").
   - Botão "Salvar Questão no Banco".
2. Lista de Controle: Relação resumida de questões ativas no banco, exibindo matéria e número de simulado vinculado, com ações de remover.`,
      expectedResult: 'Gerenciador estruturado de questões com formulário de cadastro simplificado e integração a simulados por parâmetros simples.',
      dependencies: 'Painel base de admin (Prompt ADM01).',
      classification: 'Obrigatório no MVP'
    },
    {
      id: 'adm05',
      code: 'Prompt ADM05',
      name: 'Painel simples de métricas financeiras do MVP',
      objective: 'Acompanhar a performance comercial do aplicativo de forma consolidada.',
      whatBuilds: 'Painel contendo total de assinantes pagos, faturamento bruto mensal, taxa de conversão de leads para premium e gráficos de receita.',
      whySimplified: 'Dispensa integrações com plataformas analíticas pesadas (Google Analytics); calcula a contagem bruta a partir do localStorage de forma nativa e exibe em cards limpos.',
      promptText: `Crie a aba de "Métricas e Faturamento" para o Painel Admin do OAB 3F.
A interface deve consolidar a performance comercial do MVP:
1. Indicadores Financeiros (Cards de Destaque):
   - Faturamento Mensal Recorrente (MRR simulado baseado em assinantes ativos).
   - Ticket Médio do Aluno.
   - Taxa de Churn (Cancelamento de assinaturas).
   - Taxa de Conversão de Gratuitos para Premium (%).
2. Gráfico Simples de Receita: Um gráfico de barras ou linhas nativo do Tailwind mostrando o crescimento financeiro dos últimos 4 meses de forma ilustrativa.
3. Lista de Transações Recentes: Relação das últimas compras contendo Nome do Aluno, Plano, Forma de Pagamento (PIX/Cartão) e Valor da venda.`,
      expectedResult: 'Painel executivo financeiro simples com faturamento acumulado e histórico recente de assinaturas simuladas.',
      dependencies: 'Painel base de admin (Prompt ADM01).',
      classification: 'Importante no MVP Robusto'
    },
    {
      id: 'adm06',
      code: 'Prompt ADM06',
      name: 'Suporte do aluno básico + Formulário de chamados',
      objective: 'Atender dúvidas técnicas ou pedagógicas de forma ágil.',
      whatBuilds: 'Lista de chamados recebidos dos alunos com título, e-mail do aluno, categoria de dúvida e botão para responder por e-mail ou WhatsApp direto.',
      whySimplified: 'Substitui chat integrado em tempo real por um sistema de formulário estático simples com redirecionamento de links rápidos para o WhatsApp de suporte da equipe.',
      promptText: `Crie a seção de "Atendimento ao Aluno" para o Painel Administrativo.
A interface serve para gerenciar as dúvidas enviadas pelos estudantes:
1. Tabela de Tickets Pendentes:
   - Exiba colunas com Nome do Aluno, E-mail, Tipo de Dificuldade (Técnica ou Dúvida Pedagógica de Questão) e Data de envio.
2. Caixa de Resolução Rápida:
   - Botão "Responder via WhatsApp" (gera link dinâmico api.whatsapp.com contendo mensagem personalizada de suporte).
   - Botão "Marcar Chamado como Resolvido" (muda o status visual para verde "Resolvido").`,
      expectedResult: 'Gestor simplificado de atendimento ao cliente com botões de resposta rápida e status de conclusão.',
      dependencies: 'Painel base de admin (Prompt ADM01).',
      classification: 'Obrigatório no MVP'
    }
  ];

  // Filtros aplicados sobre a esteira de prompts do aluno
  const filteredStudentPrompts = studentPrompts.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.promptText.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterClassification === 'all' || p.classification === filterClassification;
    return matchesSearch && matchesFilter;
  });

  const filteredMonetizationPrompts = monetizationPrompts.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.promptText.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterClassification === 'all' || p.classification === filterClassification;
    return matchesSearch && matchesFilter;
  });

  const filteredAdminPrompts = adminPrompts.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.promptText.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterClassification === 'all' || p.classification === filterClassification;
    return matchesSearch && matchesFilter;
  });

  return (
    <div id="oab-curated-esteira" className="bg-slate-50 border border-slate-200/80 rounded-xl p-4 sm:p-6 shadow-sm space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-200 pb-5">
        <div>
          <span className="bg-emerald-100 text-emerald-800 text-[10px] font-mono uppercase px-2.5 py-1 rounded-full font-bold">
            Curadoria Final de Implementação (Prompt 23)
          </span>
          <h2 className="text-xl font-black text-slate-900 mt-1 flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-emerald-500" />
            <span>Esteira OAB 3F Curada e Otimizada</span>
          </h2>
          <p className="text-slate-500 text-xs mt-1">
            Revisão profunda focada em simplificação extrema de MVP, prompts encurtados e alta estabilidade para o <strong>AppSell AI</strong>.
          </p>
        </div>

        {/* Tab Selector Buttons */}
        <div className="flex flex-wrap gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200/60 max-w-full overflow-x-auto">
          <button
            onClick={() => setActiveTab('diagnostico')}
            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'diagnostico' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            1. Diagnóstico
          </button>
          <button
            onClick={() => setActiveTab('arquitetura')}
            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'arquitetura' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            2. Arquitetura MVP
          </button>
          <button
            onClick={() => setActiveTab('aluno')}
            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'aluno' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            3. Aluno (U01-U17)
          </button>
          <button
            onClick={() => setActiveTab('monetizacao')}
            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'monetizacao' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            4. Monetização (M01-M06)
          </button>
          <button
            onClick={() => setActiveTab('admin')}
            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'admin' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            5. Admin (ADM01-ADM06)
          </button>
          <button
            onClick={() => setActiveTab('pos_mvp')}
            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'pos_mvp' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            6. Pós-MVP
          </button>
          <button
            onClick={() => setActiveTab('plano_operacional')}
            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'plano_operacional' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            7. Plano Operacional
          </button>
        </div>
      </div>

      {/* SEARCH AND FILTERS FOR PROMPTS TAB */}
      {(activeTab === 'aluno' || activeTab === 'monetizacao' || activeTab === 'admin') && (
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-white p-3 rounded-lg border border-slate-200">
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar por termo..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-4 py-2 w-full border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-hidden"
            />
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <span className="text-[11px] font-medium text-slate-500">Filtrar prioridade:</span>
            <select
              value={filterClassification}
              onChange={(e) => setFilterClassification(e.target.value)}
              className="border border-slate-200 rounded-lg py-1.5 px-3 text-xs focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">Todas as prioridades</option>
              <option value="Obrigatório no MVP">Apenas Obrigatório no MVP</option>
              <option value="Importante no MVP Robusto">Apenas MVP Robusto</option>
              <option value="Pós-MVP Estratégico">Apenas Pós-MVP</option>
            </select>
          </div>
        </div>
      )}

      {/* --- CONTENT AREA --- */}

      {/* CAMADA 1 - DIAGNOSTICO */}
      {activeTab === 'diagnostico' && (
        <div className="space-y-6">
          <div className="bg-amber-50 border border-amber-200/70 p-5 rounded-xl space-y-3">
            <h3 className="text-base font-black text-amber-900 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-600" />
              <span>Diagnóstico Franco da Esteira Original</span>
            </h3>
            <p className="text-amber-950 text-xs leading-relaxed">
              Analisamos criticamente a esteira anterior sob a ótica de um desenvolvedor e gerente de produto que precisa implementar o app OAB 3F sem travar o builder <strong>AppSell AI</strong>. O diagnóstico revela que a complexidade algorítmica e a redundância de telas eram as maiores ameaças de quebra ou lentidão. Abaixo está a nossa triagem direta de ações.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* MANTER & UNIR */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4 shadow-2xs">
              <h4 className="text-sm font-black text-emerald-800 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
                <span>O que Manter ou Unificar</span>
              </h4>
              <ul className="space-y-3 text-xs text-slate-600">
                <li className="leading-normal">
                  <strong className="text-slate-800 block">Metodologia 3 Fases:</strong> O core do produto (teoria, questões comentadas e simulados periódicos) foi preservado intacto.
                </li>
                <li className="leading-normal">
                  <strong className="text-slate-800 block">Unificação de Autenticação (U02 & U03):</strong> Splash Screen, Boas-Vindas e Login foram fundidos em um único fluxo de tela por estado, evitando erros de rotas em builders.
                </li>
                <li className="leading-normal">
                  <strong className="text-slate-800 block">Biblioteca Compacta (U10):</strong> Unificação em duas colunas responsivas, onde o aluno estuda a teoria, baixa PDFs e visualiza artigos de lei seca no mesmo painel.
                </li>
                <li className="leading-normal">
                  <strong className="text-slate-800 block">Controle Financeiro Simulado (M03):</strong> Fluxo completo de simulação de PIX/cartão com feedbacks visuais sem a dependência inicial de Webhooks que atrasam o MVP.
                </li>
              </ul>
            </div>

            {/* SIMPLIFICAR & ADIAR */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4 shadow-2xs">
              <h4 className="text-sm font-black text-amber-800 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-amber-500"></span>
                <span>O que Simplificar ou Adiar</span>
              </h4>
              <ul className="space-y-3 text-xs text-slate-600">
                <li className="leading-normal">
                  <strong className="text-slate-800 block">Algoritmo Adaptativo Local (U06 & U13):</strong> Substituímos recálculos em servidores ou conexões pesadas de IA por lógica de regras diretas e ordenação via <code>localStorage</code>.
                </li>
                <li className="leading-normal">
                  <strong className="text-slate-800 block">Gráficos de Desempenho Leves (U14):</strong> Trocamos mapas tridimensionais de calor ou gráficos avançados por indicadores tipo "Semáforo" feitos puramente com Tailwind CSS.
                </li>
                <li className="leading-normal">
                  <strong className="text-slate-800 block">Admin Mínimo (ADM01 a ADM06):</strong> Eliminamos painéis de CRM multicanais e exportações complexas de tabelas; concentramos na gestão direta de alunos e cadastro simplificado de banco de questões.
                </li>
                <li className="leading-normal">
                  <strong className="text-slate-800 block">Comunidade e Gamificação Pesada:</strong> Deslocados inteiramente para pós-MVP estratégico. O foco do MVP é validar aprovação e conversão financeira rápida.
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* CAMADA 2 - ARQUITETURA ENXUTA */}
      {activeTab === 'arquitetura' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-2xs space-y-4">
            <h3 className="text-base font-black text-slate-900">Mapa de Arquitetura do MVP OAB 3F</h3>
            <p className="text-slate-500 text-xs -mt-2">
              Abaixo descrevemos a composição exata de cada bloco arquitetônico minimalista, detalhando o que entra, o que sai e o que foi drasticamente simplificado para rodar com perfeição.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
              {/* BLOCO 1 */}
              <div className="border border-slate-200/80 rounded-xl p-4 bg-slate-50 hover:border-emerald-500/50 transition-all space-y-2">
                <span className="text-[10px] uppercase font-mono font-bold text-slate-400">Bloco 1</span>
                <h4 className="text-xs font-black text-slate-900">Base do Aplicativo</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  <strong>Entra:</strong> Splash Screen com copy científica, Login simplificado e cadastro local.
                  <br /><strong>Sai:</strong> Redes Sociais integradas (Google/FB) e logouts com múltiplos tokens.
                  <br /><span className="text-emerald-600 font-medium">Obrigatório para o lançamento.</span>
                </p>
              </div>

              {/* BLOCO 2 */}
              <div className="border border-slate-200/80 rounded-xl p-4 bg-slate-50 hover:border-emerald-500/50 transition-all space-y-2">
                <span className="text-[10px] uppercase font-mono font-bold text-slate-400">Bloco 2</span>
                <h4 className="text-xs font-black text-slate-900">Onboarding Essencial</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  <strong>Entra:</strong> Questionário em 4 passos e geração automática de plano via regra de dados estáticos.
                  <br /><strong>Sai:</strong> Análises psicológicas e cronogramas customizados com IA ativa externa.
                  <br /><span className="text-emerald-600 font-medium">Obrigatório para o lançamento.</span>
                </p>
              </div>

              {/* BLOCO 3 */}
              <div className="border border-slate-200/80 rounded-xl p-4 bg-slate-50 hover:border-emerald-500/50 transition-all space-y-2">
                <span className="text-[10px] uppercase font-mono font-bold text-slate-400">Bloco 3</span>
                <h4 className="text-xs font-black text-slate-900">Núcleo de Estudo</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  <strong>Entra:</strong> Dashboard unificado com contador de Streak de estudos, meta diária clara e Meu Plano Semanal.
                  <br /><strong>Sai:</strong> Calendário estendido e widgets de pomodoro interativos.
                  <br /><span className="text-emerald-600 font-medium">Obrigatório para o lançamento.</span>
                </p>
              </div>

              {/* BLOCO 4 */}
              <div className="border border-slate-200/80 rounded-xl p-4 bg-slate-50 hover:border-emerald-500/50 transition-all space-y-2">
                <span className="text-[10px] uppercase font-mono font-bold text-slate-400">Bloco 4</span>
                <h4 className="text-xs font-black text-slate-900">Núcleo de Treino</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  <strong>Entra:</strong> Banco de questões com filtro por tema, gabaritos comentados, Simulados com tempo e Flashcards.
                  <br /><strong>Sai:</strong> Fórum comunitário por questão, rankings competitivos mundiais.
                  <br /><span className="text-emerald-600 font-medium">Obrigatório para o lançamento.</span>
                </p>
              </div>

              {/* BLOCO 5 */}
              <div className="border border-slate-200/80 rounded-xl p-4 bg-slate-50 hover:border-emerald-500/50 transition-all space-y-2">
                <span className="text-[10px] uppercase font-mono font-bold text-slate-400">Bloco 5</span>
                <h4 className="text-xs font-black text-slate-900">Jornada OAB e Prova</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  <strong>Entra:</strong> Calendário com timeline oficial FGV e apresentação de mentoria de 2ª Fase com captação de WhatsApp.
                  <br /><strong>Sai:</strong> Web scrapers automáticos do Diário Oficial.
                  <br /><span className="text-emerald-600 font-medium">Obrigatório para o lançamento.</span>
                </p>
              </div>

              {/* BLOCO 6 */}
              <div className="border border-slate-200/80 rounded-xl p-4 bg-slate-50 hover:border-emerald-500/50 transition-all space-y-2">
                <span className="text-[10px] uppercase font-mono font-bold text-slate-400">Bloco 6</span>
                <h4 className="text-xs font-black text-slate-900">Monetização & Admin</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  <strong>Entra:</strong> Paywall com travas de 5 questões/dia, simulador de pagamento PIX/Cartão e gestão administrativa simples.
                  <br /><strong>Sai:</strong> Relatórios fiscais automatizados e múltiplos níveis de permissões de cargos.
                  <br /><span className="text-emerald-600 font-medium">Obrigatório para o lançamento.</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CAMADA 3 - PROMPTS ALUNO */}
      {activeTab === 'aluno' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5">
            <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
              <Code className="h-5 w-5 text-emerald-500" />
              <span>Lista de Prompts Curados - Área do Aluno</span>
            </h3>
            <p className="text-slate-500 text-xs mt-1">
              Use a barra de pesquisa ou filtre por prioridade. Clique no botão de cópia ao lado de cada caixa de texto para obter os prompts finais prontos para o <strong>AppSell AI</strong>.
            </p>
          </div>

          <div className="space-y-5">
            {filteredStudentPrompts.map((p) => (
              <PromptCard key={p.id} p={p} onCopy={handleCopyText} copiedId={copiedId} />
            ))}
            {filteredStudentPrompts.length === 0 && <EmptyState />}
          </div>
        </div>
      )}

      {/* CAMADA 4 - PROMPTS MONETIZACAO */}
      {activeTab === 'monetizacao' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5">
            <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-emerald-500" />
              <span>Lista de Prompts Curados - Monetização e Checkout</span>
            </h3>
            <p className="text-slate-500 text-xs mt-1">
              Prompts dedicados a formatar as barreiras comerciais, ofertas de reta final e validação financeira simulada do MVP.
            </p>
          </div>

          <div className="space-y-5">
            {filteredMonetizationPrompts.map((p) => (
              <PromptCard key={p.id} p={p} onCopy={handleCopyText} copiedId={copiedId} />
            ))}
            {filteredMonetizationPrompts.length === 0 && <EmptyState />}
          </div>
        </div>
      )}

      {/* CAMADA 5 - PROMPTS ADMIN */}
      {activeTab === 'admin' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5">
            <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
              <Settings className="h-5 w-5 text-emerald-500" />
              <span>Lista de Prompts Curados - Painel Administrativo</span>
            </h3>
            <p className="text-slate-500 text-xs mt-1">
              Estruturas simplificadas para permitir que o professor e gestor operem a biblioteca, moderem alunos e consultem as métricas de vendas.
            </p>
          </div>

          <div className="space-y-5">
            {filteredAdminPrompts.map((p) => (
              <PromptCard key={p.id} p={p} onCopy={handleCopyText} copiedId={copiedId} />
            ))}
            {filteredAdminPrompts.length === 0 && <EmptyState />}
          </div>
        </div>
      )}

      {/* CAMADA 6 - POS-MVP */}
      {activeTab === 'pos_mvp' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-2xs space-y-6">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <ShieldAlert className="h-5 w-5 text-amber-500" />
                <span>Triagem de Escopo: O que NÃO entra no MVP do OAB 3F</span>
              </h3>
              <p className="text-slate-500 text-xs mt-1">
                Para evitar a falência do projeto por sobrecarga de escopo, categorizamos rigidamente os recursos planejados em 3 grupos específicos de atuação técnica.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* GRUPO 1 */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-red-50/30">
                <span className="bg-red-100 text-red-800 text-[9px] font-mono uppercase px-2 py-0.5 rounded font-bold">
                  Grupo 1 — Fora do MVP Agora
                </span>
                <h4 className="text-xs font-black text-slate-900">Remover Sem Hesitar</h4>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Recursos que aumentam drasticamente a complexidade e não trazem valor imediato na validação inicial de monetização do app.
                </p>
                <ul className="space-y-1.5 text-[11px] text-slate-600 list-disc list-inside">
                  <li>Integração direta com WhatsApp API nativa (disparo automatizado real).</li>
                  <li>Mecanismo de correção automatizada de peças de 2ª Fase.</li>
                  <li>Gamificação avançada com árvore de conquistas e badges 3D.</li>
                  <li>Ranking competitivo mundial entre alunos em tempo real.</li>
                </ul>
              </div>

              {/* GRUPO 2 */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-amber-50/30">
                <span className="bg-amber-100 text-amber-800 text-[9px] font-mono uppercase px-2 py-0.5 rounded font-bold">
                  Grupo 2 — MVP Robusto
                </span>
                <h4 className="text-xs font-black text-slate-900">Congelado para Fase 1.1</h4>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Funcionalidades excelentes que só entram se a montagem dos itens obrigatórios estiver 100% lisa, sem bugs de carregamento.
                </p>
                <ul className="space-y-1.5 text-[11px] text-slate-600 list-disc list-inside">
                  <li>Mecanismo inteligente de replanejamento automático de tarefas (Prompt U09).</li>
                  <li>Checklist estruturado de reta final OAB (Prompt U16).</li>
                  <li>Filtro avançado de banco de questões por subtópicos e artigos da lei seca.</li>
                  <li>Gráficos interativos analíticos de faturamento no admin.</li>
                </ul>
              </div>

              {/* GRUPO 3 */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-emerald-50/30">
                <span className="bg-emerald-100 text-emerald-800 text-[9px] font-mono uppercase px-2 py-0.5 rounded font-bold">
                  Grupo 3 — Pós-MVP Estratégico
                </span>
                <h4 className="text-xs font-black text-slate-900">Evolução do Produto</h4>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Diferenciais de mercado de longo prazo para expansão da plataforma após conquistar os primeiros 1.000 alunos pagos.
                </p>
                <ul className="space-y-1.5 text-[11px] text-slate-600 list-disc list-inside">
                  <li>Comunidade interna integrada com fórum de suporte por disciplina.</li>
                  <li>Sistema de mentoria por videochamada ao vivo dentro do app.</li>
                  <li>Módulo completo de flashcards inteligentes alimentados por IA generativa externa.</li>
                  <li>Mapeamento avançado com dados oficiais do Conselho Federal da OAB.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CAMADA 7 - PLANO OPERACIONAL */}
      {activeTab === 'plano_operacional' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-2xs space-y-6">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Calendar className="h-5 w-5 text-emerald-500" />
                <span>Plano Operacional Final de Execução (6 Semanas)</span>
              </h3>
              <p className="text-slate-500 text-xs mt-1">
                Divisão lógica e realista para a construção organizada do aplicativo sem sobrecarga de escopo para o desenvolvedor.
              </p>
            </div>

            {/* TIMELINE SEMANAL */}
            <div className="relative border-l-2 border-slate-100 ml-4 pl-6 space-y-6">
              <div className="relative">
                <div className="absolute -left-[31px] top-0.5 h-4 w-4 rounded-full bg-slate-900 text-white flex items-center justify-center text-[9px] font-bold">1</div>
                <h4 className="text-xs font-black text-slate-900">Semana 1 — Fundação & Login (U01 a U04)</h4>
                <p className="text-[11px] text-slate-500 leading-normal mt-1">
                  Estabelecer a casca de navegação master responsiva e os formulários de autenticação visual (Splash, Login, Cadastro, Recuperação e Perfil).
                </p>
              </div>

              <div className="relative">
                <div className="absolute -left-[31px] top-0.5 h-4 w-4 rounded-full bg-slate-900 text-white flex items-center justify-center text-[9px] font-bold">2</div>
                <h4 className="text-xs font-black text-slate-900">Semana 2 — Entrada do Aluno & Teoria (U05, U06, U07, U10)</h4>
                <p className="text-[11px] text-slate-500 leading-normal mt-1">
                  Integrar o questionário de Onboarding, tela de processamento do plano de estudos, painel do Dashboard inicial e a Biblioteca teórica de aulas.
                </p>
              </div>

              <div className="relative">
                <div className="absolute -left-[31px] top-0.5 h-4 w-4 rounded-full bg-slate-900 text-white flex items-center justify-center text-[9px] font-bold">3</div>
                <h4 className="text-xs font-black text-slate-900">Semana 3 — Prática & Memorização (U08, U11, U13, U14)</h4>
                <p className="text-[11px] text-slate-500 leading-normal mt-1">
                  Montar o cronograma em lista de tarefas semanais do aluno, o banco de questões ativas com feedbacks de erros e a seção de Flashcards de memorização.
                </p>
              </div>

              <div className="relative">
                <div className="absolute -left-[31px] top-0.5 h-4 w-4 rounded-full bg-slate-900 text-white flex items-center justify-center text-[9px] font-bold">4</div>
                <h4 className="text-xs font-black text-slate-900">Semana 4 — Avaliação & Escalar (U12, U15, U17 + M01 a M04)</h4>
                <p className="text-[11px] text-slate-500 leading-normal mt-1">
                  Criar o simulado com relógio ativo regressivo, timeline oficial do calendário OAB, tela de vendas da 2ª Fase, paywalls e o checkout de pagamento.
                </p>
              </div>

              <div className="relative">
                <div className="absolute -left-[31px] top-0.5 h-4 w-4 rounded-full bg-slate-900 text-white flex items-center justify-center text-[9px] font-bold">5</div>
                <h4 className="text-xs font-black text-slate-900">Semana 5 — Administração Pedagógica (ADM01 a ADM04)</h4>
                <p className="text-[11px] text-slate-500 leading-normal mt-1">
                  Concluir o Painel Administrativo de controle do professor para gestão direta de alunos e inserção de novos exercícios e módulos na biblioteca.
                </p>
              </div>

              <div className="relative">
                <div className="absolute -left-[31px] top-0.5 h-4 w-4 rounded-full bg-slate-900 text-white flex items-center justify-center text-[9px] font-bold">6</div>
                <h4 className="text-xs font-black text-slate-900">Semana 6 — Polimento, Homologação e Lançamento (QA & ADM06)</h4>
                <p className="text-[11px] text-slate-500 leading-normal mt-1">
                  Revisão geral de todos os botões do app, fluxo do paywall, testes de simulado e ativação do suporte básico ao cliente.
                </p>
              </div>
            </div>

            {/* CHECKLIST DE VALIDAÇÃO */}
            <div className="border-t border-slate-100 pt-5 space-y-3">
              <h4 className="text-xs font-black text-slate-900 flex items-center gap-2">
                <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500" />
                <span>Checklist de Homologação de MVP (Por Marcos)</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] text-slate-600">
                <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg">
                  <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                  <span>Login e Cadastro fluindo para o localStorage local.</span>
                </div>
                <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg">
                  <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                  <span>Onboarding em 4 passos computando metas.</span>
                </div>
                <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg">
                  <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                  <span>Dashboard mostrando streak ativo e tarefa do dia.</span>
                </div>
                <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg">
                  <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                  <span>Questões ativando gabarito e comentário do professor.</span>
                </div>
                <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg">
                  <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                  <span>Simulado rodando cronômetro e calculando nota.</span>
                </div>
                <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg">
                  <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                  <span>Paywall bloqueando acessos após 5 questões.</span>
                </div>
                <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg">
                  <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                  <span>Admin permitindo cadastro de novas questões com sucesso.</span>
                </div>
              </div>
            </div>

            {/* SEGURANÇA NA IMPLEMENTAÇÃO */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-amber-900 space-y-2">
              <h4 className="text-xs font-bold text-amber-800 flex items-center gap-2">
                <Lightbulb className="h-4.5 w-4.5" />
                <span>Recomendações Cruciais para o App Builder</span>
              </h4>
              <p className="text-[11px] leading-normal text-amber-950">
                1. <strong>Nunca tente gerar tudo de uma vez:</strong> Divida o escopo por abas e certifique-se de que cada uma está 100% funcional antes de pedir novas rotinas complexas ao assistente visual.
                <br />2. <strong>Deixe o suporte manual se a automação falhar:</strong> No dia 1, encaminhe o suporte ou liberação de pagamentos direto para links rápidos de WhatsApp se as integrações automáticas quebrarem.
                <br />3. <strong>O foco é a aprovação:</strong> Concentre-se em garantir que o banco de questões resolva e entregue feedbacks precisos. A utilidade real do produto gera mais retenção do que layouts extremamente decorados.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Subcomponente: Card para os prompts individuais
interface PromptCardProps {
  key?: any;
  p: CuratedPromptItem;
  onCopy: (text: string, id: string) => void;
  copiedId: string | null;
}

function PromptCard({ p, onCopy, copiedId }: PromptCardProps) {
  const isCopied = copiedId === p.id;

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 hover:border-emerald-500/40 transition-all space-y-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
        <div className="space-y-1">
          <span className="bg-slate-100 text-slate-800 font-mono text-[9px] uppercase px-2 py-0.5 rounded font-black border border-slate-200">
            {p.code}
          </span>
          <h4 className="text-sm font-black text-slate-900 mt-1">{p.name}</h4>
        </div>
        <span
          className={`font-mono text-[9px] uppercase px-2.5 py-1 rounded-full font-bold ${
            p.classification === 'Obrigatório no MVP'
              ? 'bg-emerald-100 text-emerald-800'
              : p.classification === 'Importante no MVP Robusto'
              ? 'bg-amber-100 text-amber-800'
              : 'bg-slate-100 text-slate-800'
          }`}
        >
          {p.classification}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs bg-slate-50/50 p-3 rounded-lg border border-slate-200/50">
        <div>
          <span className="font-bold text-slate-700 block mb-1">Objetivo do Prompt:</span>
          <p className="text-slate-500 leading-relaxed">{p.objective}</p>
        </div>
        <div>
          <span className="font-bold text-slate-700 block mb-1">O que ele Constrói:</span>
          <p className="text-slate-500 leading-relaxed">{p.whatBuilds}</p>
        </div>
        <div className="md:col-span-2 border-t border-slate-200/60 pt-2 mt-1">
          <span className="font-bold text-slate-700 block mb-1">Por que foi Simplificado/Unificado:</span>
          <p className="text-emerald-700 leading-relaxed font-medium">{p.whySimplified}</p>
        </div>
      </div>

      {/* PROMPT COPYING CONTAINER */}
      <div className="space-y-1.5">
        <div className="flex justify-between items-center text-[10px] text-slate-400 font-medium">
          <span>Prompt final pronto para copiar:</span>
          <button
            onClick={() => onCopy(p.promptText, p.id)}
            className="flex items-center gap-1 text-emerald-600 hover:text-emerald-700 transition-colors font-bold"
          >
            {isCopied ? (
              <>
                <Check className="h-3 w-3" />
                <span>Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="h-3 w-3" />
                <span>Copiar Prompt</span>
              </>
            )}
          </button>
        </div>
        <div className="bg-slate-950 text-slate-300 font-mono text-[11px] p-3 rounded-lg overflow-x-auto border border-slate-800 max-h-48 overflow-y-auto leading-relaxed whitespace-pre-wrap select-all">
          {p.promptText}
        </div>
      </div>

      {/* EXPECTED RESULT & DEPENDENCIES */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-[10px] leading-normal border-t border-slate-100">
        <div>
          <span className="font-bold text-slate-800 block">Resultado Esperado:</span>
          <p className="text-slate-500">{p.expectedResult}</p>
        </div>
        <div>
          <span className="font-bold text-slate-800 block">Dependências do App:</span>
          <p className="text-slate-500">{p.dependencies}</p>
        </div>
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-2">
      <p className="text-slate-500 text-xs">Nenhum prompt encontrado com as configurações de filtros selecionadas.</p>
    </div>
  );
}
