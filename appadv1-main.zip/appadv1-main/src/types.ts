/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface StudentProgress {
  selectedSecondPhaseArea: string; // e.g. "Direito Penal", "Direito Constitucional", "Direito Civil"
  studyHoursGoal: number; // e.g. 20 hours per week
  weeklyStudyHours: number;
  completedTaskIds: string[];
  answeredQuestions: {
    [key: string]: {
      selectedOption: number;
      isCorrect: boolean;
      timestamp: string;
      attemptsCount?: number;
      correctCount?: number;
      incorrectCount?: number;
      history?: { selectedOption: number; isCorrect: boolean; timestamp: string }[];
    };
  };
  favoriteQuestions: string[];
  favoritePieces: string[];
  completedLectures: string[]; // lecture IDs
  completedPDFs: string[]; // PDF IDs
  completedFlashcards: string[]; // flashcard IDs that are "known"
  flashcardBoxes: { [key: string]: number }; // cardId -> SRS Box (1, 2, 3, 4, 5)
  notes: { [key: string]: string }; // e.g., key is pieceId or lawId -> user's notes
  simulatedExamsHistory: SimulatedResult[];
  lastSavedActivity: {
    tab: string;
    sectionId?: string;
    itemId?: string;
    title: string;
    timestamp: string;
  } | null;
}

export interface WeeklyTask {
  id: string;
  day: string; // e.g., "Segunda-feira", "Terça-feira"
  title: string;
  description: string;
  durationMinutes: number; // legacy/backward support
  estimatedMinutes?: number; // official estimated minutes
  discipline: string;
  status?: 'pending' | 'in_progress' | 'completed';
  priority: 'Baixa' | 'Média' | 'Alta';
  type?: 'teoria' | 'questoes' | 'revisao' | 'simulado' | 'peca' | 'leitura' | 'discursiva';
  origin?: 'automatica' | 'manual' | 'revisao' | 'simulado';
  realStudyTimeSeconds?: number;
  completedAt?: string;
  startedAt?: string;
  notes?: string;
  phaseRelated?: 'Fase 1' | 'Fase 2' | 'Fase 3';
  rescheduledFromDay?: string;
  rescheduledCount?: number;
}

export interface Lecture {
  id: string;
  title: string;
  duration: string;
  youtubeId?: string; // Optional real-life video simulation
  summary: string;
}

export interface PDFMaterial {
  id: string;
  title: string;
  pageCount: number;
  summary: string;
  url?: string;
}

export interface Discipline {
  id: string;
  name: string;
  icon: string; // Lucide icon key
  lectures: Lecture[];
  pdfs: PDFMaterial[];
  importance: 'Muito Alta' | 'Alta' | 'Média';
  totalQuestions: number;
}

export interface JuridicalPiece {
  id: string;
  title: string;
  area: string;
  structure: {
    section: string;
    content: string;
  }[];
  checklist: {
    id: string;
    item: string;
    checked: boolean;
  }[];
  template: string;
  tips: string[];
}

export interface Question {
  id: string;
  discipline: string;
  theme: string;
  difficulty: 'Fácil' | 'Média' | 'Difícil';
  exam: string; // e.g. "XXXVIII Exame de Ordem"
  statement: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  phase?: '1fase' | '2fase' | 'ambas';
}

export interface SimulatedResult {
  id: string;
  title: string;
  type: '1a Fase' | '2a Fase';
  date: string;
  score: number;
  total: number;
  percentage: number;
  timeSpentMinutes: number;
  subjectPerformance?: { [subject: string]: { correct: number; total: number } };
  feedback: string;
}

export interface Flashcard {
  id: string;
  discipline: string;
  theme: string;
  front: string; // Question or concept
  back: string; // Answer or definition
  lawArticle?: string; // Relevant legislation
}

export interface OABCalendarEvent {
  id: string;
  title: string;
  date: string;
  type: 'inscricao' | 'prova1' | 'prova2' | 'recurso' | 'reaproveitamento' | 'outro';
  description: string;
  isImportant: boolean;
}

export interface SupportFAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
}
