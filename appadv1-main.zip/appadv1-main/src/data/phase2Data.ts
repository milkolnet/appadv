/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Phase2Module {
  id: string;
  title: string;
  description: string;
  milestones: string[];
}

export interface Phase2Piece {
  id: string;
  title: string;
  area: string;
  importance: 'Extrema' | 'Alta' | 'Média';
  status: 'Pendente' | 'Estudando' | 'Revisado';
  cabimento: string;
  estrutura: string;
  passoAPasso: string[];
  fundamentos: string[];
  pedidos: string[];
  errosFatais: string[];
  observacoes: string;
  checklist: string[];
  template: string;
  tips: string[];
}

export interface Phase2Discursive {
  id: string;
  area: string;
  theme: string;
  difficulty: 'Fácil' | 'Média' | 'Difícil';
  title: string;
  statement: string;
  expectedTeses: string[];
  espelhoCorrecao: string;
  professorObservations: string;
}

export interface Phase2Simulado {
  id: string;
  title: string;
  area: string;
  tempoEstimado: string; // e.g. "5 horas"
  pecaEnunciado: string;
  questoesEnunciados: string[];
  pecaGabarito: string;
  questoesGabaritos: string[];
  dificuldade: 'Média' | 'Difícil' | 'Extrema';
}

export const PHASE2_LEGAL_AREAS = [
  "Direito do Trabalho",
  "Direito Penal",
  "Direito Civil",
  "Direito Constitucional",
  "Direito Administrativo",
  "Direito Tributário",
  "Direito Empresarial"
];

export const PHASE2_MODULES: Phase2Module[] = [
  {
    id: "mod-1",
    title: "1. Fundamentos da 2ª Fase",
    description: "Técnicas de consulta ao Vade Mecum, marcação de códigos permitida, gestão do tempo de prova e interpretação sistemática do edital da FGV.",
    milestones: ["Dominar marcações válidas", "Aprender a folhear por índices remissivos", "Simular tempo de busca por artigos"]
  },
  {
    id: "mod-2",
    title: "2. Identificação de Peças",
    description: "Método de leitura ativa para descobrir a peça cabível a partir dos indícios fáticos descritos no enunciado. Diferenciação de remédios constitucionais e recursos ordinários.",
    milestones: ["Tabela comparativa de prazos", "Identificação por exclusão processual", "Treino de simulação de 15 enunciados históricos"]
  },
  {
    id: "mod-3",
    title: "3. Peças Prático-Profissionais",
    description: "Biblioteca estrutural de redação jurídica técnica. Passo a passo do endereçamento ao fechamento, preliminares de nulidade e técnicas de mérito (Fato-Fundamento-Pedido).",
    milestones: ["Estrutura de Interposição e Razões", "Rascunho de 3 peças estratégicas", "Revisão dos checklists de pontuação oficial"]
  },
  {
    id: "mod-4",
    title: "4. Questões Discursivas",
    description: "Estratégia para obter nota máxima em discursivas. Como fundamentar de forma enxuta e assertiva citando artigos e súmulas de modo direto.",
    milestones: ["Treino de 10 questões discursivas reais", "Uso correto de conectivos jurídicos", "Análise de espelhos de correção de notas baixas"]
  },
  {
    id: "mod-5",
    title: "5. Simulados da Área",
    description: "Treinamentos cronometrados completos com simulados integrando peça + 4 questões discursivas na folha de resposta padrão.",
    milestones: ["Simulado de ambientação com consulta", "Simulado Geral OAB 3F com tempo real de 5h", "Correção por critérios estatísticos da FGV"]
  },
  {
    id: "mod-6",
    title: "6. Revisão Final e Súmulas",
    description: "Leitura orientada das súmulas vinculantes, súmulas do STF, STJ, TST e orientações jurisprudenciais essenciais para o dia da prova.",
    milestones: ["Cronograma de Súmulas Quentes", "Checklist de fechamento formal", "Mentalidade de aprovação e kit de prova"]
  }
];

// Comprehensive database of pieces for each area
export const PHASE2_PIECES_BY_AREA: { [area: string]: Phase2Piece[] } = {
  "Direito do Trabalho": [
    {
      id: "trab-p-1",
      title: "Reclamação Trabalhista",
      area: "Direito do Trabalho",
      importance: "Extrema",
      status: "Pendente",
      cabimento: "Sempre que houver lesão ou ameaça de lesão aos direitos do trabalhador decorrentes da relação de trabalho (Art. 840, § 1º, CLT). É a peça inaugural do rito ordinário ou sumaríssimo.",
      estrutura: "Endereçamento ao Juízo da Vara do Trabalho; Qualificação das partes (Reclamante e Reclamada); Breve síntese do contrato de trabalho; Teses de mérito com fatos, fundamentos jurídicos claros e liquidação individual dos valores de cada pedido; Requerimentos finais de notificação da ré, procedência dos pedidos, honorários sucumbenciais e indicação de provas.",
      passoAPasso: [
        "1. Faça o endereçamento correto de acordo com o último local de prestação de serviços (Art. 651, CLT).",
        "2. Qualifique de forma completa o Reclamante e a Reclamada nos termos do CPC aplicável subsidiariamente.",
        "3. Apresente os dados do contrato de trabalho (admissão, demissão, função, salário e causa de saída).",
        "4. Divida o mérito em tópicos específicos (ex: Horas Extras, Verbas Rescisórias, Multa do 477, Equiparação Salarial).",
        "5. Liquide rigorosamente cada verba requerida para cumprir a exigência do Art. 840, § 1º, da CLT.",
        "6. Encerre com os requerimentos de estilo: notificação, sucumbência (Art. 791-A, CLT) e valor da causa."
      ],
      fundamentos: [
        "Art. 840, § 1º da CLT (Requisitos da Petição Inicial Trabalhista)",
        "Art. 319 do CPC (Aplicação subsidiária por força do Art. 769 da CLT)",
        "Art. 482 e 483 da CLT (Justa causa do empregador e empregado)",
        "Súmulas e Orientações Jurisprudenciais do TST correspondentes aos direitos lesionados"
      ],
      pedidos: [
        "Notificação da Reclamada para responder, sob pena de revelia e confissão ficta",
        "Condenação da Reclamada ao pagamento de todas as verbas pleiteadas devidamente liquidadas",
        "Honorários advocatícios sucumbenciais de 15% (Art. 791-A da CLT)",
        "Juros e correção monetária cabíveis sobre o montante apurado"
      ],
      errosFatais: [
        "Não liquidar os pedidos individuais (gera inépcia da petição inicial, extinguindo o processo sem mérito).",
        "Esquecer de indicar o rito correto (ordinário se acima de 40 salários mínimos, sumaríssimo se até 40 salários mínimos).",
        "Inventar dados que não constavam no problema, como nomes de testemunhas ou valores fictícios."
      ],
      observacoes: "Peça de altíssima incidência na OAB (costuma alternar com Contestação e Recurso Ordinário). Atenção máxima na redação de teses de estabilidade (gestante, acidentado, dirigente sindical) e horas extras com reflexos.",
      checklist: [
        "Endereçamento correto ao Juiz do Trabalho da Vara do Trabalho de...",
        "Qualificação completa do Reclamante com fulcro no Art. 840 da CLT e 319 do CPC",
        "Qualificação da Reclamada com indicação de CNPJ e endereço",
        "Menção ao contrato de trabalho (admissão, demissão, cargo, salário)",
        "Tese de horas extras fundamentada no Art. 7º, XIII, da CF e Art. 58 da CLT com reflexos",
        "Liquidação de todos os pedidos formulados",
        "Pedido de notificação da ré para audiência",
        "Pedido de honorários advocatícios no importe de 15% (Art. 791-A da CLT)",
        "Valor da causa e fechamento formal"
      ],
      template: `EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DA ... VARA DO TRABALHO DE ...

RECLAMANTE, nacionalidade ..., estado civil ..., profissão ..., portador da cédula de identidade RG nº ..., inscrito no CPF sob o nº ..., CTPS nº ..., série nº ..., PIS/PASEP nº ..., filho de ..., residente e domiciliado na Rua ..., nº ..., Bairro ..., Cidade ..., Estado ..., CEP ..., por seu advogado signatário (procuração em anexo), com endereço profissional na Rua ..., onde recebe notificações e intimações, vem, perante Vossa Excelência, com esteio no Artigo 840, § 1º da CLT e Artigo 319 do CPC, propor a presente

RECLAMAÇÃO TRABALHISTA

pelo rito ordinário, em face de RECLAMADA, pessoa jurídica de direito privado, inscrita no CNPJ sob o nº ..., com sede na Rua ..., nº ..., Bairro ..., Cidade ..., Estado ..., CEP ..., pelas razões de fato e de direito a seguir aduzidas:

I. DO CONTRATO DE TRABALHO
O Reclamante foi admitido em ... para exercer a função de ..., mediante remuneração de R$ ... mensais. Foi demitido injustamente em ..., quando percebia o último salário de R$ ...

II. DO MÉRITO
(Redigir as teses estruturando: Fato, Fundamento Legal/Súmula, Aplicação ao caso e Conclusão com pedido individualizado)

1. Das Horas Extras
O reclamante trabalhava além da jornada constitucional de 8 horas diárias e 44 horas semanais, realizando habitualmente...
Fundamenta-se no artigo 7º, XIII da CF e 59 da CLT.
Diante disso, requer o pagamento de ... horas extras mensais acrescidas do adicional de 50%, no valor estimado de R$ ... e seus reflexos em aviso prévio (R$ ...), 13º salário (R$ ...), férias (R$ ...) e FGTS com multa de 40% (R$ ...).

III. DOS PEDIDOS
Ante o exposto, pleiteia o Reclamante:
a) A notificação da Reclamada para apresentar resposta em audiência, sob pena de revelia e confissão;
b) O pagamento de horas extras com reflexos, conforme tese acima, liquidado em R$ ...;
c) A condenação da Ré ao pagamento de honorários sucumbenciais de 15% nos termos do art. 791-A da CLT, no valor de R$ ...

Atribui-se à causa o valor de R$ ... (Soma de todos os pedidos liquidados).

Termos em que,
Pede deferimento.

Local ..., Data ...
Advogado ...
OAB/ ... nº ...`,
      tips: [
        "Sempre indique o rito processual na qualificação: Ordinário ou Sumaríssimo.",
        "Em matéria trabalhista, o FGTS é de 8% e a multa rescisória é de 40%. Sempre peça reflexos em aviso prévio, férias + 1/3, 13º salário e FGTS + 40%.",
        "Atente para o teto de 40 salários mínimos para o rito sumaríssimo e não exija de forma genérica a produção de provas — mencione as provas permitidas na CLT."
      ]
    },
    {
      id: "trab-p-2",
      title: "Contestação Trabalhista",
      area: "Direito do Trabalho",
      importance: "Extrema",
      status: "Pendente",
      cabimento: "Instrumento de defesa do reclamado contra a petição inicial de reclamação trabalhista (Art. 847, CLT). Deve ser apresentada em audiência ou por escrito eletronicamente.",
      estrutura: "Endereçamento vinculado ao juízo onde tramita a ação; Qualificação da Reclamada; Defesas preliminares de mérito (incompetência, inépcia da inicial, ilegitimidade); Prejudicial de mérito (Prescrição bienal e quinquenal); Impugnação específica de cada fato e tese de mérito trazidos pelo reclamante; Pedidos de improcedência e honorários sucumbenciais.",
      passoAPasso: [
        "1. Direcione a peça ao mesmo juízo trabalhista onde a inicial foi distribuída.",
        "2. Indique o número do processo em epígrafe para identificação imediata.",
        "3. Apresente as Preliminares de Processo (Art. 337 do CPC) se houver inépcia ou falta de interesse de agir.",
        "4. Argua a Prejudicial de Prescrição Quinquenal (Art. 7º, XXIX, CF e Art. 11, CLT) para extinguir as verbas anteriores aos últimos 5 anos.",
        "5. Combata ponto a ponto cada alegação do reclamante (Princípio da Impugnação Especificada, Art. 341 do CPC).",
        "6. Conclua pedindo o acolhimento das preliminares, da prejudicial e a improcedência total da demanda."
      ],
      fundamentos: [
        "Art. 847 da CLT (Apresentação da Defesa)",
        "Art. 335 e 337 do CPC (Normas gerais de contestação e preliminares)",
        "Art. 7º, inciso XXIX da CF/88 (Prescrição geral trabalhista)",
        "Súmula 308 do TST (Marcos prescricionais aplicáveis na Justiça do Trabalho)"
      ],
      pedidos: [
        "Acolhimento da preliminar arguida para extinguir o processo sem resolução de mérito",
        "Pronúncia da prescrição quinquenal para afastar condenações anteriores à data limite",
        "Improcedência integral de todos os pleitos formulados na petição inicial",
        "Condenação do Reclamante ao pagamento de honorários sucumbenciais"
      ],
      errosFatais: [
        "Não alegar prescrição bienal ou quinquenal (erro crucial que mantém cobranças de verbas já prescritas de até 5 anos).",
        "Esquecer de impugnar especificadamente alguma das verbas pleiteadas (gera presunção de veracidade sobre o fato não contestado).",
        "Não rebater os reflexos das horas extras e gratificações solicitadas."
      ],
      observacoes: "Uma das peças preferidas da banca FGV pois exige do candidato forte domínio técnico de presunções, ônus da prova e direito material.",
      checklist: [
        "Endereçamento correto ao juiz da vara trabalhista de origem",
        "Menção ao número correto dos autos da ação",
        "Qualificação resumida da reclamada com menção à peça contestatória",
        "Preliminar de inépcia da petição inicial por pedidos sem liquidação",
        "Arguir prejudicial de prescrição quinquenal (março de 5 anos antes da propositura)",
        "Impugnação de horas extras alegando ausência de jornada extra ou existência de acordo de compensação válido",
        "Combate de adicionais de insalubridade e periculosidade sem perícia prévia",
        "Pedido de improcedência total de todos os itens",
        "Requerimento de produção de provas cabíveis",
        "Fechamento formal padrão OAB"
      ],
      template: `EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DA ... VARA DO TRABALHO DE ...

PROCESSO Nº ...

RECLAMADA, já devidamente qualificada nos autos da Reclamação Trabalhista em epígrafe, movida por RECLAMANTE, por seu procurador subscritor, vem, mui respeitosamente, à presença de Vossa Excelência, com fulcro no Artigo 847 da CLT e Artigo 335 do CPC, apresentar

CONTESTAÇÃO

às pretensões deduzidas na exordial, expondo os motivos de fato e de direito que sustentam a improcedência da demanda:

I. DAS PRELIMINARES DE MÉRITO
1. Da Inépcia da Inicial
A petição inicial carece de liquidação adequada em relação ao pedido de dano moral, violando flagrantemente o art. 840, § 1º da CLT. Portanto, requer a extinção do referido pleito sem resolução do mérito, conforme o Art. 485, I do CPC.

II. DAS PREJUDICIAIS DE MÉRITO
1. Da Prescrição Quinquenal
A presente ação foi ajuizada em ... Tendo em vista o disposto no art. 7º, XXIX da CF e art. 11 da CLT, requer-se o pronunciamento da prescrição quinquenal para declarar extintos com resolução do mérito os eventuais direitos anteriores a ... (5 anos retroativos ao ajuizamento), de acordo com o art. 487, II do CPC.

III. DO MÉRITO DA CONTESTAÇÃO
(Contestar especificadamente cada pedido feito na inicial)

1. Das Horas Extras Pleiteadas
O Reclamante alega que laborava em sobrejornada sem compensação. Contudo, tal alegação não condiz com a verdade, eis que a empresa possui acordo individual de banco de horas devidamente assinado, nos termos do art. 59, § 5º da CLT...
Ademais, os controles de ponto juntados demonstram a integral compensação ou pagamento das poucas horas extras prestadas. Logo, improcede o pedido principal e todos os seus reflexos.

IV. DOS PEDIDOS
Ante o exposto, requer a Reclamada:
a) O acolhimento da preliminar com a extinção parcial do feito nos moldes indicados;
b) O acolhimento da prejudicial de prescrição quinquenal;
c) No mérito, a improcedência integral de todos os pedidos formulados pelo autor;
d) A condenação do Reclamante ao pagamento de honorários sucumbenciais (Art. 791-A da CLT).

Termos em que,
Pede deferimento.

Local ..., Data ...
Advogado ...
OAB/ ... nº ...`,
      tips: [
        "Sempre verifique as datas do problema! A prescrição bienal extingue o direito se a ação foi proposta mais de 2 anos após o término do contrato. A quinquenal extingue parcelas anteriores a 5 anos da data de distribuição.",
        "Defenda-se por partes: comece com Preliminares, passe para Prejudiciais (Prescrição) e depois Mérito propriamente dito.",
        "Lembre-se de impugnar os reflexos de verbas. Se a verba principal cai, os reflexos (acessórios) caem automaticamente por gravidade."
      ]
    },
    {
      id: "trab-p-3",
      title: "Recurso Ordinário (RO)",
      area: "Direito do Trabalho",
      importance: "Extrema",
      status: "Pendente",
      cabimento: "Cabe contra as decisões definitivas ou terminativas das Varas do Trabalho ou dos Tribunais Regionais do Trabalho em processos de sua competência originária (Art. 895, I e II, CLT). Prazo de 8 dias.",
      estrutura: "Peça de Interposição dirigida ao Juiz do Trabalho prolator da sentença, com o recolhimento do depósito recursal e custas processuais; Peça de Razões Recursais dirigida ao Tribunal Regional do Trabalho (TRT), onde se atacam as decisões de primeiro grau com efeito devolutivo amplo.",
      passoAPasso: [
        "1. Escreva a interposição ao juiz de 1º grau informando que interpõe o Recurso Ordinário no prazo legal.",
        "2. Declare expressamente o recolhimento das custas (comprovante GRU) e do depósito recursal (GFIP/guia própria).",
        "3. Faça as razões recursais endereçadas ao TRT competente.",
        "4. Indique as preliminares de recurso (nulidades da sentença por cerceamento de defesa, julgamento extra petita).",
        "5. Apresente os tópicos de reforma de mérito fundamentados na CLT, Constituição ou Súmulas.",
        "6. Peça o conhecimento do recurso por tempestivo e preparado, e o provimento para reformar a decisão recorrida."
      ],
      fundamentos: [
        "Art. 895, inciso I da CLT (Fundamentação principal do RO das Varas)",
        "Art. 1.010 do CPC (Regras gerais de apelação aplicáveis subsidiariamente)",
        "Súmulas e OJs correlatas às matérias fáticas que o juiz julgou incorretamente"
      ],
      pedidos: [
        "Recebimento do recurso em seu regular efeito devolutivo",
        "Remessa dos autos com as razões inclusas ao egrégio Tribunal Regional do Trabalho",
        "Conhecimento e provimento do recurso para reformar a r. decisão nos pontos atacados"
      ],
      errosFatais: [
        "Esquecer de mencionar a comprovação das guias de custas e do depósito recursal na peça de interposição (preclusão e deserção do recurso).",
        "Não demonstrar a tempestividade (o prazo para RO é de 8 dias úteis de acordo com a CLT).",
        "Inovar em teses de fato que não foram debatidas na petição inicial ou na contestação (supressão de instância)."
      ],
      observacoes: "Peça complexa porque exige duas petições distintas (Interposição e Razões). Treine bastante o endereçamento duplo e a tese de nulidade de sentença.",
      checklist: [
        "Folha de interposição direcionada à Vara do Trabalho de origem",
        "Menção ao recolhimento do depósito recursal e custas processuais (salvo se beneficiário de Justiça Gratuita)",
        "Razões direcionadas ao Egrégio Tribunal Regional do Trabalho da ... Região",
        "Preliminar de nulidade por negativa de prestação jurisdicional ou cerceamento de defesa",
        "Mérito: ataque exaustivo aos tópicos desfavoráveis da sentença",
        "Pedido de conhecimento e provimento integral do recurso ordinário",
        "Fechamento com local, data, assinatura 'Advogado...' e número de inscrição OAB"
      ],
      template: `EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DA ... VARA DO TRABALHO DE ...

PROCESSO Nº ...

RECORRENTE, já qualificado nos autos da Reclamação Trabalhista em tela, por seu advogado infra-assinado, não se conformando com a r. sentença de fls. ..., vem, respeitosamente, perante Vossa Excelência, interpor o presente

RECURSO ORDINÁRIO

com fundamento no Artigo 895, inciso I, da CLT, para o Egrégio Tribunal Regional do Trabalho da ... Região.

Informa o Recorrente que junta em anexo os comprovantes de recolhimento das custas processuais e do depósito recursal dentro dos limites legais.

Desta forma, requer se digne Vossa Excelência receber o recurso, intimar a parte contrária para apresentar contrarrazões no prazo legal e remeter os autos ao E Tribunal.

Pede deferimento.
Local ..., Data ...
Advogado ...
OAB/ ...
-----------------------------------------
RAZÕES DO RECURSO ORDINÁRIO

RECORRENTE: ...
RECORRIDO: ...
PROCESSO Nº: ...
ORIGEM: ... VARA DO TRABALHO DE ...

EGRÉGIO TRIBUNAL REGIONAL DO TRABALHO DA ... REGIÃO
COLENDA TURMA
DOUTOS JULGADORES

A r. sentença recorrida, apesar de proferida por magistrado de elevado saber jurídico, merece reforma parcial, haja vista não ter aplicado o melhor direito ao caso concreto:

I. DAS PRELIMINARES RECURSAIS
1. Do Cerceamento de Defesa
O juízo de origem indeferiu a oitiva da testemunha do recorrente sob pretexto de desnecessidade, proferindo sentença desfavorável. Ocorre que tal fato configura cerceamento de defesa violando o Art. 5º, LV da CF...

II. DO MÉRITO DO RECURSO
(Redigir as teses recursais de mérito atacando a sentença de forma clara)

III. DOS PEDIDOS
Ante o exposto, requer o Recorrente:
a) O conhecimento do presente Recurso Ordinário, visto que preenchidos todos os pressupostos formais de admissibilidade;
b) O acolhimento da preliminar para anular a sentença e reabrir a instrução processual;
c) Caso superada a preliminar, no mérito seja dado total provimento ao recurso para reformar a r. decisão de origem e absolver/condenar o recorrido de...

Local ..., Data ...
Advogado ...
OAB/ ...`,
      tips: [
        "Atenção às isenções de depósito recursal: beneficiários da justiça gratuita, entidades filantrópicas, empresas em recuperação judicial são isentos. Sócios administradores ou microempresas pagam pela metade.",
        "Nunca assine seu nome ou coloque datas fora do período real indicado na prova para evitar a eliminação por identificação do candidato."
      ]
    }
  ],
  "Direito Penal": [
    {
      id: "penal-p-1",
      title: "Resposta à Acusação (RA)",
      area: "Direito Penal",
      importance: "Extrema",
      status: "Pendente",
      cabimento: "Após a citação do réu, no prazo de 10 dias, nos procedimentos comum ordinário, sumário e especial do Júri (Art. 396 e 396-A, CPP). É a primeira manifestação defensiva técnica obrigatória.",
      estrutura: "Endereçamento ao Juiz de Direito da Vara Criminal prolator do despacho de citação; Qualificação do réu; Preliminares de nulidade processual (Art. 564 CPP); Teses de absolvição sumária fundada no Art. 397 do CPP (atipicidade, excludente de ilicitude, excludente de culpabilidade, extinção da punibilidade); Rol de testemunhas e pedido de produção de provas.",
      passoAPasso: [
        "1. Enderece ao Juiz da Vara Criminal de origem de onde foi expedido o mandado de citação.",
        "2. Fundamente a peça no Art. 396 e 396-A do CPP.",
        "3. Verifique exaustivamente nulidades da denúncia ou do inquérito (incompetência, nulidade de busca e apreensão).",
        "4. Formule teses de mérito focando estritamente na ABSOLVIÇÃO SUMÁRIA (Art. 397, CPP).",
        "5. Apresente o Rol de Testemunhas (máximo 8 testemunhas no rito ordinário, 5 no sumário).",
        "6. Finalize com local, data, assinatura genérica 'Advogado...' e número de inscrição OAB."
      ],
      fundamentos: [
        "Artigos 396 e 396-A do CPP (Fundamentos processuais da RA)",
        "Artigo 397 do CPP (Causas de Absolvição Sumária - Matéria central de mérito)",
        "Artigo 564 do CPP (Nulidades processuais aplicáveis)"
      ],
      pedidos: [
        "Acolhimento das nulidades processuais arguidas para anulação do processo 'ab initio'",
        "Decretar a absolvição sumária do réu com base em um dos incisos do Art. 397 do CPP",
        "Oitiva das testemunhas qualificadas no rol em anexo e produção de provas lícitas"
      ],
      errosFatais: [
        "Pedir absolvição com base no Art. 386 do CPP (Art. 386 é para alegações finais ou apelação após instrução. Na RA, o artigo correto é o 397 - absolvição sumária).",
        "Esquecer de apresentar o Rol de Testemunhas (gera preclusão, impedindo o réu de produzir prova testemunhal na audiência).",
        "Ignorar nulidades flagrantes de citação ou decadência do direito de representação."
      ],
      observacoes: "Peça recorrente e extremamente importante. Lembre-se de alegar teses de prescrição ou decadência do crime como extinção da punibilidade.",
      checklist: [
        "Endereçamento ao Juízo Criminal competente de primeiro grau",
        "Indicação do fundamento legal correto (Art. 396 e 396-A do CPP)",
        "Teses preliminares de nulidade (inépcia da denúncia, incompetência do juízo)",
        "Tese de absolvição sumária por excludente de ilicitude (legítima defesa, estado de necessidade) ou atipicidade da conduta",
        "Rol de testemunhas qualificado ao final da peça",
        "Pedido expresso de oitiva das testemunhas e absolvição sumária",
        "Fechamento formal OAB sem identificação pessoal"
      ],
      template: `EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DE DIREITO DA ... VARA CRIMINAL DA COMARCA DE ...

PROCESSO Nº ...

ACUSADO, já devidamente qualificado nos autos da ação penal em epígrafe, promovida pelo Ministério Público, por seu advogado infra-assinado, vem, mui respeitosamente, à presença de Vossa Excelência, com fulcro nos artigos 396 e 396-A do Código de Processo Penal, apresentar

RESPOSTA À ACUSAÇÃO

rebatendo os termos da denúncia com base nos motivos fáticos e jurídicos a seguir delineados:

I. DAS PRELIMINARES (Indicar nulidades ou extinção da punibilidade...)
1. Da Prescrição da Pretensão Punitiva
O crime de furto imputado ao réu ocorreu em ... Tendo em vista que a pena máxima abstrata é de 4 anos, o prazo prescricional é de 8 anos conforme o art. 109, IV do CP... Logo, requer a declaração de extinção da punibilidade conforme art. 107, IV do CP.

II. DO MÉRITO
1. Da Legítima Defesa (Excludente de Ilicitude)
O acusado agiu amparado pela excludente de ilicitude da legítima defesa, visto que...
Tal conduta ampara-se no Art. 23, II e Art. 25 do Código Penal.
Por conseguinte, imperiosa se faz a sua absolvição sumária por exclusão da própria antijuridicidade do fato.

III. DOS PEDIDOS
Ante o exposto, requer o Acusado:
a) O acolhimento da preliminar para declarar extinta a punibilidade...;
b) No mérito, decretar a ABSOLVIÇÃO SUMÁRIA do réu, com esteio no Artigo 397, inciso ... do CPP;
c) A produção de todas as provas em direito admitidas, inclusive a oitiva das testemunhas qualificadas no rol abaixo.

Termos em que,
Pede deferimento.

Local ..., Data ...
Advogado ...
OAB/ ... nº ...

ROL DE TESTEMUNHAS:
1. Nome, RG, CPF, Endereço...
2. Nome, RG, CPF, Endereço...`,
      tips: [
        "A absolvição sumária do Art. 397 do CPP exige teses de direito claras e incontroversas. Se houver dúvida fática grave, o juiz mandará instruir o feito.",
        "Não confunda: o prazo é de 10 dias no CPP geral. No caso de crimes de drogas (Lei 11.343/06), apresenta-se 'Defesa Prévia' em 10 dias antes do recebimento da denúncia."
      ]
    }
  ],
  "Direito Civil": [
    {
      id: "civil-p-1",
      title: "Petição Inicial (Procedimento Comum)",
      area: "Direito Civil",
      importance: "Extrema",
      status: "Pendente",
      cabimento: "Qualquer direito subjetivo lesado ou ameaçado de lesão na esfera cível (Art. 319, CPC). É a peça que inaugura a relação jurídica processual civil.",
      estrutura: "Endereçamento ao Juízo de Direito da Vara Cível competente; Qualificação completa do autor e do réu; Opção expressa pela realização ou não de audiência de conciliação; Fatos e fundamentos jurídicos detalhados; Pedido de tutela provisória (se houver urgência); Pedidos finais de procedência, citação, custas e honorários sucumbenciais; Valor da causa.",
      passoAPasso: [
        "1. Identifique o foro competente para processamento da causa de acordo com as regras de competência do CPC.",
        "2. Faça a qualificação das partes indicando estado civil, união estável, profissão, RG, CPF e endereços eletrônicos.",
        "3. Declare na petição se opta pela realização de audiência de autocomposição (Art. 319, VII, CPC).",
        "4. Construa a causa de pedir dividida em fatos, fundamentos jurídicos e nexo causal (se for responsabilidade civil).",
        "5. Fundamente os pedidos liminares se presentes os requisitos de urgência ou evidência (Art. 300, CPC).",
        "6. Formule os pedidos com clareza, indique o valor da causa e as provas que pretende produzir."
      ],
      fundamentos: [
        "Artigos 319 e 320 do CPC (Requisitos formais da petição inicial)",
        "Artigo 300 do CPC (Tutela provisória de urgência antecipada ou cautelar)",
        "Código Civil correspondente ao direito violado (ex: perdas e danos, divórcio, usucapião)"
      ],
      pedidos: [
        "Concessão da tutela de urgência liminarmente requerida",
        "Citação do réu para comparecer à audiência ou apresentar defesa",
        "Procedência total da ação com condenação do réu em perdas e danos ou obrigação específica",
        "Condenação do réu ao pagamento de honorários advocatícios sucumbenciais (Art. 85, CPC)"
      ],
      errosFatais: [
        "Não indicar expressamente o interesse ou desinteresse na audiência de conciliação (gera determinação de emenda à petição inicial).",
        "Esquecer de atribuir o Valor da Causa correspondente ao proveito econômico (Art. 291 e 292 do CPC).",
        "Deixar de instruir a inicial com os documentos indispensáveis à propositura da ação (Art. 320 do CPC)."
      ],
      observacoes: "Peça base do processo civil. É crucial o candidato dominar as regras de distribuição e competência territorial.",
      checklist: [
        "Endereçamento ao juízo cível competente de foro",
        "Qualificação completa do autor com dados pessoais e eletrônicos",
        "Qualificação completa do réu",
        "Opção expressa pela audiência de conciliação ou mediação",
        "Teses fáticas claras e fundamentos baseados no Código Civil e jurisprudência",
        "Pedido liminar de tutela de urgência fundamentado no perigo de dano",
        "Pedidos definitivos de procedência e condenação",
        "Especificação das provas a produzir",
        "Atribuição de valor à causa nos moldes do art. 292 do CPC",
        "Fechamento OAB padrão"
      ],
      template: `EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DE DIREITO DA ... VARA CÍVEL DA COMARCA DE ...

AUTOR, nacionalidade ..., estado civil ..., profissão ..., portador do RG nº ... e inscrito no CPF sob o nº ..., com endereço eletrônico ..., residente e domiciliado na Rua ..., por seu advogado constituído, vem, mui respeitosamente, perante Vossa Excelência, propor a presente

AÇÃO DE INDENIZAÇÃO POR DANOS MATERIAIS E MORAIS

em face de RÉU, nacionalidade ..., estado civil ..., profissão ..., inscrito no CPF sob o nº ..., residente e domiciliado na Rua ..., pelos fatos e fundamentos a seguir expostos:

I. DA AUDIÊNCIA DE CONCILIAÇÃO
O Autor manifesta, nos termos do artigo 319, inciso VII do CPC, seu integral interesse na realização da audiência de conciliação ou mediação.

II. DOS FATOS (Descrever minuciosamente o evento danoso...)

III. DO DIREITO
1. Da Responsabilidade Civil do Réu
A conduta do réu violou os preceitos dos artigos 186 e 927 do Código Civil brasileiro, visto que agiu com imprudência ao...
O nexo de causalidade resta evidente na medida em que o ato gerou prejuízos de monta ao Autor...

IV. DOS PEDIDOS
Ante o exposto, requer o Autor:
a) A citação do Réu para comparecer à audiência de conciliação ou apresentar contestação no prazo legal;
b) A procedência total dos pedidos para condenar o Réu ao pagamento de indenização por danos materiais no valor de R$ ..., e danos morais no montante de R$ ...;
c) A condenação do Réu em custas processuais e honorários advocatícios sucumbenciais (Art. 85 do CPC).

Protesta provar o alegado por todos os meios de prova em direito admitidos.

Dá-se à causa o valor de R$ ...

Termos em que,
Pede deferimento.

Local ..., Data ...
Advogado ...
OAB/ ... nº ...`,
      tips: [
        "Lembre-se de fundamentar as teses usando o Código Civil e as súmulas do STJ aplicáveis.",
        "O valor da causa na ação de indenização deve ser a soma dos valores pretendidos (danos materiais + danos morais)."
      ]
    }
  ],
  "Direito Constitucional": [
    {
      id: "const-p-1",
      title: "Mandado de Segurança (MS)",
      area: "Direito Constitucional",
      importance: "Extrema",
      status: "Pendente",
      cabimento: "Para proteger direito líquido e certo, não amparado por habeas corpus ou habeas data, sempre que ilegalmente ou com abuso de poder, qualquer pessoa física ou jurídica sofrer violação ou houver justo receio de sofrê-la por parte de autoridade pública (Art. 5º, LXIX, CF e Lei 12.016/09).",
      estrutura: "Endereçamento ao órgão competente para julgar a autoridade coatora (atentar para foro de prerrogativa); Qualificação do Impetrante; Indicação da Autoridade Coatora e da pessoa jurídica à qual ela pertence (União, Estado, Município); Exposição do ato abusivo ilegal e demonstração documental inequívoca de direito líquido e certo; Pedido de liminar; Pedido de concessão definitiva da segurança.",
      passoAPasso: [
        "1. Defina a competência jurisdicional de acordo com a categoria e sede funcional da autoridade tida como coatora.",
        "2. Identifique e qualifique a autoridade que praticou o ato impugnado (ex: Secretário de Saúde do Estado).",
        "3. Faça a indicação do órgão ou entidade federativa de representação judicial (pessoa jurídica de direito público integrada).",
        "4. Demonstre a tempestividade do mandado (prazo decadencial de 120 dias do conhecimento do ato ilegal).",
        "5. Fundamente a fumaça do bom direito (fumus boni iuris) e o perigo da demora (periculum in mora) para fins de liminar.",
        "6. Encerre requerendo notificação da autoridade, intimação do Ministério Público e concessão da ordem sem fixar honorários."
      ],
      fundamentos: [
        "Artigo 5º, incisos LXIX e LXX da CF/88 (Mandado de segurança individual e coletivo)",
        "Lei nº 12.016/2009 (Disciplina o rito processual do Mandado de Segurança)",
        "Súmulas do STF e STJ sobre direito líquido e certo e competências originárias"
      ],
      pedidos: [
        "Concessão de medida liminar suspensiva 'inaudita altera parte' para obstar os efeitos do ato ilegal",
        "Notificação da autoridade coatora para prestar as informações no prazo legal de 10 dias",
        "Intimação do representante do Ministério Público para atuar como fiscal da lei",
        "Concessão definitiva da segurança para anular em definitivo o ato impugnado"
      ],
      errosFatais: [
        "Fazer requerimento de dilação probatória (o Mandado de Segurança não admite produção de provas em juízo; todas as provas devem ser pré-constituídas juntamente com a petição inicial).",
        "Formular pedido de honorários advocatícios sucumbenciais (Súmula 512 do STF e Art. 25 da Lei 12.016/09 vedam expressamente a condenação em honorários de sucumbência no MS).",
        "Endereçar incorretamente sem considerar o foro especial de prerrogativa da autoridade coatora."
      ],
      observacoes: "Uma das peças mais queridas e cobradas em Direito Constitucional e Direito Administrativo. Memorize a ausência de dilação probatória.",
      checklist: [
        "Endereçamento à autoridade jurisdicional competente de foro",
        "Qualificação completa do impetrante",
        "Qualificação com exata denominação da autoridade coatora",
        "Identificação expressa da pessoa jurídica vinculada à autoridade",
        "Demonstração inequívoca de direito líquido e certo com provas documentais anexas",
        "Arguir tempestividade do MS (prazo de 120 dias corridos)",
        "Tese de fundamentação liminar de urgência",
        "Pedido de notificação da autoridade coatora",
        "Cientificação da Procuradoria (pessoa jurídica integrada)",
        "Oitiva obrigatória do Ministério Público",
        "Pedido final de concessão em definitivo da segurança",
        "Valor da causa e fechamento padrão"
      ],
      template: `EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DE DIREITO DA ... VARA DA FAZENDA PÚBLICA DA COMARCA DE ...

IMPETRANTE, nacionalidade ..., estado civil ..., profissão ..., portador da identidade RG nº ... e CPF sob o nº ..., residente e domiciliado na Rua ..., nº ..., por seu advogado legalmente habilitado (instrumento de mandato incluso), vem, mui respeitosamente, à presença de Vossa Excelência, com amparo no Artigo 5º, inciso LXIX, da Constituição Federal e na Lei Federal nº 12.016/2009, impetrar o presente

MANDADO DE SEGURANÇA INDIVIDUAL COM PEDIDO LIMINAR

em face de ato abusivo e ilegal praticado pelo ILUSTRÍSSIMO SENHOR DIRETOR DO DEPARTAMENTO DE ..., autoridade coatora vinculada à PESSOA JURÍDICA DE DIREITO PÚBLICO (União/Estado/Município), sediada na Rua ..., pelos motivos de fato e de direito a seguir expostos:

I. DO CABIMENTO E TEMPESTIVIDADE
O presente remédio constitucional ataca ato comissivo ilegal praticado em ..., restando plenamente demonstrada a sua tempestividade por estar dentro do prazo decadencial de 120 dias, conforme art. 23 da Lei 12.016/09. Outrossim, o direito líquido e certo exsurge do farto acervo de prova documental pré-constituída em anexo.

II. DOS FATOS (Relatar de forma cronológica o ato administrativo arbitrário...)

III. DO DIREITO (Demonstrar a violação de preceito constitucional ou direito amparado...)

IV. DO PEDIDO LIMINAR
Os pressupostos autorizadores do provimento cautelar estão sobejamente demonstrados. A fumaça do bom direito (fumus boni iuris) resta evidenciada no descumprimento expresso do Art. ... da CF. O perigo da demora (periculum in mora) consiste no prejuízo irreparável que decorrerá da manutenção do ato suspenso...
Diante disso, requer-se a concessão de medida liminar para...

V. DOS PEDIDOS
Ante todo o exposto, requer o Impetrante:
a) A concessão liminar da medida para determinar...;
b) A notificação da Autoridade Coatora para que, querendo, preste informações no prazo legal de 10 dias;
c) A cientificação do órgão de representação judicial da pessoa jurídica interessada;
d) A intimação do ilustre membro do Ministério Público;
e) No mérito, a total concessão da segurança impetrada para confirmar a liminar e anular/suspender definitivamente o ato ilegal.

Dá-se à causa o valor de R$ ...

Termos em que,
Pede deferimento.

Local ..., Data ...
Advogado ...
OAB/ ... nº ...`,
      tips: [
        "Lembre-se: em sede de Mandado de Segurança, não existe condenação em honorários advocatícios de sucumbência.",
        "Todas as provas que você precisa citar no mandado devem estar indicadas como 'documentação em anexo'. Nunca peça para ouvir testemunhas no mandado!"
      ]
    }
  ],
  "Direito Administrativo": [
    {
      id: "admin-p-1",
      title: "Ação Anulatória de Ato Administrativo",
      area: "Direito Administrativo",
      importance: "Alta",
      status: "Pendente",
      cabimento: "Quando o cidadão ou empresa necessita obter a invalidação (anulação) de ato emitido pelo poder público e seus órgãos delegados, por conter vício insanável de legalidade, formalidade, competência, motivo ou finalidade (Lei 4.717/65 - conceito legal de vícios). Permite dilação probatória ampla.",
      estrutura: "Endereçamento ao juízo federal ou estadual comum de primeiro grau; Qualificação das partes com inclusão da pessoa jurídica estatal ré; Fatos fáticos; Fundamentação apontando os vícios constitutivos do ato administrativo impugnado (sujeito, objeto, forma, motivo, finalidade); Pedido de tutela antecipada para obstar os efeitos nocivos do ato; Pedidos finais de citação e procedência total da anulação.",
      passoAPasso: [
        "1. Direcione a inicial ao juízo da vara cível estadual ou de fazenda pública competentes, ou vara federal se ré for autarquia federal.",
        "2. Identifique o ente federativo titular como Réu (ex: Estado de Minas Gerais), não o departamento isoladamente.",
        "3. Indique com riqueza de detalhes o ato administrativo ilegal sofrido pelo autor (ex: cassação de alvará, multa arbitrária).",
        "4. Argua exaustivamente a ilegalidade material do ato, indicando o abuso de poder por desvio ou excesso de poder.",
        "5. Fundamente a concessão de tutela antecipada com base nos prejuízos imediatos da vigência do ato.",
        "6. Conclua peticionando a invalidação retroativa (efeito ex tunc) com ressarcimento das perdas conexas."
      ],
      fundamentos: [
        "Artigos 319 e 300 do CPC (Estrutura e urgência)",
        "Artigo 2º da Lei nº 4.717/1965 (Conceitua os vícios do ato administrativo aplicáveis subsidiariamente)",
        "Artigo 37, 'caput', da CF (Princípios constitucionais da administração pública violados)"
      ],
      pedidos: [
        "Decretar em sede de tutela provisória a imediata suspensão dos efeitos do ato lesivo",
        "Citação da pessoa jurídica de direito público ré para contestar sob pena de revelia",
        "No mérito, julgar procedente para anular definitivamente o ato administrativo ilegal",
        "Condenação do réu em custas e honorários sucumbenciais de estilo"
      ],
      errosFatais: [
        "Colocar no polo passivo apenas a autoridade coatora ou órgão interno (em ação ordinária o réu é o ente público federado correspondente, ex: Município de... e não a Secretaria de Obras).",
        "Esquecer de requerer a intimação para que tragam aos autos a cópia integral do processo administrativo que gerou o ato ilegal.",
        "Ignorar a cumulação de perdas e danos se o ato ilegal causou prejuízo mensurável."
      ],
      observacoes: "Diferencia-se do Mandado de Segurança pois permite a dilação probatória ampla (perícias, oitiva de testemunhas) e a condenação em honorários advocatícios.",
      checklist: [
        "Endereçamento ao juízo da Vara de Fazenda Pública ou Vara Cível de...",
        "Qualificação das partes (Autor c/ dados completos e Réu sendo o Ente Federativo)",
        "Opção da audiência de autocomposição",
        "Fundamentação de incompetência ou desvio de finalidade do ato do servidor",
        "Pedido de tutela antecipada nos termos do art. 300 do CPC",
        "Pedido final de anulação do ato com efeito retroativo (ex tunc)",
        "Pedido de honorários e custas sucumbenciais",
        "Provas indicadas com destaque",
        "Valor atribuído à causa e assinatura genérica"
      ],
      template: `EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DE DIREITO DA ... VARA DA FAZENDA PÚBLICA DA COMARCA DE ...

AUTOR, já qualificado nos autos, por seu procurador assinado, vem, perante Vossa Excelência, com espeque nos Artigos 319 e 300 do CPC, propor a presente

AÇÃO ANULATÓRIA DE ATO ADMINISTRATIVO COM PEDIDO DE TUTELA DE URGÊNCIA

em face do ESTADO ..., pessoa jurídica de direito público interno, representado em juízo por sua Procuradoria Geral, sediada na Rua ..., pelas razões fáticas e jurídicas que seguem:

I. DA AUDIÊNCIA DE CONCILIAÇÃO
O Autor manifesta seu desinteresse na audiência prévia por tratar-se de matéria eminentemente de direito e indisponível para o ente público réu.

II. DOS FATOS (Narrar a imposição do ato administrativo abusivo...)

III. DO DIREITO
O ato de demissão/interdição praticado padece de vício gravíssimo de competência e finalidade. A autoridade prolatora extrapolou as balizas de sua delegação funcional...
Conforme ensina a doutrina, os princípios da legalidade, moralidade e devido processo legal insculpidos no Art. 37 da Constituição restaram mortalmente feridos, ensejando a decretação de nulidade absoluta com efeitos ex tunc do ato lesivo...

IV. DA TUTELA DE URGÊNCIA
O perigo na demora resta evidenciado na iminente quebra financeira do autor em virtude da interdição abusiva. A probabilidade do direito exsurge da prova material inconteste do vício de legalidade...
Pelo exposto, requer a suspensão liminar dos efeitos do ato até julgamento final.

V. DOS PEDIDOS
Diante do exposto, requer o Autor:
a) A concessão inaudita altera parte da tutela de urgência suspendendo os efeitos do ato;
b) A citação do Ente Público Réu para apresentar resposta;
c) A total procedência para anular definitivamente o ato impugnado com todos os reflexos decorrentes;
d) Condenação da ré ao pagamento de custas e honorários recursais de sucumbência.

Dá-se à causa o valor de R$ ...

Pede deferimento.
Local ..., Data ...
Advogado ...
OAB/ ...`,
      tips: [
        "Use a Ação Ordinária quando a narrativa envolver a necessidade de perícia (ex: comprovação de que uma obra pública interditada não oferecia riscos reais).",
        "O polo passivo em ações ordinárias administrativas de servidores estaduais é sempre o Estado, não a Secretaria de Estado."
      ]
    }
  ],
  "Direito Tributário": [
    {
      id: "trib-p-1",
      title: "Ação de Repetição de Indébito",
      area: "Direito Tributário",
      importance: "Alta",
      status: "Pendente",
      cabimento: "Sempre que o contribuinte houver pago valor de tributo (imposto, taxa, contribuição) indevido ou maior que o devido por lei, visando obter a restituição pecuniária atualizada do indébito pago (Art. 165, CTN).",
      estrutura: "Endereçamento ao juiz estadual comum ou juiz federal (conforme o tributo seja federal ou local); Qualificação do autor contribuinte e do ente tributante réu; Demonstração da ilegalidade/inconstitucionalidade da cobrança tributária sofrida; Pedido de restituição dos valores corrigidos monetariamente a partir do pagamento indevido e juros a partir do trânsito em julgado (Súmula 188 do STJ); Provas documentais (comprovantes de recolhimento das guias).",
      passoAPasso: [
        "1. Direcione a inicial de acordo com o ente tributante réu (Justiça Federal para União/Receita Federal; Justiça Estadual para Estado e Município).",
        "2. Identifique o Réu sendo o ente público tributante titular da arrecadação do imposto (União, Estado ou Município).",
        "3. Fundamente expressamente a petição inicial no Artigo 165 do CTN cumulado com o Artigo 319 do CPC.",
        "4. Demonstre de forma minuciosa a inconstitucionalidade ou ilegalidade da exigência do tributo pago.",
        "5. Requeira expressamente a correção de juros na forma do art. 167 do CTN e Súmula 188 do STJ.",
        "6. Finalize pedindo a condenação do ente réu à devolução atualizada das parcelas não prescritas (últimos 5 anos)."
      ],
      fundamentos: [
        "Artigo 165, incisos I, II ou III do CTN (Fundamento de direito material do indébito)",
        "Artigo 168 do CTN (Prazo prescricional de 5 anos do pagamento para pedir restituição)",
        "Súmula 188 do STJ e Súmula 162 do STJ (Regras de incidência de juros e correção monetária)"
      ],
      pedidos: [
        "Citação da fazenda pública ré para apresentar contestação",
        "Condenação da ré a restituir de forma integral os valores pagos indevidamente devidamente atualizados",
        "Aplicação de juros moratórios e correção conforme as normas vigentes",
        "Condenação do réu em custas e honorários advocatícios sucumbenciais de lei"
      ],
      errosFatais: [
        "Esquecer de pleitear a correção monetária desde o pagamento indevido (Súmula 162 do STJ) e juros a partir do trânsito em julgado (Súmula 188 do STJ).",
        "Não juntar as guias e os respectivos comprovantes bancários de recolhimento (em repetição, a prova do pagamento indevido é pressuposto material básico).",
        "Demandar cobranças prescritas anteriores a 5 anos anteriores à distribuição da petição inicial."
      ],
      observacoes: "Peça direta e limpa, de alta relevância pedagógica. Lembre-se de alegar violações aos princípios constitucionais tributários (legalidade, anterioridade, não confisco).",
      checklist: [
        "Endereçamento à vara de fazenda pública estadual/municipal ou vara federal correspondente",
        "Qualificação completa do contribuinte autor",
        "Qualificação do Ente Federativo Tributante no polo passivo",
        "Declaração referente ao interesse ou desinteresse na audiência",
        "Tese tributária demonstrando a ilegalidade da exação fiscal",
        "Pedido de devolução monetária atualizada desde a data do recolhimento",
        "Tese de não ocorrência da prescrição quinquenal",
        "Pedido de juros moratórios oficiais",
        "Condenação em honorários de sucumbência",
        "Atribuição exata do valor da causa condizente com a soma a restituir",
        "Assinatura ficta padrão"
      ],
      template: `EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DE DIREITO DA ... VARA DE FAZENDA PÚBLICA DA COMARCA DE ...

CONTRIBUINTE, já devidamente qualificado, vem, por seu advogado infra-assinado, perante Vossa Excelência, propor a presente

AÇÃO DE REPETIÇÃO DE INDÉBITO TRIBUTÁRIO

em face de MUNICÍPIO ..., pessoa jurídica de direito público interno, representado em juízo por sua Procuradoria, com endereço profissional na Rua ..., pelas razões fáticas e jurídicas que seguem:

I. DOS FATOS
O Autor é proprietário de imóvel e foi compelido a recolher taxas de iluminação pública ilegalmente instituídas pela Lei Municipal nº ... no período de ... a ... efetuando o pagamento da quantia de R$ ...

II. DO DIREITO
A taxa cobrada padece de inconstitucionalidade gritante, eis que os serviços de iluminação pública não possuem caráter de divisibilidade e especificidade exigidos pelo Art. 145, II da CF e Art. 77 do CTN. Tal matéria encontra-se pacificada na Súmula Vinculante 41 do STF...
Portanto, as quantias recolhidas indevidamente devem ser devolvidas, sob pena de enriquecimento sem causa do erário.

III. DOS CONSECTÁRIOS DE MORA
Requer-se a incidência de correção monetária calculada a partir de cada pagamento indevido (Súmula 162 do STJ) e juros de mora devidos no patamar de 1% ao mês contados a partir do trânsito em julgado da decisão definitiva, nos termos do art. 167, parágrafo único do CTN e Súmula 188 do STJ.

IV. DOS PEDIDOS
Ante o exposto, requer o Autor:
a) A citação do Ente Réu para apresentar resposta;
b) A total procedência para condenar o Réu à devolução integral do indébito pago no valor histórico de R$ ..., devidamente acrescido de correção monetária e juros;
c) A condenação da Ré nas custas e honorários advocatícios sucumbenciais.

Dá-se à causa o valor de R$ ...

Pede deferimento.
Local ..., Data ...
Advogado ...
OAB/ ...`,
      tips: [
        "Atenção para tributos de lançamento por homologação (ex: ICMS, IPI): o prazo para pedir repetição é de 5 anos a contar do próprio pagamento do tributo (Tese do Superior Tribunal de Justiça).",
        "A instituição de taxas para custear serviços gerais/indivisíveis (como segurança pública ou iluminação) viola a constituição e enseja restituição garantida."
      ]
    }
  ],
  "Direito Empresarial": [
    {
      id: "emp-p-1",
      title: "Petição Inicial de Recuperação Judicial",
      area: "Direito Empresarial",
      importance: "Alta",
      status: "Pendente",
      cabimento: "Sempre que a sociedade empresária preencher os requisitos legais e passar por crise econômico-financeira superável, visando obter a suspensão das ações e execuções em face dela para viabilizar reestruturação operacional (Art. 51, Lei 11.101/05).",
      estrutura: "Endereçamento ao Juízo de Direito da Vara de Falências e Recuperações Judiciais competente de foro (principal estabelecimento do devedor); Qualificação da empresa devedora; Demonstração detalhada das causas da crise e do preenchimento dos requisitos subjetivos exigidos pela Lei de Falências; Pedido de processamento e deferimento da recuperação de forma motivada.",
      passoAPasso: [
        "1. Direcione a inicial ao juízo cível do principal estabelecimento da empresa (onde se concentra o comando operacional).",
        "2. Qualifique a sociedade empresária autora de forma completa anexando atos constitutivos e demonstrações contábeis exigidas.",
        "3. Exponha as razões circunstanciadas da crise econômica que assolou a empresa nos moldes do art. 51 da LRF.",
        "4. Demonstre com clareza o exercício regular das atividades há mais de 2 anos de forma ininterrupta.",
        "5. Formule os requerimentos de estilo pedindo expressamente a nomeação de administrador judicial competente.",
        "6. Peticione o deferimento do processamento e consequente suspensão das execuções tributárias e cíveis ('stay period' de 180 dias)."
      ],
      fundamentos: [
        "Artigos 47, 48 e 51 da Lei nº 11.101/2005 (Balizas e requisitos fundamentais da Recuperação Judicial)",
        "Artigo 319 do CPC (Procedimento comum subsidiário aplicável à petição inicial)"
      ],
      pedidos: [
        "O deferimento do processamento da presente recuperação judicial da sociedade empresária",
        "Nomeação do administrador judicial de confiança do juízo",
        "Determinação da suspensão de todas as ações e execuções contra a devedora pelo prazo de 180 dias",
        "Apresentação do plano de recuperação de negócios no prazo legal de 60 dias"
      ],
      errosFatais: [
        "Não demonstrar o cumprimento dos requisitos objetivos subjetivos negativos do Art. 48 da Lei de Falências (ex: não estar falida, não ter sofrido outra recuperação nos últimos 5 anos).",
        "Deixar de instruir a petição inicial com as demonstrações contábeis trienais e relações nominais completas de credores sob pena de inépcia sumária.",
        "Errar o juízo competente escolhendo foro de filial isolada contrariando o conceito de 'principal estabelecimento'."
      ],
      observacoes: "Peça densa, que exige muita atenção técnica para as normas procedimentais da Lei nº 11.101/05.",
      checklist: [
        "Endereçamento à Vara de Falências e Recuperações Judiciais ou Vara Cível do principal estabelecimento da devedora",
        "Qualificação completa da sociedade devedora autora",
        "Menção ao cumprimento exato do lapso temporal mínimo de 2 anos de atividade regular",
        "Exposição lógica das causas da situação de crise comercial e financeira",
        "Relação de credores em anexo nominal de dívidas",
        "Pedido expresso de deferimento do processamento pelo juiz criminal/cível",
        "Pedido de nomeação de Administrador Judicial",
        "Pedido de suspensão de ações judiciais de execução contra o patrimônio da devedora",
        "Valor atribuído à causa condizente com as dívidas",
        "Fechamento formal OAB padrão"
      ],
      template: `EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DE DIREITO DA ... VARA DE FALÊNCIAS E RECUPERAÇÕES JUDICIAIS DA COMARCA DO FORO DE ... (Principal Estabelecimento)

SOCIEDADE EMPRESÁRIA LTDA., já devidamente constituída, inscrita no CNPJ sob o nº ..., com sede administrativa e operacional na Rua ..., nº ..., Bairro ..., nesta cidade, por seu advogado constituído signatário, vem, perante Vossa Excelência, com fulcro no Artigo 47 e seguintes da Lei nº 11.101/2005, bem como Artigo 319 do CPC, requerer a presente

RECUPERAÇÃO JUDICIAL

com suporte nas razões de fato e de direito a seguir expostas:

I. DO PRINCIPAL ESTABELECIMENTO E COMPETÊNCIA
O principal estabelecimento da requerente situa-se nesta urbe, onde está concentrado o maior volume de negócios, faturamento e coordenação fabril, fixando este foro como competente para processar o pedido nos termos do art. 3º da LRF.

II. DO CUMPRIMENTO DOS REQUISITOS SUBJETIVOS (Art. 48, Lei 11.101/05)
A Requerente declara cumprir todos os requisitos para o pleito:
a) Exerce atividade comercial regular há mais de 2 anos (junta-se certidão de junta comercial de ...);
b) Não é falida;
c) Não obteve concessão de recuperação nos últimos 5 anos;
d) Seus administradores nunca foram condenados por crimes falimentares.

III. DA CAUSA DA CRISE ECONÔMICO-FINANCEIRA (Narrar as dificuldades de mercado...)

IV. DOS PEDIDOS
Ante o exposto, preenchendo todos os requisitos legais exigidos, requer a sociedade autora:
a) O deferimento do processamento da presente Recuperação Judicial;
b) A suspensão de todas as ações ou execuções contra a requerente pelo prazo de 180 dias;
c) A nomeação de qualificado Administrador Judicial;
d) Intimação do digno representante do Ministério Público.

Dá-se à causa o valor de R$ ... (Valor correspondente ao passivo total a ser reestruturado).

Termos em que,
Pede deferimento.

Local ..., Data ...
Advogado ...
OAB/ ... nº ...`,
      tips: [
        "A Recuperação Judicial é exclusiva para empresários individuais ou sociedades empresárias. Sociedades simples ou cooperativas não têm legitimidade para pedi-la.",
        "Em caso de prova de empresarial, lembre-se que o foro competente é ditado pelo Artigo 3º da LRF e consiste no local onde se centraliza a atividade-fim da empresa."
      ]
    }
  ]
};

// Discursive questions database for all areas
export const PHASE2_DISCURSIVES_BY_AREA: { [area: string]: Phase2Discursive[] } = {
  "Direito do Trabalho": [
    {
      id: "trab-d-1",
      area: "Direito do Trabalho",
      theme: "Equiparação Salarial e Ônus da Prova",
      difficulty: "Média",
      title: "Questão 1 - Equiparação e Trabalho Intelectual",
      statement: "Aline e Gabriela trabalham para o mesmo empregador na mesma localidade. Aline desempenha a função de analista sênior desde 2018 com alta produtividade. Gabriela foi admitida como analista sênior em 2021, demonstrando igual produtividade e perfeição técnica, porém recebe salário 25% menor. Em reclamação trabalhista ajuizada por Gabriela pedindo equiparação, a empresa contestou alegando que Gabriela comete erros pontuais e que Aline possui curso de pós-graduação internacional. Pergunta-se: O fato de Gabriela não possuir pós-graduação constitui impedimento válido à equiparação salarial? Quem detém o ônus de provar a diferença de produtividade em juízo? Fundamente sua resposta.",
      expectedTeses: [
        "A pós-graduação ou qualificação formal superior da paradigma não impede a equiparação se houver igual perfeição técnica e produtividade no trabalho real (Art. 461 da CLT).",
        "O ônus de provar o fato impeditivo, modificativo ou extintivo da equiparação salarial (como diferença de perfeição técnica ou produtividade) pertence ao empregador (Súmula 6, VIII do TST)."
      ],
      espelhoCorrecao: "O candidato deve indicar fundamentadamente que a pós-graduação por si só não impede a equiparação salarial se na prática as funções são idênticas, e o trabalho prestado possui igual produtividade e perfeição técnica (0,65 pt). Deve indicar expressamente que o ônus da prova de tais diferenças cabe ao empregador/reclamada por tratar-se de fato impeditivo do direito do autor, conforme preconiza a Súmula 6, VIII do TST e Art. 818, II da CLT (0,60 pt).",
      professorObservations: "Questão de incidência elevadíssima. Lembre-se sempre: em equiparação salarial, o fato constitutivo (mesma função, mesma localidade, diferença de tempo na função inferior a 2 anos e tempo de serviço inferior a 4 anos) deve ser provado pelo empregado. O fato impeditivo (diferença de produtividade, perfeição técnica ou existência de quadro de carreira homologado) é ônus do empregador."
    },
    {
      id: "trab-d-2",
      area: "Direito do Trabalho",
      theme: "Estabilidade da Gestante no Contrato de Experiência",
      difficulty: "Média",
      title: "Questão 2 - Estabilidade Gestante",
      statement: "Patrícia foi contratada pela empresa Alpha por contrato de experiência pelo prazo determinado de 45 dias. Durante a vigência do contrato, Patrícia engravidou. Ao término do prazo pactuado, a empresa dispensou Patrícia sob a justificativa de decurso natural do prazo de experiência. Diante disso, Patrícia pleiteia reintegração ao emprego alegando estabilidade constitucional da gestante. A empresa alega descabimento por tratar-se de contrato a prazo determinado. Assiste razão à Patrícia? Indique a jurisprudência sumulada aplicável.",
      expectedTeses: [
        "Sim, a empregada gestante tem direito à garantia provisória de emprego, mesmo em contratos de experiência ou temporários.",
        "Súmula 244, III do TST e tese firmada em sede de Repercussão Geral pelo STF (Tema 497)."
      ],
      espelhoCorrecao: "O candidato deve asseverar que assiste razão à gestante Patrícia (0,30 pt). Deve fundamentar indicando que o direito à estabilidade provisória da gestante decorre diretamente do Artigo 10, II, 'b' do ADCT e estende-se aos contratos de prazo determinado, inclusive de experiência, conforme teor da Súmula 244, III do TST (0,65 pt). Adicionar a indicação do Tema 497 do STF enriquece a nota de mérito (0,30 pt).",
      professorObservations: "Após debates jurisprudenciais, o STF e o TST consolidaram de forma pacífica que a proteção à maternidade prevalece sobre a natureza resolúvel do contrato por tempo determinado. Não erre isso na prova da OAB!"
    }
  ],
  "Direito Penal": [
    {
      id: "penal-d-1",
      area: "Direito Penal",
      theme: "Desistência Voluntária vs Tentativa",
      difficulty: "Fácil",
      title: "Questão 1 - Desistência Voluntária no Crime de Homicídio",
      statement: "Caio, com intenção de matar Tício, desfere contra este um disparo de arma de fogo que atinge o abdômen da vítima. Vendo Tício gemer de dor e percebendo que ainda possui cinco munições intactas em seu revólver, Caio se arrepende, decide não continuar a atirar e pessoalmente socorre Tício, levando-o imediatamente ao hospital mais próximo. Devido ao rápido socorro prestado, Tício sobrevive sem sequelas graves. Diante do caso narrado, Caio responderá por tentativa de homicídio? Fundamente apontando o instituto de direito penal correspondente e sua consequência jurídica.",
      expectedTeses: [
        "Caio não responderá por tentativa de homicídio, mas sim apenas pelas lesões corporais causadas.",
        "Trata-se do instituto da Desistência Voluntária ou do Arrependimento Eficaz, previsto no Artigo 15 do Código Penal."
      ],
      espelhoCorrecao: "O candidato deve esclarecer que o réu não responderá por homicídio tentado (0,35 pt). Deve citar que se trata do instituto do arrependimento eficaz/desistência voluntária disposto no Artigo 15 do Código Penal (0,45 pt). Deve explicitar que a consequência jurídica é que o agente só responde pelos atos já praticados (lesão corporal no caso), restando afastada a punição pelo crime inicialmente cogitado de homicídio (0,45 pt).",
      professorObservations: "A distinção crucial é a frase clássica: 'Quero prosseguir, mas não posso' (tentativa) versus 'Posso prosseguir, mas não quero' (desistência). No arrependimento eficaz, o agente esgota os atos executórios, mas atua positivamente para impedir o resultado."
    }
  ],
  "Direito Civil": [
    {
      id: "civil-d-1",
      area: "Direito Civil",
      theme: "Bens e Usucapião Extraordinário",
      difficulty: "Média",
      title: "Questão 1 - Usucapião de Imóvel Abandonado",
      statement: "João possui de forma mansa, pacífica e ininterrupta, há 12 anos, um terreno urbano de 350m² onde construiu sua moradia habitual. O imóvel originalmente pertencia a Marcos, que abandonou a propriedade ao mudar-se para o exterior e nunca contestou a posse de João. No entanto, João não possui justo título ou boa-fé subjetiva documentada. Diante do caso narrado, é juridicamente possível que João adquira a propriedade do bem por meio de usucapião? Indique os requisitos legais e a modalidade cabível de acordo com o Código Civil brasileiro.",
      expectedTeses: [
        "Sim, é possível a aquisição da propriedade por meio de usucapião ordinária ou extraordinária reduzida.",
        "Fundamenta-se no artigo 1.238, parágrafo único do Código Civil (usucapião extraordinária por moradia habitual com prazo reduzido para 10 anos)."
      ],
      espelhoCorrecao: "O candidato deve asseverar a viabilidade da usucapião (0,30 pt). Deve enquadrar a situação na modalidade de Usucapião Extraordinária Reduzida por estabelecimento de morada habitual, fundamentando com base no Artigo 1.238, parágrafo único do Código Civil de 2002 (0,55 pt). Deve consignar que tal modalidade dispensa justo título e boa-fé, exigindo apenas a posse qualificada mansa pelo prazo de 10 anos (0,40 pt).",
      professorObservations: "O usucapião extraordinário geral exige 15 anos de posse (art. 1.238, caput), contudo o prazo reduz-se a 10 anos caso o possuidor tenha estabelecido no imóvel sua moradia habitual ou realizado obras/serviços produtivos (art. 1.238, parágrafo único). Atente para essa redução!"
    }
  ],
  "Direito Constitucional": [
    {
      id: "const-d-1",
      area: "Direito Constitucional",
      theme: "Processo Legislativo e Competência Privativa",
      difficulty: "Média",
      title: "Questão 1 - Competência Legislativa e Trânsito",
      statement: "A Assembleia Legislativa do Estado Alfa edita lei estadual que torna obrigatório o uso de películas refletivas protetoras em todos os veículos automotores emplacados naquele Estado federado, fixando multa administrativa para os motoristas que descumprirem. O Governador do Estado veta o projeto alegando vício de iniciativa constitucional. Os deputados rejeitam o veto e promulgam a lei. Diante das regras de repartição de competências da CF/88, tal lei estadual é constitucional? Justifique apontando o respectivo vício e fundamentação.",
      expectedTeses: [
        "A lei estadual é formalmente inconstitucional por vício de competência legislativa privativa.",
        "Compete privativamente à União legislar sobre trânsito e transporte (Art. 22, inciso XI da CF/88)."
      ],
      espelhoCorrecao: "O candidato deve responder negativamente quanto à constitucionalidade da lei (0,30 pt). Deve demonstrar que o trânsito e transporte são matérias reservadas à competência privativa de legislar da União, conforme preceitua o Artigo 22, inciso XI da CF (0,65 pt). A invasão da competência privativa por lei de estado-membro acarreta inconstitucionalidade formal orgânica insanável (0,30 pt).",
      professorObservations: "Tópico de direito constitucional básico e recorrente na prova da OAB. A distribuição de competências do Artigo 22 (União) e Artigo 24 (concorrente) deve estar marcada com cores fortes no seu Vade Mecum para consulta rápida."
    }
  ],
  "Direito Administrativo": [
    {
      id: "admin-d-1",
      area: "Direito Administrativo",
      theme: "Serviços Públicos e Concessões",
      difficulty: "Difícil",
      title: "Questão 1 - encampação de Serviço Concedido",
      statement: "O Município de Beta, alegando razões de interesse público relevante e visando prestar diretamente o serviço de coleta de resíduos sólidos urbanos, decreta de forma unilateral a retomada do serviço antes do prazo contratual expirar, rescindindo a concessão que pertencia à empresa Limpar Ltda. A concessionária alega que a prefeitura não realizou o pagamento de indenização prévia e que não houve lei autorizativa específica dos vereadores. Há ilegalidade na conduta do prefeito? Qual é o instituto jurídico aplicado de acordo com as normas de concessão pública?",
      expectedTeses: [
        "Sim, há ilegalidade na conduta do Prefeito.",
        "Trata-se de Encampação, que exige lei autorizativa específica do poder concedente e indenização prévia em dinheiro (Art. 37 da Lei 8.987/95)."
      ],
      espelhoCorrecao: "O candidato deve reconhecer a presença de ilegalidades na atuação do gestor público municipal (0,30 pt). Deve apontar que a retomada unilateral por interesse público denomina-se Encampação (0,40 pt). Deve fundamentar indicando que nos termos do Artigo 37 da Lei nº 8.987/1995, a encampação pressupõe lei autorizativa específica municipal e o pagamento prévio de indenização das parcelas de investimentos não amortizados (0,55 pt).",
      professorObservations: "Não confunda encampação (retomada por interesse público, exige lei e indenização prévia) com caducidade (retomada por descumprimento contratual da concessionária, não exige lei e a indenização ocorre a posteriori deduzidas as multas)."
    }
  ],
  "Direito Tributário": [
    {
      id: "trib-d-1",
      area: "Direito Tributário",
      theme: "Anterioridade Tributária e Noventena",
      difficulty: "Difícil",
      title: "Questão 1 - Anterioridade e Alíquota de ICMS",
      statement: "No dia 15 de novembro de 2025, o Governador de determinado Estado edita decreto de alteração aumentando em 3% as alíquotas do ICMS incidente sobre energia elétrica de consumo residencial, publicando-o no diário oficial na mesma data. O decreto prevê expressamente que as novas alíquotas entrarão em vigor no dia 1º de janeiro de 2026. Tal cobrança a partir da data estipulada é constitucional? Fundamente sua resposta de acordo com as limitações constitucionais do poder de tributar.",
      expectedTeses: [
        "A cobrança a partir de 1º de janeiro de 2026 é inconstitucional por ferir o princípio da anterioridade nonagesimal.",
        "Exige-se o cumprimento cumulativo da anterioridade anual (exercício financeiro seguinte) e da anterioridade de 90 dias (noventena), conforme Art. 150, III, 'b' e 'c' da CF/88."
      ],
      espelhoCorrecao: "O candidato deve assentar a inconstitucionalidade do prazo de vigência estabelecido no decreto tributário estadual (0,30 pt). Deve expor que o aumento de alíquota do ICMS submete-se cumulativamente ao princípio da anterioridade anual e nonagesimal (0,45 pt). De 15 de novembro a 1º de janeiro decorrem apenas cerca de 45 dias, inviabilizando a exigência e obrigando o estado a postergar a cobrança para após 15 de fevereiro de 2026, cumprindo os 90 dias completos do Artigo 150, III, 'c' da CF (0,50 pt).",
      professorObservations: "O ICMS possui algumas exceções à anterioridade (ex: ICMS combustíveis monofásicos afasta a anterioridade de exercício, mas respeita noventena). No caso de alteração genérica de alíquota, aplica-se a cumulação plena de exercício e noventena. Memorize essa barreira!"
    }
  ],
  "Direito Empresarial": [
    {
      id: "emp-d-1",
      area: "Direito Empresarial",
      theme: "Sociedades Limitadas e Exclusão de Sócio",
      difficulty: "Média",
      title: "Questão 1 - Exclusão de Sócio Minoritário por Justa Causa",
      statement: "Rodrigo e Marcos são sócios na empresa Comercial de Bebidas Ltda., detendo Rodrigo 70% do capital social e Marcos os 30% restantes. Rodrigo descobre que Marcos está desviando mercadorias em benefício de empresa concorrente de sua propriedade pessoal, configurando quebra grave de dever social. Rodrigo convoca reunião de sócios extraordinária e, por votação unilateral, exclui Marcos da sociedade registrando a alteração na Junta Comercial. O contrato social prevê expressamente a exclusão extrajudicial por justa causa. A conduta de Rodrigo respeitou as regras societárias do Código Civil brasileiro?",
      expectedTeses: [
        "Não, a conduta de Rodrigo violou as disposições legais mínimas para exclusão extrajudicial de sócio minoritário.",
        "Exige-se a realização de assembleia ou reunião convocada especificamente e garantia do direito de defesa prévia ao sócio acusado (Artigo 1.085 do Código Civil)."
      ],
      espelhoCorrecao: "O candidato deve responder negativamente quanto à plena legalidade do ato expulsório sumário (0,30 pt). Deve demonstrar que nos termos do Artigo 1.085, parágrafo único do Código Civil, a exclusão por justa causa de sócio em sociedade de apenas dois sócios (ou com minoritário detentor de menos da metade) exige indispensavelmente a convocação prévia específica para dar oportunidade de ampla defesa e manifestação ao sócio visado (0,95 pt).",
      professorObservations: "A quebra do afeto societário ('affectio societatis') possibilita a exclusão do sócio, contudo a lei impõe o devido processo legal privado garantindo o direito de defesa prévia extrajudicial antes do registro de exclusão sob pena de nulidade absoluta."
    }
  ]
};

// Simulated Exams database with Piece + 4 Discursive items per area
export const PHASE2_SIMULADOS_BY_AREA: { [area: string]: Phase2Simulado[] } = {
  "Direito do Trabalho": [
    {
      id: "trab-s-1",
      title: "Simulado 1 - Reta Final Ordinário",
      area: "Direito do Trabalho",
      tempoEstimado: "5 horas",
      dificuldade: "Média",
      pecaEnunciado: "José trabalhou na empresa Alpha de 2018 a 2024 na função de supervisor de produção. Cumpria jornada de segunda a sexta, das 8h às 19h, com apenas 30 minutos de intervalo para repouso e alimentação, não recebendo compensação de horas. Foi demitido por justa causa sob alegação genérica de insubordinação, contudo José afirma que o suposto ato foi apenas uma discussão amigável sobre diretrizes técnicas de maquinário com o gerente geral. No ato da rescisão, a empresa não quitou as verbas rescisórias básicas, tampouco a multa decorrente do atraso. Proponha a medida judicial cabível para reverter a dispensa e obter as verbas inerentes de direito material.",
      questoesEnunciados: [
        "1. É cabível o pedido de reintegração provisória de dirigente sindical que comete falta funcional sem inquérito judicial prévio? Fundamente.",
        "2. Como se divide o ônus da prova em matéria de jornada extraordinária quando o empregador possui mais de 20 colaboradores e não apresenta os cartões de ponto no processo?",
        "3. A contribuição previdenciária patronal calculada sobre as parcelas indenizatórias deferidas em sentença trabalhista é devida pelo reclamado? Fundamente.",
        "4. Em sede de rito sumaríssimo trabalhista, é viável a citação da reclamada por meio de edital público? Indique o regramento da CLT."
      ],
      pecaGabarito: "A peça cabível é uma RECLAMAÇÃO TRABALHISTA fundamentada no Art. 840, § 1º da CLT. Principais teses de mérito: a) Afastamento da Justa Causa: a insubordinação deve ser grave e provada pelo empregador. Meras divergências técnicas não configuram falta grave, ensejando a conversão em dispensa sem justa causa com pagamento de aviso prévio indenizado, multa de 40% do FGTS e liberação de guias. b) Horas Extras pela jornada suplementar além de 8h/44h semanais. c) Intervalo intrajornada: indenização de 1 hora/período suprimido acrescido de 50% (Art. 71, § 4º da CLT). d) Multa do art. 477 da CLT por atraso na quitação rescisória.",
      questoesGabaritos: [
        "1. Não, o dirigente sindical goza de estabilidade provisória e só pode ser despedido mediante a apuração de falta grave através de Inquérito Judicial para Apuração de Falta Grave (Art. 853 da CLT e Súmula 379 do TST).",
        "2. O ônus de registrar a jornada pertence ao empregador que possui mais de 20 trabalhadores. A não apresentação injustificada dos controles gera presunção relativa de veracidade da jornada alegada na exordial (Súmula 338, I do TST).",
        "3. Não. As parcelas de caráter puramente indenizatório (ex: aviso prévio indenizado, férias indenizadas, multas) não integram o salário de contribuição, estando isentas de contribuição previdenciária nos termos do art. 28 da Lei 8.212/91.",
        "4. Não. No rito sumaríssimo trabalhista, não se admite a citação por edital, incumbindo ao reclamante a indicação correta do nome e endereço do reclamado, sob pena de arquivamento sumário do feito (Art. 852-B, II da CLT)."
      ]
    }
  ],
  "Direito Penal": [
    {
      id: "penal-s-1",
      title: "Simulado 1 - Reta Final Penal",
      area: "Direito Penal",
      tempoEstimado: "5 horas",
      dificuldade: "Difícil",
      pecaEnunciado: "O Ministério Público ofereceu denúncia em face de Marcos imputando-lhe o crime de Roubo Majorado pelo emprego de arma de fogo de uso permitido (Art. 157, § 2º-A, I, do CP). Narra a exordial acusatória que Marcos subtraiu um relógio mediante grave ameaça. Durante a instrução processual na audiência una, a vítima não reconheceu Marcos pessoalmente e os policiais confessaram que prenderam Marcos em flagrante de posse de um revólver comum, mas que não encontraram o relógio da vítima. Ao final da audiência, o juiz abriu prazo de 5 dias sucessivos para a manifestação escrita das partes por tratar-se de caso complexo de instrução. Redija a peça defensiva cabível.",
      questoesEnunciados: [
        "1. É possível a aplicação do princípio da insignificância ao crime de roubo próprio? Fundamente conforme súmulas do STJ.",
        "2. A condenação penal transitada em julgado por fato cometido posteriormente ao delito em julgamento serve para caracterizar maus antecedentes na primeira fase da dosimetria? Justifique.",
        "3. No crime de furto qualificado por rompimento de obstáculo, a ausência de laudo pericial técnico pode ser suprida unicamente pela prova testemunhal de vizinhos? Indique as normas do CPP.",
        "4. Qual é o recurso cabível contra decisão de juiz que rejeita sumariamente a denúncia oferecida pelo Ministério Público no procedimento comum? Fundamente."
      ],
      pecaGabarito: "A peça cabível é MEMORIAIS DEFENSIVOS substitutivos de alegações finais orais (Art. 403, § 3º, do CPP). Principais teses: a) Absolvição por insuficiência de provas (Art. 386, VII, CPP) haja vista a vítima não ter efetuado o reconhecimento do réu. b) Desclassificação de roubo majorado para furto comum se demonstrada ausência de grave ameaça fática direta à pessoa. c) Fixação da pena-base no mínimo legal em caso de eventual condenação, afastamento de maus antecedentes e imposição de regime aberto.",
      questoesGabaritos: [
        "1. Não. Conforme Súmula 589 do STJ e pacífico entendimento dos tribunais superiores, os crimes cometidos com violência ou grave ameaça à pessoa obstam terminantemente a concessão do princípio da insignificância.",
        "2. Não. O cometimento de crime posterior não caracteriza maus antecedentes, tampouco reincidência, visto que estas circunstâncias exigem trânsito em julgado de crime pretérito à data da conduta analisada (Súmula 444 do STJ).",
        "3. Não. O rompimento de obstáculo deixa vestígios materiais, sendo indispensável o exame de corpo de delito direto ou indireto, não podendo ser suprido por testemunhas salvo se os vestígios desaparecerem por completo (Art. 158 e 167 do CPP).",
        "4. Contra a rejeição da denúncia cabe Recurso em Sentido Estrito (RESE), fundamentado no Artigo 581, inciso I, do Código de Processo Penal."
      ]
    }
  ]
};
