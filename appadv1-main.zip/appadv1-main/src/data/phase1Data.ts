/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Discipline, Lecture, PDFMaterial, Question } from '../types';

export interface Phase1DisciplineModule {
  id: string;
  title: string;
  description: string;
}

export interface DisciplineReviewItem {
  id: string;
  type: '24h' | '7d' | '30d' | 'erros';
  title: string;
  status: 'pendente' | 'em_dia' | 'atrasado';
  dueDate: string;
}

export interface DisciplineMiniSimulado {
  id: string;
  title: string;
  totalQuestions: number;
  timeLimitMinutes: number;
  completed: boolean;
  score?: number;
}

export interface EnrichedDiscipline extends Discipline {
  modules: Phase1DisciplineModule[];
  reviews: DisciplineReviewItem[];
  miniSimulados: DisciplineMiniSimulado[];
  recommendedOrder: number; // For pedagogical ordering (strategic first)
}

export const FULL_DISCIPLINES: EnrichedDiscipline[] = [
  {
    id: "disc-etica",
    name: "Ética Profissional",
    icon: "ShieldAlert",
    importance: "Muito Alta",
    totalQuestions: 8,
    recommendedOrder: 1,
    modules: [
      { id: "mod-1", title: "Introdução / Visão Geral", description: "Visão geral sobre as prerrogativas e o mercado da advocacia" },
      { id: "mod-2", title: "Bloco Teórico 1: Prerrogativas", description: "Regras do artigo 7º do EAOAB e inviolabilidade" },
      { id: "mod-3", title: "Bloco Teórico 2: Sanções e Processos", description: "Infrações e sanções disciplinares aplicáveis" },
      { id: "mod-4", title: "Bloco Teórico 3: Sociedade e Honorários", description: "Organização da atividade e regulação de honorários" },
      { id: "mod-5", title: "Questões Comentadas", description: "Bateria de questões históricas da banca FGV comentadas" },
      { id: "mod-6", title: "Revisão Final", description: "Pontos críticos de véspera para gabaritar Ética" }
    ],
    lectures: [
      { id: "l-etica-1", title: "Estrutura e Órgãos da OAB", duration: "32:40", summary: "Análise completa do Conselho Federal, Conselhos Seccionais, Subseções e Caixas de Assistência (CAA). Principais regras de composição e competências exclusivas." },
      { id: "l-etica-2", title: "Direitos e Prerrogativas do Advogado", duration: "45:15", summary: "Estudo detalhado do art. 7º do Estatuto. Inviolabilidade do escritório, comunicação reservada com cliente preso, presença de representante em caso de prisão, e desagravo público." },
      { id: "l-etica-3", title: "Infrações e Sanções Disciplinares", duration: "38:20", summary: "Comportamentos que configuram falta ética. Diferenciação das sanções de Censura, Suspensão, Exclusão e Multa. Circunstâncias atenuantes e regras de reincidência." },
      { id: "l-etica-4", title: "Honorários Advocatícios e Sociedades", duration: "28:10", summary: "Análise das espécies de honorários (contratuais, sucumbenciais, arbitrados). Regras para constituição de sociedades simples e unipessoais de advocacia." }
    ],
    pdfs: [
      { id: "pdf-etica-1", title: "Super Resumo: Prerrogativas e Ética OAB", pageCount: 15, summary: "Compilado esquematizado contendo tabelas comparativas das prerrogativas profissionais e principais infrações disciplinares cobradas pela banca." },
      { id: "pdf-etica-2", title: "Mapa Mental: Órgãos da OAB e Competências", pageCount: 3, summary: "Fluxograma visual de competências exclusivas do Conselho Federal e das Seccionais." },
      { id: "pdf-etica-3", title: "Checklist de Ética: Temas Indispensáveis", pageCount: 5, summary: "Lista de verificação rápida contendo 20 tópicos cruciais que sempre caem na primeira fase." }
    ],
    reviews: [
      { id: "rev-etica-24h", type: "24h", title: "Prerrogativas do Advogado", status: "em_dia", dueDate: "Hoje" },
      { id: "rev-etica-7d", type: "7d", title: "Sanções Disciplinares", status: "pendente", dueDate: "Em 3 dias" },
      { id: "rev-etica-30d", type: "30d", title: "Órgãos da OAB", status: "pendente", dueDate: "Em 12 dias" },
      { id: "rev-etica-erros", type: "erros", title: "Revisão de Erros: Honorários e Sociedades", status: "atrasado", dueDate: "Atrasado" }
    ],
    miniSimulados: [
      { id: "sim-etica-1", title: "Simulado Temático - Prerrogativas Básicas", totalQuestions: 8, timeLimitMinutes: 15, completed: true, score: 7 },
      { id: "sim-etica-2", title: "Simulado Geral - Estatuto e Código de Ética", totalQuestions: 15, timeLimitMinutes: 30, completed: false }
    ]
  },
  {
    id: "disc-const",
    name: "Direito Constitucional",
    icon: "BookOpen",
    importance: "Muito Alta",
    totalQuestions: 6,
    recommendedOrder: 2,
    modules: [
      { id: "mod-const-1", title: "Introdução / Visão Geral", description: "Conceitos fundamentais da Constituição e classificação das normas" },
      { id: "mod-const-2", title: "Bloco Teórico 1: Controle de Constitucionalidade", description: "Controle difuso e concentrado de constitucionalidade" },
      { id: "mod-const-3", title: "Bloco Teórico 2: Direitos Individuais", description: "Artigo 5º da CF/88 e remédios constitucionais" },
      { id: "mod-const-4", title: "Bloco Teórico 3: Organização dos Poderes", description: "Poder Legislativo, Executivo e Judiciário e Processo Legislativo" },
      { id: "mod-const-5", title: "Questões Comentadas", description: "Questões de controle de constitucionalidade aplicadas" },
      { id: "mod-const-6", title: "Revisão Final", description: "Revisão rápida de competências e processo legislativo" }
    ],
    lectures: [
      { id: "l-const-1", title: "Controle de Constitucionalidade: Difuso vs Concentrado", duration: "52:10", summary: "Análise da supremacia da Constituição. Legitimados ativos do artigo 103, objeto do controle concentrado e efeitos (ex tunc, ex nunc, erga omnes) das decisões do STF." },
      { id: "l-const-2", title: "Remédios Constitucionais e Direitos Individuais", duration: "41:30", summary: "Aplicações práticas do Habeas Corpus, Mandado de Segurança (individual e coletivo), Habeas Data, Mandado de Injunção e Ação Popular. Casuística recorrente da FGV." },
      { id: "l-const-3", title: "Processo Legislativo Constitucional", duration: "38:45", summary: "Tipos de leis, iniciativa privativa, fases do processo legislativo. Regras de tramitação de Emendas Constitucionais (PEC), Leis Complementares e Ordinárias." }
    ],
    pdfs: [
      { id: "pdf-const-1", title: "Guia Definitivo do Controle de Constitucionalidade", pageCount: 22, summary: "Material didático aprofundado com as diferenças práticas entre ADI, ADC, ADO e ADPF, com ênfase na jurisprudência do STF." },
      { id: "pdf-const-2", title: "Mapa Mental: Processo Legislativo", pageCount: 4, summary: "Esquema visual detalhado sobre as fases deliberativa, executiva e de promulgação das leis." }
    ],
    reviews: [
      { id: "rev-const-24h", type: "24h", title: "Controle de Constitucionalidade", status: "em_dia", dueDate: "Hoje" },
      { id: "rev-const-7d", type: "7d", title: "Remédios Constitucionais", status: "em_dia", dueDate: "Hoje" },
      { id: "rev-const-30d", type: "30d", title: "Processo Legislativo", status: "pendente", dueDate: "Em 8 dias" },
      { id: "rev-const-erros", type: "erros", title: "Revisão de Erros: Repartição de Competências", status: "atrasado", dueDate: "Atrasado" }
    ],
    miniSimulados: [
      { id: "sim-const-1", title: "Mini-Simulado: Remédios Constitucionais", totalQuestions: 6, timeLimitMinutes: 12, completed: true, score: 5 },
      { id: "sim-const-2", title: "Simulado Completo: Controle de Constitucionalidade", totalQuestions: 10, timeLimitMinutes: 20, completed: false }
    ]
  },
  {
    id: "disc-adm",
    name: "Direito Administrativo",
    icon: "Building",
    importance: "Muito Alta",
    totalQuestions: 6,
    recommendedOrder: 3,
    modules: [
      { id: "mod-adm-1", title: "Introdução / Visão Geral", description: "Princípios do Direito Administrativo e Organização da Administração" },
      { id: "mod-adm-2", title: "Bloco Teórico 1: Licitações e Contratos", description: "Nova Lei de Licitações (Lei 14.133/21) e contratos administrativos" },
      { id: "mod-adm-3", title: "Bloco Teórico 2: Agentes Públicos", description: "Regime jurídico, responsabilidades e improbidade administrativa" },
      { id: "mod-adm-4", title: "Bloco Teórico 3: Atos e Intervenção", description: "Atributos do ato administrativo e intervenção estatal na propriedade" },
      { id: "mod-adm-5", title: "Questões Comentadas", description: "Questões comentadas sobre a Lei 14.133/21" },
      { id: "mod-adm-6", title: "Revisão Final", description: "Revisão de serviços públicos, concessões e improbidade" }
    ],
    lectures: [
      { id: "l-adm-1", title: "Nova Lei de Licitações (Lei 14.133/21)", duration: "48:30", summary: "Análise das novas modalidades de licitação (ênfase no Diálogo Competitivo), critérios de julgamento, dispensa e inexigibilidade de licitação." },
      { id: "l-adm-2", title: "Organização Administrativa e Terceiro Setor", duration: "35:10", summary: "Estudo da Administração Direta e Indireta (Autarquias, Fundações, Empresas Públicas e Sociedades de Economia Mista). Entidades do Terceiro Setor (OS e OSCIP)." },
      { id: "l-adm-3", title: "Atos Administrativos: Requisitos e Atributos", duration: "42:15", summary: "Os cinco requisitos de validade (Competência, Finalidade, Forma, Motivo, Objeto). Atributos essenciais do ato: Presunção de Legitimidade, Imperatividade, Autoexecutoriedade e Tipicidade." }
    ],
    pdfs: [
      { id: "pdf-adm-1", title: "Tabela Resumo: Licitações (Lei 14.133/21)", pageCount: 18, summary: "Quadro comparativo de modalidades, prazos, fases e hipóteses de contratação direta na nova lei." },
      { id: "pdf-adm-2", title: "Esquema: Improbidade Administrativa Reformada", pageCount: 8, summary: "Resumo das alterações trazidas pela Lei 14.230/21 na Lei de Improbidade Administrativa." }
    ],
    reviews: [
      { id: "rev-adm-24h", type: "24h", title: "Nova Lei de Licitações", status: "pendente", dueDate: "Hoje" },
      { id: "rev-adm-7d", type: "7d", title: "Organização Administrativa", status: "pendente", dueDate: "Em 4 dias" },
      { id: "rev-adm-30d", type: "30d", title: "Atos Administrativos", status: "pendente", dueDate: "Em 15 dias" },
      { id: "rev-adm-erros", type: "erros", title: "Revisão de Erros: Improbidade", status: "atrasado", dueDate: "Atrasado" }
    ],
    miniSimulados: [
      { id: "sim-adm-1", title: "Mini-Simulado: Atos Administrativos", totalQuestions: 6, timeLimitMinutes: 12, completed: false },
      { id: "sim-adm-2", title: "Simulado Temático: Licitações e Parcerias", totalQuestions: 8, timeLimitMinutes: 16, completed: false }
    ]
  },
  {
    id: "disc-civil",
    name: "Direito Civil",
    icon: "Users",
    importance: "Alta",
    totalQuestions: 6,
    recommendedOrder: 4,
    modules: [
      { id: "mod-civil-1", title: "Introdução / Visão Geral", description: "Parte Geral do Código Civil e LINDB" },
      { id: "mod-civil-2", title: "Bloco Teórico 1: Obrigações e Contratos", description: "Teoria geral e contratos em espécie mais recorrentes" },
      { id: "mod-civil-3", title: "Bloco Teórico 2: Direitos Reais", description: "Propriedade, posse e usucapião" },
      { id: "mod-civil-4", title: "Bloco Teórico 3: Família e Sucessões", description: "Casamento, regimes de bens, sucessão legítima e testamentária" },
      { id: "mod-civil-5", title: "Questões Comentadas", description: "Casos fáticos da FGV comentados de Obrigações" },
      { id: "mod-civil-6", title: "Revisão Final", description: "Revisão de prazos prescricionais e vocação hereditária" }
    ],
    lectures: [
      { id: "l-civil-1", title: "LINDB - Vigência, Integração e Conflito de Leis", duration: "31:10", summary: "Análise sistemática da Lei de Introdução às Normas do Direito Brasileiro. Critérios de vigência, vacatio legis, antinomias e aplicação de leis no tempo e espaço." },
      { id: "l-civil-2", title: "Teoria Geral dos Negócios Jurídicos e Defeitos", duration: "48:50", summary: "Análise dos vícios de consentimento (Erro, Dolo, Coação, Estado de Perigo, Lesão) e sociais (Fraude contra Credores, Simulação). Efeitos decorrentes da invalidade." },
      { id: "l-civil-3", title: "Direito das Sucessões: Vocação Hereditária", duration: "40:22", summary: "Ordem de vocação hereditária (Art. 1829 CC). Concorrência de cônjuge/companheiro com descendentes e ascendentes nos regimes de bens." }
    ],
    pdfs: [
      { id: "pdf-civil-1", title: "Resumo Prático: Vícios dos Negócios Jurídicos", pageCount: 12, summary: "Tabela indicando prazos decadenciais de anulação, requisitos e consequências legais de cada vício." },
      { id: "pdf-civil-2", title: "Guia Visual: Sucessão Legítima OAB", pageCount: 6, summary: "Diagrama interativo simulando a distribuição de quinhões hereditários na prática." }
    ],
    reviews: [
      { id: "rev-civil-24h", type: "24h", title: "Negócios Jurídicos", status: "em_dia", dueDate: "Hoje" },
      { id: "rev-civil-7d", type: "7d", title: "LINDB e Vigência", status: "em_dia", dueDate: "Hoje" },
      { id: "rev-civil-30d", type: "30d", title: "Direito de Família", status: "pendente", dueDate: "Em 10 dias" },
      { id: "rev-civil-erros", type: "erros", title: "Revisão de Erros: Usucapião", status: "em_dia", dueDate: "Hoje" }
    ],
    miniSimulados: [
      { id: "sim-civil-1", title: "Mini-Simulado: Parte Geral", totalQuestions: 6, timeLimitMinutes: 12, completed: true, score: 4 },
      { id: "sim-civil-2", title: "Simulado Geral: Família e Sucessões", totalQuestions: 10, timeLimitMinutes: 20, completed: false }
    ]
  },
  {
    id: "disc-proc-civil",
    name: "Processo Civil",
    icon: "Scale",
    importance: "Alta",
    totalQuestions: 6,
    recommendedOrder: 5,
    modules: [
      { id: "mod-pc-1", title: "Introdução / Visão Geral", description: "Princípios processuais fundamentais e normas fundamentais" },
      { id: "mod-pc-2", title: "Bloco Teórico 1: Fase de Conhecimento", description: "Petição inicial, audiência, contestação e providências preliminares" },
      { id: "mod-pc-3", title: "Bloco Teórico 2: Recursos no CPC/15", description: "Apelação, agravo de instrumento, embargos e recursos aos tribunais superiores" },
      { id: "mod-pc-4", title: "Bloco Teórico 3: Execução e Tutelas", description: "Tutelas de urgência, evidência e cumprimento de sentença" },
      { id: "mod-pc-5", title: "Questões Comentadas", description: "Análise de prazos recursais em questões da banca" },
      { id: "mod-pc-6", title: "Revisão Final", description: "Revisão sistemática de prazos e preclusões" }
    ],
    lectures: [
      { id: "l-pc-1", title: "Teoria Geral dos Recursos e Apelação", duration: "49:20", summary: "Princípios recursais, efeitos devolutivo e suspensivo, juízo de admissibilidade e mérito. Regras gerais e exceções da apelação no CPC/15." },
      { id: "l-pc-2", title: "Agravo de Instrumento e o Rol do Art. 1.015", duration: "38:40", summary: "Estudo minucioso das hipóteses de cabimento do agravo de instrumento. A tese da taxatividade mitigada definida pelo STJ e prazos." },
      { id: "l-pc-3", title: "Tutelas de Urgência e de Evidência", duration: "41:15", summary: "Tutela antecipada e cautelar (antecedente e incidental). Requisitos de fumus boni iuris e periculum in mora. Hipóteses objetivas da tutela de evidência." }
    ],
    pdfs: [
      { id: "pdf-pc-1", title: "Esquema Geral de Recursos e Prazos CPC", pageCount: 16, summary: "Compilado com fluxogramas de todos os recursos cíveis, prazos em dias úteis e hipóteses de cabimento." },
      { id: "pdf-pc-2", title: "Resumo Prático: Respostas do Réu no CPC", pageCount: 10, summary: "Guia rápido sobre a Contestação, Reconvenção e exceções de incompetência ou ilegitimidade." }
    ],
    reviews: [
      { id: "rev-pc-24h", type: "24h", title: "Teoria dos Recursos", status: "pendente", dueDate: "Hoje" },
      { id: "rev-pc-7d", type: "7d", title: "Agravo de Instrumento", status: "pendente", dueDate: "Em 5 dias" },
      { id: "rev-pc-30d", type: "30d", title: "Tutelas de Urgência", status: "pendente", dueDate: "Em 14 dias" },
      { id: "rev-pc-erros", type: "erros", title: "Revisão de Erros: Contestação", status: "atrasado", dueDate: "Atrasado" }
    ],
    miniSimulados: [
      { id: "sim-pc-1", title: "Mini-Simulado: Procedimento Comum", totalQuestions: 6, timeLimitMinutes: 12, completed: false },
      { id: "sim-pc-2", title: "Simulado Geral: Recursos Cíveis", totalQuestions: 8, timeLimitMinutes: 16, completed: false }
    ]
  },
  {
    id: "disc-penal",
    name: "Direito Penal",
    icon: "ShieldAlert",
    importance: "Alta",
    totalQuestions: 6,
    recommendedOrder: 6,
    modules: [
      { id: "mod-penal-1", title: "Introdução / Visão Geral", description: "Princípios do Direito Penal e Aplicação da Lei" },
      { id: "mod-penal-2", title: "Bloco Teórico 1: Teoria do Crime", description: "Fato típico, ilicitude, culpabilidade e causas excludentes" },
      { id: "mod-penal-3", title: "Bloco Teórico 2: Penas e Dosimetria", description: "Cálculo da pena privativa de liberdade e substitutivas" },
      { id: "mod-penal-4", title: "Bloco Teórico 3: Crimes em Espécie", description: "Crimes contra a pessoa, patrimônio e administração pública" },
      { id: "mod-penal-5", title: "Questões Comentadas", description: "Questões de teoria do erro e concurso de pessoas" },
      { id: "mod-penal-6", title: "Revisão Final", description: "Revisão de prescrição penal e causas de extinção da punibilidade" }
    ],
    lectures: [
      { id: "l-penal-1", title: "Aplicação da Lei Penal no Tempo e Espaço", duration: "29:45", summary: "Princípios de irretroatividade da lei penal gravosa. Ultratividade da norma benigna. Teoria do crime continuado e crime permanente frente a novas leis." },
      { id: "l-penal-2", title: "Teoria do Crime: Erros e Consequências", duration: "44:18", summary: "Diferenciação clara entre Erro de Tipo (essencial e acidental) e Erro de Proibição. Erro sobre a pessoa, erro na execução e resultado diverso do pretendido." },
      { id: "l-penal-3", title: "Dosimetria da Pena nas Provas da OAB", duration: "51:02", summary: "O critério trifásico de Nelson Hungria. Circunstâncias judiciais, agravantes/atenuantes (reincidência e menoridade), causas de aumento e diminuição." }
    ],
    pdfs: [
      { id: "pdf-penal-1", title: "Manual Prático de Teoria do Crime", pageCount: 25, summary: "Esquema explicativo de todos os elementos integrantes do fato típico, ilicitude e culpabilidade." },
      { id: "pdf-penal-2", title: "Resumo de Bolso: Prescrição Penal", pageCount: 8, summary: "Tabela e fórmulas rápidas para calcular a prescrição da pretensão punitiva (médio, abstrato e retroativo)." }
    ],
    reviews: [
      { id: "rev-penal-24h", type: "24h", title: "Aplicação da Lei Penal", status: "em_dia", dueDate: "Hoje" },
      { id: "rev-penal-7d", type: "7d", title: "Teoria do Crime e Erros", status: "em_dia", dueDate: "Hoje" },
      { id: "rev-penal-30d", type: "30d", title: "Crimes contra o Patrimônio", status: "pendente", dueDate: "Em 7 dias" },
      { id: "rev-penal-erros", type: "erros", title: "Revisão de Erros: Dosimetria", status: "em_dia", dueDate: "Hoje" }
    ],
    miniSimulados: [
      { id: "sim-penal-1", title: "Mini-Simulado: Teoria do Crime", totalQuestions: 6, timeLimitMinutes: 12, completed: true, score: 5 },
      { id: "sim-penal-2", title: "Simulado Geral: Crimes contra a Vida", totalQuestions: 10, timeLimitMinutes: 20, completed: false }
    ]
  },
  {
    id: "disc-proc-penal",
    name: "Processo Penal",
    icon: "FolderClosed",
    importance: "Alta",
    totalQuestions: 6,
    recommendedOrder: 7,
    modules: [
      { id: "mod-pp-1", title: "Introdução / Visão Geral", description: "Inquérito policial e ação penal pública e privada" },
      { id: "mod-pp-2", title: "Bloco Teórico 1: Provas e Medidas", description: "Teoria geral das provas, busca e apreensão, interceptação" },
      { id: "mod-pp-3", title: "Bloco Teórico 2: Prisão e Liberdade", description: "Prisão em flagrante, preventiva, temporária e medidas cautelares" },
      { id: "mod-pp-4", title: "Bloco Teórico 3: Recursos Criminais", description: "Apelação, RESE, embargos e habeas corpus como ação autônoma" },
      { id: "mod-pp-5", title: "Questões Comentadas", description: "Prazos recursais do CPP em questões práticas" },
      { id: "mod-pp-6", title: "Revisão Final", description: "Revisão de competência penal e ritos (comum e especial do júri)" }
    ],
    lectures: [
      { id: "l-pp-1", title: "Prisões Cautelares: Requisitos e Decretração", duration: "46:15", summary: "Estudo detalhado da prisão preventiva (art. 312 e 313 do CPP), flagrante e prisão temporária. Medidas cautelares alternativas introduzidas pela lei." },
      { id: "l-pp-2", title: "Recursos Criminais: Apelação e RESE", duration: "53:40", summary: "Regras de cabimento, legitimação e prazos para interposição e razões de Apelação Penal e Recurso em Sentido Estrito. Hipóteses do art. 581 do CPP." },
      { id: "l-pp-3", title: "Inquérito Policial e Ação Penal", duration: "32:10", summary: "Características do inquérito (sigilo, inquisitividade, dispensabilidade). Prazos de conclusão de investigações e espécies de ação penal." }
    ],
    pdfs: [
      { id: "pdf-pp-1", title: "Guia Prático de Recursos no CPP", pageCount: 18, summary: "Tabelas e fluxos comparativos para identificar se o recurso cabível é RESE, Apelação, Carta Testemunhável ou Correição Parcial." },
      { id: "pdf-pp-2", title: "Resumo Ilustrado: Prisões e Prazos", pageCount: 8, summary: "Esquema resumido de todas as prisões processuais e seus respectivos prazos e prorrogações legais." }
    ],
    reviews: [
      { id: "rev-pp-24h", type: "24h", title: "Prisões Cautelares", status: "atrasado", dueDate: "Ontem" },
      { id: "rev-pp-7d", type: "7d", title: "Inquérito Policial", status: "pendente", dueDate: "Em 6 dias" },
      { id: "rev-pp-30d", type: "30d", title: "Rito do Tribunal do Júri", status: "pendente", dueDate: "Em 16 dias" },
      { id: "rev-pp-erros", type: "erros", title: "Revisão de Erros: RESE e Apelação", status: "atrasado", dueDate: "Atrasado" }
    ],
    miniSimulados: [
      { id: "sim-pp-1", title: "Mini-Simulado: Prisões no CPP", totalQuestions: 6, timeLimitMinutes: 12, completed: false },
      { id: "sim-pp-2", title: "Simulado Geral: Recursos no CPP", totalQuestions: 8, timeLimitMinutes: 16, completed: false }
    ]
  },
  {
    id: "disc-trabalho",
    name: "Direito do Trabalho",
    icon: "Briefcase",
    importance: "Média",
    totalQuestions: 5,
    recommendedOrder: 8,
    modules: [
      { id: "mod-trab-1", title: "Introdução / Visão Geral", description: "Princípios do Direito do Trabalho e Fontes Formais" },
      { id: "mod-trab-2", title: "Bloco Teórico 1: Relação de Trabalho", description: "Diferenciação entre relação de trabalho e emprego, requisitos" },
      { id: "mod-trab-3", title: "Bloco Teórico 2: Contrato de Trabalho", description: "Alteração, suspensão, interrupção e extinção do contrato" },
      { id: "mod-trab-4", title: "Bloco Teórico 3: Salário, Jornada e Equiparação", description: "Regras de remuneração, horas extras, intervalos e isonomia" },
      { id: "mod-trab-5", title: "Questões Comentadas", description: "Resolução de casos de justa causa e rescisões contratuais" },
      { id: "mod-trab-6", title: "Revisão Final", description: "Revisão da Reforma Trabalhista e estabilidades provisórias" }
    ],
    lectures: [
      { id: "l-trab-1", title: "Relação de Emprego e Requisitos", duration: "34:15", summary: "Análise dos cinco requisitos cumulativos da relação de emprego (Pessoalidade, Habitualidade, Subordinação, Onerosidade, Pessoa Física). Trabalho eventual e autônomo." },
      { id: "l-trab-2", title: "Jornada de Trabalho e Descansos", duration: "47:30", summary: "Regras gerais de duração do trabalho, limite diário e semanal, horas extras, banco de horas e intervalos intrajornada e interjornada pós-Reforma Trabalhista." },
      { id: "l-trab-3", title: "Cessação do Contrato de Trabalho", duration: "39:50", summary: "Espécies de extinção: dispensa sem e com justa causa, pedido de demissão, rescisão indireta, culpa recíproca e distrato. Verbas devidas em cada hipótese." }
    ],
    pdfs: [
      { id: "pdf-trab-1", title: "Tabelão OAB: Rescisão e Verbas Rescisórias", pageCount: 8, summary: "Tabela cruzada correlacionando motivos de término de contrato às respectivas verbas rescisórias aplicáveis." },
      { id: "pdf-trab-2", title: "Guia Rápido: Estabilidades Provisórias OAB", pageCount: 5, summary: "Prazos, garantias e indenizações da gestante, dirigente sindical, cipeiro e acidentado." }
    ],
    reviews: [
      { id: "rev-trab-24h", type: "24h", title: "Relação de Emprego", status: "em_dia", dueDate: "Hoje" },
      { id: "rev-trab-7d", type: "7d", title: "Estabilidades e Garantias", status: "pendente", dueDate: "Em 2 dias" },
      { id: "rev-trab-30d", type: "30d", title: "Rescisão Contratual", status: "pendente", dueDate: "Em 11 dias" },
      { id: "rev-trab-erros", type: "erros", title: "Revisão de Erros: Equiparação Salarial", status: "em_dia", dueDate: "Hoje" }
    ],
    miniSimulados: [
      { id: "sim-trab-1", title: "Mini-Simulado: Contrato de Trabalho", totalQuestions: 5, timeLimitMinutes: 10, completed: true, score: 4 },
      { id: "sim-trab-2", title: "Simulado Geral: Jornada e Salário", totalQuestions: 8, timeLimitMinutes: 16, completed: false }
    ]
  },
  {
    id: "disc-proc-trabalho",
    name: "Processo do Trabalho",
    icon: "Gavel",
    importance: "Média",
    totalQuestions: 5,
    recommendedOrder: 9,
    modules: [
      { id: "mod-pt-1", title: "Introdução / Visão Geral", description: "Organização da Justiça do Trabalho e Competência (Art. 114 CF)" },
      { id: "mod-pt-2", title: "Bloco Teórico 1: Rito e Petição Inicial", description: "Rito ordinário, sumariíssimo, petição inicial e audiência" },
      { id: "mod-pt-3", title: "Bloco Teórico 2: Recursos Trabalhistas", description: "Recurso Ordinário, Agravo de Petição, Recurso de Revista e embargos" },
      { id: "mod-pt-4", title: "Bloco Teórico 3: Execução Trabalhista", description: "Liquidação, embargos à execução e defesas do executado" },
      { id: "mod-pt-5", title: "Questões Comentadas", description: "Audiência una trabalhista e revelia comentadas" },
      { id: "mod-pt-6", title: "Revisão Final", description: "Revisão rápida de depósitos recursais e custas na CLT" }
    ],
    lectures: [
      { id: "l-pt-1", title: "Audiência Trabalhista e Efeitos da Ausência", duration: "43:20", summary: "Estudo da audiência una. Consequências do arquivamento (ausência do reclamante) e revelia (ausência do reclamado) com confissão ficta." },
      { id: "l-pt-2", title: "Recurso Ordinário e Agravo de Petição", duration: "49:10", summary: "Cabimento do RO (Art. 895 CLT) e Agravo de Petição na execução (Art. 897, a CLT). Prazos de 8 dias, depósitos recursais e isenções." }
    ],
    pdfs: [
      { id: "pdf-pt-1", title: "Manual de Recursos e Prazos CLT", pageCount: 14, summary: "Compilado objetivo de depósitos, custas e cabimento de recursos trabalhistas ordinários e extraordinários." }
    ],
    reviews: [
      { id: "rev-pt-24h", type: "24h", title: "Audiência e Defesas na CLT", status: "pendente", dueDate: "Hoje" },
      { id: "rev-pt-7d", type: "7d", title: "Recurso Ordinário", status: "pendente", dueDate: "Em 6 dias" },
      { id: "rev-pt-30d", type: "30d", title: "Execução Trabalhista", status: "pendente", dueDate: "Em 20 dias" },
      { id: "rev-pt-erros", type: "erros", title: "Revisão de Erros: Revelia", status: "atrasado", dueDate: "Atrasado" }
    ],
    miniSimulados: [
      { id: "sim-pt-1", title: "Mini-Simulado: Audiência Una", totalQuestions: 5, timeLimitMinutes: 10, completed: false },
      { id: "sim-pt-2", title: "Simulado Geral: Recursos CLT", totalQuestions: 5, timeLimitMinutes: 10, completed: false }
    ]
  },
  {
    id: "disc-empresarial",
    name: "Direito Empresarial",
    icon: "Coins",
    importance: "Média",
    totalQuestions: 5,
    recommendedOrder: 10,
    modules: [
      { id: "mod-emp-1", title: "Introdução / Visão Geral", description: "Teoria da empresa, empresário individual e estabelecimento" },
      { id: "mod-emp-2", title: "Bloco Teórico 1: Sociedades", description: "Sociedade limitada, anônima, dissolução e exclusão" },
      { id: "mod-emp-3", title: "Bloco Teórico 2: Títulos de Crédito", description: "Letra de câmbio, nota promissória, cheque e duplicata" },
      { id: "mod-emp-4", title: "Bloco Teórico 3: Falência e Recuperação", description: "Procedimentos e classificação dos créditos na Lei 11.101/05" },
      { id: "mod-emp-5", title: "Questões Comentadas", description: "Bateria de títulos de crédito e protestos na OAB" },
      { id: "mod-emp-6", title: "Revisão Final", description: "Revisão de responsabilidade de sócios e administrador" }
    ],
    lectures: [
      { id: "l-emp-1", title: "Sociedades Limitadas e Anônimas", duration: "45:30", summary: "Formação do capital social, responsabilidade subsidiária dos sócios, administração de sociedades e direitos dos acionistas minoritários na S/A." },
      { id: "l-emp-2", title: "Títulos de Crédito: Endosso vs Aval", duration: "32:15", summary: "Estudo dos princípios (cartularidade, literalidade, autonomia). Diferenças essenciais entre endosso e cessão civil, aval e fiança." }
    ],
    pdfs: [
      { id: "pdf-emp-1", title: "Guia OAB de Direito Societário e Falências", pageCount: 16, summary: "Resumo das etapas da recuperação judicial e ordem de classificação de credores na falência." }
    ],
    reviews: [
      { id: "rev-emp-24h", type: "24h", title: "Sociedades Limitadas", status: "pendente", dueDate: "Hoje" },
      { id: "rev-emp-7d", type: "7d", title: "Títulos de Crédito", status: "pendente", dueDate: "Em 5 dias" },
      { id: "rev-emp-30d", type: "30d", title: "Ordem de Credores Falimentares", status: "pendente", dueDate: "Em 18 dias" },
      { id: "rev-emp-erros", type: "erros", title: "Revisão de Erros: Desconsideração da Personalidade", status: "atrasado", dueDate: "Atrasado" }
    ],
    miniSimulados: [
      { id: "sim-emp-1", title: "Mini-Simulado: Sociedades", totalQuestions: 5, timeLimitMinutes: 10, completed: false }
    ]
  },
  {
    id: "disc-tributario",
    name: "Direito Tributário",
    icon: "Receipt",
    importance: "Média",
    totalQuestions: 5,
    recommendedOrder: 11,
    modules: [
      { id: "mod-trib-1", title: "Introdução / Visão Geral", description: "Sistema Tributário Nacional e conceito de tributo" },
      { id: "mod-trib-2", title: "Bloco Teórico 1: Limitações e Imunidades", description: "Princípios constitucionais tributários e imunidades gerais" },
      { id: "mod-trib-3", title: "Bloco Teórico 2: Competência e Impostos", description: "Impostos federais, estaduais e municipais em espécie" },
      { id: "mod-trib-4", title: "Bloco Teórico 3: Crédito e Suspensão", description: "Lançamento, suspensão, extinção e exclusão do crédito tributário" },
      { id: "mod-trib-5", title: "Questões Comentadas", description: "Questões comentadas sobre competência e taxas" },
      { id: "mod-trib-6", title: "Revisão Final", description: "Revisão de certidões, execução fiscal e repetição do indébito" }
    ],
    lectures: [
      { id: "l-trib-1", title: "Limitações Constitucionais ao Poder de Tributar", duration: "48:20", summary: "Estudo detalhado dos princípios da Legalidade, Anterioridade Anual e Nonagesimal, Irretroatividade e Vedação ao Confisco." },
      { id: "l-trib-2", title: "Suspensão e Extinção do Crédito Tributário", duration: "39:45", summary: "Análise sistemática das hipóteses do art. 151 (Suspensão) e art. 156 (Extinção) do CTN. Diferenciação precisa de moratória, depósito, liminar, transação e remissão." }
    ],
    pdfs: [
      { id: "pdf-trib-1", title: "Super Tabela: Impostos em Espécie e Competência", pageCount: 11, summary: "Tabela comparativa cruzada contendo fato gerador, alíquotas e contribuintes de todos os impostos nacionais." }
    ],
    reviews: [
      { id: "rev-trib-24h", type: "24h", title: "Princípios da Anterioridade", status: "pendente", dueDate: "Hoje" },
      { id: "rev-trib-7d", type: "7d", title: "Suspensão do Crédito Tributário", status: "pendente", dueDate: "Em 4 dias" },
      { id: "rev-trib-erros", type: "erros", title: "Revisão de Erros: Lançamento", status: "atrasado", dueDate: "Atrasado" }
    ],
    miniSimulados: [
      { id: "sim-trib-1", title: "Mini-Simulado: Imunidades Tributárias", totalQuestions: 5, timeLimitMinutes: 10, completed: false }
    ]
  },
  {
    id: "disc-direitos-humanos",
    name: "Direitos Humanos",
    icon: "Heart",
    importance: "Média",
    totalQuestions: 2,
    recommendedOrder: 12,
    modules: [
      { id: "mod-dh-1", title: "Introdução / Visão Geral", description: "Conceito, características e gerações/dimensões dos Direitos Humanos" },
      { id: "mod-dh-2", title: "Sistemas de Proteção", description: "Sistemas global (ONU) e interamericano (OEA) de proteção ativa" }
    ],
    lectures: [
      { id: "l-dh-1", title: "Pacto de San José da Costa Rica e Comissão", duration: "35:10", summary: "O funcionamento da Corte Interamericana de Direitos Humanos, o trâmite de petições individuais e as obrigações assumidas pelo Brasil." }
    ],
    pdfs: [
      { id: "pdf-dh-1", title: "Resumo Dirigido: Convenção Americana de DH", pageCount: 8, summary: "Foco nos artigos mais cobrados: direito à vida, vedação à prisão civil por dívida e direito à integridade pessoal." }
    ],
    reviews: [
      { id: "rev-dh-24h", type: "24h", title: "Sistemas de Proteção Interamericano", status: "pendente", dueDate: "Hoje" }
    ],
    miniSimulados: [
      { id: "sim-dh-1", title: "Simulado Expresso: Direitos Humanos", totalQuestions: 4, timeLimitMinutes: 8, completed: false }
    ]
  },
  {
    id: "disc-eca",
    name: "ECA",
    icon: "Baby",
    importance: "Média",
    totalQuestions: 2,
    recommendedOrder: 13,
    modules: [
      { id: "mod-eca-1", title: "Introdução / Visão Geral", description: "Direitos fundamentais da criança e do adolescente" },
      { id: "mod-eca-2", title: "Medidas de Proteção e Atos Infracionais", description: "Medidas socioeducativas, conselho tutelar e acolhimento" }
    ],
    lectures: [
      { id: "l-eca-1", title: "Medidas Socioeducativas e Prática de Ato Infracional", duration: "38:45", summary: "Diferenças entre advertência, obrigação de reparar dano, prestação de serviços, liberdade assistida, semiliberdade e internação (prazos e excepcionalidade)." }
    ],
    pdfs: [
      { id: "pdf-eca-1", title: "Esquema Geral de Adoção e Guarda no ECA", pageCount: 10, summary: "Prazos, idades limites, consentimentos, e trâmite do processo de adoção nacional e internacional." }
    ],
    reviews: [
      { id: "rev-eca-24h", type: "24h", title: "Medidas Socioeducativas", status: "em_dia", dueDate: "Hoje" }
    ],
    miniSimulados: [
      { id: "sim-eca-1", title: "Simulado Expresso: ECA Temático", totalQuestions: 4, timeLimitMinutes: 8, completed: false }
    ]
  },
  {
    id: "disc-consumidor",
    name: "Direito do Consumidor",
    icon: "ShoppingBag",
    importance: "Média",
    totalQuestions: 2,
    recommendedOrder: 14,
    modules: [
      { id: "mod-con-1", title: "Introdução / Visão Geral", description: "Relação de consumo: consumidor, fornecedor e produtos" },
      { id: "mod-con-2", title: "Responsabilidade e Práticas Comerciais", description: "Fato vs vício do produto, cobrança de débitos e bancos de dados" }
    ],
    lectures: [
      { id: "l-con-1", title: "Responsabilidade pelo Fato e Vício do Produto", duration: "42:10", summary: "Diferenciação indispensável: Fato (defeito que causa acidente de consumo) vs Vício (defeito de adequação do produto). Prazos decadenciais e prescricionais." }
    ],
    pdfs: [
      { id: "pdf-con-1", title: "Resumo do CDC: Prazos e Defesas", pageCount: 8, summary: "Tabela com prazos de direito de arrependimento, reclamação por vícios e prescrição de indenização." }
    ],
    reviews: [
      { id: "rev-con-24h", type: "24h", title: "Fato vs Vício no CDC", status: "em_dia", dueDate: "Hoje" }
    ],
    miniSimulados: [
      { id: "sim-con-1", title: "Simulado Expresso: Consumidor", totalQuestions: 4, timeLimitMinutes: 8, completed: false }
    ]
  },
  {
    id: "disc-ambiental",
    name: "Direito Ambiental",
    icon: "Leaf",
    importance: "Média",
    totalQuestions: 2,
    recommendedOrder: 15,
    modules: [
      { id: "mod-amb-1", title: "Introdução / Visão Geral", description: "Princípios ambientais e competência constitucional ambiental" },
      { id: "mod-amb-2", title: "Instrumentos e Responsabilidade", description: "Licenciamento ambiental, SISNAMA e tríplice responsabilidade" }
    ],
    lectures: [
      { id: "l-amb-1", title: "Licenciamento Ambiental e Responsabilidade Civil", duration: "39:50", summary: "Estudo das licenças prévia, de instalação e de operação (LP, LI, LO). Responsabilidade civil por dano ambiental (teoria do risco integral e imprescritibilidade)." }
    ],
    pdfs: [
      { id: "pdf-amb-1", title: "Esquema: Licenças Ambientais e SISNAMA", pageCount: 7, summary: "Quadro rápido resumindo a atuação do IBAMA, órgãos estaduais e municipais e prazos das licenças." }
    ],
    reviews: [
      { id: "rev-amb-24h", type: "24h", title: "Licenças Ambientais e Prazos", status: "pendente", dueDate: "Hoje" }
    ],
    miniSimulados: [
      { id: "sim-amb-1", title: "Simulado Expresso: Ambiental", totalQuestions: 4, timeLimitMinutes: 8, completed: false }
    ]
  },
  {
    id: "disc-internacional",
    name: "Direito Internacional",
    icon: "Globe",
    importance: "Média",
    totalQuestions: 2,
    recommendedOrder: 16,
    modules: [
      { id: "mod-int-1", title: "Introdução / Visão Geral", description: "Internacional Público e Privado" },
      { id: "mod-int-2", title: "Condição do Estrangeiro", description: "Retirada compulsória (expulsão, deportação e extradição)" }
    ],
    lectures: [
      { id: "l-int-1", title: "Condição Jurídica do Estrangeiro no Brasil", duration: "36:40", summary: "Análise da Lei de Migração (Lei 13.445/17). Distinções definitivas entre Deportação, Expulsão, Extradição e Asilo Político." }
    ],
    pdfs: [
      { id: "pdf-int-1", title: "Resumo: Conflitos de Leis e Lei de Migração", pageCount: 9, summary: "Disposições da LINDB relativas a contratos internacionais e regras de extradição ativa e passiva." }
    ],
    reviews: [
      { id: "rev-int-24h", type: "24h", title: "Condição do Estrangeiro", status: "pendente", dueDate: "Hoje" }
    ],
    miniSimulados: [
      { id: "sim-int-1", title: "Simulado Expresso: Internacional", totalQuestions: 4, timeLimitMinutes: 8, completed: false }
    ]
  },
  {
    id: "disc-filosofia",
    name: "Filosofia do Direito",
    icon: "Brain",
    importance: "Média",
    totalQuestions: 2,
    recommendedOrder: 17,
    modules: [
      { id: "mod-fil-1", title: "Principais Escolas", description: "Jusnaturalismo, positivismo, realismo e pós-positivismo" },
      { id: "mod-fil-2", title: "Autores Clássicos na OAB", description: "Kelsen, Kant, Bobbio, Alexy e Dworkin" }
    ],
    lectures: [
      { id: "l-fil-1", title: "Positivismo Jurídico de Hans Kelsen e Bobbio", duration: "38:15", summary: "A teoria pura do direito. Norma fundamental, estrutura escalonada do ordenamento jurídico, e antinomias sob a ótica de Norberto Bobbio." }
    ],
    pdfs: [
      { id: "pdf-fil-1", title: "Guia Rápido dos Filósofos da OAB", pageCount: 12, summary: "Sintetização das ideias centrais dos autores mais cobrados pela banca para garantir as 2 questões de Filosofia." }
    ],
    reviews: [
      { id: "rev-fil-24h", type: "24h", title: "Norma Pura e Estrutura de Kelsen", status: "pendente", dueDate: "Hoje" }
    ],
    miniSimulados: [
      { id: "sim-fil-1", title: "Simulado Expresso: Filosofia", totalQuestions: 4, timeLimitMinutes: 8, completed: false }
    ]
  },
  {
    id: "disc-previdenciario",
    name: "Direito Previdenciário",
    icon: "HeartHandshake",
    importance: "Média",
    totalQuestions: 2,
    recommendedOrder: 18,
    modules: [
      { id: "mod-prev-1", title: "Introdução / Visão Geral", description: "Seguridade Social: princípios e financiamento" },
      { id: "mod-prev-2", title: "Segurados e Prestações", description: "Espécies de segurados, carência, salários de contribuição e benefícios" }
    ],
    lectures: [
      { id: "l-prev-1", title: "Regime Geral de Previdência e Segurados", duration: "41:10", summary: "Segurados obrigatórios (empregado, avulso, doméstico, especial, contribuinte individual) e segurado facultativo. Regras de perda e manutenção da qualidade de segurado." }
    ],
    pdfs: [
      { id: "pdf-prev-1", title: "Resumo da Reforma da Previdência (EC 103/19)", pageCount: 15, summary: "Tabelas com novas regras de idade, tempo de contribuição, alíquotas e fórmulas de cálculo de aposentadoria." }
    ],
    reviews: [
      { id: "rev-prev-24h", type: "24h", title: "Espécies de Segurados e Qualidade de Segurado", status: "pendente", dueDate: "Hoje" }
    ],
    miniSimulados: [
      { id: "sim-prev-1", title: "Simulado Expresso: Previdenciário", totalQuestions: 4, timeLimitMinutes: 8, completed: false }
    ]
  },
  {
    id: "disc-financeiro",
    name: "Direito Financeiro",
    icon: "PiggyBank",
    importance: "Média",
    totalQuestions: 2,
    recommendedOrder: 19,
    modules: [
      { id: "mod-fin-1", title: "Introdução / Visão Geral", description: "Atividade financeira do Estado e receitas públicas" },
      { id: "mod-fin-2", title: "Orçamento Público e LRF", description: "PPA, LDO, LOA, créditos adicionais e limites da Lei de Responsabilidade Fiscal" }
    ],
    lectures: [
      { id: "l-fin-1", title: "Leis Orçamentárias e Créditos Adicionais", duration: "40:05", summary: "Análise da elaboração e vigência do Plano Plurianual (PPA), Diretrizes Orçamentárias (LDO) e Lei Orçamentária Anual (LOA). Créditos suplementares, especiais e extraordinários." }
    ],
    pdfs: [
      { id: "pdf-fin-1", title: "Resumo: LRF e Princípios Orçamentários", pageCount: 10, summary: "Compilado sobre o princípio da unidade, universalidade, anualidade e limites de gastos com pessoal." }
    ],
    reviews: [
      { id: "rev-fin-24h", type: "24h", title: "PPA, LDO e LOA", status: "pendente", dueDate: "Hoje" }
    ],
    miniSimulados: [
      { id: "sim-fin-1", title: "Simulado Expresso: Financeiro", totalQuestions: 4, timeLimitMinutes: 8, completed: false }
    ]
  }
];

export const PHASE1_QUESTIONS: Record<string, Question[]> = {
  "disc-etica": [
    {
      id: "q-etica-1",
      discipline: "Ética Profissional",
      theme: "Prerrogativas do Advogado",
      difficulty: "Média",
      exam: "XXXVIII Exame de Ordem",
      statement: "Lucas, advogado regularmente inscrito nos quadros da OAB, comparece a uma penitenciária para se entrevistar pessoalmente e reservadamente com seu cliente preso, acusado de participação em organização criminosa de alta periculosidade. O agente penitenciário de plantão impede a entrevista de Lucas, alegando ordem por escrito do juiz corregedor de que o cliente só poderá falar com o advogado na presença de um policial armado, para segurança de todos. Diante do caso fático, assinale a opção correta:",
      options: [
        "A ordem do juiz é plenamente legal diante do princípio da segurança pública em crimes de alta periculosidade.",
        "Lucas tem o direito de entrevistar seu cliente pessoal e reservadamente, mesmo sem procuração, estando este preso ou detido, constituindo a recusa violação às suas prerrogativas.",
        "O advogado só poderá se entrevistar na presença de agente policial se houver fundado receio de fuga, cabendo recurso administrativo à OAB.",
        "A inviolabilidade do advogado restringe-se ao seu ambiente físico de trabalho (escritório), não abrangendo estabelecimentos penitenciários estatais."
      ],
      correctIndex: 1,
      explanation: "De acordo com o art. 7º, inciso III, do Estatuto da Advocacia e da OAB (Lei 8.906/94), é direito do advogado comunicar-se com seus clientes, pessoal e reservadamente, mesmo sem procuração, quando estes se acharem presos, detidos ou recolhidos em estabelecimentos civis ou militares, ainda que considerados incomunicáveis. A exigência de policial armado viola diretamente esta garantia."
    },
    {
      id: "q-etica-2",
      discipline: "Ética Profissional",
      theme: "Sanções Disciplinares",
      difficulty: "Difícil",
      exam: "XXXIX Exame de Ordem",
      statement: "O advogado Roberto, após ser devidamente notificado, retém abusivamente os autos de um processo cível pelo prazo de 6 meses, impossibilitando a parte contrária de se manifestar e causando atraso relevante na prestação jurisdicional. Diante das infrações disciplinares capituladas na Lei 8.906/94, qual a sanção aplicável a Roberto pela infração de retenção abusiva de autos?",
      options: [
        "Multa pecuniária simples, cumulada com advertência reservada.",
        "Suspensão do exercício profissional pelo prazo de 30 dias a 12 meses, prorrogável até a efetiva devolução dos autos.",
        "Exclusão dos quadros da OAB, por configurar inidoneidade moral superveniente.",
        "Censura verbal ou por escrito, sem anotação em seus assentamentos funcionais."
      ],
      correctIndex: 1,
      explanation: "A infração de reter abusivamente os autos é punível com a sanção de suspensão (Art. 37, I da Lei 8.906/94). Conforme o Art. 37, § 1º, a suspensão é aplicada pelo prazo de 30 dias a 12 meses e perdura até que o infrator satisfaça o requisito (neste caso, a devolução efetiva dos autos retidos)."
    }
  ],
  "disc-const": [
    {
      id: "q-const-1",
      discipline: "Direito Constitucional",
      theme: "Controle de Constitucionalidade",
      difficulty: "Difícil",
      exam: "XXXVII Exame de Ordem",
      statement: "O Governador do Estado Alfa decide propor uma Ação Direta de Inconstitucionalidade (ADI) perante o Supremo Tribunal Federal em face de uma Lei Federal que cria novas obrigações fiscais para todos os entes da Federação. No entanto, a mesa diretora do partido de oposição contesta a legitimidade do Governador, alegando que ele não possui relação com o tema da referida lei. De acordo com a sistemática constitucional e a jurisprudência pacífica do STF, assinale a opção correta:",
      options: [
        "O Governador é considerado legitimado universal, não necessitando demonstrar pertinência temática para propor ADI em face de lei federal.",
        "O Governador é legitimado especial, necessitando comprovar o nexo de afinidade/pertinência temática entre a lei federal impugnada e os interesses do seu respectivo Estado.",
        "Qualquer Governador precisa de autorização expressa da Assembleia Legislativa estadual para impetrar controle concentrado perante o STF.",
        "Governadores de Estado perderam a legitimidade ativa para propor ADI após a reforma do judiciário pela Emenda Constitucional 45."
      ],
      correctIndex: 1,
      explanation: "O Supremo Tribunal Federal classifica os legitimados ativos do Art. 103 da CF em dois grupos: Legitimados Universais (que não precisam provar pertinência temática, como o Presidente, Mesa do Senado, etc.) e Legitimados Especiais (que precisam provar interesse, como o Governador, Mesa de Assembleia Legislativa, etc.). Portanto, o Governador é legitimado especial e precisa comprovar pertinência temática (nexo de interesse do seu respectivo Estado)."
    }
  ],
  "disc-civil": [
    {
      id: "q-civil-1",
      discipline: "Direito Civil",
      theme: "Defeitos do Negócio Jurídico",
      difficulty: "Média",
      exam: "XXXVIII Exame de Ordem",
      statement: "Mário, sob forte temor provocado por sérias ameaças proferidas por Júlio (que dizia que iria agredir fisicamente os filhos de Mário caso este não lhe vendesse seu veículo importado por metade do valor de mercado), assina o contrato de compra e venda de carro com Júlio. Passados 6 meses do ocorrido e livre das ameaças, Mário consulta você como advogado(a) para saber se é possível invalidar tal contrato. Com base nas regras do Código Civil de 2002, assinale a opção correta:",
      options: [
        "O negócio jurídico celebrado sob coação é nulo de pleno direito, não estando sujeito a prazos de decadência.",
        "O contrato é anulável por defeito de coação moral, e o prazo decadencial para pleitear tal anulação é de 4 anos, a contar do dia em que cessar a coação.",
        "A coação é vício que gera mera obrigação de indenizar por perdas e danos, mantendo-se o contrato integralmente válido.",
        "Como a venda envolveu valor abaixo da metade do mercado, o vício correto a ser alegado é a lesão, cujo prazo é de 2 anos a contar da assinatura."
      ],
      correctIndex: 1,
      explanation: "De acordo com o Art. 171, II do Código Civil, o negócio jurídico é anulável por defeito resultante de coação. O prazo decadencial para pleitear a anulação é de 4 anos, sendo que, especificamente no caso de coação, este prazo se inicia no dia em que ela cessar, conforme disposto no Art. 178, inciso I do CC."
    }
  ],
  "disc-adm": [
    {
      id: "q-adm-1",
      discipline: "Direito Administrativo",
      theme: "Nova Lei de Licitações",
      difficulty: "Média",
      exam: "XL Exame de Ordem",
      statement: "A Administração Pública do Município de Beta pretende contratar serviços de engenharia altamente complexos, cuja solução técnica é desconhecida e exige uma análise conjunta com os licitantes para encontrar o melhor arranjo metodológico e tecnológico antes da fase competitiva propriamente dita. Sob a égide da Nova Lei de Licitações (Lei 14.133/2021), qual é a modalidade de licitação expressamente indicada e criada para suprir esta necessidade específica?",
      options: [
        "Pregão eletrônico com regime de técnica e preço.",
        "Tomada de preços com audiência pública de esclarecimento.",
        "Diálogo Competitivo.",
        "Concorrência pública simplificada."
      ],
      correctIndex: 2,
      explanation: "O Diálogo Competitivo é a nova modalidade licitatória introduzida pela Lei 14.133/21, inspirada no modelo europeu, destinada à contratação de obras, serviços e compras em que a Administração realiza diálogos com licitantes previamente selecionados, visando desenvolver soluções aptas a satisfazer suas necessidades, para que depois os licitantes apresentem uma proposta final."
    }
  ],
  "disc-trabalho": [
    {
      id: "q-trab-1",
      discipline: "Direito do Trabalho",
      theme: "Extinção do Contrato",
      difficulty: "Média",
      exam: "XXXVIII Exame de Ordem",
      statement: "Mariana trabalhava em uma loja de calçados e cometeu falta grave, consistente no desvio reiterado de valores do caixa para proveito próprio, o que restou plenamente comprovado por auditoria interna e filmagens. Diante da gravidade, o empregador a demitiu por justa causa com esteio no art. 482 da CLT. No momento da homologação da rescisão contratual, quais verbas rescisórias são devidas a Mariana por lei?",
      options: [
        "Apenas saldo de salário e férias vencidas com acréscimo do terço constitucional.",
        "Saldo de salário, férias proporcionais, 13º salário proporcional e multa de 40% do FGTS.",
        "Férias vencidas, férias proporcionais e aviso prévio indenizado de 30 dias.",
        "Ela perde o direito a absolutamente todas as verbas por conta da demissão por justa causa."
      ],
      correctIndex: 0,
      explanation: "Na extinção do contrato de trabalho por justa causa cometida pelo trabalhador (Art. 482 CLT), o empregado perde o direito ao aviso prévio, às férias proporcionais, ao 13º salário proporcional e à multa rescisória e ao saque do FGTS. Mariana terá direito apenas ao saldo de salário dos dias trabalhados no mês e às férias vencidas que já integraram seu patrimônio jurídico, acrescidas de 1/3, se houver (Súmula 171 do TST)."
    }
  ]
};
