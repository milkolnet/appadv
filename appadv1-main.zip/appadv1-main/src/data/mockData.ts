/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  StudentProgress,
  WeeklyTask,
  Discipline,
  JuridicalPiece,
  Question,
  Flashcard,
  OABCalendarEvent,
  SupportFAQ,
  SimulatedResult
} from '../types';

export const INITIAL_PROGRESS: StudentProgress = {
  selectedSecondPhaseArea: "Direito Penal",
  studyHoursGoal: 25,
  weeklyStudyHours: 14.5,
  completedTaskIds: ["task-1", "task-3", "task-5"],
  answeredQuestions: {
    "q-1": { selectedOption: 2, isCorrect: true, timestamp: "2026-06-23T10:00:00Z" },
    "q-2": { selectedOption: 0, isCorrect: false, timestamp: "2026-06-23T11:00:00Z" },
    "q-3": { selectedOption: 1, isCorrect: true, timestamp: "2026-06-24T09:30:00Z" }
  },
  favoriteQuestions: ["q-1", "q-4"],
  favoritePieces: ["p-1"],
  completedLectures: ["l-1-1", "l-2-1"],
  completedPDFs: ["pdf-1-1"],
  completedFlashcards: ["f-1", "f-4"],
  flashcardBoxes: {
    "f-1": 3,
    "f-2": 1,
    "f-3": 2,
    "f-4": 4,
    "f-5": 1
  },
  notes: {
    "p-1": "Lembrar de sempre fundamentar a tempestividade da Apelação Penal com base no art. 593, I do CPP."
  },
  simulatedExamsHistory: [
    {
      id: "sim-1",
      title: "Simulado 1ª Fase OAB - Geral (XXXIX Exame)",
      type: "1a Fase",
      date: "2026-06-15",
      score: 48,
      total: 80,
      percentage: 60,
      timeSpentMinutes: 240,
      subjectPerformance: {
        "Ética Profissional": { correct: 6, total: 8 },
        "Direito Constitucional": { correct: 4, total: 6 },
        "Direito Civil": { correct: 3, total: 6 },
        "Direito Penal": { correct: 5, total: 6 },
        "Direito do Trabalho": { correct: 4, total: 5 },
        "Processo Civil": { correct: 3, total: 6 }
      },
      feedback: "Excelente progresso! Você ultrapassou os 40 pontos mínimos exigidos para aprovação na 1ª Fase. Foque agora em manter a constância e fortalecer Direito Civil e Processo Civil."
    },
    {
      id: "sim-2",
      title: "Simulado 2ª Fase OAB - Direito Penal Prático",
      type: "2a Fase",
      date: "2026-06-20",
      score: 7.2,
      total: 10,
      percentage: 72,
      timeSpentMinutes: 270,
      feedback: "Parabéns! Sua pontuação foi de 7,2 (o mínimo é 6.0). A fundamentação das teses preliminares foi muito boa, mas você perdeu alguns pontos no fechamento e na indicação exata de artigos das teses de mérito."
    }
  ],
  lastSavedActivity: {
    tab: "1ª Fase",
    sectionId: "disc-etica",
    itemId: "l-1-2",
    title: "Videoaula: Direitos do Advogado (Art. 7º EAOAB)",
    timestamp: "2026-06-24T18:30:00Z"
  }
};

export const WEEKLY_TASKS_TEMPLATE: WeeklyTask[] = [
  {
    id: "task-1",
    day: "Segunda-feira",
    title: "Estatuto da OAB - Direitos e Prerrogativas",
    description: "Assistir à aula introdutória e fazer leitura atenta do art. 6º e 7º do EAOAB. Essencial para gabaritar Ética.",
    durationMinutes: 120,
    estimatedMinutes: 120,
    discipline: "Ética Profissional",
    status: "completed",
    priority: "Alta",
    realStudyTimeSeconds: 7200,
    completedAt: "2026-06-22T20:00:00Z"
  },
  {
    id: "task-2",
    day: "Segunda-feira",
    title: "Resolução de Questões - Prerrogativas",
    description: "Fazer 15 questões de provas anteriores focadas exclusivamente em Direitos dos Advogados.",
    durationMinutes: 45,
    estimatedMinutes: 45,
    discipline: "Ética Profissional",
    status: "pending",
    priority: "Alta"
  },
  {
    id: "task-3",
    day: "Terça-feira",
    title: "Remédios Constitucionais - Teoria",
    description: "Estudar Habeas Corpus, Mandado de Segurança, Habeas Data, Mandado de Injunção e Ação Popular.",
    durationMinutes: 90,
    estimatedMinutes: 90,
    discipline: "Direito Constitucional",
    status: "completed",
    priority: "Média",
    realStudyTimeSeconds: 5400,
    completedAt: "2026-06-23T11:00:00Z"
  },
  {
    id: "task-4",
    day: "Terça-feira",
    title: "Leitura da CF/88 (Art. 5º)",
    description: "Leitura seca minuciosa do Artigo 5º da CF, com foco nos incisos correspondentes aos remédios constitucionais.",
    durationMinutes: 60,
    estimatedMinutes: 60,
    discipline: "Direito Constitucional",
    status: "pending",
    priority: "Alta"
  },
  {
    id: "task-5",
    day: "Quarta-feira",
    title: "Teoria do Delito: Fato Típico",
    description: "Revisar conduta, resultado, nexo de causalidade e tipicidade. Compreender dolo e culpa.",
    durationMinutes: 120,
    estimatedMinutes: 120,
    discipline: "Direito Penal",
    status: "completed",
    priority: "Alta",
    realStudyTimeSeconds: 7200,
    completedAt: "2026-06-24T19:30:00Z"
  },
  {
    id: "task-6",
    day: "Quarta-feira",
    title: "Simulado de Questões - Penal",
    description: "Resolver 10 questões do exame da OAB sobre Ilicitude e Culpabilidade.",
    durationMinutes: 40,
    estimatedMinutes: 40,
    discipline: "Direito Penal",
    status: "pending",
    priority: "Média"
  },
  {
    id: "task-7",
    day: "Quinta-feira",
    title: "Contratos em Espécie - Direito Civil",
    description: "Estudo dos principais contratos cobrados pela banca: Compra e Venda, Locação e Mandato.",
    durationMinutes: 100,
    estimatedMinutes: 100,
    discipline: "Direito Civil",
    status: "pending",
    priority: "Média"
  },
  {
    id: "task-8",
    day: "Sexta-feira",
    title: "Extinção do Contrato de Trabalho",
    description: "Ver as modalidades de dispensa, aviso prévio, verbas rescisórias e multas do art. 467 e 477 da CLT.",
    durationMinutes: 90,
    estimatedMinutes: 90,
    discipline: "Direito do Trabalho",
    status: "pending",
    priority: "Alta"
  },
  {
    id: "task-9",
    day: "Sexta-feira",
    title: "Flashcards Diários - Revisão Act",
    description: "Revisar todos os flashcards programados para o dia de hoje no sistema de repetição espaçada.",
    durationMinutes: 30,
    estimatedMinutes: 30,
    discipline: "Revisão Geral",
    status: "pending",
    priority: "Média"
  },
  {
    id: "task-10",
    day: "Sábado",
    title: "Simulado Semanal de 1ª Fase",
    description: "Responder um caderno reduzido de 40 questões simuladas cobrindo as disciplinas estudadas na semana.",
    durationMinutes: 120,
    estimatedMinutes: 120,
    discipline: "Simulado",
    status: "pending",
    priority: "Alta"
  }
];

export const DISCIPLINES: Discipline[] = [
  {
    id: "disc-etica",
    name: "Ética Profissional",
    icon: "ShieldAlert",
    importance: "Muito Alta",
    totalQuestions: 8,
    lectures: [
      {
        id: "l-1-1",
        title: "Estrutura e Órgãos da OAB",
        duration: "32:40",
        summary: "Análise completa do Conselho Federal, Conselhos Seccionais, Subseções e Caixa de Assistência dos Advogados (CAA). Principais competências e regras de composição."
      },
      {
        id: "l-1-2",
        title: "Direitos e Prerrogativas do Advogado",
        duration: "45:15",
        summary: "Estudo detalhado do artigo 7º do Estatuto da Advocacia e da OAB. Inviolabilidade do escritório, comunicação com cliente, prisão em sala de estado-maior, e direito de presença."
      },
      {
        id: "l-1-3",
        title: "Infrações e Sanções Disciplinares",
        duration: "38:20",
        summary: "Quais comportamentos configuram infrações éticas. Estudo das penas: Censura, Suspensão, Exclusão e Multa. Circunstâncias atenuantes e reincidência."
      }
    ],
    pdfs: [
      {
        id: "pdf-1-1",
        title: "Super Resumo: Prerrogativas e Ética OAB",
        pageCount: 15,
        summary: "Compilado esquematizado com tabelas comparativas dos principais direitos dos advogados e infrações mais recorrentes na prova da FGV."
      },
      {
        id: "pdf-1-2",
        title: "Mapa Mental - Órgãos da OAB e Competências",
        pageCount: 3,
        summary: "Fluxograma visual de competências exclusivas do Conselho Federal e das Seccionais."
      }
    ]
  },
  {
    id: "disc-const",
    name: "Direito Constitucional",
    icon: "BookOpen",
    importance: "Muito Alta",
    totalQuestions: 6,
    lectures: [
      {
        id: "l-2-1",
        title: "Controle de Constitucionalidade: Difuso vs Concentrado",
        duration: "52:10",
        summary: "Introdução à supremacia da Constituição. Conceitos essenciais do controle de constitucionalidade. Legitimados do art. 103 e efeitos das decisões no STF."
      },
      {
        id: "l-2-2",
        title: "Remédios Constitucionais e Direitos Individuais",
        duration: "41:30",
        summary: "Aplicações práticas do Habeas Corpus, Mandado de Segurança (individual e coletivo), Habeas Data e Ação Popular. Casos práticos cobrados pela banca."
      },
      {
        id: "l-2-3",
        title: "Organização do Estado e Repartição de Competências",
        duration: "35:12",
        summary: "Como se dividem as competências legislativas e materiais entre União, Estados, DF e Municípios. Dicas para não confundir o Art. 22 com o Art. 24 da CF."
      }
    ],
    pdfs: [
      {
        id: "pdf-2-1",
        title: "Guia Definitivo do Controle de Constitucionalidade",
        pageCount: 22,
        summary: "Material focado nas diferenças entre ADI, ADC, ADO e ADPF, abordando legitimidade ativa, objeto e efeitos erga omnes."
      }
    ]
  },
  {
    id: "disc-penal",
    name: "Direito Penal",
    icon: "Scale",
    importance: "Alta",
    totalQuestions: 6,
    lectures: [
      {
        id: "l-3-1",
        title: "Aplicação da Lei Penal no Tempo e no Espaço",
        duration: "29:45",
        summary: "Princípio da legalidade e anterioridade. Abolitio criminis, novatio legis in pejus e in melius. Teoria da atividade e do resultado. Territorialidade e Extraterritorialidade."
      },
      {
        id: "l-3-2",
        title: "Teoria do Crime: Erro de Tipo vs Erro de Proibição",
        duration: "44:18",
        summary: "Diferenciação precisa e sem decorebas. Consequências jurídicas do erro essencial, acidental, erro sobre a pessoa, aberratio ictus e erro de proibição."
      },
      {
        id: "l-3-3",
        title: "Dosimetria da Pena (As Três Fases)",
        duration: "51:02",
        summary: "Como calcular a pena privativa de liberdade. Circunstâncias judiciais (art. 59), atenuantes e agravantes genéricas, e causas de aumento e diminuição."
      }
    ],
    pdfs: [
      {
        id: "pdf-3-1",
        title: "Manual OAB de Direito Penal Geral",
        pageCount: 30,
        summary: "Teoria do crime e teoria da pena explicadas de forma didática com esquemas e as principais jurisprudências do STF/STJ que caem na OAB."
      }
    ]
  },
  {
    id: "disc-civil",
    name: "Direito Civil",
    icon: "Users",
    importance: "Alta",
    totalQuestions: 6,
    lectures: [
      {
        id: "l-4-1",
        title: "LINDB - Lei de Introdução às Normas do Direito Brasileiro",
        duration: "31:10",
        summary: "Vigência e eficácia da lei. Represtinação, obrigatoriedade, critérios de integração (analogia, costumes, princípios gerais) e aplicação da lei estrangeira."
      },
      {
        id: "l-4-2",
        title: "Teoria Geral dos Negócios Jurídicos e Defeitos",
        duration: "48:50",
        summary: "Análise dos vícios de consentimento: Erro, Dolo, Coação, Estado de Perigo e Lesão. Vícios sociais: Fraude contra credores e Simulação (nulidade)."
      },
      {
        id: "l-4-3",
        title: "Família e Sucessões na Prova da OAB",
        duration: "40:22",
        summary: "Regime de bens e suas comunicações patrimoniais. Regras de herança, ordem de vocação hereditária e direito real de habitação do cônjuge sobrevivente."
      }
    ],
    pdfs: [
      {
        id: "pdf-4-1",
        title: "Resumo Esquematizado - Vícios do Negócio Jurídico",
        pageCount: 12,
        summary: "Tabela comparativa prática indicando prazos decadenciais, efeitos (anulabilidade vs nulidade) e requisitos de configuração de cada defeito."
      }
    ]
  },
  {
    id: "disc-trabalho",
    name: "Direito do Trabalho",
    icon: "Briefcase",
    importance: "Média",
    totalQuestions: 5,
    lectures: [
      {
        id: "l-5-1",
        title: "Relação de Emprego e Requisitos de Caracterização",
        duration: "34:15",
        summary: "Os 5 requisitos cumulativos (Subordinação, Habitualidade, Onerosidade, Pessoalidade, Pessoa Física). Distinção de autônomo, terceirizado e voluntário."
      },
      {
        id: "l-5-2",
        title: "Jornada de Trabalho e Horas Extraordinárias",
        duration: "47:30",
        summary: "Regras gerais de duração do trabalho, acordo de compensação, banco de horas, intervalos intra e interjornada. Impacto da reforma trabalhista e teletrabalho."
      }
    ],
    pdfs: [
      {
        id: "pdf-5-1",
        title: "Tabelão OAB: Verbas Rescisórias por Tipo de Rescisão",
        pageCount: 8,
        summary: "Material prático e visual correlacionando o motivo do desligamento com as verbas devidas (saldo, aviso, 13º, férias, FGV, indenização de 40%)."
      }
    ]
  }
];

export const JURIDICAL_PIECES: JuridicalPiece[] = [
  {
    id: "p-1",
    title: "Apelação Criminal",
    area: "Direito Penal",
    structure: [
      {
        section: "1. Peça de Interposição",
        content: "Dirigida ao juízo sentenciante (Juiz de Direito da Vara Criminal). Deve conter o requerimento de recebimento e processamento, a indicação do fundamento legal (Art. 593, I, do CPP ou art. 82 da Lei 9.099/95) e o pedido de remessa dos autos e das razões ao Tribunal de Justiça. Fechamento com local, data, advogado e OAB."
      },
      {
        section: "2. Peça de Razões de Apelação",
        content: "Dirigida ao Tribunal de Justiça (Egrégio Tribunal... Colenda Câmara... Doutos Desembargadores). Deve iniciar com a qualificação e histórico processual sumário, seguida das teses defensivas divididas pedagogicamente."
      },
      {
        section: "3. Teses Preliminares (Nulidades)",
        content: "Alegar eventuais violações processuais com base no Art. 564 do CPP (ex: incompetência de juízo, cerceamento de defesa por falta de testemunha, ausência de fundamentação da sentença ou nulidade na citação)."
      },
      {
        section: "4. Teses de Mérito (Principais e Subsidiárias)",
        content: "Pedido principal: Absolvição fundada em um dos incisos do Art. 386 do CPP (ausência de prova, atipicidade, excludente de ilicitude/culpabilidade). Pedido subsidiário: Desclassificação para crime mais leve, fixação da pena-base no mínimo legal, afastamento de qualificadoras/agravantes, fixação de regime inicial mais benéfico, substituição de pena privativa de liberdade por restritiva de direitos (Art. 44 CP)."
      },
      {
        section: "5. Pedidos Finais",
        content: "Requerer o conhecimento e provimento do recurso, acolhimento das preliminares de nulidade ou, no mérito, a reforma da decisão para absolver o réu e, subsidiariamente, acolher as teses de redução de pena e regime."
      }
    ],
    checklist: [
      { id: "ck-1-1", item: "Endereçamento de interposição ao Juiz Singular", checked: true },
      { id: "ck-1-2", item: "Fundamentação legal correta (Art. 593, I, do CPP)", checked: true },
      { id: "ck-1-3", item: "Indicação da tempestividade (prazo de 5 dias para interpor)", checked: false },
      { id: "ck-1-4", item: "Endereçamento das razões ao Tribunal de Justiça", checked: true },
      { id: "ck-1-5", item: "Tese de mérito principal de Absolvição (Art. 386, CPP)", checked: false },
      { id: "ck-1-6", item: "Teses subsidiárias de dosimetria e regime inicial", checked: false },
      { id: "ck-1-7", item: "Pedido expresso de reforma da sentença", checked: false }
    ],
    template: `EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DE DIREITO DA ... VARA CRIMINAL DA COMARCA DE ...

PROCESSO Nº ...

FULANO DE TAL, já devidamente qualificado nos autos da ação penal em epígrafe, por seu procurador signatário, não se conformando com a r. sentença condenatória de fls. ..., vem, mui respeitosamente, perante Vossa Excelência, interpor o presente recurso de

APELAÇÃO

com esteio no artigo 593, inciso I, do Código de Processo Penal.

Requer seja recebido e processado o presente recurso e, ato contínuo, intimado o recorrente para apresentação das razões de apelação no prazo legal (art. 600, CPP) ou que subam os autos diretamente com as razões inclusas em anexo.

Termos em que,
Pede deferimento.

Local ..., Data ... (atentar para o último dia do prazo).
Advogado ...
OAB/ ... Nº ...

-----------------------------------------
RAZÕES DE APELAÇÃO

APELANTE: FULANO DE TAL
APELADO: MINISTÉRIO PÚBLICO
EGRÉGIO TRIBUNAL DE JUSTIÇA DO ESTADO DE ...
COLENDA CÂMARA CRIMINAL
DOUTOS DESEMBARGADORES

Em que pese o notório saber jurídico do MM. Magistrado a quo, a r. sentença condenatória não merece prosperar, pelas razões fáticas e jurídicas a seguir expostas:

I. DOS FATOS (Breve síntese fática...)
II. DAS PRELIMINARES (Indicar nulidades...)
III. DO MÉRITO (Teses de absolvição, desclassificação, redução de pena...)
IV. DOS PEDIDOS
Ante o exposto, requer o Apelante seja conhecido e provido o recurso para:
a) Acolher a preliminar de nulidade por ...;
b) No mérito, reformar a decisão para absolver o réu com fulcro no Art. 386, inciso ... do CPP;
c) Subsidiariamente, reduzir a reprimenda imposta e fixar o regime inicial aberto...

Nestes termos,
Pede deferimento.

Local ..., Data ...
Advogado ...
OAB/ ...`,
    tips: [
      "Prazo de Interposição: 5 dias. Prazo de Razões: 8 dias. Na prova da OAB, usualmente apresenta-se a peça única interposta no prazo de 5 dias.",
      "Lembre de verificar se há nulidade de citação, incompetência de juiz ou cerceamento de defesa nas questões de processo penal.",
      "Nunca crie dados de local e data que a prova não forneça. Use 'Local...', 'Data...' para evitar identificação e anulação da prova."
    ]
  },
  {
    id: "p-2",
    title: "Mandado de Segurança Coletivo",
    area: "Direito Constitucional",
    structure: [
      {
        section: "1. Endereçamento e Qualificação",
        content: "Dirigido à autoridade competente a depender de quem praticou o ato coator. Requer legitimados específicos (Partido político com representação no Congresso, entidade de classe, sindicato, associação constituída há mais de 1 ano)."
      },
      {
        section: "2. Do Ato Coator",
        content: "Identificação exata da autoridade que violou direito líquido e certo da coletividade ou grupo representado."
      },
      {
        section: "3. Cabimento do MS",
        content: "Argumentar a existência de ato ilegal ou abusivo de poder, ausência de dilação probatória (direito comprovado de plano) e tempestividade (prazo decadencial de 120 dias do ato)."
      },
      {
        section: "4. Do Pedido de Liminar (Fumus Boni Iuris e Periculum In Mora)",
        content: "Fundamentar a concessão de liminar inaudita altera parte com base no artigo 7º, III da Lei 12.016/09."
      }
    ],
    checklist: [
      { id: "ck-2-1", item: "Endereçamento correto à autoridade coatora competente", checked: false },
      { id: "ck-2-2", item: "Indicação da legitimidade ativa especial (ex: Sindicato regularizado)", checked: false },
      { id: "ck-2-3", item: "Demonstração do direito líquido e certo de plano", checked: false },
      { id: "ck-2-4", item: "Pedido de liminar fundamentado na Lei 12.016/09", checked: false },
      { id: "ck-2-5", item: "Notificação da autoridade coatora e da PJ de direito público", checked: false }
    ],
    template: `EXCELENTÍSSIMO SENHOR DOUTOR DESEMBARGADOR PRESIDENTE DO EGRÉGIO TRIBUNAL DE JUSTIÇA DO ESTADO DE ...

SINDICATO DOS SERVIDORES PÚBLICOS DE ..., entidade sindical de primeiro grau, devidamente inscrita no CNPJ sob o nº ..., com sede em ..., representada por seu Diretor Presidente, por intermédio de seu advogado signatário (procuração em anexo), vem impetrar o presente

MANDADO DE SEGURANÇA COLETIVO COM PEDIDO DE LIMINAR

com fulcro no artigo 5º, incisos LXIX e LXX, alínea 'b' da Constituição Federal e na Lei 12.016/09, em face de ato ilegal praticado pelo EXCELENTÍSSIMO SENHOR SECRETÁRIO DE ESTADO DE ADMINISTRAÇÃO, vinculado à PESSOA JURÍDICA DE DIREITO PÚBLICO ESTADO DE ..., pelas razões de fato e de direito a seguir aduzidas:

I. DOS FATOS...
II. DA LEGITIMIDADE E CABIMENTO...
III. DO DIREITO LÍQUIDO E CERTO...
IV. DO PEDIDO DE LIMINAR...
V. DOS PEDIDOS FINAIS...`,
    tips: [
      "Atenção extrema ao prazo de 120 dias do conhecimento do ato impugnado para garantir a tempestividade.",
      "MS Coletivo exige que o interesse tutelado seja dos associados/membros do grupo impetrante.",
      "Não há condenação em honorários advocatícios em sede de Mandado de Segurança (Súmula 512 do STF e 105 do STJ)."
    ]
  },
  {
    id: "p-3",
    title: "Reclamação Trabalhista",
    area: "Direito do Trabalho",
    structure: [
      {
        section: "1. Endereçamento e Qualificação",
        content: "Dirigida à Vara do Trabalho do local da prestação de serviços do trabalhador (Art. 651 CLT)."
      },
      {
        section: "2. Do Contrato de Trabalho",
        content: "Mencionar data de admissão, demissão, função desempenhada, última remuneração e forma de dispensa."
      },
      {
        section: "3. Fundamentação dos Pedidos (Teses)",
        content: "Cobrar verbas em atraso, horas extras, adicionais (insalubridade, periculosidade, noturno), equiparação salarial, indenização por dano moral, reversão de justa causa, multas do art. 467 e 477 da CLT."
      },
      {
        section: "4. Pedido de Justiça Gratuita e Honorários",
        content: "Requerer benefício da Justiça Gratuita e honorários de sucumbência recíproca ou integral com base no art. 791-A da CLT."
      }
    ],
    checklist: [
      { id: "ck-3-1", item: "Endereçamento correto à Vara do Trabalho competente", checked: false },
      { id: "ck-3-2", item: "Mapeamento minucioso do contrato (admissão/demissão)", checked: false },
      { id: "ck-3-3", item: "Pedido de horas extras com reflexos em repouso remunerado", checked: false },
      { id: "ck-3-4", item: "Requerimento das multas do art. 467 e 477, § 8º, CLT", checked: false },
      { id: "ck-3-5", item: "Atribuição de valor individualizado a cada pedido (Requisito CLT)", checked: false }
    ],
    template: `EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DA ... VARA DO TRABALHO DE ...

FULANO DE TAL, nacionalidade ..., estado civil ..., profissão ..., portador do RG nº ..., inscrito no CPF sob o nº ..., residente e domiciliado na Rua ..., portador da CTPS nº ..., série ..., PIS nº ..., vem, por seu advogado infra-assinado, propor

RECLAMAÇÃO TRABALHISTA

em face de EMPRESA LTDA, pessoa jurídica de direito privado, inscrita no CNPJ sob o nº ..., com sede em ..., pelos motivos que passa a expor:

I. DO CONTRATO DE TRABALHO
II. DAS HORAS EXTRAS (Fatos, fundamentação no Art. 58 CLT e pedidos)
III. DAS VERBAS RESCISÓRIAS
IV. DOS HONORÁRIOS E DA GRATUIDADE
V. DOS PEDIDOS E REQUERIMENTOS (Dar valor líquido a cada pedido!)
Valor da Causa: R$ ... (soma de todos os pedidos).`,
    tips: [
      "Desde a Reforma Trabalhista, TODA petição inicial na Justiça do Trabalho deve ter pedidos liquidados (valores expressos).",
      "Sempre peça o pagamento de reflexos das parcelas salariais em aviso prévio, 13º salário, férias + 1/3, e FGTS + 40%.",
      "Lembre do prazo bienal (2 anos do fim do contrato) e quinquenal (últimos 5 anos) para reclamar direitos trabalhistas."
    ]
  }
];

export const QUESTIONS_BANK: Question[] = [
  {
    id: "q-1",
    discipline: "Ética Profissional",
    theme: "Sigilo Profissional do Advogado",
    difficulty: "Média",
    exam: "XXXVIII Exame de Ordem (2023)",
    statement: "Mariana, advogada renomada, é procurada por seu cliente Carlos, que lhe confessa em ambiente reservado a prática de um crime de extorsão que ainda não foi descoberto pelas autoridades. Carlos pede a orientação de Mariana para ocultar o produto do crime. Diante dessa situação, assinale a afirmativa correta de acordo com as normas do Estatuto da Advocacia e o Código de Ética e Disciplina da OAB:",
    options: [
      "Mariana deve denunciar imediatamente o cliente à polícia, uma vez que o sigilo profissional não se aplica em casos de crimes de natureza econômica.",
      "Mariana deve recusar a orientação sobre como ocultar o produto do crime, devendo manter o sigilo sobre a confissão do crime passado praticado pelo cliente, salvo se houver grave risco à vida ou à integridade física de terceiro.",
      "O dever de sigilo cessa por completo com a mera confissão de qualquer ilícito penal, devendo a advogada depor em juízo como testemunha sobre os fatos confessados pelo cliente.",
      "A advogada está obrigada a orientar Carlos sobre a melhor forma de ocultação dos valores, posto que o dever de ampla defesa do cliente ampara qualquer conduta de consultoria."
    ],
    correctIndex: 1,
    explanation: "Conforme o art. 35 a 38 do Código de Ética e Disciplina da OAB, o sigilo profissional é de ordem pública e cessa apenas em circunstâncias excepcionais, como grave ameaça ao direito à vida e à integridade física, ou em legítima defesa do próprio advogado. Mariana não pode orientá-lo a cometer um novo crime (ocultação de valores), mas deve manter absoluto sigilo sobre o crime de extorsão já consumado confessado confidencialmente pelo cliente."
  },
  {
    id: "q-2",
    discipline: "Direito Constitucional",
    theme: "Controle de Constitucionalidade",
    difficulty: "Difícil",
    exam: "XXXVII Exame de Ordem (2023)",
    statement: "Uma lei estadual do Rio de Janeiro promulgada em 2022 disciplinou matéria relativa a trânsito e transporte, estabelecendo regras específicas de segurança para o tráfego de motocicletas em rodovias estaduais. Diante disso, a Associação Nacional de Fabricantes de Veículos propõe ação direta de inconstitucionalidade. Sob o prisma constitucional brasileiro, essa lei estadual é:",
    options: [
      "Inconstitucional, pois invade competência legislativa privativa da União para dispor sobre trânsito e transporte (Art. 22, XI da CF/88).",
      "Constitucional, visto que os Estados possuem competência concorrente para legislar sobre trânsito, transporte e segurança rodoviária de âmbito local.",
      "Constitucional apenas se houver lei federal delegando expressamente essa competência de forma geral a todos os municípios brasileiros.",
      "Inconstitucional meramente por vício formal de iniciativa exclusiva do Governador do Estado, podendo ser convalidada se sancionada sem vetos."
    ],
    correctIndex: 0,
    explanation: "Conforme o artigo 22, inciso XI, da CRFB/88, compete privativamente à União legislar sobre trânsito e transporte. Portanto, lei estadual que verse sobre trânsito, ainda que restrita a rodovias estaduais, viola formalmente a repartição de competências estipulada pela Carta Magna, padecendo de inconstitucionalidade formal orgânica."
  },
  {
    id: "q-3",
    discipline: "Direito Penal",
    theme: "Excludentes de Ilicitude",
    difficulty: "Média",
    exam: "XXXIX Exame de Ordem (2023)",
    statement: "Roberto é atacado ferozmente pelo pitbull de seu vizinho, que escapou devido à negligência do dono. Sem qualquer outra saída para salvar-se da severa agressão do animal, Roberto saca de um pedaço de madeira pesado e desfere um golpe letal na cabeça do cão, matando-o. Do ponto de vista da teoria do crime, o comportamento de Roberto é amparado por:",
    options: [
      "Legítima Defesa, uma vez que houve repulsa a uma agressão atual de terceiro por meio de força proporcional.",
      "Estado de Necessidade, haja vista que Roberto sacrificou o bem jurídico alheio (o cão) para afastar um perigo atual e inevitável não provocado por ele.",
      "Estrito Cumprimento do Dever Legal, já que é dever de todo cidadão proteger sua própria integridade física frente a animais soltos.",
      "Causa de exclusão da tipicidade formal por força da insignificância do objeto jurídico tutelado."
    ],
    correctIndex: 1,
    explanation: "Como o ataque partiu de um animal agindo espontaneamente (mesmo que por desleixo do dono), trata-se de perigo atual que ameaça bem jurídico próprio (vida/integridade), caracterizando o Estado de Necessidade (art. 24, CP). Falar-se-ia em Legítima Defesa se o cão estivesse sendo usado deliberadamente por um ser humano como 'instrumento' de agressão dolosa."
  },
  {
    id: "q-4",
    discipline: "Direito Civil",
    theme: "Prescrição e Decadência",
    difficulty: "Difícil",
    exam: "XXXVI Exame de Ordem (2022)",
    statement: "Com relação às regras gerais de prescrição e decadência dispostas no Código Civil de 2002, assinale a opção juridicamente correta:",
    options: [
      "A prescrição pode ser decretada de ofício pelo magistrado, ao passo que a decadência convencional só pode ser conhecida mediante expressa provocação da parte interessada.",
      "Os prazos prescricionais podem ser alterados de comum acordo pelas partes em contratos de adesão de consumo.",
      "A renúncia da prescrição é válida mesmo antes de consumado o prazo prescricional respectivo.",
      "A prescrição corre normalmente contra os menores de 18 anos incompletos, suspendendo-se apenas quando estes atingirem a idade de 16 anos."
    ],
    correctIndex: 0,
    explanation: "O art. 194 do CC foi revogado e agora o juiz deve pronunciar de ofício a prescrição (Art. 332, § 1º, CPC e Art. 487, II CPC). Ademais, o art. 210 do CC prescreve que o juiz deve conhecer de ofício a decadência estabelecida por lei, mas o art. 211 veda o conhecimento de ofício da decadência convencional (que depende de alegação da parte beneficiada)."
  },
  {
    id: "q-5",
    discipline: "Direito do Trabalho",
    theme: "Equiparação Salarial",
    difficulty: "Média",
    exam: "XXXVIII Exame de Ordem (2023)",
    statement: "João e Pedro trabalham na mesma empresa, exercendo idêntica função com igual produtividade e perfeição técnica. João foi admitido na empresa há 6 anos e exerce a função há 5 anos. Pedro trabalha na empresa há 2 anos e exerce a função há 1 ano. Pedro descobre que João recebe salário 30% maior e aciona o sindicato. Sobre a equiparação salarial, à luz da CLT atualizada:",
    options: [
      "Pedro tem direito à equiparação, pois ambos trabalham na mesma localidade e exercem a mesma função.",
      "Pedro NÃO tem direito à equiparação, pois a diferença de tempo de serviço na função entre João e Pedro é superior a 2 anos (Art. 461, § 1º da CLT).",
      "Pedro tem direito à equiparação desde que a empresa conte com quadro de carreira homologado pelo Ministério do Trabalho.",
      "A equiparação é indevida tão somente se João for empregado portador de diploma de nível superior e Pedro não."
    ],
    correctIndex: 1,
    explanation: "De acordo com o Art. 461, § 1º da CLT, para haver equiparação salarial, o trabalho deve ser de igual valor, prestado ao mesmo empregador, no mesmo estabelecimento. No entanto, obsta a equiparação se a diferença de tempo de serviço na função for superior a dois anos ou a diferença de tempo de contratação na empresa for superior a quatro anos. No caso, João está na função há 5 anos e Pedro há 1 ano (diferença de 4 anos na função), o que impede legalmente a concessão de equiparação salarial."
  }
];

export const FLASHCARDS: Flashcard[] = [
  {
    id: "f-1",
    discipline: "Ética Profissional",
    theme: "Advogado Empregado",
    front: "Qual é a jornada de trabalho semanal máxima do advogado empregado, salvo acordo ou convenção coletiva ou regime de dedicação exclusiva?",
    back: "A jornada máxima é de 4 horas diárias e 20 horas semanais, segundo o art. 20 do Estatuto da Advocacia (EAOAB). No caso de dedicação exclusiva, o limite passa a ser de 8h diárias e 40h semanais.",
    lawArticle: "Art. 20 da Lei 8.906/94"
  },
  {
    id: "f-2",
    discipline: "Direito Constitucional",
    theme: "Legitimados de Ações de Controle",
    front: "Quem são os legitimados universais para propor Ação Direta de Inconstitucionalidade (ADI) que não precisam demonstrar pertinência temática?",
    back: "Presidente da República, Mesa do Senado Federal, Mesa da Câmara dos Deputados, Procurador-Geral da República, Conselho Federal da OAB e Partido Político com representação no Congresso Nacional. Os demais (Mesa de Assembleia, Governador e Confederação Sindical) são legitimados especiais.",
    lawArticle: "Art. 103 da CF/88"
  },
  {
    id: "f-3",
    discipline: "Direito Penal",
    theme: "Tentativa Abandonada",
    front: "Qual é a diferença fundamental entre Desistência Voluntária e Arrependimento Eficaz?",
    back: "Na Desistência Voluntária, o agente interrompe a execução do crime ('posso prosseguir, mas não quero'). No Arrependimento Eficaz, o agente já concluiu os atos executórios, mas age para evitar o resultado consumativo ('fiz tudo, mas evito o efeito'). Ambos excluem o crime inicial, respondendo só pelos atos já praticados.",
    lawArticle: "Art. 15 do Código Penal"
  },
  {
    id: "f-4",
    discipline: "Direito Civil",
    theme: "Bens Públicos",
    front: "Quais são as três categorias de bens públicos quanto à sua destinação e quais deles podem ser alienados?",
    back: "1. Bens de uso comum do povo (rios, praças) - inalienáveis.\n2. Bens de uso especial (prédios de repartições, escolas) - inalienáveis.\n3. Bens dominicais (patrimônio disponível) - alienáveis, observadas as exigências legais.",
    lawArticle: "Arts. 99 e 101 do Código Civil"
  },
  {
    id: "f-5",
    discipline: "Direito do Trabalho",
    theme: "Estabilidade Provisória",
    front: "Qual é o período de estabilidade provisória da empregada gestante e qual a consequência da confirmação da gravidez durante o aviso prévio?",
    back: "A estabilidade vai desde a confirmação da gravidez até 5 meses após o parto. A gravidez ocorrida durante o aviso prévio (trabalhado ou indenizado) garante a reintegração ou indenização substitutiva da empregada.",
    lawArticle: "Art. 10, II, 'b' do ADCT e Art. 391-A da CLT"
  }
];

export const CALENDAR_EVENTS: OABCalendarEvent[] = [
  {
    id: "ev-1",
    title: "Publicação do Edital do XL Exame de Ordem",
    date: "2026-07-10",
    type: "inscricao",
    description: "Divulgação oficial das regras, prazos de isenção de taxa e cronograma definitivo do XL Exame Unificado.",
    isImportant: true
  },
  {
    id: "ev-2",
    title: "Período de Inscrições - XL Exame",
    date: "2026-07-13",
    type: "inscricao",
    description: "Início do prazo para realização de inscrição online no site oficial da FGV Projetos.",
    isImportant: true
  },
  {
    id: "ev-3",
    title: "Aplicação da Prova de 1ª Fase (XL Exame)",
    date: "2026-09-13",
    type: "prova1",
    description: "Prova objetiva com 80 questões de múltipla escolha. Duração de 5 horas. Necessário acertar no mínimo 40 questões para avançar.",
    isImportant: true
  },
  {
    id: "ev-4",
    title: "Gabarito Preliminar & Prazo de Recursos 1ª Fase",
    date: "2026-09-14",
    type: "recurso",
    description: "Divulgação do gabarito oficial preliminar e abertura da janela para envio de recursos contra questões ambíguas ou erradas.",
    isImportant: false
  },
  {
    id: "ev-5",
    title: "Resultado Definitivo da 1ª Fase (XL Exame)",
    date: "2026-10-02",
    type: "prova1",
    description: "Lista oficial de candidatos aprovados aptos a realizarem a prova prático-profissional da 2ª Fase.",
    isImportant: false
  },
  {
    id: "ev-6",
    title: "Aplicação da Prova de 2ª Fase (XL Exame)",
    date: "2026-11-15",
    type: "prova2",
    description: "Prova prático-profissional composta de 1 peça profissional (5,0 pontos) e 4 questões discursivas (1,25 pontos cada). Duração de 5 horas.",
    isImportant: true
  },
  {
    id: "ev-7",
    title: "Resultado Preliminar da 2ª Fase & Recursos",
    date: "2026-12-09",
    type: "recurso",
    description: "Divulgação das notas provisórias das peças e questões discursivas. Prazo para contestação de pontuação de espelho.",
    isImportant: false
  },
  {
    id: "ev-8",
    title: "Resultado Final & Homologação XL Exame",
    date: "2027-01-12",
    type: "outro",
    description: "Publicação da lista definitiva dos novos Advogados e Advogadas inscritos nos quadros da OAB.",
    isImportant: true
  },
  {
    id: "ev-9",
    title: "Abertura do Edital de Reaproveitamento (Repescagem)",
    date: "2026-10-15",
    type: "reaproveitamento",
    description: "Inscrição especial para candidatos aprovados na 1ª fase do XXXIX Exame que foram reprovados na 2ª fase, permitindo pular a 1ª fase do XL Exame.",
    isImportant: true
  }
];

export const SUPPORT_FAQS: SupportFAQ[] = [
  {
    id: "faq-1",
    question: "Como funciona a pontuação mínima para aprovação na 1ª Fase?",
    answer: "A prova de 1ª Fase da OAB é composta de 80 questões de múltipla escolha. Para ser aprovado e avançar para a 2ª Fase, o candidato precisa acertar no mínimo 40 questões (50% de aproveitamento). Não há concorrência ou nota de corte variável: acertou 40, está aprovado.",
    category: "Sobre o Exame"
  },
  {
    id: "faq-2",
    question: "Se eu reprovar na 2ª Fase, preciso fazer a 1ª Fase de novo?",
    answer: "Não imediatamente! Existe o instituto do Reaproveitamento da 1ª Fase (comumente chamado de 'Repescagem'). Você pode se inscrever na repescagem para fazer diretamente a prova de 2ª Fase do exame subsequente. O edital de repescagem é publicado cerca de duas semanas após o resultado preliminar da 2ª fase.",
    category: "Repescagem"
  },
  {
    id: "faq-3",
    question: "Como funciona o sistema de flashcards com repetição espaçada?",
    answer: "O aplicativo utiliza o algoritmo de Leitner para Revisão Inteligente. Cada flashcard respondido avança ou retrocede de 'caixas' (Boxes de 1 a 5). Cartões na caixa 1 são revisados diariamente; caixa 2 a cada 3 dias; caixa 3 semanalmente; e assim por diante. Isso otimiza sua memorização de longo prazo da lei seca.",
    category: "Uso do App"
  },
  {
    id: "faq-4",
    question: "Posso escolher qualquer matéria para a 2ª Fase?",
    answer: "Sim! No momento da inscrição no exame da OAB, você deve indicar uma das 7 áreas jurídicas disponíveis: Direito Administrativo, Direito Constitucional, Direito Civil, Direito do Trabalho, Direito Empresarial, Direito Penal ou Direito Tributário. A prova prática e discursiva será integralmente sobre a área escolhida.",
    category: "Sobre o Exame"
  },
  {
    id: "faq-5",
    question: "O app está atualizado com as últimas leis do Congresso?",
    answer: "Sim! Nossa equipe monitora semanalmente as publicações legislativas. Todas as disciplinas de 1ª Fase e modelos de peças de 2ª Fase estão atualizados conforme a legislação vigente e as principais súmulas dos tribunais superiores (STF, STJ e TST) editadas até o fechamento do edital.",
    category: "Conteúdo"
  }
];

export const SUPPORT_TIPS = [
  "Crie o hábito de resolver ao menos 10 questões de Ética Profissional por dia. São 8 questões na prova (10% do total) com conteúdo relativamente curto.",
  "Na 2ª Fase, o segredo da aprovação é saber manusear o Vade Mecum rapidamente. Pratique encontrar artigos usando o índice alfabético-remissivo.",
  "Durante os simulados, controle rigorosamente o tempo: reserve no máximo 4 horas para responder as questões e 1 hora para preencher o gabarito ou passar as peças a limpo."
];
